/******/ (function(modules) { // webpackBootstrap
/******/ 	// install a JSONP callback for chunk loading
/******/ 	function webpackJsonpCallback(data) {
/******/ 		var chunkIds = data[0];
/******/ 		var moreModules = data[1];
/******/ 		var executeModules = data[2];
/******/
/******/ 		// add "moreModules" to the modules object,
/******/ 		// then flag all "chunkIds" as loaded and fire callback
/******/ 		var moduleId, chunkId, i = 0, resolves = [];
/******/ 		for(;i < chunkIds.length; i++) {
/******/ 			chunkId = chunkIds[i];
/******/ 			if(Object.prototype.hasOwnProperty.call(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 				resolves.push(installedChunks[chunkId][0]);
/******/ 			}
/******/ 			installedChunks[chunkId] = 0;
/******/ 		}
/******/ 		for(moduleId in moreModules) {
/******/ 			if(Object.prototype.hasOwnProperty.call(moreModules, moduleId)) {
/******/ 				modules[moduleId] = moreModules[moduleId];
/******/ 			}
/******/ 		}
/******/ 		if(parentJsonpFunction) parentJsonpFunction(data);
/******/
/******/ 		while(resolves.length) {
/******/ 			resolves.shift()();
/******/ 		}
/******/
/******/ 		// add entry modules from loaded chunk to deferred list
/******/ 		deferredModules.push.apply(deferredModules, executeModules || []);
/******/
/******/ 		// run deferred modules when all chunks ready
/******/ 		return checkDeferredModules();
/******/ 	};
/******/ 	function checkDeferredModules() {
/******/ 		var result;
/******/ 		for(var i = 0; i < deferredModules.length; i++) {
/******/ 			var deferredModule = deferredModules[i];
/******/ 			var fulfilled = true;
/******/ 			for(var j = 1; j < deferredModule.length; j++) {
/******/ 				var depId = deferredModule[j];
/******/ 				if(installedChunks[depId] !== 0) fulfilled = false;
/******/ 			}
/******/ 			if(fulfilled) {
/******/ 				deferredModules.splice(i--, 1);
/******/ 				result = __webpack_require__(__webpack_require__.s = deferredModule[0]);
/******/ 			}
/******/ 		}
/******/
/******/ 		return result;
/******/ 	}
/******/
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// object to store loaded and loading chunks
/******/ 	// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 	// Promise = chunk loading, 0 = chunk loaded
/******/ 	var installedChunks = {
/******/ 		"index": 0
/******/ 	};
/******/
/******/ 	var deferredModules = [];
/******/
/******/ 	// script path function
/******/ 	function jsonpScriptSrc(chunkId) {
/******/ 		return __webpack_require__.p + "js/" + ({"BusinessStatistics~HistorySumRecord~OrganizationIncome":"BusinessStatistics~HistorySumRecord~OrganizationIncome","BusinessStatistics":"BusinessStatistics","HistorySumRecord":"HistorySumRecord","OrganizationIncome":"OrganizationIncome"}[chunkId]||chunkId) + ".js"
/******/ 	}
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/ 	// This file contains only the entry chunk.
/******/ 	// The chunk loading function for additional chunks
/******/ 	__webpack_require__.e = function requireEnsure(chunkId) {
/******/ 		var promises = [];
/******/
/******/
/******/ 		// JSONP chunk loading for javascript
/******/
/******/ 		var installedChunkData = installedChunks[chunkId];
/******/ 		if(installedChunkData !== 0) { // 0 means "already installed".
/******/
/******/ 			// a Promise means "currently loading".
/******/ 			if(installedChunkData) {
/******/ 				promises.push(installedChunkData[2]);
/******/ 			} else {
/******/ 				// setup Promise in chunk cache
/******/ 				var promise = new Promise(function(resolve, reject) {
/******/ 					installedChunkData = installedChunks[chunkId] = [resolve, reject];
/******/ 				});
/******/ 				promises.push(installedChunkData[2] = promise);
/******/
/******/ 				// start chunk loading
/******/ 				var script = document.createElement('script');
/******/ 				var onScriptComplete;
/******/
/******/ 				script.charset = 'utf-8';
/******/ 				script.timeout = 120;
/******/ 				if (__webpack_require__.nc) {
/******/ 					script.setAttribute("nonce", __webpack_require__.nc);
/******/ 				}
/******/ 				script.src = jsonpScriptSrc(chunkId);
/******/
/******/ 				// create error before stack unwound to get useful stacktrace later
/******/ 				var error = new Error();
/******/ 				onScriptComplete = function (event) {
/******/ 					// avoid mem leaks in IE.
/******/ 					script.onerror = script.onload = null;
/******/ 					clearTimeout(timeout);
/******/ 					var chunk = installedChunks[chunkId];
/******/ 					if(chunk !== 0) {
/******/ 						if(chunk) {
/******/ 							var errorType = event && (event.type === 'load' ? 'missing' : event.type);
/******/ 							var realSrc = event && event.target && event.target.src;
/******/ 							error.message = 'Loading chunk ' + chunkId + ' failed.\n(' + errorType + ': ' + realSrc + ')';
/******/ 							error.name = 'ChunkLoadError';
/******/ 							error.type = errorType;
/******/ 							error.request = realSrc;
/******/ 							chunk[1](error);
/******/ 						}
/******/ 						installedChunks[chunkId] = undefined;
/******/ 					}
/******/ 				};
/******/ 				var timeout = setTimeout(function(){
/******/ 					onScriptComplete({ type: 'timeout', target: script });
/******/ 				}, 120000);
/******/ 				script.onerror = script.onload = onScriptComplete;
/******/ 				document.head.appendChild(script);
/******/ 			}
/******/ 		}
/******/ 		return Promise.all(promises);
/******/ 	};
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// on error function for async loading
/******/ 	__webpack_require__.oe = function(err) { console.error(err); throw err; };
/******/
/******/ 	var jsonpArray = window["webpackJsonp"] = window["webpackJsonp"] || [];
/******/ 	var oldJsonpFunction = jsonpArray.push.bind(jsonpArray);
/******/ 	jsonpArray.push = webpackJsonpCallback;
/******/ 	jsonpArray = jsonpArray.slice();
/******/ 	for(var i = 0; i < jsonpArray.length; i++) webpackJsonpCallback(jsonpArray[i]);
/******/ 	var parentJsonpFunction = oldJsonpFunction;
/******/
/******/
/******/ 	// add entry module to deferred list
/******/ 	deferredModules.push([0,"chunk-vendors"]);
/******/ 	// run deferred modules when ready
/******/ 	return checkDeferredModules();
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/App.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--12-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/App.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/s-dialog-normal.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--12-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/s-dialog-normal.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 's-dialog-normal',
  props: {
    config: {
      type: Object,
      default: function _default() {
        return {
          dialogVisible: false,
          //弹窗开关
          width: '35%',
          //弹窗相对于屏幕的宽度
          title: '默认',
          //弹窗标题
          buttonPosition: 'flex-end',
          //按钮内容的位置
          ismodal: true,
          //是否需要遮罩黑幕层
          modalClose: false //点击遮罩层是否可以关闭弹窗
          // Button:[{
          //     name:'默认',
          //     methods:''
          // },{
          //     name:'默认',
          //     methods:''
          // }]

        };
      }
    }
  },
  methods: {
    handleButtonClick: function handleButtonClick(methods) {
      //  this.config.dialogVisible = false //组件内的两个按钮设置的关闭弹窗
      if (!methods || !this.$parent[methods]) return;
      this.$parent[methods]();
    },
    handleClose: function handleClose() {
      this.$emit('modelClose');
      this.config.dialogVisible = false;
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/s-table-result.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--12-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/s-table-result.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);



//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 's-table-result',
  props: {
    config: {
      type: Object,
      default: function _default() {
        return {
          pVue: null,
          height: 180,
          // table高度
          select: false,
          // 是否可以多选
          isSingleSelect: false,
          //是否可以单选
          isCommands: true,
          //是否需要操作列
          showPagenation: true,
          //是否需要显示分页器
          layout: 'total,sizes, prev, pager, next, jumper',
          //分页器控件
          requestCurData: false,
          // 每次分页数据是否请求后台 true:每次都请求后台
          columns: [],
          // 后台字段属性、表头名、颜色、长度、是否过长隐藏、是否需要字符转换、
          // table行按钮：span width
          commandsWidth: '50',
          //操作列宽度
          commands: [] // table行按钮：color 文字 处理点击的事件函数名  elementUicon

        };
      }
    },
    optionData: {
      type: Object,
      default: function _default() {
        return {
          currentTableData: [],
          //当前表格数据
          TransValtoDesc: null,
          //数据字典函数
          selectData: '',
          //页面的单选函数
          selectDatas: '',
          //页面的多选函数
          sizesCtrl: [5, 10, 20, 30, 40, 50, 100],
          //分页器控件的长度控制器
          pageSize: 5,
          // 每页行数
          currentPage: 1,
          // 当前页
          total: 0,
          //总数据量
          pagenationChange: '' //页面的处理分页器长度改变或页码改变的函数

        };
      }
    },
    buttonIsFilter: {
      type: Boolean,
      default: false
    },
    // todo 需要展示的按钮
    needButton: {
      type: Object,
      default: function _default() {
        return {
          field: '',
          controlShow: [],
          button: []
        };
      }
    }
  },
  data: function data() {
    return {
      rowData: null,
      radio: '',
      total: 0,
      // 总行数
      currentData: [],
      // 当前table显示的数据
      allData: [],
      // 全部的数据
      selection: [],
      // 保存选择的数组
      flag: 0
    };
  },
  filters: {
    colorfilter: function colorfilter(val) {
      switch (val) {
        case '指定':
          return 'val-primary';
          break;

        case '已上架':
          return 'val-primary';
          break;

        case '已下架':
          return 'val-danger';
          break;

        case '是':
          return 'val-primary';
          break;

        case '否':
          return 'val-danger';
          break;

        case '有效':
          return 'val-primary';
          break;

        case '无效':
          return 'val-danger';
          break;

        case '启用':
          return 'val-primary';
          break;

        case '禁用':
          return 'val-danger';
          break;

        case '代理人':
          return 'val-primary';
          break;
      }
    }
  },
  methods: {
    // todo 控制是否展示条件中的按钮
    isShowButton: function isShowButton(scope, name) {
      if (this.buttonIsFilter === false) return true;

      if (this.buttonIsFilter === true) {
        var value = scope.row[this.needButton.field];
        var isShowArr = this.needButton.controlShow;
        var buttonArr = this.needButton.button;
        var a = isShowArr.findIndex(function (item) {
          return item === value;
        });

        if (a === -1) {
          return true;
        } else if (a > -1) {
          var b = buttonArr.findIndex(function (item) {
            return item === name;
          });
          return b > -1;
        }
      }
    },
    handleRowClick: function handleRowClick(methods) {
      var _this = this;

      //处理列表内容row的点击
      // todo
      this.$nextTick(function () {
        if (!methods) return false;

        var currentComponents = _this.checkHandle(_this.$parent, methods);

        if (!currentComponents[methods]) {
          throw Error("".concat(methods, "\u65B9\u6CD5\u6CA1\u6709\u5728\u9875\u9762\u4E2D\u5B9A\u4E49"));
        } else {
          currentComponents[methods](_this.rowData);
        }
      });
    },
    handleSingleSelect: function handleSingleSelect(currentRow, oldCurrentRow) {
      //处理单选点击
      if (!this.config.isSingleSelect) return false;
      this.$refs.multipleTable.setCurrentRow(currentRow);
      this.radio = currentRow._seqno;

      if (this.optionData.selectData) {
        console.log(this.optionData.selectData, 'this.optionData.selectData');
        console.log(this.$parent, 'this.$parent[this.optionData.selectData]');

        if (!this.$parent[this.optionData.selectData]) {
          throw Error("\u9875\u9762\u7684methods\u4E2D\u7F3A\u5C11".concat(this.optionData.selectData, "\u65B9\u6CD5"));
        } else {
          this.$parent[this.optionData.selectData]({
            currentRow: currentRow,
            oldCurrentRow: oldCurrentRow
          });
        }
      } else {
        throw Error('请在optionData中声明selectData方法');
      }
    },
    handleClick: function handleClick(row, column, cell, event) {
      //任何区域的点击都可以触发
      // console.log(row);
      if (this.$parent.handleSresultTableClick) {
        this.$parent.handleSresultTableClick(row, column, cell, event);
      } else {
        return false;
      }
    },
    // todo 2
    handleOpreate: function handleOpreate(value) {
      //处理操作点击
      if (!value) return;
      var component = this.checkHandle(this.$parent, value);
      component[value](this.rowData);
    },
    handleSizeChange: function handleSizeChange(val) {
      //处理分页器长度改变
      // console.log(`每页 ${val} 条`);
      this.optionData.pageSize = val;
      this.preTableData();
    },
    handleCurrentChange: function handleCurrentChange(val) {
      //处理页码改变
      console.log("\u5F53\u524D\u9875: ".concat(val));
      this.optionData.currentPage = val;
      this.preTableData();
    },
    preTableData: function preTableData() {
      //
      if (!this.config.requestCurData) {
        //如果每次点击分页都不需要请求后台的话
        this.showTableData();
        return;
      }

      var maxnum = Math.ceil(this.optionData.total / this.optionData.pageSize); //计算出最大页码数量

      this.optionData.currentPage = this.optionData.currentPage > maxnum ? maxnum : this.optionData.currentPage; // todo 1

      if (this.optionData.pagenationChange) {
        var methodName = this.optionData.pagenationChange;
        var currentComponents = this.checkHandle(this.$parent, methodName);
        currentComponents[this.optionData.pagenationChange](this.optionData.currentPage, this.optionData.pageSize);
      } else {
        throw Error('optionData中缺少pagenationChange函数');
      }
    },
    showTableData: function showTableData(ptotal) {
      //接受的形参是总数据的数量
      this.selection = []; // 清空多选框的选项

      var cdata = [];

      if (this.config.showPagenation == false) {
        // 不分页，那么就在一页显示所有内容
        for (var i = 0; i < this.allData.length; i++) {
          this.allData[i]._seqno = i;
          cdata.push(this.allData[i]);
        }
      } else if (!this.config.requestCurData) {
        //如果每次点击分页都不需要请求后台,则根据页面长度计算出页码
        this.optionData.total = this.allData.length;
        var page = this.optionData.currentPage;
        var pageSize = this.optionData.pageSize;
        var start = (page - 1) * pageSize;
        var len = this.optionData.total - pageSize * (page - 1) < pageSize ? this.optionData.total - pageSize * (page - 1) : pageSize;

        for (var _i = start; _i < len + start; _i++) {
          this.allData[_i]._seqno = _i;
          cdata.push(this.allData[_i]);
        }
      } else {
        this.optionData.total = ptotal ? ptotal : this.optionData.total; //将总条目数转给组件

        for (var _i2 = 0; _i2 < this.allData.length; _i2++) {
          this.allData[_i2]._seqno = _i2;
          cdata.push(this.allData[_i2]);
        }
      }

      this.currentData = cdata;
    },
    handleSelectionChange: function handleSelectionChange(selection) {
      var _this2 = this;

      this.$nextTick(function () {
        if (!_this2.config.select) return false;

        if (_this2.optionData.selectDatas) {
          var current = _this2.checkHandle(_this2.$parent, _this2.optionData.selectDatas);

          current[_this2.optionData.selectDatas](selection);
        } else {
          throw Error('请在optionData中声明selectDatas方法');
        }
      }); // this.selection = selection;
      // console.log('this.selection', this.selection);
    },
    handleHover: function handleHover(row, column, cell, event) {
      this.rowData = row; // if (this.$parent.handleSresultTableHover) {
      //     this.$parent.handleSresultTableHover(row, column, cell, event);
      // } else {
      //     console.log(
      //         '期待使用本组件的页面中存在handleSresultTableHover函数，页面不存在此函数，此处调用的是组件中点击处理函数'
      //     );
      //     console.log(row, column, cell, event);
      // }
    },
    handleLeave: function handleLeave(row, column, cell, event) {//  if (this.$parent.handleSresultTableLeave) {
      //     this.$parent.handleSresultTableLeave(row, column, cell, event);
      // } else {
      //     console.log(
      //         '期待使用本组件的页面中存在handleSresultTableLeave函数，页面不存在此函数，此处调用的是组件中点击处理函数'
      //     );
      //     console.log(row, column, cell, event);
      // }
    },
    TransValtoDesc: function TransValtoDesc(id, val, item) {
      // 处理需要转换字段的列
      var ret = val;
      var methods = this.optionData.TransValtoDesc;

      if (!methods) {
        throw Error('请在option.TransValtoDesc中声明数据字典转换函数');
      }

      var currentComponents = this.checkHandle(this.$parent, methods);
      ret = currentComponents[methods](id, val, item);
      return ret || val;
    },
    //todo  检查当前页面中是否含有过滤函数，最多三层
    checkHandle: function checkHandle(currentComponents, methods) {
      for (var i = 0; i < 3; i++) {
        if (!currentComponents[methods]) {
          currentComponents = currentComponents.$parent;
        } else if (currentComponents[methods]) {
          return currentComponents;
        } else {
          throw Error('页面缺少数据字典转换函数，请在methods中定义');
        }
      }
    },
    removeRow: function removeRow(row) {
      var seqno = row._seqno;
      this.allData.splice(seqno, 1);
      console.log(this.allData);

      if (this.allData.length == 0) {
        //如果这一页没有数据了则请求上一页数据
        this.optionData.currentPage -= 1;
        this.handleCurrentChange(this.optionData.currentPage);
      }
    },
    removeRowArray: function removeRowArray(rows) {
      for (var i = 0; i < rows.length; i++) {
        var seqno = rows[i]._seqno;
        this.allData.splice(seqno, 1);
      }

      if (this.allData.length == 0) {
        //如果这一页没有数据了则请求上一页数据
        this.optionData.currentPage -= 1;
        this.handleCurrentChange(this.optionData.currentPage);
      }
    },
    addRow: function addRow(row, id) {
      this.allData.push(row);
      if (id) this.allData = this.unique(this.allData, id);
      this.showTableData();
    },
    addRowArray: function addRowArray(rows, id) {
      this.allData = this.allData.concat(rows);
      if (id) this.allData = this.unique(this.allData, id);
      this.showTableData();
    },
    unique: function unique(arr, name) {
      var hash = {};
      return arr.reduce(function (item, next) {
        hash[next[name]] ? '' : hash[next[name]] =  true && item.push(next);
        return item;
      }, []);
    }
  },
  watch: {
    //监测表格数据的变化
    'optionData.currentTableData': function optionDataCurrentTableData(val) {
      this.allData = val; // console.log(this.allData,"allData");

      this.showTableData();
    }
  },
  mounted: function mounted() {
    if (this.config.pVue) {
      this.$parent = this.config.pVue;
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"b9734f90-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/App.vue?vue&type=template&id=7ba5bd90&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"b9734f90-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/App.vue?vue&type=template&id=7ba5bd90& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "fillcontain", attrs: { id: "app" } },
    [_c("router-view")],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"b9734f90-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/s-dialog-normal.vue?vue&type=template&id=5ebdee52&scoped=true&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"b9734f90-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/s-dialog-normal.vue?vue&type=template&id=5ebdee52&scoped=true& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "el-dialog",
    {
      attrs: {
        "close-on-press-escape": false,
        title: _vm.config.title,
        "before-close": _vm.handleClose,
        visible: _vm.config.dialogVisible,
        width: _vm.config.width,
        modal: _vm.config.ismodal,
        "show-close": true,
        "close-on-click-modal": _vm.config.modalClose
      },
      on: {
        "update:visible": function($event) {
          return _vm.$set(_vm.config, "dialogVisible", $event)
        }
      }
    },
    [
      _c("div", { staticClass: "slot-wrap" }, [
        _c("div", [_vm._t("default")], 2),
        _c(
          "div",
          {
            staticClass: "dialog-footer_button",
            style: { justifyContent: _vm.config.buttonPosition }
          },
          [
            _vm._l(_vm.config.Button, function(item, index) {
              return [
                _c(
                  "el-button",
                  {
                    key: index,
                    attrs: { type: _vm.config.Button[index].type },
                    on: {
                      click: function($event) {
                        return _vm.handleButtonClick(
                          _vm.config.Button[index].methods
                        )
                      }
                    }
                  },
                  [_vm._v(" " + _vm._s(_vm.config.Button[index].name) + " ")]
                )
              ]
            })
          ],
          2
        )
      ])
    ]
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"b9734f90-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/s-table-result.vue?vue&type=template&id=37877db4&scoped=true&":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"b9734f90-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/s-table-result.vue?vue&type=template&id=37877db4&scoped=true& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c(
      "div",
      { staticClass: "table-info" },
      [
        _c(
          "el-table",
          {
            ref: "multipleTable",
            staticStyle: { width: "100%" },
            attrs: {
              data: _vm.currentData,
              height: _vm.config.height,
              "highlight-current-row": _vm.config.isSingleSelect,
              border: "",
              "tooltip-effect": "dark"
            },
            on: {
              "cell-mouse-enter": _vm.handleHover,
              "cell-mouse-leave": _vm.handleLeave,
              "cell-click": _vm.handleClick,
              "selection-change": _vm.handleSelectionChange,
              "current-change": _vm.handleSingleSelect
            }
          },
          [
            _vm.config.select
              ? _c("el-table-column", {
                  attrs: {
                    align: "center",
                    "header-align": "center",
                    type: "selection",
                    width: "70"
                  }
                })
              : _vm._e(),
            _vm.config.isSingleSelect
              ? _c("el-table-column", {
                  attrs: {
                    align: "center",
                    "header-align": "center",
                    label: "选择",
                    width: "70"
                  },
                  scopedSlots: _vm._u(
                    [
                      {
                        key: "default",
                        fn: function(scope) {
                          return [
                            _c(
                              "el-radio",
                              {
                                attrs: { label: scope.$index },
                                model: {
                                  value: _vm.radio,
                                  callback: function($$v) {
                                    _vm.radio = $$v
                                  },
                                  expression: "radio"
                                }
                              },
                              [_vm._v(_vm._s(""))]
                            )
                          ]
                        }
                      }
                    ],
                    null,
                    false,
                    152931958
                  )
                })
              : _vm._e(),
            _vm.config.isOrder
              ? _c("el-table-column", {
                  attrs: {
                    align: "center",
                    "header-align": "center",
                    label: "序号",
                    width: "70"
                  },
                  scopedSlots: _vm._u(
                    [
                      {
                        key: "default",
                        fn: function(scope) {
                          return [_vm._v(" " + _vm._s(scope.$index + 1) + " ")]
                        }
                      }
                    ],
                    null,
                    false,
                    3056706777
                  )
                })
              : _vm._e(),
            _vm._l(_vm.config.columns, function(column, index) {
              return _c("el-table-column", {
                key: index,
                attrs: {
                  label: column[1],
                  prop: column[0],
                  width: column[2],
                  align: "center",
                  "header-align": "center"
                },
                scopedSlots: _vm._u(
                  [
                    {
                      key: "default",
                      fn: function(scope) {
                        return [
                          column[7]
                            ? _c("img", {
                                staticClass: "coverImage",
                                attrs: { src: scope.row.img, alt: "图片显示" }
                              })
                            : column[5]
                            ? _c(
                                "span",
                                {
                                  class: _vm._f("colorfilter")(
                                    _vm.TransValtoDesc(
                                      column[0],
                                      scope.row[column[0]],
                                      scope.row
                                    )
                                  ),
                                  style: {
                                    color: column[3],
                                    cursor: column[6] ? "pointer" : "normal"
                                  },
                                  on: {
                                    click: function($event) {
                                      $event.stopPropagation()
                                      return _vm.handleRowClick(column[6])
                                    }
                                  }
                                },
                                [
                                  _vm._v(
                                    " " +
                                      _vm._s(
                                        _vm.TransValtoDesc(
                                          column[0],
                                          scope.row[column[0]],
                                          scope.row
                                        )
                                      ) +
                                      " "
                                  )
                                ]
                              )
                            : _c(
                                "span",
                                {
                                  style: {
                                    color: column[3],
                                    cursor: column[6] ? "pointer" : "normal"
                                  },
                                  on: {
                                    click: function($event) {
                                      $event.stopPropagation()
                                      return _vm.handleRowClick(column[6])
                                    }
                                  }
                                },
                                [
                                  _vm._v(
                                    " " + _vm._s(scope.row[column[0]]) + " "
                                  )
                                ]
                              )
                        ]
                      }
                    }
                  ],
                  null,
                  true
                )
              })
            }),
            _vm.config.isCommands
              ? _c("el-table-column", {
                  attrs: {
                    fixed: _vm.config.fixed,
                    width: _vm.config.commandsWidth,
                    align: "center",
                    "header-align": "center",
                    label: "操作"
                  },
                  scopedSlots: _vm._u(
                    [
                      {
                        key: "default",
                        fn: function(scope) {
                          return [
                            _c(
                              "div",
                              { staticClass: "commands-style" },
                              _vm._l(_vm.config.commands, function(
                                column,
                                index
                              ) {
                                return _c(
                                  "span",
                                  {
                                    directives: [
                                      {
                                        name: "show",
                                        rawName: "v-show",
                                        value: _vm.isShowButton(
                                          scope,
                                          column[1]
                                        ),
                                        expression:
                                          "isShowButton(scope, column[1])"
                                      }
                                    ],
                                    key: index,
                                    staticClass: "links",
                                    style: { color: column[0] },
                                    on: {
                                      click: function($event) {
                                        $event.stopPropagation()
                                        return _vm.handleOpreate(column[2])
                                      }
                                    }
                                  },
                                  [
                                    column[3]
                                      ? _c("i", { class: column[3] })
                                      : _vm._e(),
                                    _vm._v(" " + _vm._s(column[1]) + " ")
                                  ]
                                )
                              }),
                              0
                            )
                          ]
                        }
                      }
                    ],
                    null,
                    false,
                    2684809223
                  )
                })
              : _vm._e()
          ],
          2
        )
      ],
      1
    ),
    _vm.config.showPagenation
      ? _c(
          "div",
          { staticClass: "pagination" },
          [
            _c("el-pagination", {
              attrs: {
                "current-page": _vm.optionData.currentPage,
                layout: _vm.config.layout,
                "page-size": _vm.optionData.pageSize,
                "page-sizes": _vm.optionData.sizesCtrl,
                total: _vm.optionData.total,
                background: ""
              },
              on: {
                "size-change": _vm.handleSizeChange,
                "current-change": _vm.handleCurrentChange
              }
            }),
            _vm._t("default")
          ],
          2
        )
      : _vm._e()
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/s-dialog-normal.vue?vue&type=style&index=0&id=5ebdee52&lang=less&scoped=true&":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--10-oneOf-1-2!./node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/s-dialog-normal.vue?vue&type=style&index=0&id=5ebdee52&lang=less&scoped=true& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".slot-wrap .dialog-footer_button[data-v-5ebdee52] {\n  margin-top: 20px;\n  display: flex;\n}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/s-table-result.vue?vue&type=style&index=0&id=37877db4&lang=less&scoped=true&":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--10-oneOf-1-2!./node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/s-table-result.vue?vue&type=style&index=0&id=37877db4&lang=less&scoped=true& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "\n[data-v-37877db4] .el-table {\n  min-width: 702px !important;\n}\n.table-info[data-v-37877db4] {\n  width: 100%;\n  overflow: auto;\n  height: 100%;\n}\n.table-info[data-v-37877db4] .el-table td {\n  padding: 10px 0;\n}\n.table-info .links[data-v-37877db4] {\n  color: #409eff;\n  cursor: pointer;\n}\n.table-info .links[data-v-37877db4]:hover {\n  text-decoration: underline;\n}\n.pagination[data-v-37877db4] {\n  text-align: center;\n  margin-bottom: 10px;\n}\n.commands-style[data-v-37877db4] {\n  display: flex;\n  flex-flow: row nowrap;\n  justify-content: space-around;\n  text-align: center;\n}\n.val-primary[data-v-37877db4] {\n  color: #409eff;\n}\n.val-danger[data-v-37877db4] {\n  color: #ff5600;\n}\n.coverImage[data-v-37877db4] {\n  width: 60px;\n  height: 80px;\n}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/App.vue?vue&type=style&index=0&lang=scss&":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--8-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--8-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--8-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/App.vue?vue&type=style&index=0&lang=scss& ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "body,\ndiv,\nspan,\nheader,\nfooter,\nnav,\nsection,\naside,\narticle,\nul,\ndl,\ndt,\ndd,\nli,\na,\np,\nh1,\nh2,\nh3,\nh4,\nh5,\nh6,\ni,\nb,\ntextarea,\nbutton,\ninput,\nselect,\nfigure,\nfigcaption {\n  padding: 0;\n  margin: 0;\n  list-style: none;\n  font-style: normal;\n  text-decoration: none;\n  border: none;\n  font-family: \"Microsoft Yahei\", sans-serif;\n  -webkit-tap-highlight-color: transparent;\n  -webkit-font-smoothing: antialiased;\n}\nbody:focus,\ndiv:focus,\nspan:focus,\nheader:focus,\nfooter:focus,\nnav:focus,\nsection:focus,\naside:focus,\narticle:focus,\nul:focus,\ndl:focus,\ndt:focus,\ndd:focus,\nli:focus,\na:focus,\np:focus,\nh1:focus,\nh2:focus,\nh3:focus,\nh4:focus,\nh5:focus,\nh6:focus,\ni:focus,\nb:focus,\ntextarea:focus,\nbutton:focus,\ninput:focus,\nselect:focus,\nfigure:focus,\nfigcaption:focus {\n  outline: none;\n}\ninput[type=button],\ninput[type=submit],\ninput[type=search],\ninput[type=reset] {\n  -webkit-appearance: none;\n}\ntextarea {\n  -webkit-appearance: none;\n}\nhtml,\nbody {\n  height: 100%;\n  width: 100%;\n}\n.fillcontain {\n  height: 100%;\n  width: 100%;\n}\n.clear:after {\n  content: \"\";\n  display: block;\n  clear: both;\n}\n.clear {\n  zoom: 1;\n}\n.back_img {\n  background-repeat: no-repeat;\n  background-size: 100% 100%;\n}\n.margin {\n  margin: 0 auto;\n}\n.left {\n  float: left;\n}\n.right {\n  float: right;\n}\n.hide {\n  display: none;\n}\n.show {\n  display: block;\n}\n.ellipsis {\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n.text-editor .w-e-toolbar {\n  border: 1px solid #eeeeee;\n}\n.text-editor .w-e-text-container {\n  border: 1px solid #eeeeee;\n  height: 300px;\n}\n*::-webkit-scrollbar {\n  width: 0.5em;\n  height: 0.6em;\n}\n*::-webkit-scrollbar-track {\n  background-color: #eee;\n}\n*::-webkit-scrollbar-thumb {\n  border-radius: 50px;\n  background-color: rgba(0, 0, 0, 0.3);\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/s-dialog-normal.vue?vue&type=style&index=0&id=5ebdee52&lang=less&scoped=true&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--10-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--10-oneOf-1-2!./node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/s-dialog-normal.vue?vue&type=style&index=0&id=5ebdee52&lang=less&scoped=true& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../node_modules/postcss-loader/src??ref--10-oneOf-1-2!../../node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../node_modules/vue-loader/lib??vue-loader-options!./s-dialog-normal.vue?vue&type=style&index=0&id=5ebdee52&lang=less&scoped=true& */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/s-dialog-normal.vue?vue&type=style&index=0&id=5ebdee52&lang=less&scoped=true&");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("17483459", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/s-table-result.vue?vue&type=style&index=0&id=37877db4&lang=less&scoped=true&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--10-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--10-oneOf-1-2!./node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/s-table-result.vue?vue&type=style&index=0&id=37877db4&lang=less&scoped=true& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../node_modules/postcss-loader/src??ref--10-oneOf-1-2!../../node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../node_modules/vue-loader/lib??vue-loader-options!./s-table-result.vue?vue&type=style&index=0&id=37877db4&lang=less&scoped=true& */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/s-table-result.vue?vue&type=style&index=0&id=37877db4&lang=less&scoped=true&");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("94ef36ac", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/App.vue?vue&type=style&index=0&lang=scss&":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--8-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--8-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--8-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--8-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/App.vue?vue&type=style&index=0&lang=scss& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../node_modules/css-loader/dist/cjs.js??ref--8-oneOf-1-1!../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../node_modules/postcss-loader/src??ref--8-oneOf-1-2!../node_modules/sass-loader/dist/cjs.js??ref--8-oneOf-1-3!../node_modules/cache-loader/dist/cjs.js??ref--0-0!../node_modules/vue-loader/lib??vue-loader-options!./App.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/App.vue?vue&type=style&index=0&lang=scss&");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("6f033d23", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/App.vue":
/*!*********************!*\
  !*** ./src/App.vue ***!
  \*********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _App_vue_vue_type_template_id_7ba5bd90___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./App.vue?vue&type=template&id=7ba5bd90& */ "./src/App.vue?vue&type=template&id=7ba5bd90&");
/* harmony import */ var _App_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./App.vue?vue&type=script&lang=js& */ "./src/App.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _App_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./App.vue?vue&type=style&index=0&lang=scss& */ "./src/App.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _App_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _App_vue_vue_type_template_id_7ba5bd90___WEBPACK_IMPORTED_MODULE_0__["render"],
  _App_vue_vue_type_template_id_7ba5bd90___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/App.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/App.vue?vue&type=script&lang=js&":
/*!**********************************************!*\
  !*** ./src/App.vue?vue&type=script&lang=js& ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_12_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../node_modules/cache-loader/dist/cjs.js??ref--12-0!../node_modules/babel-loader/lib!../node_modules/cache-loader/dist/cjs.js??ref--0-0!../node_modules/vue-loader/lib??vue-loader-options!./App.vue?vue&type=script&lang=js& */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/App.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_12_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/App.vue?vue&type=style&index=0&lang=scss&":
/*!*******************************************************!*\
  !*** ./src/App.vue?vue&type=style&index=0&lang=scss& ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_8_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_8_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../node_modules/vue-style-loader??ref--8-oneOf-1-0!../node_modules/css-loader/dist/cjs.js??ref--8-oneOf-1-1!../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../node_modules/postcss-loader/src??ref--8-oneOf-1-2!../node_modules/sass-loader/dist/cjs.js??ref--8-oneOf-1-3!../node_modules/cache-loader/dist/cjs.js??ref--0-0!../node_modules/vue-loader/lib??vue-loader-options!./App.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/App.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_8_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_8_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_8_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_8_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_8_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_8_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_8_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_8_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/App.vue?vue&type=template&id=7ba5bd90&":
/*!****************************************************!*\
  !*** ./src/App.vue?vue&type=template&id=7ba5bd90& ***!
  \****************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_template_id_7ba5bd90___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"b9734f90-vue-loader-template"}!../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../node_modules/cache-loader/dist/cjs.js??ref--0-0!../node_modules/vue-loader/lib??vue-loader-options!./App.vue?vue&type=template&id=7ba5bd90& */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"b9734f90-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/App.vue?vue&type=template&id=7ba5bd90&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_template_id_7ba5bd90___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_template_id_7ba5bd90___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/common/mixinWares.js":
/*!**********************************!*\
  !*** ./src/common/mixinWares.js ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_s_table_result_vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/components/s-table-result.vue */ "./src/components/s-table-result.vue");
/* harmony import */ var _components_s_dialog_normal_vue__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/components/s-dialog-normal.vue */ "./src/components/s-dialog-normal.vue");




//超级混入 组件 公共方法  所有组件共用的东西都在这个页面

 //弹窗封装混入

/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      menuId: '',
      userId: '',
      pageButtons: {//页面button
      },
      tableButtons: [] //表格button

    };
  },
  methods: {
    confirm: function confirm(txt, title, handleCancel) {
      var _this = this;

      //带确认和取消的提示信息弹框
      return new Promise(function (resolve, reject) {
        _this.$confirm(txt, title, {
          dangerouslyUseHTMLString: true,
          // 必填
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          roundButton: true,
          // 必填
          type: 'info',
          // 必填
          customClass: 'infoBox',
          //控制这个弹窗的类名
          center: true,
          showClose: false
        }).then(function () {
          resolve();
        }, function () {
          handleCancel ? reject() : null;
        });
      });
    },
    warning: function warning(txt, title, handleCancel) {
      var _this2 = this;

      //警告提示框
      return new Promise(function (resolve, reject) {
        _this2.$confirm(txt, title, {
          dangerouslyUseHTMLString: true,
          // 必填
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          roundButton: true,
          // 必填
          type: 'warning',
          // 必填
          customClass: 'warningBox',
          //控制这个弹窗的类名
          center: true,
          showClose: false
        }).then(function () {
          resolve();
        }, function () {
          handleCancel ? reject() : null;
        });
      });
    },
    alert: function alert(txt, title, type) {
      var _this3 = this;

      //只带一个确定的弹框
      var styleinfo = {
        dangerouslyUseHTMLString: true,
        // 必填
        confirmButtonText: '确定',
        roundButton: true,
        // 必填
        customClass: 'alertBox',
        //必填
        center: true,
        showClose: false
      };
      if (title) styleinfo.type = type ? type : 'error'; // error-错误  success-成功

      return new Promise(function (resolve, reject) {
        _this3.$alert(txt, title, styleinfo).then(function () {
          resolve();
        });
      });
    },
    success: function success(txt) {
      var _this4 = this;

      //成功提示框
      var styleinfo = {
        dangerouslyUseHTMLString: true,
        // 必填
        confirmButtonText: '确定',
        roundButton: true,
        // 必填
        customClass: 'successBox',
        //必填
        type: 'success',
        center: true,
        showClose: false
      };
      return new Promise(function (resolve, reject) {
        _this4.$alert(txt, '信息', styleinfo).then(function () {
          resolve();
        });
      });
    },
    fail: function fail(txt) {
      var _this5 = this;

      //失败提示框
      var styleinfo = {
        dangerouslyUseHTMLString: true,
        // 必填
        confirmButtonText: '确定',
        roundButton: true,
        // 必填
        // customClass: "picc-message-box", //必填
        type: 'error',
        center: true,
        showClose: false
      };
      return new Promise(function (resolve, reject) {
        _this5.$alert(txt, '错误', styleinfo).then(function () {
          resolve();
        });
      });
    },
    OPTIONinit: function OPTIONinit() {
      var _this6 = this;

      //页面权限初始化
      var OPTION = JSON.parse(sessionStorage.getItem('OPTION'));

      if (!OPTION) {
        this.$router.replace('/').catch(function (err) {
          return err;
        });
        return false;
      }

      this.pageButtons = OPTION.pageButtons;
      this.tableButtons = OPTION.tableButtons;
      if (!this.commands) return false; //健壮性代码，如果页面不存在commands数据则停止执行

      var commands = this.commands || [];
      var tableCommands = [];
      commands.forEach(function (item, index) {
        //双重foreach循环取权限
        _this6.tableButtons.forEach(function (citem, index) {
          if (citem === item[4]) {
            tableCommands.push(item);
          }
        });
      });
      this.tbConfig.commands = tableCommands; //将拥有的权限赋给页面的表格配置项

      this.tbConfig.commandsWidth = tableCommands.length * 90;

      if (tableCommands.length === 0) {
        //没取到任何权限则代表不需要操作列
        this.tbConfig.isCommands = false; //关闭表格操作列配置项
      }
    }
  },
  components: {
    stable: _components_s_table_result_vue__WEBPACK_IMPORTED_MODULE_4__["default"],
    sdialog: _components_s_dialog_normal_vue__WEBPACK_IMPORTED_MODULE_5__["default"]
  },
  mounted: function mounted() {
    this.OPTIONinit();
  }
});

/***/ }),

/***/ "./src/components/s-dialog-normal.vue":
/*!********************************************!*\
  !*** ./src/components/s-dialog-normal.vue ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _s_dialog_normal_vue_vue_type_template_id_5ebdee52_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./s-dialog-normal.vue?vue&type=template&id=5ebdee52&scoped=true& */ "./src/components/s-dialog-normal.vue?vue&type=template&id=5ebdee52&scoped=true&");
/* harmony import */ var _s_dialog_normal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./s-dialog-normal.vue?vue&type=script&lang=js& */ "./src/components/s-dialog-normal.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _s_dialog_normal_vue_vue_type_style_index_0_id_5ebdee52_lang_less_scoped_true___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./s-dialog-normal.vue?vue&type=style&index=0&id=5ebdee52&lang=less&scoped=true& */ "./src/components/s-dialog-normal.vue?vue&type=style&index=0&id=5ebdee52&lang=less&scoped=true&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _s_dialog_normal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _s_dialog_normal_vue_vue_type_template_id_5ebdee52_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _s_dialog_normal_vue_vue_type_template_id_5ebdee52_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "5ebdee52",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/s-dialog-normal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/s-dialog-normal.vue?vue&type=script&lang=js&":
/*!*********************************************************************!*\
  !*** ./src/components/s-dialog-normal.vue?vue&type=script&lang=js& ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_12_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_s_dialog_normal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/cache-loader/dist/cjs.js??ref--12-0!../../node_modules/babel-loader/lib!../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../node_modules/vue-loader/lib??vue-loader-options!./s-dialog-normal.vue?vue&type=script&lang=js& */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/s-dialog-normal.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_12_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_s_dialog_normal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/s-dialog-normal.vue?vue&type=style&index=0&id=5ebdee52&lang=less&scoped=true&":
/*!******************************************************************************************************!*\
  !*** ./src/components/s-dialog-normal.vue?vue&type=style&index=0&id=5ebdee52&lang=less&scoped=true& ***!
  \******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_s_dialog_normal_vue_vue_type_style_index_0_id_5ebdee52_lang_less_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/vue-style-loader??ref--10-oneOf-1-0!../../node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../node_modules/postcss-loader/src??ref--10-oneOf-1-2!../../node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../node_modules/vue-loader/lib??vue-loader-options!./s-dialog-normal.vue?vue&type=style&index=0&id=5ebdee52&lang=less&scoped=true& */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/s-dialog-normal.vue?vue&type=style&index=0&id=5ebdee52&lang=less&scoped=true&");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_s_dialog_normal_vue_vue_type_style_index_0_id_5ebdee52_lang_less_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_s_dialog_normal_vue_vue_type_style_index_0_id_5ebdee52_lang_less_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_s_dialog_normal_vue_vue_type_style_index_0_id_5ebdee52_lang_less_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_s_dialog_normal_vue_vue_type_style_index_0_id_5ebdee52_lang_less_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/components/s-dialog-normal.vue?vue&type=template&id=5ebdee52&scoped=true&":
/*!***************************************************************************************!*\
  !*** ./src/components/s-dialog-normal.vue?vue&type=template&id=5ebdee52&scoped=true& ***!
  \***************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_s_dialog_normal_vue_vue_type_template_id_5ebdee52_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"b9734f90-vue-loader-template"}!../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../node_modules/vue-loader/lib??vue-loader-options!./s-dialog-normal.vue?vue&type=template&id=5ebdee52&scoped=true& */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"b9734f90-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/s-dialog-normal.vue?vue&type=template&id=5ebdee52&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_s_dialog_normal_vue_vue_type_template_id_5ebdee52_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_s_dialog_normal_vue_vue_type_template_id_5ebdee52_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/s-table-result.vue":
/*!*******************************************!*\
  !*** ./src/components/s-table-result.vue ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _s_table_result_vue_vue_type_template_id_37877db4_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./s-table-result.vue?vue&type=template&id=37877db4&scoped=true& */ "./src/components/s-table-result.vue?vue&type=template&id=37877db4&scoped=true&");
/* harmony import */ var _s_table_result_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./s-table-result.vue?vue&type=script&lang=js& */ "./src/components/s-table-result.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _s_table_result_vue_vue_type_style_index_0_id_37877db4_lang_less_scoped_true___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./s-table-result.vue?vue&type=style&index=0&id=37877db4&lang=less&scoped=true& */ "./src/components/s-table-result.vue?vue&type=style&index=0&id=37877db4&lang=less&scoped=true&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _s_table_result_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _s_table_result_vue_vue_type_template_id_37877db4_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _s_table_result_vue_vue_type_template_id_37877db4_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "37877db4",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/s-table-result.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/s-table-result.vue?vue&type=script&lang=js&":
/*!********************************************************************!*\
  !*** ./src/components/s-table-result.vue?vue&type=script&lang=js& ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_12_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_s_table_result_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/cache-loader/dist/cjs.js??ref--12-0!../../node_modules/babel-loader/lib!../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../node_modules/vue-loader/lib??vue-loader-options!./s-table-result.vue?vue&type=script&lang=js& */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/s-table-result.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_12_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_s_table_result_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/s-table-result.vue?vue&type=style&index=0&id=37877db4&lang=less&scoped=true&":
/*!*****************************************************************************************************!*\
  !*** ./src/components/s-table-result.vue?vue&type=style&index=0&id=37877db4&lang=less&scoped=true& ***!
  \*****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_s_table_result_vue_vue_type_style_index_0_id_37877db4_lang_less_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/vue-style-loader??ref--10-oneOf-1-0!../../node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../node_modules/postcss-loader/src??ref--10-oneOf-1-2!../../node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../node_modules/vue-loader/lib??vue-loader-options!./s-table-result.vue?vue&type=style&index=0&id=37877db4&lang=less&scoped=true& */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/s-table-result.vue?vue&type=style&index=0&id=37877db4&lang=less&scoped=true&");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_s_table_result_vue_vue_type_style_index_0_id_37877db4_lang_less_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_s_table_result_vue_vue_type_style_index_0_id_37877db4_lang_less_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_s_table_result_vue_vue_type_style_index_0_id_37877db4_lang_less_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_s_table_result_vue_vue_type_style_index_0_id_37877db4_lang_less_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/components/s-table-result.vue?vue&type=template&id=37877db4&scoped=true&":
/*!**************************************************************************************!*\
  !*** ./src/components/s-table-result.vue?vue&type=template&id=37877db4&scoped=true& ***!
  \**************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_s_table_result_vue_vue_type_template_id_37877db4_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"b9734f90-vue-loader-template"}!../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../node_modules/vue-loader/lib??vue-loader-options!./s-table-result.vue?vue&type=template&id=37877db4&scoped=true& */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"b9734f90-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/s-table-result.vue?vue&type=template&id=37877db4&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_s_table_result_vue_vue_type_template_id_37877db4_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_s_table_result_vue_vue_type_template_id_37877db4_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/main.js":
/*!*********************!*\
  !*** ./src/main.js ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/core-js/modules/es.array.iterator.js */ "./node_modules/core-js/modules/es.array.iterator.js");
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/core-js/modules/es.promise.js */ "./node_modules/core-js/modules/es.promise.js");
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/core-js/modules/es.object.assign.js */ "./node_modules/core-js/modules/es.object.assign.js");
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_core_js_modules_es_promise_finally_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/core-js/modules/es.promise.finally.js */ "./node_modules/core-js/modules/es.promise.finally.js");
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_core_js_modules_es_promise_finally_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_core_js_modules_es_promise_finally_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.esm.js");
/* harmony import */ var _App_vue__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./App.vue */ "./src/App.vue");
/* harmony import */ var _router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./router */ "./src/router/index.js");
/* harmony import */ var _store___WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./store/ */ "./src/store/index.js");
/* harmony import */ var element_ui__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! element-ui */ "./node_modules/element-ui/lib/element-ui.common.js");
/* harmony import */ var element_ui__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(element_ui__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var element_ui_lib_theme_chalk_index_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! element-ui/lib/theme-chalk/index.css */ "./node_modules/element-ui/lib/theme-chalk/index.css");
/* harmony import */ var element_ui_lib_theme_chalk_index_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(element_ui_lib_theme_chalk_index_css__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _common_mixinWares__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @/common/mixinWares */ "./src/common/mixinWares.js");
/* harmony import */ var vue_cookies__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! vue-cookies */ "./node_modules/vue-cookies/vue-cookies.js");
/* harmony import */ var vue_cookies__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(vue_cookies__WEBPACK_IMPORTED_MODULE_11__);










 //组件和全局methods方法的引入


vue__WEBPACK_IMPORTED_MODULE_4__["default"].use(vue_cookies__WEBPACK_IMPORTED_MODULE_11___default.a);
vue__WEBPACK_IMPORTED_MODULE_4__["default"].config.devtools = true;
vue__WEBPACK_IMPORTED_MODULE_4__["default"].config.productionTip = false;
vue__WEBPACK_IMPORTED_MODULE_4__["default"].use(element_ui__WEBPACK_IMPORTED_MODULE_8___default.a);
vue__WEBPACK_IMPORTED_MODULE_4__["default"].mixin(_common_mixinWares__WEBPACK_IMPORTED_MODULE_10__["default"]);
new vue__WEBPACK_IMPORTED_MODULE_4__["default"]({
  router: _router__WEBPACK_IMPORTED_MODULE_6__["default"],
  store: _store___WEBPACK_IMPORTED_MODULE_7__["default"],
  render: function render(h) {
    return h(_App_vue__WEBPACK_IMPORTED_MODULE_5__["default"]);
  }
}).$mount('#app');

/***/ }),

/***/ "./src/router/index.js":
/*!*****************************!*\
  !*** ./src/router/index.js ***!
  \*****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.esm.js");
/* harmony import */ var vue_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! vue-router */ "./node_modules/vue-router/dist/vue-router.esm.js");





vue__WEBPACK_IMPORTED_MODULE_3__["default"].use(vue_router__WEBPACK_IMPORTED_MODULE_4__["default"]);

var login = function login() {
  return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(10), __webpack_require__.e(29)]).then(__webpack_require__.bind(null, /*! @/views/login.vue */ "./src/views/login.vue"));
};

var manage = function manage() {
  return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(10), __webpack_require__.e(14)]).then(__webpack_require__.bind(null, /*! @/views/manage.vue */ "./src/views/manage.vue"));
};

var home = function home() {
  return __webpack_require__.e(/*! import() */ 67).then(__webpack_require__.bind(null, /*! @/views/home.vue */ "./src/views/home.vue"));
};

var newsInfoManage = function newsInfoManage() {
  return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(7), __webpack_require__.e(28)]).then(__webpack_require__.bind(null, /*! @/views/newsinfo/news-info-manage.vue */ "./src/views/newsinfo/news-info-manage.vue"));
};

var newslist = function newslist() {
  return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(7), __webpack_require__.e(24)]).then(__webpack_require__.bind(null, /*! @/views/newsinfo/news-info-list.vue */ "./src/views/newsinfo/news-info-list.vue"));
};

var dictionary = function dictionary() {
  return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(49)]).then(__webpack_require__.bind(null, /*! @/views/dataDectonary/dictionary.vue */ "./src/views/dataDectonary/dictionary.vue"));
};

var routes = [{
  path: '*',
  component: function component() {
    return __webpack_require__.e(/*! import() */ 55).then(__webpack_require__.bind(null, /*! @/views/notFound */ "./src/views/notFound.vue"));
  }
}, {
  path: '/',
  component: login
}, {
  path: '/manage',
  name: 'manage',
  component: manage,
  meta: ['首页'],
  children: [{
    path: '/text',
    name: 'componentsText',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(11), __webpack_require__.e(72)]).then(__webpack_require__.bind(null, /*! @/views/componentsText/Text */ "./src/views/componentsText/Text.vue"));
    },
    meta: ['组件测试页面']
  }, {
    path: '/home',
    name: 'manage.home',
    component: home,
    meta: []
  }, {
    path: '/newseditor',
    name: 'newseditor',
    component: newsInfoManage,
    meta: ['新闻动态', '新增']
  }, {
    path: '/newslist',
    name: 'newslist',
    component: newslist,
    meta: ['官网管理', '新闻动态文章列表及上传']
  }, {
    path: '/dictionary',
    name: 'dictionary',
    component: dictionary,
    meta: ['数据字典管理']
  }, {
    path: '/agentList',
    name: 'agentList',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(31)]).then(__webpack_require__.bind(null, /*! @/views/agent-manage/agentList */ "./src/views/agent-manage/agentList.vue"));
    },
    meta: ['人员管理', '代理人管理']
  }, {
    path: '/usermanage',
    name: 'usermanage',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(34)]).then(__webpack_require__.bind(null, /*! @/views/authority-manage/user-manage */ "./src/views/authority-manage/user-manage.vue"));
    },
    meta: ['权限管理', '用户管理']
  }, {
    path: '/rolemanage',
    name: 'rolemanage',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(33)]).then(__webpack_require__.bind(null, /*! @/views/authority-manage/role-manage */ "./src/views/authority-manage/role-manage.vue"));
    },
    meta: ['权限管理', '角色管理']
  }, {
    path: '/resoumanage',
    name: 'resoumanage',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(11), __webpack_require__.e(46)]).then(__webpack_require__.bind(null, /*! @/views/authority-manage/resou-manage */ "./src/views/authority-manage/resou-manage.vue"));
    },
    meta: ['权限管理', '角色管理']
  }, {
    path: '/ordermanage',
    name: 'ordermanage',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(5), __webpack_require__.e(9)]).then(__webpack_require__.bind(null, /*! @/views/order-manage/orderList */ "./src/views/order-manage/orderList.vue"));
    },
    meta: ['订单管理', '订单列表']
  }, {
    path: '/AdvancedOrder',
    name: 'AdvancedOrder',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(5), __webpack_require__.e(9), __webpack_require__.e(73)]).then(__webpack_require__.bind(null, /*! @/views/order-manage/AdvancedOrder.vue */ "./src/views/order-manage/AdvancedOrder.vue"));
    },
    meta: ['订单管理', '订单列表']
  }, {
    path: '/appointmentmanage',
    name: 'appointmentmanage',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(32)]).then(__webpack_require__.bind(null, /*! @/views/appointment-manage/appointmentList */ "./src/views/appointment-manage/appointmentList.vue"));
    },
    meta: ['预约投保管理', '预约投保列表']
  }, {
    path: '/productmanage',
    name: 'productmanage',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(56)]).then(__webpack_require__.bind(null, /*! @/views/product-manage/productList */ "./src/views/product-manage/productList.vue"));
    },
    meta: ['产品中心', '产品列表']
  }, {
    path: '/outproduct',
    name: 'outproduct',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(3), __webpack_require__.e(4), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e(8), __webpack_require__.e(22)]).then(__webpack_require__.bind(null, /*! @/views/product-manage/outproductList */ "./src/views/product-manage/outproductList.vue"));
    },
    meta: ['产品中心', '外部产品列表']
  }, {
    path: '/supplier',
    name: 'supplier',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(3), __webpack_require__.e(4), __webpack_require__.e(7), __webpack_require__.e(40)]).then(__webpack_require__.bind(null, /*! @/views/product-manage/supplier */ "./src/views/product-manage/supplier.vue"));
    },
    meta: ['产品中心', '供应商管理']
  }, {
    path: '/servicechargecheck',
    name: 'servicechargecheck',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(4), __webpack_require__.e(5), __webpack_require__.e(8), __webpack_require__.e(71)]).then(__webpack_require__.bind(null, /*! @/views/product-manage/servicechargecheckList */ "./src/views/product-manage/servicechargecheckList.vue"));
    },
    meta: ['产品中心', '手续费率审核']
  }, {
    path: '/reviewOfCommissionRate',
    name: 'reviewOfCommissionRate',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(4), __webpack_require__.e(5), __webpack_require__.e(8), __webpack_require__.e(70)]).then(__webpack_require__.bind(null, /*! @/views/product-manage/ReviewOfCommissionRate */ "./src/views/product-manage/ReviewOfCommissionRate.vue"));
    },
    meta: ['产品中心', '佣金费率审核']
  }, {
    path: '/onshowmanage',
    name: 'onshowmanage',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(26)]).then(__webpack_require__.bind(null, /*! @/views/onShow-manage/onShowList */ "./src/views/onShow-manage/onShowList.vue"));
    },
    meta: ['直播管理', '直播列表']
  }, {
    path: '/regusermanage',
    name: 'regusermanage',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(57)]).then(__webpack_require__.bind(null, /*! @/views/reguser-manage/reguserList */ "./src/views/reguser-manage/reguserList.vue"));
    },
    meta: ['人员管理', '注册用户列表']
  }, {
    path: '/bannerConfig',
    name: 'bannerConfig',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(58)]).then(__webpack_require__.bind(null, /*! @/views/wechatpro-manage/bannerConfig */ "./src/views/wechatpro-manage/bannerConfig.vue"));
    },
    meta: ['微信小程序管理', 'Banner图配置']
  }, {
    path: '/produConfig',
    name: 'produConfig',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(59)]).then(__webpack_require__.bind(null, /*! @/views/wechatpro-manage/produConfig */ "./src/views/wechatpro-manage/produConfig.vue"));
    },
    meta: ['微信小程序管理', '产品轮播图配置']
  }, {
    path: '/mallModle',
    name: 'mallModle',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(20)]).then(__webpack_require__.bind(null, /*! @/views/wechatpub-manage/mallModle */ "./src/views/wechatpub-manage/mallModle.vue"));
    },
    meta: ['微信公众号管理', '保险商城模块配置']
  }, {
    path: '/productBanner',
    name: 'productBanner',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(60)]).then(__webpack_require__.bind(null, /*! @/views/wechatpub-manage/productBanner */ "./src/views/wechatpub-manage/productBanner.vue"));
    },
    meta: ['微信公众号管理', '保险商城banner图配置']
  }, {
    path: '/remindTime',
    name: 'remindTime',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(61)]).then(__webpack_require__.bind(null, /*! @/views/wechatpub-manage/remindTime */ "./src/views/wechatpub-manage/remindTime.vue"));
    },
    meta: ['微信公众号管理', '续期续保提醒时间段配置']
  }, //agentManage
  {
    path: '/uploadHeader',
    name: 'uploadHeader',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(7), __webpack_require__.e(27)]).then(__webpack_require__.bind(null, /*! @/views/wechatpub-manage/uploadHeader */ "./src/views/wechatpub-manage/uploadHeader.vue"));
    },
    meta: ['微信公众号管理', '财保头条上传']
  }, {
    path: '/appBanner',
    name: 'appBanner',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(41)]).then(__webpack_require__.bind(null, /*! @/views/app-manage/appBanner */ "./src/views/app-manage/appBanner.vue"));
    },
    meta: ['APP管理', 'banner图配置']
  }, {
    path: '/card',
    name: 'card',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(43)]).then(__webpack_require__.bind(null, /*! @/views/app-manage/card */ "./src/views/app-manage/card.vue"));
    },
    meta: ['APP管理', '签到贺卡配置']
  }, {
    path: '/appProductType',
    name: 'appProductType',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(3), __webpack_require__.e(42)]).then(__webpack_require__.bind(null, /*! @/views/app-manage/appProductType */ "./src/views/app-manage/appProductType.vue"));
    },
    meta: ['APP管理', '产品模块配置']
  }, {
    path: '/performance',
    name: 'performance',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(2), __webpack_require__.e(63)]).then(__webpack_require__.bind(null, /*! @/views/app-manage/performance */ "./src/views/app-manage/performance.vue"));
    },
    meta: ['APP管理', '团队业绩配置']
  }, {
    path: '/poster',
    name: 'poster',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(64)]).then(__webpack_require__.bind(null, /*! @/views/app-manage/poster */ "./src/views/app-manage/poster.vue"));
    },
    meta: ['APP管理', '海报配置']
  }, {
    path: '/questionManage',
    name: 'questionManage',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(13)]).then(__webpack_require__.bind(null, /*! @/views/app-manage/questionManage */ "./src/views/app-manage/questionManage.vue"));
    },
    meta: ['APP管理', '考试管理']
  }, {
    path: '/knowledge',
    name: 'knowledge',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(62)]).then(__webpack_require__.bind(null, /*! @/views/app-manage/knowledge */ "./src/views/app-manage/knowledge.vue"));
    },
    meta: ['APP管理', '知识库管理']
  }, {
    path: '/shopAudit',
    name: 'shopAudit',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(44)]).then(__webpack_require__.bind(null, /*! @/views/app-manage/shopAudit */ "./src/views/app-manage/shopAudit.vue"));
    },
    meta: ['APP管理', '微店审核']
  }, {
    path: '/visitCardAudit',
    name: 'visitCardAudit',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(45)]).then(__webpack_require__.bind(null, /*! @/views/app-manage/visitCardAudit */ "./src/views/app-manage/visitCardAudit.vue"));
    },
    meta: ['APP管理', '名片管理']
  }, {
    path: '/receipt',
    name: 'receipt',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(53)]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/receipt */ "./src/views/mga-manage/receipt.vue"));
    },
    meta: ['订单管理', '回执管理']
  }, {
    path: '/mgaVisit',
    name: 'mgaVisit',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(54)]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/visit */ "./src/views/mga-manage/visit.vue"));
    },
    meta: ['订单管理', '回访管理']
  }, {
    path: '/action',
    name: 'action',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(3), __webpack_require__.e(4), __webpack_require__.e(7), __webpack_require__.e(16)]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/action */ "./src/views/mga-manage/action.vue"));
    },
    meta: ['营销活动', '活动管理']
  }, {
    path: '/channelcomponeny',
    name: 'channelcomponeny',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(3), __webpack_require__.e(4), __webpack_require__.e(5), __webpack_require__.e(7), __webpack_require__.e(30)]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/channelcomponeny */ "./src/views/mga-manage/channelcomponeny.vue"));
    },
    meta: ['机构管理', '渠道公司管理']
  }, {
    path: '/channelTeam',
    name: 'channelTeam',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(3), __webpack_require__.e(4), __webpack_require__.e(7), __webpack_require__.e(35)]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/channelTeam */ "./src/views/mga-manage/channelTeam.vue"));
    },
    meta: ['机构管理', '渠道团队管理']
  }, {
    path: '/channelPeople',
    name: 'channelPeople',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(4), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e(12), __webpack_require__.e(68)]).then(__webpack_require__.bind(null, /*! views/mga-manage/channelPeople */ "./src/views/mga-manage/channelPeople.vue"));
    },
    meta: ['机构管理', '渠道人员管理']
  }, {
    path: '/settleManger',
    name: 'settleManger',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(3), __webpack_require__.e(4), __webpack_require__.e(5), __webpack_require__.e(19)]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/settleAccount/settleManger */ "./src/views/mga-manage/settleAccount/settleManger.vue"));
    },
    meta: ['结算管理', '渠道结算', '结算管理']
  }, {
    path: '/settleBatchList',
    name: 'settleBatchList',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(3), __webpack_require__.e(4), __webpack_require__.e(39)]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/settleAccount/settleBatchList */ "./src/views/mga-manage/settleAccount/settleBatchList.vue"));
    },
    meta: ['结算管理', '渠道结算', '结算批次列表']
  }, {
    path: '/cashOutApplication',
    name: 'cashOutApplication',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(3), __webpack_require__.e(4), __webpack_require__.e(7), __webpack_require__.e(38)]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/settleAccount/cashOutApplication */ "./src/views/mga-manage/settleAccount/cashOutApplication.vue"));
    },
    meta: ['结算管理', '提现申请']
  }, {
    path: '/accounting',
    name: 'accounting',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(3), __webpack_require__.e(4), __webpack_require__.e(37)]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/settleAccount/accounting */ "./src/views/mga-manage/settleAccount/accounting.vue"));
    },
    meta: ['机构管理', '收入统计']
  }, {
    path: '/checkAccount',
    name: 'checkAccount',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(3), __webpack_require__.e(4), __webpack_require__.e(52)]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/checkManage/checkAccount */ "./src/views/mga-manage/checkManage/checkAccount.vue"));
    },
    meta: ['结算管理', '供应商结算', '对账管理']
  }, {
    path: '/batchList',
    name: 'batchList',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(3), __webpack_require__.e(4), __webpack_require__.e(36)]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/checkManage/batchList */ "./src/views/mga-manage/checkManage/batchList.vue"));
    },
    meta: ['结算管理', '供应商结算', '对账批次']
  }, {
    path: '/hesitationPeriod',
    name: 'hesitationPeriod',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(4), __webpack_require__.e(69)]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/hesitationPeriod */ "./src/views/mga-manage/hesitationPeriod.vue"));
    },
    meta: ['订单管理', '犹豫期管理']
  }, {
    path: '/Statistics',
    name: 'Statistics',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(3), __webpack_require__.e(4), __webpack_require__.e(51)]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/Statistics */ "./src/views/mga-manage/Statistics.vue"));
    },
    meta: ['机构管理', '业务统计']
  }, {
    path: '/Announcements',
    name: 'Announcements',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(3), __webpack_require__.e(7), __webpack_require__.e(17)]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/Announcements */ "./src/views/mga-manage/Announcements.vue"));
    },
    meta: ['通知与公告', '公告管理']
  }, {
    path: '/BigBPeopleQuery',
    name: 'BigBPeopleQuery',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(50)]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/BigBPeopleQuery */ "./src/views/mga-manage/BigBPeopleQuery.vue"));
    },
    meta: ['机构管理', '大B人员查询']
  }, {
    path: '/SafeAllMange',
    name: 'SafeAllMange',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e(21)]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/SafeAllMange/SafeAllMange */ "./src/views/mga-manage/SafeAllMange/SafeAllMange.vue"));
    },
    meta: ['订单管理', '保全管理']
  }, {
    path: '/JoinApply',
    name: 'JoinApply',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e(7), __webpack_require__.e(12), __webpack_require__.e(15)]).then(__webpack_require__.bind(null, /*! @/views/agent-manage/JoinApply */ "./src/views/agent-manage/JoinApply.vue"));
    },
    meta: ['人员管理', '入离司初审']
  }, {
    path: '/VideoUpload',
    name: 'VideoUpload',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(6), __webpack_require__.e(18)]).then(__webpack_require__.bind(null, /*! @/views/authority-manage/VideoUpload.vue */ "./src/views/authority-manage/VideoUpload.vue"));
    },
    meta: ['权限管理', '文件上传']
  }, {
    path: '/FormalAssessment',
    name: 'FormalAssessment',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(2), __webpack_require__.e(65)]).then(__webpack_require__.bind(null, /*! @/views/channelAssess-manage/FormalAssessment.vue */ "./src/views/channelAssess-manage/FormalAssessment.vue"));
    },
    meta: ['渠道考核', '正式考核']
  }, {
    path: '/ProgressReport',
    name: 'ProgressReport',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(3), __webpack_require__.e(6), __webpack_require__.e(25)]).then(__webpack_require__.bind(null, /*! views/channelAssess-manage/ProgressReport.vue */ "./src/views/channelAssess-manage/ProgressReport.vue"));
    },
    meta: ['渠道考核', '考核进度报表']
  }, {
    path: '/AssessmentResults',
    name: 'AssessmentResults',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(3), __webpack_require__.e(6), __webpack_require__.e(23)]).then(__webpack_require__.bind(null, /*! views/channelAssess-manage/AssessmentResults.vue */ "./src/views/channelAssess-manage/AssessmentResults.vue"));
    },
    meta: ['渠道考核', '考核进度报表']
  }, {
    path: '/AnnualPremiumSetting',
    name: 'AnnualPremiumSetting',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(3), __webpack_require__.e(6), __webpack_require__.e(47)]).then(__webpack_require__.bind(null, /*! views/channelAssess-manage/AnnualPremiumSetting */ "./src/views/channelAssess-manage/AnnualPremiumSetting.vue"));
    },
    meta: ['渠道考核', '年度保费设置']
  }, {
    path: '/AnnualPremiumSettingEdit',
    name: 'AnnualPremiumSettingEdit',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(6), __webpack_require__.e(48)]).then(__webpack_require__.bind(null, /*! views/channelAssess-manage/AnnualPremiumSettingEdit */ "./src/views/channelAssess-manage/AnnualPremiumSettingEdit.vue"));
    },
    meta: ['年度保费设置']
  }, {
    path: '/ReWithdrawal',
    name: 'ReWithdrawal',
    component: function component() {
      return Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(2), __webpack_require__.e(66)]).then(__webpack_require__.bind(null, /*! views/channelAssess-manage/ReWithdrawal */ "./src/views/channelAssess-manage/ReWithdrawal.vue"));
    },
    meta: ['渠道考核', '重新提数']
  }]
}, {
  path: '/manageTwo',
  name: 'manageTwo',
  component: manage,
  meta: '首页',
  children: [{
    path: '/HistorySumRecord',
    name: 'HistorySumRecord',
    component: function component() {
      return Promise.all(/*! import() | HistorySumRecord */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e("BusinessStatistics~HistorySumRecord~OrganizationIncome"), __webpack_require__.e("HistorySumRecord")]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/HistorySumRecord/HistorySumRecord */ "./src/views/mga-manage/HistorySumRecord/HistorySumRecord.vue"));
    },
    meta: []
  }, // todo one
  {
    path: '/HistorySumRecord-detail',
    name: 'HistorySumRecord-detail',
    component: function component() {
      return Promise.all(/*! import() | HistorySumRecord */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e("BusinessStatistics~HistorySumRecord~OrganizationIncome"), __webpack_require__.e("HistorySumRecord")]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/HistorySumRecord/one/Detail */ "./src/views/mga-manage/HistorySumRecord/one/Detail.vue"));
    },
    meta: []
  }, {
    path: '/HistorySumRecord-detail-two',
    name: 'HistorySumRecord-detail-two',
    component: function component() {
      return Promise.all(/*! import() | HistorySumRecord */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e("BusinessStatistics~HistorySumRecord~OrganizationIncome"), __webpack_require__.e("HistorySumRecord")]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/HistorySumRecord/one/DetailTwo */ "./src/views/mga-manage/HistorySumRecord/one/DetailTwo.vue"));
    },
    meta: []
  }, // todo 机构业务统计
  {
    path: '/BusinessStatistics',
    name: 'BusinessStatistics',
    component: function component() {
      return Promise.all(/*! import() | BusinessStatistics */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e("BusinessStatistics~HistorySumRecord~OrganizationIncome"), __webpack_require__.e("BusinessStatistics")]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/BusinessStatistics/BusinessStatistics */ "./src/views/mga-manage/BusinessStatistics/BusinessStatistics.vue"));
    },
    meta: []
  }, // ?第一个tab
  {
    path: '/BusinessStatistics_One_Detail',
    name: 'BusinessStatistics_One_Detail',
    component: function component() {
      return Promise.all(/*! import() | BusinessStatistics */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e("BusinessStatistics~HistorySumRecord~OrganizationIncome"), __webpack_require__.e("BusinessStatistics")]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/BusinessStatistics/one/Detail */ "./src/views/mga-manage/BusinessStatistics/one/Detail.vue"));
    },
    meta: []
  }, {
    path: '/BusinessStatistics_One_DetailTwo',
    component: function component() {
      return Promise.all(/*! import() | BusinessStatistics */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e("BusinessStatistics~HistorySumRecord~OrganizationIncome"), __webpack_require__.e("BusinessStatistics")]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/BusinessStatistics/one/DetailTwo */ "./src/views/mga-manage/BusinessStatistics/one/DetailTwo.vue"));
    },
    meta: []
  }, {
    path: '/BusinessStatistics_One_DetailThree',
    component: function component() {
      return Promise.all(/*! import() | BusinessStatistics */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e("BusinessStatistics~HistorySumRecord~OrganizationIncome"), __webpack_require__.e("BusinessStatistics")]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/BusinessStatistics/one/DetailThree */ "./src/views/mga-manage/BusinessStatistics/one/DetailThree.vue"));
    },
    meta: []
  }, // ?第二个tab
  {
    path: '/BusinessStatistics_Two_Detail',
    component: function component() {
      return Promise.all(/*! import() | BusinessStatistics */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e("BusinessStatistics~HistorySumRecord~OrganizationIncome"), __webpack_require__.e("BusinessStatistics")]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/BusinessStatistics/two/Detail */ "./src/views/mga-manage/BusinessStatistics/two/Detail.vue"));
    },
    meta: []
  }, {
    path: '/BusinessStatistics_Two_DetailTwo',
    component: function component() {
      return Promise.all(/*! import() | BusinessStatistics */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e("BusinessStatistics~HistorySumRecord~OrganizationIncome"), __webpack_require__.e("BusinessStatistics")]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/BusinessStatistics/two/DetailTwo */ "./src/views/mga-manage/BusinessStatistics/two/DetailTwo.vue"));
    },
    meta: []
  }, {
    path: '/BusinessStatistics_Two_DetailThree',
    component: function component() {
      return Promise.all(/*! import() | BusinessStatistics */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e("BusinessStatistics~HistorySumRecord~OrganizationIncome"), __webpack_require__.e("BusinessStatistics")]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/BusinessStatistics/two/DetailThree */ "./src/views/mga-manage/BusinessStatistics/two/DetailThree.vue"));
    },
    meta: []
  }, // ?第三个tab
  {
    path: '/BusinessStatistics_Three_Detail',
    component: function component() {
      return Promise.all(/*! import() | BusinessStatistics */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e("BusinessStatistics~HistorySumRecord~OrganizationIncome"), __webpack_require__.e("BusinessStatistics")]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/BusinessStatistics/three/Detail */ "./src/views/mga-manage/BusinessStatistics/three/Detail.vue"));
    },
    meta: []
  }, {
    path: '/BusinessStatistics_Three_DetailTwo',
    component: function component() {
      return Promise.all(/*! import() | BusinessStatistics */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e("BusinessStatistics~HistorySumRecord~OrganizationIncome"), __webpack_require__.e("BusinessStatistics")]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/BusinessStatistics/three/DetailTwo */ "./src/views/mga-manage/BusinessStatistics/three/DetailTwo.vue"));
    },
    meta: []
  }, // ?第四个tab
  {
    path: '/BusinessStatistics_Four_Detail',
    component: function component() {
      return Promise.all(/*! import() | BusinessStatistics */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e("BusinessStatistics~HistorySumRecord~OrganizationIncome"), __webpack_require__.e("BusinessStatistics")]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/BusinessStatistics/four/Detail */ "./src/views/mga-manage/BusinessStatistics/four/Detail.vue"));
    },
    meta: []
  }, // todo 机构收入统计
  {
    path: '/OrganizationIncomeNum',
    component: function component() {
      return Promise.all(/*! import() | OrganizationIncome */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e("BusinessStatistics~HistorySumRecord~OrganizationIncome"), __webpack_require__.e("OrganizationIncome")]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/OrganizationIncomeNum/OrganizationIncomeNum */ "./src/views/mga-manage/OrganizationIncomeNum/OrganizationIncomeNum.vue"));
    },
    meta: []
  }, // ?第一个tab
  {
    path: '/OrganizationIncomeNum_One_Detail',
    component: function component() {
      return Promise.all(/*! import() | OrganizationIncome */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e("BusinessStatistics~HistorySumRecord~OrganizationIncome"), __webpack_require__.e("OrganizationIncome")]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/OrganizationIncomeNum/one/Detail */ "./src/views/mga-manage/OrganizationIncomeNum/one/Detail.vue"));
    },
    meta: []
  }, {
    path: '/OrganizationIncomeNum_One_DetailTwo',
    component: function component() {
      return Promise.all(/*! import() | OrganizationIncome */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e("BusinessStatistics~HistorySumRecord~OrganizationIncome"), __webpack_require__.e("OrganizationIncome")]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/OrganizationIncomeNum/one/DetailTwo */ "./src/views/mga-manage/OrganizationIncomeNum/one/DetailTwo.vue"));
    },
    meta: []
  }, {
    path: '/OrganizationIncomeNum_One_DetailThree',
    component: function component() {
      return Promise.all(/*! import() | OrganizationIncome */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e("BusinessStatistics~HistorySumRecord~OrganizationIncome"), __webpack_require__.e("OrganizationIncome")]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/OrganizationIncomeNum/one/DetailThree */ "./src/views/mga-manage/OrganizationIncomeNum/one/DetailThree.vue"));
    },
    meta: []
  }, // ?第二个tab
  {
    path: '/OrganizationIncomeNum_Two_Detail',
    component: function component() {
      return Promise.all(/*! import() | OrganizationIncome */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e("BusinessStatistics~HistorySumRecord~OrganizationIncome"), __webpack_require__.e("OrganizationIncome")]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/OrganizationIncomeNum/two/Detail */ "./src/views/mga-manage/OrganizationIncomeNum/two/Detail.vue"));
    },
    meta: []
  }, {
    path: '/OrganizationIncomeNum_Two_DetailTwo',
    component: function component() {
      return Promise.all(/*! import() | OrganizationIncome */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e("BusinessStatistics~HistorySumRecord~OrganizationIncome"), __webpack_require__.e("OrganizationIncome")]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/OrganizationIncomeNum/two/DetailTwo */ "./src/views/mga-manage/OrganizationIncomeNum/two/DetailTwo.vue"));
    },
    meta: []
  }, {
    path: '/OrganizationIncomeNum_Two_DetailThree',
    component: function component() {
      return Promise.all(/*! import() | OrganizationIncome */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e("BusinessStatistics~HistorySumRecord~OrganizationIncome"), __webpack_require__.e("OrganizationIncome")]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/OrganizationIncomeNum/two/DetailThree */ "./src/views/mga-manage/OrganizationIncomeNum/two/DetailThree.vue"));
    },
    meta: []
  }, // ?第三个tab
  {
    path: '/OrganizationIncomeNum_Three_Detail',
    component: function component() {
      return Promise.all(/*! import() | OrganizationIncome */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e("BusinessStatistics~HistorySumRecord~OrganizationIncome"), __webpack_require__.e("OrganizationIncome")]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/OrganizationIncomeNum/three/Detail */ "./src/views/mga-manage/OrganizationIncomeNum/three/Detail.vue"));
    },
    meta: []
  }, {
    path: '/OrganizationIncomeNum_Three_DetailTwo',
    component: function component() {
      return Promise.all(/*! import() | OrganizationIncome */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e("BusinessStatistics~HistorySumRecord~OrganizationIncome"), __webpack_require__.e("OrganizationIncome")]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/OrganizationIncomeNum/three/DetailTwo */ "./src/views/mga-manage/OrganizationIncomeNum/three/DetailTwo.vue"));
    },
    meta: []
  }, // ?第四个tab
  {
    path: '/OrganizationIncomeNum_Four_Detail',
    component: function component() {
      return Promise.all(/*! import() | OrganizationIncome */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e("BusinessStatistics~HistorySumRecord~OrganizationIncome"), __webpack_require__.e("OrganizationIncome")]).then(__webpack_require__.bind(null, /*! @/views/mga-manage/OrganizationIncomeNum/four/Detail */ "./src/views/mga-manage/OrganizationIncomeNum/four/Detail.vue"));
    },
    meta: []
  }]
}];
/* harmony default export */ __webpack_exports__["default"] = (new vue_router__WEBPACK_IMPORTED_MODULE_4__["default"]({
  routes: routes,
  strict: "development" !== 'production'
}));

/***/ }),

/***/ "./src/store/actions.js":
/*!******************************!*\
  !*** ./src/store/actions.js ***!
  \******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({});

/***/ }),

/***/ "./src/store/getters.js":
/*!******************************!*\
  !*** ./src/store/getters.js ***!
  \******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  getPageParams: function getPageParams(state, getters) {
    var body = JSON.parse(JSON.stringify(state.nav.body));

    if (body.length > 1) {
      for (var i = 0; i <= body.length - 1; i++) {
        if (i + 1 < body.length) {
          body[i].url = body[i + 1].url;
        }
      }

      body[body.length - 1].url = '';
    }

    return body;
  }
});

/***/ }),

/***/ "./src/store/index.js":
/*!****************************!*\
  !*** ./src/store/index.js ***!
  \****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.esm.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var _state__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./state */ "./src/store/state.js");
/* harmony import */ var _mutations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./mutations */ "./src/store/mutations.js");
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./actions */ "./src/store/actions.js");
/* harmony import */ var _getters__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./getters */ "./src/store/getters.js");






vue__WEBPACK_IMPORTED_MODULE_0__["default"].use(vuex__WEBPACK_IMPORTED_MODULE_1__["default"]);
/* harmony default export */ __webpack_exports__["default"] = (new vuex__WEBPACK_IMPORTED_MODULE_1__["default"].Store({
  state: _state__WEBPACK_IMPORTED_MODULE_2__["default"],
  getters: _getters__WEBPACK_IMPORTED_MODULE_5__["default"],
  actions: _actions__WEBPACK_IMPORTED_MODULE_4__["default"],
  mutations: _mutations__WEBPACK_IMPORTED_MODULE_3__["default"]
}));

/***/ }),

/***/ "./src/store/mutations.js":
/*!********************************!*\
  !*** ./src/store/mutations.js ***!
  \********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.object.entries.js */ "./node_modules/core-js/modules/es.object.entries.js");
/* harmony import */ var core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_2__);



/* harmony default export */ __webpack_exports__["default"] = ({
  saveUserid: function saveUserid(state, value) {
    state.userId = value;
  },
  saveDomButton: function saveDomButton(state, value) {
    state.domButton[value] = true;
  },
  // todo 页面跳转相关mutation
  clearParams: function clearParams(state, payload) {
    state.QueryMust = {};
  },
  clearNavBody: function clearNavBody(state, payload) {
    // if (payload === 'tab') {
    //     state.nav.body.splice(1)
    // } else
    if (payload === 'nav') {
      state.nav.body.splice(0);
    }
  },
  addMustData: function addMustData(state, payload) {
    for (var _i = 0, _Object$entries = Object.entries(payload); _i < _Object$entries.length; _i++) {
      var _Object$entries$_i = Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__["default"])(_Object$entries[_i], 2),
          key = _Object$entries$_i[0],
          value = _Object$entries$_i[1];

      state.QueryMust[key] = value;
    }
  },
  addNavData: function addNavData(state, payload) {
    if (payload.nav.body !== undefined) {
      // const index = state.nav.body.findIndex(item => {
      //     return item.name === payload.nav.body[0].name
      // })
      //
      // if (state.nav.body.length === 0) {
      //     state.nav.body.push(payload.nav.body[0])
      // } else if (index === -1) {
      //     // 将数组url位置左移一位
      //     state.nav.body[state.nav.body.length - 1].url = payload.nav.body[0].url
      //     payload.nav.body[0].url = ''
      //     state.nav.body.push(payload.nav.body[0])
      // }
      if (state.nav.body.length > 1) {
        state.nav.body.splice(payload.nav.pageNum - 1);
      }

      state.nav.body.push(payload.nav.body[0]);
    }

    state.nav.pageNum = payload.nav.pageNum;
  }
});

/***/ }),

/***/ "./src/store/state.js":
/*!****************************!*\
  !*** ./src/store/state.js ***!
  \****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  userId: "",
  domButton: {},
  //页面button
  tableButton: {},
  //表格button
  // todo 表格数据
  QueryMust: {},
  nav: {
    pageNum: 0,
    body: []
  }
});

/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.js ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\SoftwareDev\Code\Work\GT\spread-backstage-leave\src\main.js */"./src/main.js");


/***/ })

/******/ });
//# sourceMappingURL=index.js.map