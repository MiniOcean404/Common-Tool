(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[9],{

/***/ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js":
/*!*******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/defineProperty.js ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _defineProperty; });
function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _objectSpread2; });
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.symbol.js */ "./node_modules/core-js/modules/es.symbol.js");
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_object_get_own_property_descriptor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.object.get-own-property-descriptor.js */ "./node_modules/core-js/modules/es.object.get-own-property-descriptor.js");
/* harmony import */ var core_js_modules_es_object_get_own_property_descriptor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_get_own_property_descriptor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_get_own_property_descriptors_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.object.get-own-property-descriptors.js */ "./node_modules/core-js/modules/es.object.get-own-property-descriptors.js");
/* harmony import */ var core_js_modules_es_object_get_own_property_descriptors_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_get_own_property_descriptors_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _defineProperty_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./defineProperty.js */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");








function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);

    if (enumerableOnly) {
      symbols = symbols.filter(function (sym) {
        return Object.getOwnPropertyDescriptor(object, sym).enumerable;
      });
    }

    keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread2(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    if (i % 2) {
      ownKeys(Object(source), true).forEach(function (key) {
        Object(_defineProperty_js__WEBPACK_IMPORTED_MODULE_6__["default"])(target, key, source[key]);
      });
    } else if (Object.getOwnPropertyDescriptors) {
      Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
      ownKeys(Object(source)).forEach(function (key) {
        Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
      });
    }
  }

  return target;
}

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/order-manage/orderList.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--12-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/order-manage/orderList.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_objectSpread2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2 */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! regenerator-runtime/runtime.js */ "./node_modules/regenerator-runtime/runtime.js");
/* harmony import */ var regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_string_search_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.string.search.js */ "./node_modules/core-js/modules/es.string.search.js");
/* harmony import */ var core_js_modules_es_string_search_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_search_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _api_api__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/api/api */ "./src/api/api.js");
/* harmony import */ var _assets_staticFilter__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/assets/staticFilter */ "./src/assets/staticFilter.js");
/* harmony import */ var _api_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/api/common */ "./src/api/common.js");





//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
 //导入请求

 //静态数据过滤器


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'orderList',
  props: {
    api: {
      type: Function
    },
    searchApi: {
      type: Function
    },
    isShowAssign: {
      type: Boolean,
      default: true
    }
  },
  data: function data() {
    return {
      isLegar: '',
      esourceList: [{
        value: '',
        name: '全部'
      }, {
        value: '01',
        name: '内部'
      }, {
        value: '02',
        name: '外部'
      }],
      commands: [['#409eff', '指定', 'handleSpecify', 'el-icon-setting', 'order-agent'], ['#409eff', '详情', 'handleDetailClick', '', 'order-detail']],
      search: {},
      //搜索栏
      upDataForm: {
        orderId: '',
        agentName: '',
        agentCode: ''
      },
      //指定代理人的绑定表单
      orderBase: {},
      //订单
      orderBeneficiarys: [],
      //受益人
      orderInsureds: [],
      //被保人
      orderNewCovenant: {},
      //保单
      orderPolicyHolder: {},
      //投保人
      orderRisks: [],
      //险种
      searchForm: {//查询表单
      },
      detailForm: {
        //查询的展示表单
        demo: 'demo'
      },
      tbConfig: {
        //表格组件配置项
        fixed: 'right',
        height: '550px',
        // table高度
        select: false,
        // 是否可以多选择
        isSingleSelect: false,
        //是否可以单选
        isOrder: true,
        isCommands: true,
        //是否需要操作列
        commandsWidth: '180',
        //操作列宽度
        showPagenation: true,
        //是否需要显示分页器
        layout: 'total, prev, pager, next, jumper',
        //分页器控件
        requestCurData: true,
        // 每次分页数据是否请求后台 true:每次都请求后台
        columns: [// 后台字段属性、表头名、长度、颜色、是否过长隐藏、是否需要字典转换、点击事件的处理函数
        ['orderId', '订单号', '225', '#409eff', true, false, 'orderDetail'], ['innerOrderSource', '订单来源', '', '', true, true], ['esource', '订单类型', '', '', true, false], ['companyName', '供应商名称', '250', '', true, false], ['orderStatus', '订单状态', '', '', true, true], ['verifyStatus', '核保状态', '', '', true, true], ['appStatus', '承保状态', '', '', true, true], ['makeDate', '订单日期', '200', '', true, false], ['holderName', '投保人', '', '', true, false], ['insuredName', '被保人', '', '', true, false], ['productName', '险种名称', '250', '', true, false], ['orderPayment', '订单金额', '', '', true, false], // ["buyCopies", "分数", "", "", true, false],
        ['policyNo', '保单号', '200', '', true, false], ['agentName', '代理人', '', '', true, true]],
        // table行按钮：color 文字 处理点击的事件函数名  elementUicon
        commands: [['#E6A23C', '指定', 'handleSpecify'], ['#E6A23C', '详情', 'handleDetailClick']]
      },
      tbOptionData: {
        currentTableData: [],
        TransValtoDesc: 'dataFilter',
        //数据字典过滤函数
        selectData: 'handleSelect',
        //单选处理函数
        selectDatas: 'handleSelects',
        //多选处理函数
        sizesCtrl: [5, 10, 20, 30, 40, 50, 100],
        //分页器控件的长度控制器
        pageSize: 10,
        // 每页行数
        currentPage: 1,
        // 当前页
        total: 0,
        //总数据量
        pagenationChange: 'handlPageChange' //处理分页器长度改变或页码改变的函数

      },
      spConfig: {
        //表格组件配置项
        pVue: this,
        height: '530px',
        // table高度
        select: false,
        // 是否可以多选择
        isSingleSelect: true,
        //是否可以单选
        isCommands: false,
        //是否需要操作列
        commandsWidth: '200',
        //操作列宽度
        showPagenation: true,
        //是否需要显示分页器
        layout: 'prev, pager, next, jumper',
        //分页器控件
        requestCurData: true,
        // 每次分页数据是否请求后台 true:每次都请求后台
        columns: [// 后台字段属性、表头名、长度、颜色、是否过长隐藏、是否需要字典转换、点击事件的处理函数
        ['agentName', '姓名', '', '', true, false], ['reserve1', '工号', '', '', true, false]]
      },
      spOptionData: {
        currentTableData: [],
        //当前表格数据
        TransValtoDesc: 'dataFilter',
        //数据字典过滤函数
        selectData: 'handleSelect',
        //单选处理函数
        selectDatas: 'handleSelects',
        //多选处理函数
        sizesCtrl: [5, 10, 20, 30, 40, 50, 100],
        //分页器控件的长度控制器
        pageSize: 10,
        // 每页行数
        currentPage: 1,
        // 当前页
        total: 0,
        //总数据量
        pagenationChange: 'handlPageChangetb' //处理分页器长度改变或页码改变的函数

      },
      detailConfig: {
        //详情查看弹窗组件配置项
        dialogVisible: false,
        width: '1100px',
        buttonPosition: 'flex-end',
        ismodal: true,
        modalClose: false,
        Button: [{
          name: '关闭',
          type: 'default',
          methods: 'handleDialogClose'
        }]
      },
      specifyConfig: {
        //指定代理人弹窗组件配置项
        title: '指定代理人',
        dialogVisible: false,
        width: '550px',
        buttonPosition: 'flex-end',
        ismodal: true,
        modalClose: false,
        Button: [{
          name: '取消',
          methods: 'cancelFn'
        }, {
          name: '确定',
          type: 'primary',
          methods: 'handleupDate'
        }]
      }
    };
  },
  created: function created() {
    this.componentShow();
  },
  mounted: function mounted() {
    this.dataInit();
  },
  filters: {
    appStatusFilter: function appStatusFilter(status) {
      return _assets_staticFilter__WEBPACK_IMPORTED_MODULE_6__["appStatus"][status];
    }
  },
  methods: {
    componentShow: function componentShow() {
      if (this.isShowAssign === false) {
        this.commands = [['#409eff', '详情', 'handleDetailClick', '', 'order-detail']];
      }
    },
    download: function download() {
      Object(_api_common__WEBPACK_IMPORTED_MODULE_7__["download"])('/admin/order/downloadOrderInfo', this.searchForm);
    },
    dataFilter: function dataFilter(id, val) {
      //数据字典过滤
      switch (id) {
        case 'verifyStatus':
          return _assets_staticFilter__WEBPACK_IMPORTED_MODULE_6__["verifyStatus"][val];
          break;

        case 'appStatus':
          return _assets_staticFilter__WEBPACK_IMPORTED_MODULE_6__["appStatus"][val];
          break;

        case 'orderStatus':
          return _assets_staticFilter__WEBPACK_IMPORTED_MODULE_6__["orderStatus"][val];
          break;

        case 'agentName':
          return val ? val : '';
          break;

        case 'innerOrderSource':
          return _assets_staticFilter__WEBPACK_IMPORTED_MODULE_6__["orderSource"][val];
          break;
      }
    },
    onSubmit: function onSubmit() {
      //点击查询
      this.tbOptionData.currentPage = '1';
      this.dataInit();
    },
    //订单详情
    orderDetail: function orderDetail(row) {
      var params = {
        orderId: row.orderId
      };
      this.detailConfig.dialogVisible = true;
      this.searchOrderDetail(params);
    },
    handlPageChange: function handlPageChange(cur, size) {
      //处理主页面的页码改变
      var data = JSON.parse(JSON.stringify(this.searchForm));
      data.pageNum = this.tbOptionData.currentPage;
      data.pageSize = this.tbOptionData.pageSize;
      this.orderList(data);
    },
    handlPageChangetb: function handlPageChangetb(cur, size) {
      var params = {};
      params.pageNum = this.spOptionData.currentPage;
      params.pageSize = this.spOptionData.pageSize;
      this.searchProxyList(params);
    },
    handleSpecify: function handleSpecify(row) {
      //点击了指定
      console.log('点击了指定', row);

      if (row.agentName) {
        this.alert('该用户已完成了指定', '提示');
        return false;
      }

      this.specifyConfig.dialogVisible = true;
      this.upDataForm.orderId = row.orderId;
      console.log(this.upDataForm);
      var params = {};
      params.pageNum = this.spOptionData.currentPage;
      params.pageSize = this.spOptionData.pageSize;
      this.searchProxyList(params);
    },
    searcj: function searcj() {
      //搜索代理人
      var params = JSON.parse(JSON.stringify(this.search));
      params.pageNum = this.spOptionData.currentPage = 1;
      params.pageSize = this.spOptionData.pageSize;
      this.searchProxyList(params);
    },
    handleDetailClick: function handleDetailClick(row) {
      //点击了详情
      console.log('查看详情', row);
      var params = {
        orderId: row.orderId
      };
      this.detailConfig.dialogVisible = true;
      this.searchOrderDetail(params);
    },
    handleDialogClose: function handleDialogClose() {
      this.detailConfig.dialogVisible = false;
    },
    handleSelect: function handleSelect(row) {
      //单选了行
      console.log('选择了行', row);
      this.upDataForm.agentName = row.currentRow.agentName;
      this.upDataForm.agentCode = row.currentRow.agentCode;
    },
    handleupDate: function handleupDate() {
      // this.confirm('确定指定该代理人吗？', '提示').then(() => {
      var data = JSON.parse(JSON.stringify(this.upDataForm));
      this.orderBindAgent(data); // })
    },
    //取消函数
    cancelFn: function cancelFn() {
      this.specifyConfig.dialogVisible = false;
    },
    dataInit: function dataInit() {
      //列表数据更新
      var data = JSON.parse(JSON.stringify(this.searchForm));
      data.pageNum = this.tbOptionData.currentPage;
      data.pageSize = this.tbOptionData.pageSize;

      if (this.searchApi) {
        this.searchApiHandle(data);
      } else {
        this.orderList(data);
      }
    },
    searchApiHandle: function searchApiHandle(data) {
      var _this = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
        var result;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return _this.searchApi(data);

              case 2:
                result = _context.sent;

                if (result.code == 200) {
                  // result.data.records[1].agentName = "宋汉林"
                  _this.tbOptionData.currentTableData = result.data.records;
                  _this.tbOptionData.total = result.data.total;
                }

              case 4:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    orderList: function orderList(data) {
      var _this2 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
        var result;
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return Object(_api_api__WEBPACK_IMPORTED_MODULE_5__["orderList"])(data);

              case 2:
                result = _context2.sent;

                if (result.code == 200) {
                  // result.data.records[1].agentName = "宋汉林"
                  _this2.tbOptionData.currentTableData = result.data.records;
                  _this2.tbOptionData.total = result.data.total;
                  console.log(_this2.tbOptionData.currentTableData, 'this.tbOptionData.currentTableData');
                }

              case 4:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    searchOrderDetail: function searchOrderDetail(params) {
      var _this3 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
        var result;
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                if (!_this3.api) {
                  _context3.next = 6;
                  break;
                }

                _context3.next = 3;
                return _this3.api(params);

              case 3:
                result = _context3.sent;
                _context3.next = 9;
                break;

              case 6:
                _context3.next = 8;
                return Object(_api_api__WEBPACK_IMPORTED_MODULE_5__["searchOrderDetail"])(params);

              case 8:
                result = _context3.sent;

              case 9:
                if (result.code === 200) {
                  _this3.orderRisks = result.data.orderRisks;
                  _this3.orderNewCovenant = result.data.orderNewCovenant;
                  _this3.orderBase = result.data.orderBase;
                  _this3.orderPolicyHolder = result.data.orderPolicyHolder;
                  _this3.orderInsureds = result.data.orderInsureds;
                  _this3.orderBeneficiarys = result.data.orderBeneficiarys;
                  _this3.isLegar = result.data.orderBase.isLegar;
                }

              case 10:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3);
      }))();
    },
    searchProxyList: function searchProxyList(params) {
      var _this4 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
        var result;
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return Object(_api_api__WEBPACK_IMPORTED_MODULE_5__["searchProxyList"])(params);

              case 2:
                result = _context4.sent;

                if (result.code === 200) {
                  _this4.spOptionData.currentTableData = result.data.records;
                  _this4.spOptionData.total = result.data.total;
                }

              case 4:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4);
      }))();
    },
    warninggold: function warninggold() {
      var _this5 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
        var data, warning, result;
        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                data = _this5.upDataForm;
                warning = Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_objectSpread2__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_objectSpread2__WEBPACK_IMPORTED_MODULE_0__["default"])({}, data), {}, {
                  warnFlag: '1' //警告值

                });
                _context5.next = 4;
                return Object(_api_api__WEBPACK_IMPORTED_MODULE_5__["orderBindAgent"])(warning);

              case 4:
                result = _context5.sent;

                if (result.code == 200) {
                  _this5.$message('指定成功', '提示');

                  _this5.specifyConfig.dialogVisible = false;

                  _this5.dataInit();
                }

              case 6:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5);
      }))();
    },
    orderBindAgent: function orderBindAgent(data) {
      var _this6 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
        var result;
        return regeneratorRuntime.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                _context6.next = 2;
                return Object(_api_api__WEBPACK_IMPORTED_MODULE_5__["orderBindAgent"])(data);

              case 2:
                result = _context6.sent;

                if (result.code == 200) {
                  _this6.$message('指定成功', '提示');

                  _this6.specifyConfig.dialogVisible = false;

                  _this6.dataInit();
                } else if (result.code == 104) {
                  _this6.confirm(result.msg, '提示').then(function () {
                    _this6.warninggold();
                  });
                }

              case 4:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6);
      }))();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"b9734f90-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/order-manage/orderList.vue?vue&type=template&id=29df8b9b&scoped=true&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"b9734f90-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/order-manage/orderList.vue?vue&type=template&id=29df8b9b&scoped=true& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "container_ordermanage" },
    [
      _c("h3", [_vm._v("订单列表")]),
      _c("div", { staticClass: "search-grid-top" }, [
        _c("div", { staticStyle: { "grid-area": "a" } }, [
          _c("span", [_vm._v("订单号：")]),
          _c(
            "div",
            { staticClass: "item-right" },
            [
              _c("el-input", {
                attrs: { placeholder: "请输入内容", clearable: "" },
                model: {
                  value: _vm.searchForm.orderId,
                  callback: function($$v) {
                    _vm.$set(_vm.searchForm, "orderId", $$v)
                  },
                  expression: "searchForm.orderId"
                }
              })
            ],
            1
          )
        ]),
        _c("div", { staticStyle: { "grid-area": "b" } }, [
          _c("span", [_vm._v("被保人：")]),
          _c(
            "div",
            { staticClass: "item-right" },
            [
              _c("el-input", {
                attrs: { placeholder: "请输入内容", clearable: "" },
                model: {
                  value: _vm.searchForm.insuredName,
                  callback: function($$v) {
                    _vm.$set(_vm.searchForm, "insuredName", $$v)
                  },
                  expression: "searchForm.insuredName"
                }
              })
            ],
            1
          )
        ]),
        _c("div", { staticStyle: { "grid-area": "c" } }, [
          _c("span", [_vm._v("供应商名称：")]),
          _c(
            "div",
            { staticClass: "item-right" },
            [
              _c("el-input", {
                attrs: { placeholder: "请输入内容", clearable: "" },
                model: {
                  value: _vm.searchForm.companyName,
                  callback: function($$v) {
                    _vm.$set(_vm.searchForm, "companyName", $$v)
                  },
                  expression: "searchForm.companyName"
                }
              })
            ],
            1
          )
        ]),
        _c("div", { staticStyle: { "grid-area": "d" } }, [
          _c("span", [_vm._v("订单类型：")]),
          _c(
            "div",
            { staticClass: "item-right" },
            [
              _c(
                "el-select",
                {
                  attrs: { clearable: "", placeholder: "请选择" },
                  model: {
                    value: _vm.searchForm.eSource,
                    callback: function($$v) {
                      _vm.$set(_vm.searchForm, "eSource", $$v)
                    },
                    expression: "searchForm.eSource"
                  }
                },
                _vm._l(_vm.esourceList, function(item, index) {
                  return _c("el-option", {
                    key: index,
                    attrs: { label: item.name, value: item.value }
                  })
                }),
                1
              )
            ],
            1
          )
        ]),
        _c("div", { staticStyle: { "grid-area": "e" } }, [
          _c("span", [_vm._v("订单状态：")]),
          _c(
            "div",
            { staticClass: "item-right" },
            [
              _c(
                "el-select",
                {
                  attrs: { clearable: "", placeholder: "请选择" },
                  model: {
                    value: _vm.searchForm.order_status,
                    callback: function($$v) {
                      _vm.$set(_vm.searchForm, "order_status", $$v)
                    },
                    expression: "searchForm.order_status"
                  }
                },
                [
                  _c("el-option", {
                    attrs: { label: "未处理", value: "UNPROCESSED" }
                  }),
                  _c("el-option", {
                    attrs: { label: "处理中", value: "PROCESSE" }
                  }),
                  _c("el-option", {
                    attrs: { label: "已处理", value: "PROCESSED" }
                  }),
                  _c("el-option", {
                    attrs: { label: "已关闭", value: "CLOSED" }
                  })
                ],
                1
              )
            ],
            1
          )
        ]),
        _c("div", { staticStyle: { "grid-area": "f" } }, [
          _c("span", [_vm._v("投保人：")]),
          _c(
            "div",
            { staticClass: "item-right" },
            [
              _c("el-input", {
                attrs: { placeholder: "请输入内容", clearable: "" },
                model: {
                  value: _vm.searchForm.holderName,
                  callback: function($$v) {
                    _vm.$set(_vm.searchForm, "holderName", $$v)
                  },
                  expression: "searchForm.holderName"
                }
              })
            ],
            1
          )
        ]),
        _c("div", { staticStyle: { "grid-area": "g" } }, [
          _c("span", [_vm._v("险种名称：")]),
          _c(
            "div",
            { staticClass: "item-right" },
            [
              _c("el-input", {
                attrs: { placeholder: "请输入内容", clearable: "" },
                model: {
                  value: _vm.searchForm.riskName,
                  callback: function($$v) {
                    _vm.$set(_vm.searchForm, "riskName", $$v)
                  },
                  expression: "searchForm.riskName"
                }
              })
            ],
            1
          )
        ]),
        _c("div", { staticStyle: { "grid-area": "h" } }, [
          _c("span", [_vm._v("保单号：")]),
          _c(
            "div",
            { staticClass: "item-right" },
            [
              _c("el-input", {
                attrs: { placeholder: "请输入内容", clearable: "" },
                model: {
                  value: _vm.searchForm.policyNo,
                  callback: function($$v) {
                    _vm.$set(_vm.searchForm, "policyNo", $$v)
                  },
                  expression: "searchForm.policyNo"
                }
              })
            ],
            1
          )
        ]),
        _c("div", { staticStyle: { "grid-area": "i" } }, [
          _c("span", [_vm._v("订单日期：")]),
          _c(
            "div",
            { staticClass: "item-right" },
            [
              _c("el-date-picker", {
                staticStyle: { width: "190px" },
                attrs: {
                  "value-format": "yyyy/MM/dd",
                  type: "date",
                  placeholder: "开始日期"
                },
                model: {
                  value: _vm.searchForm.makeDateStart,
                  callback: function($$v) {
                    _vm.$set(_vm.searchForm, "makeDateStart", $$v)
                  },
                  expression: "searchForm.makeDateStart"
                }
              })
            ],
            1
          )
        ]),
        _c("div", { staticStyle: { "grid-area": "j" } }, [
          _c(
            "div",
            {
              staticStyle: {
                width: "100px",
                display: "inline-block",
                padding: "0 10px"
              }
            },
            [_vm._v(" 至 ")]
          ),
          _c(
            "div",
            { staticClass: "item-right" },
            [
              _c("el-date-picker", {
                staticStyle: { width: "190px" },
                attrs: {
                  "value-format": "yyyy/MM/dd",
                  type: "date",
                  placeholder: "结束日期"
                },
                model: {
                  value: _vm.searchForm.makeDateEnd,
                  callback: function($$v) {
                    _vm.$set(_vm.searchForm, "makeDateEnd", $$v)
                  },
                  expression: "searchForm.makeDateEnd"
                }
              })
            ],
            1
          )
        ]),
        _c("div", { staticStyle: { "grid-area": "k" } }, [
          _c("span", [_vm._v("代理人：")]),
          _c(
            "div",
            { staticClass: "item-right" },
            [
              _c("el-input", {
                attrs: { placeholder: "请输入内容", clearable: "" },
                model: {
                  value: _vm.searchForm.agentName,
                  callback: function($$v) {
                    _vm.$set(_vm.searchForm, "agentName", $$v)
                  },
                  expression: "searchForm.agentName"
                }
              })
            ],
            1
          )
        ]),
        _c(
          "div",
          { staticStyle: { "grid-area": "l" } },
          [
            _c(
              "el-button",
              {
                staticClass: "btn1",
                attrs: { type: "primary", size: "small" },
                on: { click: _vm.onSubmit }
              },
              [_vm._v("查询")]
            ),
            _c(
              "el-button",
              {
                staticClass: "btn1",
                attrs: { type: "primary", size: "small" },
                on: { click: _vm.download }
              },
              [_vm._v("导出")]
            )
          ],
          1
        )
      ]),
      _c("stable", {
        ref: "result",
        attrs: { config: _vm.tbConfig, optionData: _vm.tbOptionData }
      }),
      _c("sdialog", { attrs: { config: _vm.detailConfig } }, [
        _c(
          "div",
          { staticClass: "detaiConfig-wrap" },
          [
            _c(
              "el-card",
              { staticClass: "box-card" },
              [
                _c(
                  "div",
                  {
                    staticClass: "clearfix",
                    attrs: { slot: "header" },
                    slot: "header"
                  },
                  [_c("span", [_vm._v("订单详情")])]
                ),
                _c(
                  "el-main",
                  [
                    _c(
                      "el-row",
                      [
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("订单号:")
                          ]),
                          _vm._v(" " + _vm._s(_vm.orderBase.order_id) + " ")
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("订单状态:")
                          ]),
                          _vm._v(
                            " " + _vm._s(_vm.orderBase.order_status_name) + " "
                          )
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("代理人:")
                          ]),
                          _vm._v(" " + _vm._s(_vm.orderBase.member_name) + " ")
                        ])
                      ],
                      1
                    ),
                    _c(
                      "el-row",
                      [
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("保险公司:")
                          ]),
                          _vm._v(" " + _vm._s(_vm.orderBase.supplierName) + " ")
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("计划名称:")
                          ]),
                          _vm._v(" " + _vm._s(_vm.orderBase.programName) + " ")
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("险种名称:")
                          ]),
                          _vm._v(" " + _vm._s(_vm.orderBase.product_name) + " ")
                        ]),
                        _c("el-col", { attrs: { span: 8 } })
                      ],
                      1
                    ),
                    _c(
                      "el-row",
                      [
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("订单生成时间:")
                          ]),
                          _vm._v(" " + _vm._s(_vm.orderBase.create_date) + " ")
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("支付状态:")
                          ]),
                          _vm._v(
                            " " + _vm._s(_vm.orderBase.pay_status_name) + " "
                          )
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("份数:")
                          ]),
                          _vm._v(" " + _vm._s(_vm.orderBase.buy_copies) + " ")
                        ])
                      ],
                      1
                    ),
                    _c(
                      "el-row",
                      [
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("支付金额:")
                          ]),
                          _vm.orderBase.total_order_payment
                            ? _c("span", [
                                _vm._v(
                                  _vm._s(_vm.orderBase.total_order_payment) +
                                    " 元"
                                )
                              ])
                            : _vm._e()
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("保单金额:")
                          ]),
                          _vm.orderBase.total_order
                            ? _c("span", [
                                _vm._v(
                                  _vm._s(_vm.orderBase.total_order) + " 元"
                                )
                              ])
                            : _vm._e()
                        ])
                      ],
                      1
                    ),
                    _c(
                      "el-row",
                      [
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("开户行:")
                          ]),
                          _vm._v(" " + _vm._s(_vm.orderBase.openBank) + " ")
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("账户名:")
                          ]),
                          _vm._v(
                            " " + _vm._s(_vm.orderBase.bankSubmitName) + " "
                          )
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("银行账号:")
                          ]),
                          _vm._v(" " + _vm._s(_vm.orderBase.bankCode) + " ")
                        ])
                      ],
                      1
                    ),
                    _c("el-row")
                  ],
                  1
                )
              ],
              1
            ),
            _c(
              "el-card",
              { staticClass: "box-card" },
              [
                _c(
                  "div",
                  {
                    staticClass: "clearfix",
                    attrs: { slot: "header" },
                    slot: "header"
                  },
                  [_c("span", [_vm._v("保单信息")])]
                ),
                _c(
                  "el-main",
                  [
                    _c(
                      "el-row",
                      [
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("保单号:")
                          ]),
                          _vm._v(
                            " " + _vm._s(_vm.orderNewCovenant.policyNo) + " "
                          )
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("保单状态:")
                          ]),
                          _vm._v(
                            " " + _vm._s(_vm.orderNewCovenant.appStatus) + " "
                          )
                        ])
                      ],
                      1
                    ),
                    _vm._l(_vm.orderRisks, function(item, index) {
                      return [
                        _c("div", { key: index }, [
                          _c(
                            "div",
                            { staticClass: "baodan-item" },
                            [
                              _c(
                                "el-row",
                                [
                                  _c("el-col", { attrs: { span: 8 } }, [
                                    _c("span", { staticClass: "col-title" }, [
                                      _vm._v("险种名称:")
                                    ]),
                                    _vm._v(
                                      " " +
                                        _vm._s(
                                          _vm.orderRisks[index].productName
                                        ) +
                                        " "
                                    )
                                  ]),
                                  _c("el-col", { attrs: { span: 8 } }, [
                                    _c("span", { staticClass: "col-title" }, [
                                      _vm._v("是否主险:")
                                    ]),
                                    _vm._v(
                                      " " +
                                        _vm._s(
                                          _vm.orderRisks[index].mainRiskFlag
                                        ) +
                                        " "
                                    )
                                  ]),
                                  _c("el-col", { attrs: { span: 8 } }, [
                                    _c("span", { staticClass: "col-title" }, [
                                      _vm._v("保额:")
                                    ]),
                                    _vm.orderRisks[index].amnt
                                      ? _c("span", [
                                          _vm._v(
                                            _vm._s(_vm.orderRisks[index].amnt) +
                                              " 元"
                                          )
                                        ])
                                      : _vm._e()
                                  ])
                                ],
                                1
                              ),
                              _c(
                                "el-row",
                                [
                                  _c("el-col", { attrs: { span: 8 } }, [
                                    _c("span", { staticClass: "col-title" }, [
                                      _vm._v("缴费方式:")
                                    ]),
                                    _vm._v(
                                      " " +
                                        _vm._s(_vm.orderRisks[index].appType) +
                                        " "
                                    )
                                  ]),
                                  _c("el-col", { attrs: { span: 8 } }, [
                                    _c("span", { staticClass: "col-title" }, [
                                      _vm._v("缴费期间:")
                                    ]),
                                    _vm._v(
                                      " " +
                                        _vm._s(_vm.orderRisks[index].feeYear) +
                                        " "
                                    )
                                  ]),
                                  _c("el-col", { attrs: { span: 8 } }, [
                                    _c("span", { staticClass: "col-title" }, [
                                      _vm._v("保障时间:")
                                    ]),
                                    _vm._v(
                                      " " +
                                        _vm._s(_vm.orderRisks[index].period) +
                                        " "
                                    )
                                  ])
                                ],
                                1
                              ),
                              _c(
                                "el-row",
                                [
                                  _c("el-col", { attrs: { span: 8 } }, [
                                    _c("span", { staticClass: "col-title" }, [
                                      _vm._v("保费:")
                                    ]),
                                    _vm.orderRisks[index].premium
                                      ? _c("span", [
                                          _vm._v(
                                            _vm._s(
                                              _vm.orderRisks[index].premium
                                            ) + "元"
                                          )
                                        ])
                                      : _vm._e()
                                  ])
                                ],
                                1
                              )
                            ],
                            1
                          )
                        ])
                      ]
                    })
                  ],
                  2
                )
              ],
              1
            ),
            _c(
              "el-card",
              { staticClass: "box-card" },
              [
                _c(
                  "div",
                  {
                    staticClass: "clearfix",
                    attrs: { slot: "header" },
                    slot: "header"
                  },
                  [_c("span", [_vm._v("投保人信息")])]
                ),
                _c(
                  "el-main",
                  [
                    _c(
                      "el-row",
                      [
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("投保人:")
                          ]),
                          _vm._v(" " + _vm._s(_vm.orderPolicyHolder.name) + " ")
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("手机号码:")
                          ]),
                          _vm._v(
                            " " +
                              _vm._s(_vm.orderPolicyHolder.phoneNumber) +
                              " "
                          )
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("证件类型:")
                          ]),
                          _vm._v(
                            " " +
                              _vm._s(
                                _vm.orderPolicyHolder.certificateTypeName
                              ) +
                              " "
                          )
                        ])
                      ],
                      1
                    ),
                    _c(
                      "el-row",
                      [
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("证件号:")
                          ]),
                          _vm._v(
                            " " +
                              _vm._s(_vm.orderPolicyHolder.certificateNumber) +
                              " "
                          )
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("证件有效期:")
                          ]),
                          _vm.orderPolicyHolder.certificateValidityEnd != "" &&
                          _vm.orderPolicyHolder.certificateValidityEnd !=
                            null &&
                          _vm.orderPolicyHolder.certificateValidityEnd !=
                            "undefined"
                            ? _c("span", [
                                _vm._v(
                                  " " +
                                    _vm._s(
                                      _vm.orderPolicyHolder
                                        .certificateValidityStart
                                    ) +
                                    " 至 " +
                                    _vm._s(
                                      _vm.orderPolicyHolder
                                        .certificateValidityEnd
                                    ) +
                                    " "
                                )
                              ])
                            : _vm._e()
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("出生日期:")
                          ]),
                          _vm._v(
                            " " + _vm._s(_vm.orderPolicyHolder.birthday) + " "
                          )
                        ])
                      ],
                      1
                    ),
                    _c(
                      "el-row",
                      [
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("性别:")
                          ]),
                          _vm._v(
                            " " + _vm._s(_vm.orderPolicyHolder.sexName) + " "
                          )
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("通讯地址:")
                          ]),
                          _vm._v(
                            " " +
                              _vm._s(_vm.orderPolicyHolder.homeaddress) +
                              " "
                          )
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("详细地址:")
                          ]),
                          _vm._v(
                            " " + _vm._s(_vm.orderPolicyHolder.address) + " "
                          )
                        ])
                      ],
                      1
                    ),
                    _c(
                      "el-row",
                      [
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("电子邮箱:")
                          ]),
                          _vm._v(" " + _vm._s(_vm.orderPolicyHolder.mail) + " ")
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("国籍:")
                          ]),
                          _vm._v(
                            " " +
                              _vm._s(_vm.orderPolicyHolder.nationalityname) +
                              " "
                          )
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _vm.orderPolicyHolder.occupationName
                            ? _c("span", { staticClass: "col-title" }, [
                                _vm._v("从事职业名称:")
                              ])
                            : _vm._e(),
                          _vm._v(
                            " " +
                              _vm._s(_vm.orderPolicyHolder.occupationName) +
                              " "
                          )
                        ])
                      ],
                      1
                    ),
                    _c("el-row")
                  ],
                  1
                )
              ],
              1
            ),
            _c(
              "el-card",
              { staticClass: "box-card" },
              [
                _c(
                  "div",
                  {
                    staticClass: "clearfix",
                    attrs: { slot: "header" },
                    slot: "header"
                  },
                  [_c("span", [_vm._v("被保人信息")])]
                ),
                _c(
                  "el-main",
                  [
                    _vm._l(_vm.orderInsureds, function(item, index) {
                      return [
                        _c(
                          "div",
                          { key: index },
                          [
                            _c(
                              "el-row",
                              [
                                _c("el-col", { attrs: { span: 8 } }, [
                                  _c("span", { staticClass: "col-title" }, [
                                    _vm._v("被保人:")
                                  ]),
                                  _vm._v(" " + _vm._s(item.name) + " ")
                                ]),
                                _c("el-col", { attrs: { span: 8 } }, [
                                  _c("span", { staticClass: "col-title" }, [
                                    _vm._v("与投保人的关系:")
                                  ]),
                                  _vm._v(
                                    " " + _vm._s(item.holderRelationName) + " "
                                  )
                                ]),
                                _c("el-col", { attrs: { span: 8 } }, [
                                  _c("span", { staticClass: "col-title" }, [
                                    _vm._v("证件类型:")
                                  ]),
                                  _vm._v(
                                    " " + _vm._s(item.certificateTypeName) + " "
                                  )
                                ])
                              ],
                              1
                            ),
                            _c(
                              "el-row",
                              [
                                _c("el-col", { attrs: { span: 8 } }, [
                                  _c("span", { staticClass: "col-title" }, [
                                    _vm._v("证件号:")
                                  ]),
                                  _vm._v(
                                    " " + _vm._s(item.certificateNumber) + " "
                                  )
                                ]),
                                _c("el-col", { attrs: { span: 8 } }, [
                                  _c("span", { staticClass: "col-title" }, [
                                    _vm._v("证件有效期:")
                                  ]),
                                  item.certificateValidityEnd
                                    ? _c("span", [
                                        _vm._v(
                                          " " +
                                            _vm._s(
                                              item.certificateValidityStart
                                            ) +
                                            " 至 " +
                                            _vm._s(
                                              item.certificateValidityEnd
                                            ) +
                                            " "
                                        )
                                      ])
                                    : _vm._e()
                                ]),
                                _c("el-col", { attrs: { span: 8 } }, [
                                  _c("span", { staticClass: "col-title" }, [
                                    _vm._v("出生日期:")
                                  ]),
                                  _vm._v(" " + _vm._s(item.birthday) + " ")
                                ])
                              ],
                              1
                            ),
                            _c(
                              "el-row",
                              [
                                _c("el-col", { attrs: { span: 8 } }, [
                                  _c("span", { staticClass: "col-title" }, [
                                    _vm._v("性别:")
                                  ]),
                                  _vm._v(" " + _vm._s(item.sexName) + " ")
                                ]),
                                _c("el-col", { attrs: { span: 8 } }, [
                                  _c("span", { staticClass: "col-title" }, [
                                    _vm._v("通讯地址:")
                                  ]),
                                  _vm._v(" " + _vm._s(item.homeaddress) + " ")
                                ]),
                                _c("el-col", { attrs: { span: 8 } }, [
                                  _c("span", { staticClass: "col-title" }, [
                                    _vm._v("详细地址:")
                                  ]),
                                  _vm._v(" " + _vm._s(item.address) + " ")
                                ])
                              ],
                              1
                            ),
                            _c(
                              "el-row",
                              [
                                _c("el-col", { attrs: { span: 8 } }, [
                                  _c("span", { staticClass: "col-title" }, [
                                    _vm._v("电子邮箱:")
                                  ]),
                                  _vm._v(" " + _vm._s(item.mail) + " ")
                                ]),
                                _c("el-col", { attrs: { span: 8 } }, [
                                  _c("span", { staticClass: "col-title" }, [
                                    _vm._v("手机号码:")
                                  ]),
                                  _vm._v(" " + _vm._s(item.phoneNumber) + " ")
                                ]),
                                _c("el-col", { attrs: { span: 8 } }, [
                                  _c("span", { staticClass: "col-title" }, [
                                    _vm._v("国籍:")
                                  ]),
                                  _vm._v(
                                    " " + _vm._s(item.nationalityname) + " "
                                  )
                                ])
                              ],
                              1
                            ),
                            _c(
                              "el-row",
                              [
                                _c("el-col", { attrs: { span: 8 } }, [
                                  item.occupationName
                                    ? _c("span", { staticClass: "col-title" }, [
                                        _vm._v("从事职业名称:")
                                      ])
                                    : _vm._e(),
                                  _vm._v(
                                    " " + _vm._s(item.occupationName) + " "
                                  )
                                ])
                              ],
                              1
                            )
                          ],
                          1
                        )
                      ]
                    })
                  ],
                  2
                )
              ],
              1
            ),
            _c("el-card", { staticClass: "box-card" }, [
              _vm.isLegar === "N"
                ? _c(
                    "div",
                    [
                      _c(
                        "div",
                        {
                          staticClass: "clearfix",
                          attrs: { slot: "header" },
                          slot: "header"
                        },
                        [_c("span", [_vm._v("受益人信息")])]
                      ),
                      _vm.orderBeneficiarys.length > 0
                        ? _c(
                            "el-main",
                            [
                              _vm._l(_vm.orderBeneficiarys, function(
                                item,
                                index
                              ) {
                                return [
                                  _c(
                                    "div",
                                    { key: index, staticClass: "baodan-item" },
                                    [
                                      _c(
                                        "el-col",
                                        {
                                          staticStyle: {
                                            "margin-bottom": "1.5%"
                                          },
                                          attrs: { span: 24 }
                                        },
                                        [
                                          _c(
                                            "span",
                                            { staticClass: "col-title" },
                                            [_vm._v("受益人顺序:")]
                                          ),
                                          _c("span", [
                                            _vm._v(_vm._s(item.bnfOrder))
                                          ])
                                        ]
                                      ),
                                      _c(
                                        "el-row",
                                        [
                                          _c("el-col", { attrs: { span: 8 } }, [
                                            _c(
                                              "span",
                                              { staticClass: "col-title" },
                                              [_vm._v("受益人:")]
                                            ),
                                            _vm._v(
                                              " " + _vm._s(item.name) + " "
                                            )
                                          ]),
                                          _c("el-col", { attrs: { span: 8 } }, [
                                            _c(
                                              "span",
                                              { staticClass: "col-title" },
                                              [_vm._v("与被保人的关系:")]
                                            ),
                                            _vm._v(
                                              " " +
                                                _vm._s(
                                                  item.insuredrelationname
                                                ) +
                                                " "
                                            )
                                          ]),
                                          _c("el-col", { attrs: { span: 8 } }, [
                                            _c(
                                              "span",
                                              { staticClass: "col-title" },
                                              [_vm._v("证件类型:")]
                                            ),
                                            _vm._v(
                                              " " +
                                                _vm._s(
                                                  item.certificateTypeName
                                                ) +
                                                " "
                                            )
                                          ])
                                        ],
                                        1
                                      ),
                                      _c(
                                        "el-row",
                                        [
                                          _c("el-col", { attrs: { span: 8 } }, [
                                            _c(
                                              "span",
                                              { staticClass: "col-title" },
                                              [_vm._v("证件号:")]
                                            ),
                                            _vm._v(
                                              " " +
                                                _vm._s(item.certificateNumber) +
                                                " "
                                            )
                                          ]),
                                          _c("el-col", { attrs: { span: 8 } }, [
                                            _c(
                                              "span",
                                              { staticClass: "col-title" },
                                              [_vm._v("证件有效期:")]
                                            ),
                                            _vm._v(
                                              " " +
                                                _vm._s(
                                                  item.certificateValidityStart
                                                ) +
                                                " 至 " +
                                                _vm._s(
                                                  item.certificatevalidityend
                                                ) +
                                                " "
                                            )
                                          ]),
                                          _c("el-col", { attrs: { span: 8 } }, [
                                            _c(
                                              "span",
                                              { staticClass: "col-title" },
                                              [_vm._v("出生日期:")]
                                            ),
                                            _vm._v(
                                              " " + _vm._s(item.birthday) + " "
                                            )
                                          ])
                                        ],
                                        1
                                      ),
                                      _c(
                                        "el-row",
                                        [
                                          _c("el-col", { attrs: { span: 8 } }, [
                                            _c(
                                              "span",
                                              { staticClass: "col-title" },
                                              [_vm._v("性别:")]
                                            ),
                                            _vm._v(
                                              " " + _vm._s(item.sexname) + " "
                                            )
                                          ]),
                                          _c("el-col", { attrs: { span: 8 } }, [
                                            _c(
                                              "span",
                                              { staticClass: "col-title" },
                                              [_vm._v("受益份额:")]
                                            ),
                                            _vm._v(
                                              " " + _vm._s(item.beneper) + " "
                                            )
                                          ])
                                        ],
                                        1
                                      )
                                    ],
                                    1
                                  )
                                ]
                              })
                            ],
                            2
                          )
                        : _vm._e()
                    ],
                    1
                  )
                : _vm._e(),
              _vm.isLegar === "Y" ? _c("div", [_vm._v("法定受益人")]) : _vm._e()
            ])
          ],
          1
        )
      ]),
      _c(
        "sdialog",
        { attrs: { config: _vm.specifyConfig } },
        [
          _c(
            "el-row",
            [
              _c(
                "el-col",
                { attrs: { span: 19 } },
                [
                  _c("el-input", {
                    attrs: { placeholder: "请输入代理人姓名" },
                    model: {
                      value: _vm.search.agentName,
                      callback: function($$v) {
                        _vm.$set(_vm.search, "agentName", $$v)
                      },
                      expression: "search.agentName"
                    }
                  })
                ],
                1
              ),
              _c(
                "el-col",
                { attrs: { offset: 1, span: 4 } },
                [
                  _c(
                    "el-button",
                    {
                      attrs: { type: "primary", icon: "el-icon-search" },
                      on: { click: _vm.searcj }
                    },
                    [_vm._v("搜索")]
                  )
                ],
                1
              )
            ],
            1
          ),
          _c("stable", {
            ref: "result",
            attrs: { config: _vm.spConfig, optionData: _vm.spOptionData }
          })
        ],
        1
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/core-js/internals/same-value.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/internals/same-value.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// `SameValue` abstract operation
// https://tc39.es/ecma262/#sec-samevalue
// eslint-disable-next-line es/no-object-is -- safe
module.exports = Object.is || function is(x, y) {
  // eslint-disable-next-line no-self-compare -- NaN check
  return x === y ? x !== 0 || 1 / x === 1 / y : x != x && y != y;
};


/***/ }),

/***/ "./node_modules/core-js/modules/es.array.filter.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es.array.filter.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var $filter = __webpack_require__(/*! ../internals/array-iteration */ "./node_modules/core-js/internals/array-iteration.js").filter;
var arrayMethodHasSpeciesSupport = __webpack_require__(/*! ../internals/array-method-has-species-support */ "./node_modules/core-js/internals/array-method-has-species-support.js");

var HAS_SPECIES_SUPPORT = arrayMethodHasSpeciesSupport('filter');

// `Array.prototype.filter` method
// https://tc39.es/ecma262/#sec-array.prototype.filter
// with adding support of @@species
$({ target: 'Array', proto: true, forced: !HAS_SPECIES_SUPPORT }, {
  filter: function filter(callbackfn /* , thisArg */) {
    return $filter(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es.object.get-own-property-descriptor.js":
/*!*******************************************************************************!*\
  !*** ./node_modules/core-js/modules/es.object.get-own-property-descriptor.js ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
var toIndexedObject = __webpack_require__(/*! ../internals/to-indexed-object */ "./node_modules/core-js/internals/to-indexed-object.js");
var nativeGetOwnPropertyDescriptor = __webpack_require__(/*! ../internals/object-get-own-property-descriptor */ "./node_modules/core-js/internals/object-get-own-property-descriptor.js").f;
var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/core-js/internals/descriptors.js");

var FAILS_ON_PRIMITIVES = fails(function () { nativeGetOwnPropertyDescriptor(1); });
var FORCED = !DESCRIPTORS || FAILS_ON_PRIMITIVES;

// `Object.getOwnPropertyDescriptor` method
// https://tc39.es/ecma262/#sec-object.getownpropertydescriptor
$({ target: 'Object', stat: true, forced: FORCED, sham: !DESCRIPTORS }, {
  getOwnPropertyDescriptor: function getOwnPropertyDescriptor(it, key) {
    return nativeGetOwnPropertyDescriptor(toIndexedObject(it), key);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es.object.get-own-property-descriptors.js":
/*!********************************************************************************!*\
  !*** ./node_modules/core-js/modules/es.object.get-own-property-descriptors.js ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/core-js/internals/descriptors.js");
var ownKeys = __webpack_require__(/*! ../internals/own-keys */ "./node_modules/core-js/internals/own-keys.js");
var toIndexedObject = __webpack_require__(/*! ../internals/to-indexed-object */ "./node_modules/core-js/internals/to-indexed-object.js");
var getOwnPropertyDescriptorModule = __webpack_require__(/*! ../internals/object-get-own-property-descriptor */ "./node_modules/core-js/internals/object-get-own-property-descriptor.js");
var createProperty = __webpack_require__(/*! ../internals/create-property */ "./node_modules/core-js/internals/create-property.js");

// `Object.getOwnPropertyDescriptors` method
// https://tc39.es/ecma262/#sec-object.getownpropertydescriptors
$({ target: 'Object', stat: true, sham: !DESCRIPTORS }, {
  getOwnPropertyDescriptors: function getOwnPropertyDescriptors(object) {
    var O = toIndexedObject(object);
    var getOwnPropertyDescriptor = getOwnPropertyDescriptorModule.f;
    var keys = ownKeys(O);
    var result = {};
    var index = 0;
    var key, descriptor;
    while (keys.length > index) {
      descriptor = getOwnPropertyDescriptor(O, key = keys[index++]);
      if (descriptor !== undefined) createProperty(result, key, descriptor);
    }
    return result;
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es.object.keys.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es.object.keys.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var toObject = __webpack_require__(/*! ../internals/to-object */ "./node_modules/core-js/internals/to-object.js");
var nativeKeys = __webpack_require__(/*! ../internals/object-keys */ "./node_modules/core-js/internals/object-keys.js");
var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");

var FAILS_ON_PRIMITIVES = fails(function () { nativeKeys(1); });

// `Object.keys` method
// https://tc39.es/ecma262/#sec-object.keys
$({ target: 'Object', stat: true, forced: FAILS_ON_PRIMITIVES }, {
  keys: function keys(it) {
    return nativeKeys(toObject(it));
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es.string.search.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/es.string.search.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var fixRegExpWellKnownSymbolLogic = __webpack_require__(/*! ../internals/fix-regexp-well-known-symbol-logic */ "./node_modules/core-js/internals/fix-regexp-well-known-symbol-logic.js");
var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/core-js/internals/an-object.js");
var requireObjectCoercible = __webpack_require__(/*! ../internals/require-object-coercible */ "./node_modules/core-js/internals/require-object-coercible.js");
var sameValue = __webpack_require__(/*! ../internals/same-value */ "./node_modules/core-js/internals/same-value.js");
var regExpExec = __webpack_require__(/*! ../internals/regexp-exec-abstract */ "./node_modules/core-js/internals/regexp-exec-abstract.js");

// @@search logic
fixRegExpWellKnownSymbolLogic('search', 1, function (SEARCH, nativeSearch, maybeCallNative) {
  return [
    // `String.prototype.search` method
    // https://tc39.es/ecma262/#sec-string.prototype.search
    function search(regexp) {
      var O = requireObjectCoercible(this);
      var searcher = regexp == undefined ? undefined : regexp[SEARCH];
      return searcher !== undefined ? searcher.call(regexp, O) : new RegExp(regexp)[SEARCH](String(O));
    },
    // `RegExp.prototype[@@search]` method
    // https://tc39.es/ecma262/#sec-regexp.prototype-@@search
    function (regexp) {
      var res = maybeCallNative(nativeSearch, regexp, this);
      if (res.done) return res.value;

      var rx = anObject(regexp);
      var S = String(this);

      var previousLastIndex = rx.lastIndex;
      if (!sameValue(previousLastIndex, 0)) rx.lastIndex = 0;
      var result = regExpExec(rx, S);
      if (!sameValue(rx.lastIndex, previousLastIndex)) rx.lastIndex = previousLastIndex;
      return result === null ? -1 : result.index;
    }
  ];
});


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/order-manage/orderList.vue?vue&type=style&index=0&id=29df8b9b&scoped=true&lang=less&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--10-oneOf-1-2!./node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/order-manage/orderList.vue?vue&type=style&index=0&id=29df8b9b&scoped=true&lang=less& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".container_ordermanage[data-v-29df8b9b] {\n  padding: 15px;\n}\n.search-grid-top[data-v-29df8b9b] {\n  display: grid;\n  grid-template-columns: repeat(4, 300px);\n  -moz-column-gap: 10px;\n       column-gap: 10px;\n  grid-template-rows: repeat(3, 50px);\n  grid-template-areas: 'a b c d' 'e f g h' 'i j k l';\n  align-items: center;\n  border-bottom: 40px solid #f4f4f5;\n  border-top: 40px solid #f4f4f5;\n}\n.search-grid-top .btn1[data-v-29df8b9b] {\n  height: 40px;\n}\n.search-grid-top > div[data-v-29df8b9b] {\n  height: 50px;\n  line-height: 50px;\n  display: flex;\n  flex-flow: row nowrap;\n}\n.search-grid-top > div span[data-v-29df8b9b] {\n  display: inline-block;\n  width: 100px;\n  padding-right: 10px;\n}\n.search-grid-top > div .item-right[data-v-29df8b9b] {\n  display: inline-block;\n  width: 190px;\n}\n.detaiConfig-wrap .el-header[data-v-29df8b9b] {\n  height: 40px !important;\n  font-size: 20px;\n  line-height: 40px;\n  border-bottom: 1px solid #cdcdcd;\n}\n.el-row[data-v-29df8b9b] {\n  margin: 5px 0;\n}\n.col-title[data-v-29df8b9b] {\n  color: #999;\n  padding-right: 7px;\n}\n.baodan-item[data-v-29df8b9b] {\n  border: 1px dashed #cdcdcd;\n  border-radius: 10px;\n  width: 99%;\n  margin: 10px auto;\n  padding: 10px;\n}\n.el-main[data-v-29df8b9b] {\n  padding: 10px 20px 20px 20px;\n}\n.el-main .el-row[data-v-29df8b9b] {\n  margin-bottom: 15px;\n}\n.box-card[data-v-29df8b9b] {\n  margin-bottom: 15px;\n}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/order-manage/orderList.vue?vue&type=style&index=0&id=29df8b9b&scoped=true&lang=less&":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--10-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--10-oneOf-1-2!./node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/order-manage/orderList.vue?vue&type=style&index=0&id=29df8b9b&scoped=true&lang=less& ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--10-oneOf-1-2!../../../node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../node_modules/vue-loader/lib??vue-loader-options!./orderList.vue?vue&type=style&index=0&id=29df8b9b&scoped=true&lang=less& */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/order-manage/orderList.vue?vue&type=style&index=0&id=29df8b9b&scoped=true&lang=less&");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("ec75d122", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/assets/staticFilter.js":
/*!************************************!*\
  !*** ./src/assets/staticFilter.js ***!
  \************************************/
/*! exports provided: classification, specialArea, recommend, bannerPlat, bannerPos, bannerStatus, picAddr, isUse, posterStatus, posterTypes, category, riskType, appStatus, verifyStatus, orderStatus, userType, status, userLocked, permissionType, goldType, picPostion, orderSource */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "classification", function() { return classification; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "specialArea", function() { return specialArea; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "recommend", function() { return recommend; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bannerPlat", function() { return bannerPlat; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bannerPos", function() { return bannerPos; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bannerStatus", function() { return bannerStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "picAddr", function() { return picAddr; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isUse", function() { return isUse; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "posterStatus", function() { return posterStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "posterTypes", function() { return posterTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "category", function() { return category; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "riskType", function() { return riskType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "appStatus", function() { return appStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "verifyStatus", function() { return verifyStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "orderStatus", function() { return orderStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "userType", function() { return userType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "status", function() { return status; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "userLocked", function() { return userLocked; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "permissionType", function() { return permissionType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "goldType", function() { return goldType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "picPostion", function() { return picPostion; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "orderSource", function() { return orderSource; });
//静态变量过滤器
//classification
var classification = {
  //图文分类
  '1': '图文',
  '2': '视频'
}; //specialArea

var specialArea = {
  //专区
  '0': '财富密码',
  '1': '保险知识',
  '2': '走进理赔'
}; //recommend

var recommend = {
  //推荐
  '0': '是',
  '1': '否'
}; //bannerPlat

var bannerPlat = {
  //所属平台
  '0': '小程序',
  '1': '公众号',
  '2': 'App'
}; //bannerPos

var bannerPos = {
  //位置
  '0': '首页banner图',
  '1': '轮播图'
}; //bannerStatus

var bannerStatus = {
  //状态
  '0': '已上架',
  '1': '未上架',
  '2': '已下架'
};
var picAddr = {
  '0': '公众号财报头条',
  '1': '公众号保险商城',
  '2': '小程序首页图片',
  '3': 'APP首页',
  '4': '产品库首页',
  '5': '弹窗图'
};
var isUse = {
  //状态
  '0': '未使用',
  '1': '已上架'
};
var posterStatus = {
  '0': '未使用',
  '1': '已上架',
  '2': '已下架'
};
var posterTypes = {
  '1': '问候',
  '2': '理念',
  '3': '励志',
  '4': '增员',
  '5': '节日',
  '6': '理财'
}; //category

var category = {
  //状态
  '1': '公司新闻',
  '2': '行业动态'
}; //riskType

var riskType = {
  //保险类型、产品类型
  A: '企业财产险',
  B: '家庭财产险',
  C: '工程险',
  D: '船舶险',
  E: '农业险',
  F: '货物运输险',
  G: '责任险',
  O: '健康险',
  J: '综合险',
  K: '特殊风险险',
  L: '信用险',
  M: '保证险',
  X: '意外险',
  Y: '寿险',
  P: '失能险',
  Q: '护理险',
  R: '税收优惠健康险',
  S: '旅行意外伤害险',
  T: '长期意外伤害险',
  W: '两全险',
  N: '年金险',
  H: '财产险',
  Z: '全部产品'
}; //appStatus

var appStatus = {
  //保单状态
  UNINSURED: '未承保',
  ACPTINSD_FAILURE: '承保失败',
  ACPTINSD_SUCCESS: '承保成功',
  SURRENDER_SUCCESS: '犹豫期退保成功',
  REVISIT_FAILURE: '回访失败',
  REVISIT_SUCCESS: '已回访',
  RECEIPT_SUCCESS: '回执成功',
  VERIFY_SUCCESS: '核保成功',
  REFUNDPOLICY_SUCCESS: '退保终止'
};
var verifyStatus = {
  //核保状态
  UNVERIFY: '未核保',
  VERIFY_RIGHTOFF: '待核保',
  VERIFY_SUCCESS: '核保成功',
  VERIFY_FAILURE: '核保失败'
}; //orderStatus

var orderStatus = {
  //订单状态
  UNPROCESSED: '未处理',
  PROCESSE: '处理中',
  PROCESSED: '已处理',
  CLOSED: '已关闭'
}; //userType

var userType = {
  //订单状态
  N: '普通',
  T: '推客',
  A: '代理人'
}; //state

var status = {
  //订单状态
  Y: '有效',
  N: '无效'
}; //userLocked

var userLocked = {
  //账号是否锁定
  '1': '是',
  '0': '否'
}; //permissionType

var permissionType = {
  //账号是否锁定
  '1': '菜单',
  '2': '页面按钮',
  '3': '表格按钮'
};
var goldType = {
  Y: '是',
  N: '否'
}; //图片位置

var picPostion = {
  '0': '公众号财报头条',
  '1': '公众号保险商城',
  '2': '小程序首页图片'
}; //订单来源

var orderSource = {
  U: '渠道',
  C: '公众号',
  X: '小程序',
  A: 'app',
  S: '公众号'
};

/***/ }),

/***/ "./src/views/order-manage/orderList.vue":
/*!**********************************************!*\
  !*** ./src/views/order-manage/orderList.vue ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _orderList_vue_vue_type_template_id_29df8b9b_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./orderList.vue?vue&type=template&id=29df8b9b&scoped=true& */ "./src/views/order-manage/orderList.vue?vue&type=template&id=29df8b9b&scoped=true&");
/* harmony import */ var _orderList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./orderList.vue?vue&type=script&lang=js& */ "./src/views/order-manage/orderList.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _orderList_vue_vue_type_style_index_0_id_29df8b9b_scoped_true_lang_less___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./orderList.vue?vue&type=style&index=0&id=29df8b9b&scoped=true&lang=less& */ "./src/views/order-manage/orderList.vue?vue&type=style&index=0&id=29df8b9b&scoped=true&lang=less&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _orderList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _orderList_vue_vue_type_template_id_29df8b9b_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _orderList_vue_vue_type_template_id_29df8b9b_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "29df8b9b",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/order-manage/orderList.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/order-manage/orderList.vue?vue&type=script&lang=js&":
/*!***********************************************************************!*\
  !*** ./src/views/order-manage/orderList.vue?vue&type=script&lang=js& ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_12_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_orderList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--12-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../node_modules/vue-loader/lib??vue-loader-options!./orderList.vue?vue&type=script&lang=js& */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/order-manage/orderList.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_12_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_orderList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/order-manage/orderList.vue?vue&type=style&index=0&id=29df8b9b&scoped=true&lang=less&":
/*!********************************************************************************************************!*\
  !*** ./src/views/order-manage/orderList.vue?vue&type=style&index=0&id=29df8b9b&scoped=true&lang=less& ***!
  \********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_orderList_vue_vue_type_style_index_0_id_29df8b9b_scoped_true_lang_less___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--10-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--10-oneOf-1-2!../../../node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../node_modules/vue-loader/lib??vue-loader-options!./orderList.vue?vue&type=style&index=0&id=29df8b9b&scoped=true&lang=less& */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/order-manage/orderList.vue?vue&type=style&index=0&id=29df8b9b&scoped=true&lang=less&");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_orderList_vue_vue_type_style_index_0_id_29df8b9b_scoped_true_lang_less___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_orderList_vue_vue_type_style_index_0_id_29df8b9b_scoped_true_lang_less___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_orderList_vue_vue_type_style_index_0_id_29df8b9b_scoped_true_lang_less___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_orderList_vue_vue_type_style_index_0_id_29df8b9b_scoped_true_lang_less___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/order-manage/orderList.vue?vue&type=template&id=29df8b9b&scoped=true&":
/*!*****************************************************************************************!*\
  !*** ./src/views/order-manage/orderList.vue?vue&type=template&id=29df8b9b&scoped=true& ***!
  \*****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_orderList_vue_vue_type_template_id_29df8b9b_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"b9734f90-vue-loader-template"}!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../node_modules/vue-loader/lib??vue-loader-options!./orderList.vue?vue&type=template&id=29df8b9b&scoped=true& */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"b9734f90-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/order-manage/orderList.vue?vue&type=template&id=29df8b9b&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_orderList_vue_vue_type_template_id_29df8b9b_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_orderList_vue_vue_type_template_id_29df8b9b_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=9.js.map