(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[57],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/reguser-manage/reguserList.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--12-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/reguser-manage/reguserList.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! regenerator-runtime/runtime.js */ "./node_modules/regenerator-runtime/runtime.js");
/* harmony import */ var regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _api_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/api/api */ "./src/api/api.js");
/* harmony import */ var _assets_staticFilter__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/assets/staticFilter */ "./src/assets/staticFilter.js");


//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
 //导入请求

 //静态数据过滤器

/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      commands: [["#409eff", "编辑", "handleRowUpdata", "el-icon-edit", "zyUser-edit"], ["#67C23A", "设置/取消 金牌", "configusergold", "el-icon-setting", "zyUser-goldenAgent-set"], ["#FF3A30", "启用/禁用", "checkEnable", "el-icon-link", "zyUser-qiyong"]],
      SEtime: [],
      //时间数据保存
      searchForm: {//查询表单
      },
      upDataForm: {//编辑的表单
      },
      exportForm: {//条件导出的表单
      },
      goldData: {
        //金牌代理人信息
        goldenRecommend: '0',
        goldenSort: '1',
        itemData: {} //当前点击的数据

      },
      tbConfig: {
        //表格组件配置项
        height: "530px",
        // table高度
        select: false,
        // 是否可以多选择
        isSingleSelect: false,
        //是否可以单选o
        isCommands: true,
        //是否需要操作列
        isOrder: true,
        commandsWidth: "200",
        //操作列宽度
        showPagenation: true,
        //是否需要显示分页器
        layout: "total , prev, pager, next, jumper",
        //分页器控件
        requestCurData: true,
        // 每次分页数据是否请求后台 true:每次都请求后台
        columns: [// 后台字段属性、表头名、长度、颜色、是否过长隐藏、是否需要字典转换、点击事件的处理函数
        ["name", "用户姓名", "", "", true, false], ["phone", "用户手机号", "", "", true, false], ["userType", "用户类型", "", "", true, true], ["belongAgentName", "所属代理人", "", "", true, false], ["goldenType", "金牌", "", "", true, true], // ["status", "用户状态", "", "", true, true],
        ["certNo", "证件号码", "200", "", true, false], ["regDate", "注册时间", "", "", true, false]],
        commands: []
      },
      tbOptionData: {
        currentTableData: [],
        //当前表格数据
        TransValtoDesc: 'dataFilter',
        //数据字典过滤函数
        selectData: 'handleSelect',
        //单选处理函数
        selectDatas: 'handleSelects',
        //多选处理函数
        sizesCtrl: [5, 10, 20, 30, 40, 50, 100],
        //分页器控件的长度控制器
        pageSize: 10,
        // 每页行数
        currentPage: 1,
        // 当前页
        total: 0,
        //总数据量
        pagenationChange: 'handlPageChange' //处理分页器长度改变或页码改变的函数

      },
      userphone: '',
      //用户手机号
      goladialog: false,
      detailConfig: {
        //编辑列表弹窗组件配置项
        title: "基本信息",
        dialogVisible: false,
        width: "1200px",
        buttonPosition: "flex-end",
        ismodal: true,
        modalClose: false,
        Button: [{
          name: "取消",
          methods: "permCancel"
        }, {
          name: "保存",
          methods: "permDetermine",
          type: "primary"
        }]
      }
    };
  },
  methods: {
    dataFilter: function dataFilter(id, val, item) {
      switch (id) {
        case "goldenType":
          return this.goleMethod(val, item);
          break;

        case "userType":
          return _assets_staticFilter__WEBPACK_IMPORTED_MODULE_3__["userType"][val];
          break;
      }
    },
    onSubmit: function onSubmit() {
      //点击查询
      this.dataInit();
      this.exportForm = JSON.parse(JSON.stringify(this.searchForm));
    },
    goleMethod: function goleMethod(val, item) {
      var goldtext = '';

      if (item && val) {
        if (item.goldenRecommend == '0') {
          goldtext = '(不推荐)';
        } else if (item.goldenRecommend == '1') {
          if (item.goldenSort && item.goldenSort != null) {
            var step = [' ', '第一位', '第二位', '第三位'];
            goldtext = '(推荐)' + '(' + step[item.goldenSort] + ')';
          } else {
            goldtext = '(推荐)';
          }
        }

        return _assets_staticFilter__WEBPACK_IMPORTED_MODULE_3__["goldType"][val] + goldtext;
      }
    },
    handleRowUpdata: function handleRowUpdata(row) {
      //查看/编辑
      console.log("点击了查看/编辑", row);
      this.userphone = row.phone;
      this.goldData.itemData = row;
      var params = {
        visitId: row.visitId
      };
      this.searchAgentById(params);
      this.detailConfig.dialogVisible = true;
    },
    //代理人设置金牌
    configGold: function configGold() {
      var params = {
        agentCode: this.goldData.itemData.empNo,
        goldenRecommend: this.goldData.goldenRecommend,
        goldenSort: this.goldData.goldenSort
      };
      this.goldenAgentApi(params, 'config');
    },
    //设置取消金牌
    configusergold: function configusergold(row) {
      var _this = this;

      this.goldData.itemData = row;

      if (row.userType == 'A') {
        var mes = "";

        if (row.goldenType == 'N' || row.goldenType == '' || row.goldenType == 'null' || row.goldenType == null) {
          mes = "新增";
        } else {
          mes = '取消';
        }

        if (row.goldenType == "N" || row.goldenType == '' || row.goldenType == 'null' || row.goldenType == null) {
          this.goladialog = true; //设置金牌
        } else {
          //取消设置金牌
          this.confirm("\u786E\u5B9A".concat(mes, "\u8BE5\u4EE3\u7406\u4EBA\u7684\u91D1\u724C\u5417?"), "提示").then(function () {
            var params = {
              agentCode: row.empNo
            };

            _this.goldenAgentApi(params);
          });
        } // this.$confirm(`确定${mes}该代理人的金牌吗?`, "提示", {//这里需要根据row中传来的金牌字段判断提示信息中的mes是取消还是设置
        //   confirmButtonText: "确定",
        //   cancelButtonText: "取消",
        //   type: "warning",
        // }).then(() => {
        //   let params = { agentCode: row.empNo}
        //   this.goldenAgentApi(params)
        // })

      } else {
        this.alert("仅支持代理人设置金牌");
      }
    },
    goldenAgentApi: function goldenAgentApi(params, type) {
      var _this2 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
        var result;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return Object(_api_api__WEBPACK_IMPORTED_MODULE_2__["goldenAgentApi"])(params, type);

              case 2:
                result = _context.sent;

                if (result.code == 200) {
                  if (type == 'config') {
                    _this2.goladialog = false;
                  }

                  _this2.$message({
                    type: "success",
                    message: "操作成功"
                  });

                  _this2.dataInit();
                }

              case 4:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    permCancel: function permCancel() {
      //弹窗取消
      this.detailConfig.dialogVisible = false;
    },
    permDetermine: function permDetermine() {
      //弹窗保存
      var data = JSON.parse(JSON.stringify(this.upDataForm));
      this.editAgentById(data);
    },
    handlPageChange: function handlPageChange(cur, size) {
      var params = JSON.parse(JSON.stringify(this.searchForm));
      params.pageNum = cur;
      params.pageSize = this.tbOptionData.pageSize;
      this.searchAgentList(params);
    },
    checkEnable: function checkEnable(row) {
      var _this3 = this;

      //启用禁用按钮
      console.log('点击了启用/禁用', row);
      this.confirm("确定启用或禁用这个用户吗?", "提示").then(function () {
        var params = {
          visitId: row.visitId
        };

        _this3.updateAgentStatus(params);
      });
    },
    handleExport: function handleExport() {
      // excel导出
      var params = JSON.parse(JSON.stringify(this.exportForm));
      console.log("打印的导出参数", params);
      this.$confirm("确定修改吗？", "提示").then(function () {
        Object(_api_api__WEBPACK_IMPORTED_MODULE_2__["adminExportUser"])(params);
      }); // import('../../vendor/Export2Excel').then(excel => {
      //   const tHeader = ['序号', '用户姓名', '用户手机号', '用户类型', '用户状态', '注册时间',];
      //   const filterVal = ['id', 'name', 'type', 'DDZT', 'TBR', 'dataTime',];
      //   const list = this.resultData
      //   const data = list.map(v => filterVal.map(j => v[j]))
      //   excel.export_json_to_excel({
      //     header: tHeader,
      //     data,
      //     filename: '注册用户列表',
      //     autoWidth: this.autoWidth,
      //     bookType: this.bookType
      //   })
      // })
    },
    dataInit: function dataInit() {
      //列表数据更新
      if (this.searchForm.userType != 'A') {
        delete this.searchForm.goldenRecommend;
        delete this.searchForm.reserve3;
      }

      var params = JSON.parse(JSON.stringify(this.searchForm));
      params.pageNum = this.tbOptionData.currentPage;
      params.pageSize = this.tbOptionData.pageSize;
      this.searchAgentList(params);
    },
    searchAgentList: function searchAgentList(params) {
      var _this4 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
        var result;
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return Object(_api_api__WEBPACK_IMPORTED_MODULE_2__["searchAgentList"])(params);

              case 2:
                result = _context2.sent;

                if (result.code == 200) {
                  _this4.tbOptionData.currentTableData = result.data.records;
                  _this4.tbOptionData.total = result.data.total;
                }

              case 4:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    searchAgentById: function searchAgentById(params) {
      var _this5 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
        var result;
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.next = 2;
                return Object(_api_api__WEBPACK_IMPORTED_MODULE_2__["searchAgentById"])(params);

              case 2:
                result = _context3.sent;

                if (result.code == 200) {
                  _this5.upDataForm = JSON.parse(JSON.stringify(result.data));
                }

              case 4:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3);
      }))();
    },
    updateAgentStatus: function updateAgentStatus(params) {
      var _this6 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
        var result;
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return Object(_api_api__WEBPACK_IMPORTED_MODULE_2__["updateAgentStatus"])(params);

              case 2:
                result = _context4.sent;

                if (result.code == 200) {
                  _this6.$message({
                    type: "success",
                    message: "操作成功"
                  });

                  _this6.dataInit();
                }

              case 4:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4);
      }))();
    },
    editAgentById: function editAgentById(data) {
      var _this7 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
        var result;
        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.next = 2;
                return Object(_api_api__WEBPACK_IMPORTED_MODULE_2__["editAgentById"])(data);

              case 2:
                result = _context5.sent;

                if (result.code == 200) {
                  _this7.$message({
                    type: "success",
                    message: "操作成功"
                  });

                  _this7.detailConfig.dialogVisible = false;

                  _this7.dataInit();
                }

              case 4:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5);
      }))();
    }
  },
  mounted: function mounted() {
    this.dataInit();
  },
  watch: {
    "SEtime": function SEtime(nval, oval) {
      this.searchForm.regDateStart = nval && nval[0] ? nval[0] : '';
      this.searchForm.regDateEnd = nval && nval[1] ? nval[1] : '';
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"b9734f90-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/reguser-manage/reguserList.vue?vue&type=template&id=057ae58a&scoped=true&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"b9734f90-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/reguser-manage/reguserList.vue?vue&type=template&id=057ae58a&scoped=true& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "container" },
    [
      _c("h3", [_vm._v("注册用户列表")]),
      _c("div", { staticClass: "search-grid-top" }, [
        _c("div", { staticStyle: { "grid-area": "a" } }, [
          _c("span", [_vm._v("用户姓名:")]),
          _c(
            "div",
            { staticClass: "item-right" },
            [
              _c("el-input", {
                attrs: { placeholder: "请输入内容", clearable: "" },
                model: {
                  value: _vm.searchForm.name,
                  callback: function($$v) {
                    _vm.$set(_vm.searchForm, "name", $$v)
                  },
                  expression: "searchForm.name"
                }
              })
            ],
            1
          )
        ]),
        _c("div", { staticStyle: { "grid-area": "b" } }, [
          _c("span", [_vm._v("用户手机:")]),
          _c(
            "div",
            { staticClass: "item-right" },
            [
              _c("el-input", {
                attrs: { placeholder: "请输入内容", clearable: "" },
                model: {
                  value: _vm.searchForm.phone,
                  callback: function($$v) {
                    _vm.$set(_vm.searchForm, "phone", $$v)
                  },
                  expression: "searchForm.phone"
                }
              })
            ],
            1
          )
        ]),
        _c("div", { staticStyle: { "grid-area": "c" } }, [
          _c("span", [_vm._v("证件号码:")]),
          _c(
            "div",
            { staticClass: "item-right" },
            [
              _c("el-input", {
                attrs: { placeholder: "请输入内容", clearable: "" },
                model: {
                  value: _vm.searchForm.idNo,
                  callback: function($$v) {
                    _vm.$set(_vm.searchForm, "idNo", $$v)
                  },
                  expression: "searchForm.idNo"
                }
              })
            ],
            1
          )
        ]),
        _c("div", { staticStyle: { "grid-area": "d" } }, [
          _c("span", [_vm._v("用户类型:")]),
          _c(
            "div",
            { staticClass: "item-right" },
            [
              _c(
                "el-select",
                {
                  attrs: { clearable: "", placeholder: "请选择" },
                  model: {
                    value: _vm.searchForm.userType,
                    callback: function($$v) {
                      _vm.$set(_vm.searchForm, "userType", $$v)
                    },
                    expression: "searchForm.userType"
                  }
                },
                [
                  _c("el-option", { attrs: { label: "普通", value: "N" } }),
                  _c("el-option", { attrs: { label: "推客", value: "T" } }),
                  _c("el-option", { attrs: { label: "代理人", value: "A" } })
                ],
                1
              )
            ],
            1
          )
        ]),
        _vm.searchForm.userType == "A"
          ? _c("div", { staticStyle: { "grid-area": "e" } }, [
              _c("span", [_vm._v("是否金牌:")]),
              _c(
                "div",
                { staticClass: "item-right" },
                [
                  _c(
                    "el-radio-group",
                    {
                      model: {
                        value: _vm.searchForm.reserve3,
                        callback: function($$v) {
                          _vm.$set(_vm.searchForm, "reserve3", $$v)
                        },
                        expression: "searchForm.reserve3"
                      }
                    },
                    [
                      _c("el-radio", { attrs: { label: "Y" } }, [_vm._v("是")]),
                      _c("el-radio", { attrs: { label: "N" } }, [_vm._v("否")])
                    ],
                    1
                  )
                ],
                1
              )
            ])
          : _vm._e(),
        _vm.searchForm.userType == "A" && _vm.searchForm.reserve3 == "Y"
          ? _c("div", { staticStyle: { "grid-area": "f" } }, [
              _c("span", [_vm._v("是否推荐:")]),
              _c(
                "div",
                { staticClass: "item-right" },
                [
                  _c(
                    "el-radio-group",
                    {
                      model: {
                        value: _vm.searchForm.goldenRecommend,
                        callback: function($$v) {
                          _vm.$set(_vm.searchForm, "goldenRecommend", $$v)
                        },
                        expression: "searchForm.goldenRecommend"
                      }
                    },
                    [
                      _c("el-radio", { attrs: { label: "1" } }, [
                        _vm._v("推荐")
                      ]),
                      _c("el-radio", { attrs: { label: "0" } }, [
                        _vm._v("不推荐")
                      ])
                    ],
                    1
                  )
                ],
                1
              )
            ])
          : _vm._e(),
        _c("div", { staticStyle: { "grid-area": "g" } }, [
          _c("span", [_vm._v("注册时间:")]),
          _c(
            "div",
            { staticClass: "item-right" },
            [
              _c("el-date-picker", {
                staticStyle: { width: "475px" },
                attrs: {
                  type: "daterange",
                  "range-separator": "至",
                  "start-placeholder": "开始日期",
                  "end-placeholder": "结束日期"
                },
                model: {
                  value: _vm.SEtime,
                  callback: function($$v) {
                    _vm.SEtime = $$v
                  },
                  expression: "SEtime"
                }
              })
            ],
            1
          )
        ]),
        _c(
          "div",
          { staticStyle: { "grid-area": "h" } },
          [
            _c(
              "el-button",
              {
                attrs: { type: "primary", icon: "el-icon-search" },
                on: { click: _vm.onSubmit }
              },
              [_vm._v("查询 ")]
            ),
            _c(
              "el-button",
              {
                directives: [
                  {
                    name: "show",
                    rawName: "v-show",
                    value: _vm.pageButtons["zyUser-export"],
                    expression: "pageButtons['zyUser-export']"
                  }
                ],
                attrs: { type: "primary", icon: "el-icon-download", plain: "" },
                on: { click: _vm.handleExport }
              },
              [_vm._v("导出 ")]
            )
          ],
          1
        )
      ]),
      _c("stable", {
        ref: "result",
        attrs: { config: _vm.tbConfig, optionData: _vm.tbOptionData }
      }),
      _c(
        "sdialog",
        { attrs: { config: _vm.detailConfig } },
        [
          _c(
            "el-row",
            { staticClass: "el-row" },
            [
              _c("el-col", { attrs: { span: 2 } }, [
                _c("span", { staticClass: "strang" }, [_vm._v("用户姓名:")])
              ]),
              _c(
                "el-col",
                { attrs: { span: 4, offset: 1 } },
                [
                  _c("el-input", {
                    attrs: { disabled: "" },
                    model: {
                      value: _vm.upDataForm.userName,
                      callback: function($$v) {
                        _vm.$set(_vm.upDataForm, "userName", $$v)
                      },
                      expression: "upDataForm.userName"
                    }
                  })
                ],
                1
              ),
              _c("el-col", { attrs: { offset: 1, span: 2 } }, [
                _c("span", { staticClass: "strang" }, [_vm._v("用户类型:")])
              ]),
              _c(
                "el-col",
                { attrs: { span: 4, offset: 1 } },
                [
                  _c(
                    "el-select",
                    {
                      attrs: { placeholder: "请选择" },
                      model: {
                        value: _vm.upDataForm.userType,
                        callback: function($$v) {
                          _vm.$set(_vm.upDataForm, "userType", $$v)
                        },
                        expression: "upDataForm.userType"
                      }
                    },
                    [
                      _c("el-option", { attrs: { label: "普通", value: "N" } }),
                      _c("el-option", { attrs: { label: "推客", value: "T" } }),
                      _c("el-option", {
                        attrs: { label: "代理人", value: "A" }
                      })
                    ],
                    1
                  )
                ],
                1
              )
            ],
            1
          ),
          _c(
            "el-row",
            { staticClass: "el-row" },
            [
              _c("el-col", { attrs: { span: 2 } }, [
                _c("span", { staticClass: "strang" }, [_vm._v("证件类型:")])
              ]),
              _c(
                "el-col",
                { attrs: { span: 4, offset: 1 } },
                [
                  _c(
                    "el-select",
                    {
                      attrs: { placeholder: "请选择" },
                      model: {
                        value: _vm.upDataForm.certType,
                        callback: function($$v) {
                          _vm.$set(_vm.upDataForm, "certType", $$v)
                        },
                        expression: "upDataForm.certType"
                      }
                    },
                    [
                      _c("el-option", {
                        attrs: { label: "居民身份证", value: "1" }
                      }),
                      _c("el-option", { attrs: { label: "禁用", value: "2" } })
                    ],
                    1
                  )
                ],
                1
              ),
              _c("el-col", { attrs: { offset: 1, span: 2 } }, [
                _c("span", { staticClass: "strang" }, [_vm._v("证件号码:")])
              ]),
              _c(
                "el-col",
                { attrs: { span: 4, offset: 1 } },
                [
                  _c("el-input", {
                    model: {
                      value: _vm.upDataForm.certNo,
                      callback: function($$v) {
                        _vm.$set(_vm.upDataForm, "certNo", $$v)
                      },
                      expression: "upDataForm.certNo"
                    }
                  })
                ],
                1
              ),
              _c("el-col", { attrs: { offset: 1, span: 2 } }, [
                _c("span", { staticClass: "strang" }, [_vm._v("注册日期:")])
              ]),
              _c(
                "el-col",
                { attrs: { span: 4, offset: 1 } },
                [
                  _c("el-input", {
                    attrs: { disabled: "" },
                    model: {
                      value: _vm.upDataForm.regDate,
                      callback: function($$v) {
                        _vm.$set(_vm.upDataForm, "regDate", $$v)
                      },
                      expression: "upDataForm.regDate"
                    }
                  })
                ],
                1
              )
            ],
            1
          ),
          _c(
            "el-row",
            { staticClass: "el-row" },
            [
              _c("el-col", { attrs: { span: 2 } }, [
                _c("span", { staticClass: "strang" }, [_vm._v("出生日期:")])
              ]),
              _c(
                "el-col",
                { attrs: { span: 4, offset: 1 } },
                [
                  _c("el-input", {
                    attrs: { disabled: "" },
                    model: {
                      value: _vm.upDataForm.birthday,
                      callback: function($$v) {
                        _vm.$set(_vm.upDataForm, "birthday", $$v)
                      },
                      expression: "upDataForm.birthday"
                    }
                  })
                ],
                1
              ),
              _c("el-col", { attrs: { offset: 1, span: 2 } }, [
                _c("span", { staticClass: "strang" }, [_vm._v("性别:")])
              ]),
              _c(
                "el-col",
                { staticClass: "sexCol", attrs: { span: 4, offset: 1 } },
                [
                  _c(
                    "el-radio",
                    {
                      attrs: { label: "1" },
                      model: {
                        value: _vm.upDataForm.sex,
                        callback: function($$v) {
                          _vm.$set(_vm.upDataForm, "sex", $$v)
                        },
                        expression: "upDataForm.sex"
                      }
                    },
                    [_vm._v("男 ")]
                  ),
                  _c(
                    "el-radio",
                    {
                      attrs: { label: "0" },
                      model: {
                        value: _vm.upDataForm.sex,
                        callback: function($$v) {
                          _vm.$set(_vm.upDataForm, "sex", $$v)
                        },
                        expression: "upDataForm.sex"
                      }
                    },
                    [_vm._v("女 ")]
                  )
                ],
                1
              ),
              _c("el-col", { attrs: { offset: 1, span: 2 } }, [
                _c("span", { staticClass: "strang" }, [_vm._v("联系地址:")])
              ]),
              _c(
                "el-col",
                { attrs: { span: 4, offset: 1 } },
                [
                  _c("el-input", {
                    model: {
                      value: _vm.upDataForm.address,
                      callback: function($$v) {
                        _vm.$set(_vm.upDataForm, "address", $$v)
                      },
                      expression: "upDataForm.address"
                    }
                  })
                ],
                1
              )
            ],
            1
          ),
          _c("el-row"),
          _c(
            "el-row",
            [
              _c("el-col", { attrs: { span: 2 } }, [
                _c("span", { staticClass: "strang" }, [_vm._v("用户手机号:")])
              ]),
              _c(
                "el-col",
                { attrs: { span: 4, offset: 1 } },
                [
                  _c("el-input", {
                    attrs: { disabled: "" },
                    model: {
                      value: _vm.userphone,
                      callback: function($$v) {
                        _vm.userphone = $$v
                      },
                      expression: "userphone"
                    }
                  })
                ],
                1
              ),
              _vm.upDataForm.userType == "A" &&
              _vm.goldData.itemData.goldenType == "Y"
                ? _c(
                    "div",
                    [
                      _c("el-col", { attrs: { offset: 1, span: 2 } }, [
                        _c("span", { staticClass: "strang" }, [
                          _vm._v("是否推荐:")
                        ])
                      ]),
                      _c(
                        "el-col",
                        {
                          staticStyle: { "line-height": "40px" },
                          attrs: { span: 4, offset: 1 }
                        },
                        [
                          _c(
                            "el-radio-group",
                            {
                              model: {
                                value: _vm.upDataForm.goldenRecommend,
                                callback: function($$v) {
                                  _vm.$set(
                                    _vm.upDataForm,
                                    "goldenRecommend",
                                    $$v
                                  )
                                },
                                expression: "upDataForm.goldenRecommend"
                              }
                            },
                            [
                              _c("el-radio", { attrs: { label: "1" } }, [
                                _vm._v("推荐")
                              ]),
                              _c("el-radio", { attrs: { label: "0" } }, [
                                _vm._v("不推荐")
                              ])
                            ],
                            1
                          )
                        ],
                        1
                      ),
                      _vm.upDataForm.goldenRecommend == "1"
                        ? _c(
                            "div",
                            [
                              _c("el-col", { attrs: { offset: 1, span: 2 } }, [
                                _c("span", { staticClass: "strang" }, [
                                  _vm._v("代理人排序")
                                ])
                              ]),
                              _c(
                                "el-col",
                                {
                                  staticStyle: { "line-height": "40px" },
                                  attrs: { span: 6 }
                                },
                                [
                                  _c(
                                    "el-radio-group",
                                    {
                                      model: {
                                        value: _vm.upDataForm.goldenSort,
                                        callback: function($$v) {
                                          _vm.$set(
                                            _vm.upDataForm,
                                            "goldenSort",
                                            $$v
                                          )
                                        },
                                        expression: "upDataForm.goldenSort"
                                      }
                                    },
                                    [
                                      _c(
                                        "el-radio",
                                        { attrs: { label: "1" } },
                                        [_vm._v("第一位")]
                                      ),
                                      _c(
                                        "el-radio",
                                        { attrs: { label: "2" } },
                                        [_vm._v("第二位")]
                                      ),
                                      _c(
                                        "el-radio",
                                        { attrs: { label: "3" } },
                                        [_vm._v("第三位")]
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ],
                            1
                          )
                        : _vm._e()
                    ],
                    1
                  )
                : _vm._e()
            ],
            1
          )
        ],
        1
      ),
      _c(
        "el-dialog",
        {
          attrs: {
            title: "确定要设置金牌代理人么？",
            visible: _vm.goladialog,
            width: "30%"
          },
          on: {
            "update:visible": function($event) {
              _vm.goladialog = $event
            }
          }
        },
        [
          _c(
            "el-form",
            { attrs: { "label-width": "80px" } },
            [
              _c(
                "el-form-item",
                { attrs: { label: "是否推荐" } },
                [
                  _c(
                    "el-radio-group",
                    {
                      model: {
                        value: _vm.goldData.goldenRecommend,
                        callback: function($$v) {
                          _vm.$set(_vm.goldData, "goldenRecommend", $$v)
                        },
                        expression: "goldData.goldenRecommend"
                      }
                    },
                    [
                      _c("el-radio", { attrs: { label: "1" } }, [
                        _vm._v("推荐")
                      ]),
                      _c("el-radio", { attrs: { label: "0" } }, [
                        _vm._v("不推荐")
                      ])
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-form-item",
                { attrs: { label: "排序" } },
                [
                  _c(
                    "el-radio-group",
                    {
                      model: {
                        value: _vm.goldData.goldenSort,
                        callback: function($$v) {
                          _vm.$set(_vm.goldData, "goldenSort", $$v)
                        },
                        expression: "goldData.goldenSort"
                      }
                    },
                    [
                      _c("el-radio", { attrs: { label: "1" } }, [
                        _vm._v("第一位")
                      ]),
                      _c("el-radio", { attrs: { label: "2" } }, [
                        _vm._v("第二位")
                      ]),
                      _c("el-radio", { attrs: { label: "3" } }, [
                        _vm._v("第三位")
                      ])
                    ],
                    1
                  )
                ],
                1
              )
            ],
            1
          ),
          _c(
            "span",
            {
              staticClass: "dialog-footer",
              attrs: { slot: "footer" },
              slot: "footer"
            },
            [
              _c(
                "el-button",
                {
                  on: {
                    click: function($event) {
                      _vm.goladialog = false
                    }
                  }
                },
                [_vm._v("取 消")]
              ),
              _c(
                "el-button",
                { attrs: { type: "primary" }, on: { click: _vm.configGold } },
                [_vm._v("确 定")]
              )
            ],
            1
          )
        ],
        1
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/reguser-manage/reguserList.vue?vue&type=style&index=0&id=057ae58a&scoped=true&lang=scss&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--8-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--8-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--8-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/reguser-manage/reguserList.vue?vue&type=style&index=0&id=057ae58a&scoped=true&lang=scss& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".infoBox.el-message-box--center[data-v-057ae58a] {\n  z-index: 2020 !important;\n}\n.infoBox.el-message-box--center .el-message-box__title[data-v-057ae58a] {\n  display: flex;\n  justify-content: flex-start;\n}\n.infoBox.el-message-box--center .el-message-box__status[data-v-057ae58a] {\n  color: #409eff;\n}\n.infoBox.el-message-box--center .el-message-box__message[data-v-057ae58a] {\n  text-align: left;\n}\n.infoBox.el-message-box--center .el-message-box__btns[data-v-057ae58a] {\n  text-align: right;\n}\n.warningBox.el-message-box--center .el-message-box__title[data-v-057ae58a] {\n  display: flex;\n  justify-content: flex-start;\n}\n.warningBox.el-message-box--center .el-message-box__status[data-v-057ae58a] {\n  color: #ff3a30;\n}\n.warningBox.el-message-box--center .el-message-box__message[data-v-057ae58a] {\n  text-align: left;\n}\n.warningBox.el-message-box--center .el-message-box__btns[data-v-057ae58a] {\n  text-align: right;\n}\n.warningBox.el-message-box--center .el-message-box__btns button[data-v-057ae58a]:nth-child(2) {\n  background-color: #ff3a30;\n  border-color: #ff3a30;\n}\n.container[data-v-057ae58a] {\n  padding: 15px;\n}\n.search-grid-top[data-v-057ae58a] {\n  display: grid;\n  grid-template-columns: repeat(4, 275px);\n  -moz-column-gap: 20px;\n       column-gap: 20px;\n  grid-template-rows: repeat(3, 50px);\n  grid-template-areas: \"a b c \" \"d e f\" \"g g h\";\n  align-items: center;\n  border-bottom: 40px solid #f4f4f5;\n  border-top: 40px solid #f4f4f5;\n}\n.search-grid-top > div[data-v-057ae58a] {\n  height: 50px;\n  line-height: 50px;\n  display: flex;\n  justify-content: space-between;\n  justify-content: flex-start;\n  flex-flow: row nowrap;\n}\n.search-grid-top > div span[data-v-057ae58a] {\n  padding-right: 10px;\n  display: inline-block;\n  width: 80px;\n}\n.search-grid-top > div .item-right[data-v-057ae58a] {\n  display: inline-block;\n  width: 190px;\n}\n.strang[data-v-057ae58a],\n.main[data-v-057ae58a] {\n  font-size: 12px;\n  line-height: 40px;\n  font-weight: 600;\n}\n.main[data-v-057ae58a]::after {\n  content: \"*\";\n  color: red;\n}\n.el-row[data-v-057ae58a] {\n  margin: 10px 0;\n}\n.avatar-uploader .el-upload[data-v-057ae58a]:hover {\n  border-color: #409eff;\n}\n.avatar-uploader-icon[data-v-057ae58a] {\n  border: 1px dashed #d9d9d9;\n  border-radius: 6px;\n  font-size: 28px;\n  color: #8c939d;\n  width: 178px;\n  height: 178px;\n  line-height: 178px;\n  text-align: center;\n}\n.avatar[data-v-057ae58a] {\n  width: 178px;\n  height: 178px;\n  display: block;\n}\n.sexCol[data-v-057ae58a] {\n  padding-top: 10px;\n}\n.el-radio[data-v-057ae58a] {\n  margin-right: 7px;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/reguser-manage/reguserList.vue?vue&type=style&index=0&id=057ae58a&scoped=true&lang=scss&":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--8-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--8-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--8-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--8-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/reguser-manage/reguserList.vue?vue&type=style&index=0&id=057ae58a&scoped=true&lang=scss& ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--8-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--8-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--8-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../node_modules/vue-loader/lib??vue-loader-options!./reguserList.vue?vue&type=style&index=0&id=057ae58a&scoped=true&lang=scss& */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/reguser-manage/reguserList.vue?vue&type=style&index=0&id=057ae58a&scoped=true&lang=scss&");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("cdbcd9a6", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/assets/staticFilter.js":
/*!************************************!*\
  !*** ./src/assets/staticFilter.js ***!
  \************************************/
/*! exports provided: classification, specialArea, recommend, bannerPlat, bannerPos, bannerStatus, picAddr, isUse, posterStatus, posterTypes, category, riskType, appStatus, verifyStatus, orderStatus, userType, status, userLocked, permissionType, goldType, picPostion, orderSource */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "classification", function() { return classification; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "specialArea", function() { return specialArea; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "recommend", function() { return recommend; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bannerPlat", function() { return bannerPlat; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bannerPos", function() { return bannerPos; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bannerStatus", function() { return bannerStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "picAddr", function() { return picAddr; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isUse", function() { return isUse; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "posterStatus", function() { return posterStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "posterTypes", function() { return posterTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "category", function() { return category; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "riskType", function() { return riskType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "appStatus", function() { return appStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "verifyStatus", function() { return verifyStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "orderStatus", function() { return orderStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "userType", function() { return userType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "status", function() { return status; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "userLocked", function() { return userLocked; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "permissionType", function() { return permissionType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "goldType", function() { return goldType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "picPostion", function() { return picPostion; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "orderSource", function() { return orderSource; });
//静态变量过滤器
//classification
var classification = {
  //图文分类
  '1': '图文',
  '2': '视频'
}; //specialArea

var specialArea = {
  //专区
  '0': '财富密码',
  '1': '保险知识',
  '2': '走进理赔'
}; //recommend

var recommend = {
  //推荐
  '0': '是',
  '1': '否'
}; //bannerPlat

var bannerPlat = {
  //所属平台
  '0': '小程序',
  '1': '公众号',
  '2': 'App'
}; //bannerPos

var bannerPos = {
  //位置
  '0': '首页banner图',
  '1': '轮播图'
}; //bannerStatus

var bannerStatus = {
  //状态
  '0': '已上架',
  '1': '未上架',
  '2': '已下架'
};
var picAddr = {
  '0': '公众号财报头条',
  '1': '公众号保险商城',
  '2': '小程序首页图片',
  '3': 'APP首页',
  '4': '产品库首页',
  '5': '弹窗图'
};
var isUse = {
  //状态
  '0': '未使用',
  '1': '已上架'
};
var posterStatus = {
  '0': '未使用',
  '1': '已上架',
  '2': '已下架'
};
var posterTypes = {
  '1': '问候',
  '2': '理念',
  '3': '励志',
  '4': '增员',
  '5': '节日',
  '6': '理财'
}; //category

var category = {
  //状态
  '1': '公司新闻',
  '2': '行业动态'
}; //riskType

var riskType = {
  //保险类型、产品类型
  A: '企业财产险',
  B: '家庭财产险',
  C: '工程险',
  D: '船舶险',
  E: '农业险',
  F: '货物运输险',
  G: '责任险',
  O: '健康险',
  J: '综合险',
  K: '特殊风险险',
  L: '信用险',
  M: '保证险',
  X: '意外险',
  Y: '寿险',
  P: '失能险',
  Q: '护理险',
  R: '税收优惠健康险',
  S: '旅行意外伤害险',
  T: '长期意外伤害险',
  W: '两全险',
  N: '年金险',
  H: '财产险',
  Z: '全部产品'
}; //appStatus

var appStatus = {
  //保单状态
  UNINSURED: '未承保',
  ACPTINSD_FAILURE: '承保失败',
  ACPTINSD_SUCCESS: '承保成功',
  SURRENDER_SUCCESS: '犹豫期退保成功',
  REVISIT_FAILURE: '回访失败',
  REVISIT_SUCCESS: '已回访',
  RECEIPT_SUCCESS: '回执成功',
  VERIFY_SUCCESS: '核保成功',
  REFUNDPOLICY_SUCCESS: '退保终止'
};
var verifyStatus = {
  //核保状态
  UNVERIFY: '未核保',
  VERIFY_RIGHTOFF: '待核保',
  VERIFY_SUCCESS: '核保成功',
  VERIFY_FAILURE: '核保失败'
}; //orderStatus

var orderStatus = {
  //订单状态
  UNPROCESSED: '未处理',
  PROCESSE: '处理中',
  PROCESSED: '已处理',
  CLOSED: '已关闭'
}; //userType

var userType = {
  //订单状态
  N: '普通',
  T: '推客',
  A: '代理人'
}; //state

var status = {
  //订单状态
  Y: '有效',
  N: '无效'
}; //userLocked

var userLocked = {
  //账号是否锁定
  '1': '是',
  '0': '否'
}; //permissionType

var permissionType = {
  //账号是否锁定
  '1': '菜单',
  '2': '页面按钮',
  '3': '表格按钮'
};
var goldType = {
  Y: '是',
  N: '否'
}; //图片位置

var picPostion = {
  '0': '公众号财报头条',
  '1': '公众号保险商城',
  '2': '小程序首页图片'
}; //订单来源

var orderSource = {
  U: '渠道',
  C: '公众号',
  X: '小程序',
  A: 'app',
  S: '公众号'
};

/***/ }),

/***/ "./src/views/reguser-manage/reguserList.vue":
/*!**************************************************!*\
  !*** ./src/views/reguser-manage/reguserList.vue ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _reguserList_vue_vue_type_template_id_057ae58a_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./reguserList.vue?vue&type=template&id=057ae58a&scoped=true& */ "./src/views/reguser-manage/reguserList.vue?vue&type=template&id=057ae58a&scoped=true&");
/* harmony import */ var _reguserList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./reguserList.vue?vue&type=script&lang=js& */ "./src/views/reguser-manage/reguserList.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _reguserList_vue_vue_type_style_index_0_id_057ae58a_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./reguserList.vue?vue&type=style&index=0&id=057ae58a&scoped=true&lang=scss& */ "./src/views/reguser-manage/reguserList.vue?vue&type=style&index=0&id=057ae58a&scoped=true&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _reguserList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _reguserList_vue_vue_type_template_id_057ae58a_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _reguserList_vue_vue_type_template_id_057ae58a_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "057ae58a",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/reguser-manage/reguserList.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/reguser-manage/reguserList.vue?vue&type=script&lang=js&":
/*!***************************************************************************!*\
  !*** ./src/views/reguser-manage/reguserList.vue?vue&type=script&lang=js& ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_12_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_reguserList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--12-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../node_modules/vue-loader/lib??vue-loader-options!./reguserList.vue?vue&type=script&lang=js& */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/reguser-manage/reguserList.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_12_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_reguserList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/reguser-manage/reguserList.vue?vue&type=style&index=0&id=057ae58a&scoped=true&lang=scss&":
/*!************************************************************************************************************!*\
  !*** ./src/views/reguser-manage/reguserList.vue?vue&type=style&index=0&id=057ae58a&scoped=true&lang=scss& ***!
  \************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_8_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_8_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_reguserList_vue_vue_type_style_index_0_id_057ae58a_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--8-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--8-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--8-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--8-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../node_modules/vue-loader/lib??vue-loader-options!./reguserList.vue?vue&type=style&index=0&id=057ae58a&scoped=true&lang=scss& */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/reguser-manage/reguserList.vue?vue&type=style&index=0&id=057ae58a&scoped=true&lang=scss&");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_8_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_8_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_reguserList_vue_vue_type_style_index_0_id_057ae58a_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_8_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_8_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_reguserList_vue_vue_type_style_index_0_id_057ae58a_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_8_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_8_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_reguserList_vue_vue_type_style_index_0_id_057ae58a_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_8_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_8_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_reguserList_vue_vue_type_style_index_0_id_057ae58a_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/reguser-manage/reguserList.vue?vue&type=template&id=057ae58a&scoped=true&":
/*!*********************************************************************************************!*\
  !*** ./src/views/reguser-manage/reguserList.vue?vue&type=template&id=057ae58a&scoped=true& ***!
  \*********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_reguserList_vue_vue_type_template_id_057ae58a_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"b9734f90-vue-loader-template"}!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../node_modules/vue-loader/lib??vue-loader-options!./reguserList.vue?vue&type=template&id=057ae58a&scoped=true& */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"b9734f90-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/reguser-manage/reguserList.vue?vue&type=template&id=057ae58a&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_reguserList_vue_vue_type_template_id_057ae58a_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_reguserList_vue_vue_type_template_id_057ae58a_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=57.js.map