(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[68],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/channelPeople.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--12-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/mga-manage/channelPeople.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! regenerator-runtime/runtime.js */ "./node_modules/regenerator-runtime/runtime.js");
/* harmony import */ var regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/web.url.js */ "./node_modules/core-js/modules/web.url.js");
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.string.split.js */ "./node_modules/core-js/modules/es.string.split.js");
/* harmony import */ var core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _config_env__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @/config/env */ "./src/config/env.js");
/* harmony import */ var _api_api__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @/api/api */ "./src/api/api.js");
/* harmony import */ var _api_mgaApi__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/api/mgaApi */ "./src/api/mgaApi.js");
/* harmony import */ var api_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! api/common */ "./src/api/common.js");
/* harmony import */ var _common_MixinUtils__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @/common/MixinUtils */ "./src/common/MixinUtils.js");
/* harmony import */ var _common_dictionarieList_JoinApply__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @/common/dictionarieList/JoinApply */ "./src/common/dictionarieList/JoinApply.js");
/* harmony import */ var api_JoinApply__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! api/JoinApply */ "./src/api/JoinApply.js");











//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

 //导入请求
// todo api

 //导入请求

 // todo 导入混入




/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'channelPeople',
  mixins: [_common_MixinUtils__WEBPACK_IMPORTED_MODULE_15__["tableMixin"]],
  data: function data() {
    return {
      // 主动解约
      upAddress: api_common__WEBPACK_IMPORTED_MODULE_14__["FTPUpAddress"],
      acceptType: '',
      // application/msword,application/pdf
      noticeFiles: [],
      selectPeopleDate: {},
      //todo 表格展示数据
      tableDataOne: {
        resultData: [],
        needData: [['agentName', '代理人姓名', '', '', false, false], ['agentCode', '代理人编号', '', '', false, false]]
      },
      dialogVisible10: false,
      currentAgent: '',
      checkTitle: '初审结果',
      isShow: true,
      agentType: _common_dictionarieList_JoinApply__WEBPACK_IMPORTED_MODULE_16__["agentType"],
      isAllow: false,
      startCheck: {},
      auditType: _common_dictionarieList_JoinApply__WEBPACK_IMPORTED_MODULE_16__["auditType"],
      bank: [],
      editData: {},
      editDialog2: false,
      currentName: '入职终审',
      peopleInfo: '修改渠道人员',
      errorVisible: false,
      errorMessage: [],
      educationList: [{
        value: '11',
        label: '博士'
      }, {
        value: '17',
        label: '研究生'
      }, {
        value: '21',
        label: '本科'
      }, {
        value: '31',
        label: '大专'
      }],
      picUploadData: {
        midAddr: _config_env__WEBPACK_IMPORTED_MODULE_11__["uploadPicPath"].uploadfile
      },
      //上传图片的地址
      fileList: [],
      headers: {
        mimeType: 'multipart/form-data'
      },
      importAgentUrl: _api_api__WEBPACK_IMPORTED_MODULE_12__["importAgentUrl"],
      id: '',
      //设置角色时用户的id
      isEdit: false,
      searchForm: {},
      //搜索表单
      addForm: {
        identType: '01' //默认身份证类型是01

      },
      //新建表单
      tbConfig: {
        fixed: 'right',
        //表格组件配置项
        height: '530px',
        // table高度
        select: false,
        // 是否可以多选择
        isSingleSelect: false,
        //是否可以单选
        isCommands: true,
        //是否需要操作列
        commandsWidth: '300',
        //操作列宽度300
        isOrder: true,
        showPagenation: true,
        //是否需要显示分页器
        layout: 'total, prev, pager, next, jumper',
        //分页器控件
        requestCurData: true,
        // 每次分页数据是否请求后台 true:每次都请求后台
        columns: [// 后台字段属性、表头名、长度、颜色、是否过长隐藏、是否需要字典转换、点击事件的处理函数
        ['agentName', '姓名', '', '', true, false], ['agentCode', '人员编码', '', '', true, false], ['hxAgentCode', '销售人员编码', '', '', true, false], ['phone', '手机号', '', '', true, true], ['joinApplyDate', '申请日期', '', '', true, false], ['agentType', '人员类型', '', '', true, true], ['state', '在职状态', '', '', true, true], ['recommendName', '推荐人', '', '', true, true], ['channelCompanyName', '所属渠道公司', '', '', true, true], ['channelCompanyCode', '所属渠道公司编码', '', '', true, true], ['channelGroupName', '所属渠道团队', '', '', true, true], ['channelGroupCode', '所属渠道团队编码', '', '', true, true], ['isGroupLeader', '团队负责人', '', '', true, true], ['remark', '备注', '', '', true, true], ['firstAuditDate', '入职初审通过日期', '', '', true, true], ['joinAuditResult', '入职终审状态', '', '', true, true], ['joinAuditDate', '入职终审日期', '', '', true, true], ['joinAuditReason', '入职终审拒绝原因', '', '', true, true], ['resignFirstAuditDate', '离职初审时间', '', '', true, true], ['resignApplicationStatus', '离职申请提交状态', '', '', true, true], ['resignApplicationReason', '申请离职原因', '', '', true, true], ['resignFinalAuditResult', '离职终审状态', '', '', true, true], ['resignFinalAuditDate', '离职终审日期', '', '', true, true], ['resignFinalAuditReason', '离职终审拒绝原因', '200', '', true, true] // ["joinApplyType", "申请人类型", "", "", true, true],
        // ["joinAuditDate", "审核日期", "", "", true, true],
        // // ["state", "在职状态", "", "", true, true],
        // ["joinAuditResult", "审核状态", "", "", true, true],
        // ["joinAuditReason", "审核拒绝原因", "", "", true, true],
        ],
        // table行按钮：color 文字 处理点击的事件函数名  elementUicon
        commands: [['#409eff', '编辑', 'handleEdit', '', 'wxApplet-banner-update'], ['#409eff', '入职终审', 'auditSuccess', '', 'wxApplet-banner-update'], // ['#409eff', '导出离职申请表', 'export', '', 'wxApplet-banner-update'],
        ['#409eff', '离职终审', 'auditFail', '', 'wxApplet-banner-update'], ['#409eff', '主动解约', 'activeTermination', '', 'wxApplet-banner-update']]
      },
      tbOptionData: {
        selectData: '',
        //页面单选函数
        currentTableData: [],
        //当前表格数据
        TransValtoDesc: 'dataFilter',
        //数据字典过滤函数
        pageSize: 10,
        // 每页行数
        currentPage: 1,
        // 当前页
        total: 0,
        //总数据量
        pagenationChange: 'handlPageChange' //处理分页器长度改变或页码改变的函数

      },
      dialogVisible: false,
      //是否显示弹出框
      sdialogConfig: {
        //新增用户弹窗组件配置项
        dialogVisible: false,
        width: '590px',
        title: '新增渠道人员',
        buttonPosition: 'flex-end',
        ismodal: true,
        modalClose: false,
        Button: [{
          name: '取消',
          methods: 'addCancel'
        }, {
          name: '确定',
          methods: 'addDetermine',
          type: 'primary'
        }]
      },
      renderFunc: function renderFunc(h, option) {
        //穿梭框渲染函数
        return h('span', "\u6743\u9650".concat(option.id, " - ").concat(option.roleName, " "));
      },
      dialogFormVisible: false,
      tableData: [],
      //代理人类型区分
      receiverTypeList: [],
      rules: {},
      companyList: [],
      // 渠道公司列表
      groupList: [],
      //渠道团队列表
      joinAuditReason: '',
      //拒绝原因
      // 入职终审状态
      joinAuditResultList: [{
        value: '0',
        name: '待审核'
      }, {
        value: '1',
        name: '审核通过'
      }, {
        value: '2',
        name: '审核拒绝'
      }],
      // 离职申请提交状态
      resignFirstInstanceResultList: [{
        value: '0',
        name: '未离职'
      }, {
        value: '1',
        name: '未提交'
      }, {
        value: '2',
        name: '已提交'
      }],
      // 离职终审状态
      resignFinalReviewResultList: [{
        value: '0',
        name: '待审核'
      }, {
        value: '1',
        name: '通过'
      }, {
        value: '2',
        name: '拒绝'
      }],
      //在职状态
      stateList: [{
        value: '',
        name: '全部'
      }, {
        value: '1',
        name: '在职'
      }, {
        value: '0',
        name: '离职'
      }, {
        value: '2',
        name: '未入驻'
      }],
      // joinAuditResultList: [
      // 	{
      // 		value: '',
      // 		name: '全部'
      // 	},
      // 	{
      // 		value: '1',
      // 		name: '审核通过'
      // 	},
      // 	{
      // 		value: '2',
      // 		name: '审核拒绝'
      // 	},
      // 	{
      // 		value: '0',
      // 		name: '待审核'
      // 	}
      // ],
      //认证类型
      joinApplyTypeList: [{
        value: '',
        name: '全部'
      }, {
        value: '1',
        name: '签约'
      }, {
        value: '2',
        name: '认证'
      }],
      nationList: [],
      //民族列表
      msg: '',
      downParams: {},
      //下载使用参数
      currentCode: '',
      currentSelect: ''
    };
  },
  created: function created() {
    this.getSelectList(_api_mgaApi__WEBPACK_IMPORTED_MODULE_13__["getBank"], this.bank, 'dictCode', 'dictValue');
    this.dataInit();
    this.getCompanyList();
  },
  mounted: function mounted() {
    var _this = this;

    Object(_api_mgaApi__WEBPACK_IMPORTED_MODULE_13__["fValueBySKApi"])({
      dicttypeName: 'nation'
    }).then(function (res) {
      _this.nationList = res.data;
    });
  },
  computed: {
    isB: function isB() {
      return function (q) {
        return q.isEditAgentType === 'Y';
      };
    },
    isA: function isA() {
      return function (q) {
        return q.agentType === 'AGE';
      };
    },
    recommendAndIsAlone: function recommendAndIsAlone() {
      return function (q) {
        return q.agentType === 'DLA' && q.recommendCode !== '';
      };
    },
    noRecommendAndIsAlone: function noRecommendAndIsAlone() {
      return function (q) {
        return q.agentType === 'DLA' && q.recommendCode === '';
      };
    }
  },
  methods: {
    // * 查询代理人入离职信息（编辑等弹窗上边的信息）
    queryAgentInfo: function queryAgentInfo(row) {
      var _this2 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
        var result, res, _res;

        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                //请求参数
                _this2.addForm.agentCode = row.agentCode;
                _context.next = 3;
                return Object(_api_mgaApi__WEBPACK_IMPORTED_MODULE_13__["channelAgentDetailApi"])({
                  agentCode: row.agentCode
                });

              case 3:
                result = _context.sent;

                if (result.code === 200) {
                  _this2.addForm = result.data;
                }

                if (!(_this2.addForm.resignFinalAuditResult === '主动解约' && _this2.addForm.resignNotice && !_this2.addForm.initiativeBase64URL)) {
                  _context.next = 10;
                  break;
                }

                _context.next = 8;
                return Object(api_JoinApply__WEBPACK_IMPORTED_MODULE_17__["getInitiativeFtpBase64Address"])(_this2.addForm.resignNotice);

              case 8:
                res = _context.sent;
                _this2.lookData.initiativeBase64URL = res.slice(0, -1, 'application/pdf');

              case 10:
                if (!(_this2.addForm.resignApplicationStatus === '1' && !_this2.addForm.onlineLeaveBase64URL)) {
                  _context.next = 15;
                  break;
                }

                _context.next = 13;
                return Object(api_JoinApply__WEBPACK_IMPORTED_MODULE_17__["getOnlineLeaveFtpBase64Address"])(_this2.addForm.agentCode);

              case 13:
                _res = _context.sent;
                _this2.lookData.onlineLeaveBase64URL = _res.slice(0, -1, 'application/pdf');

              case 15:
                // 判断某些情况下不展示某些数据
                if (!(_this2.noRecommendAndIsAlone || _this2.recommendAndIsAlone)) {
                  _this2.$set(_this2.addForm, 'isTutor', '');

                  _this2.$set(_this2.addForm, 'isLecturer', '');

                  _this2.$set(_this2.addForm, 'tutorName', '');

                  _this2.$set(_this2.addForm, 'lecturerName', '');
                }

                if (!_this2.isB) {
                  _this2.$set(_this2.addForm, 'channelCompanyName', '');

                  _this2.$set(_this2.addForm, 'channelCompanyCode', '');
                }

              case 17:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    // * 点击编辑
    handleEdit: function handleEdit(row) {
      this.isEdit = true;
      this.dialogVisible = true;
      this.sdialogConfig.title = '修改渠道人员';
      this.currentAgent = row.agentType;
      this.peopleInfo = '修改渠道人员';
      this.queryAgentInfo(row);
    },
    // * 编辑后确定
    sureSelect: function sureSelect() {
      this.dialogVisible10 = false;

      switch (this.currentSelect) {
        case '导师':
          this.$set(this.addForm, 'tutorName', this.currentCode.agentName);
          this.$set(this.addForm, 'tutor', this.currentCode.agentCode);
          break;

        case '讲师':
          this.$set(this.addForm, 'lecturerName', this.currentCode.agentName);
          this.$set(this.addForm, 'lecturer', this.currentCode.agentCode);
          break;
      }
    },
    // * 入职终审 按钮
    auditSuccess: function auditSuccess(rows) {
      var _this3 = this;

      if (rows.joinAuditResult === '1' || rows.joinAuditResult === '2') {
        this.$message({
          message: '已审核，请勿重复操作'
        });
      } else {
        this.editDialog2 = true;
        this.currentName = '入职终审';
        this.checkTitle = '初审结果';
        this.startCheck = {};
        this.startCheck.auditType = 2;
        this.startCheck.agentCode = rows.agentCode;
        Object(api_JoinApply__WEBPACK_IMPORTED_MODULE_17__["getAgentDetail"])({
          agentCode: rows.agentCode
        }).then(function (res) {
          if (res.code === 200) {
            _this3.$set(_this3.startCheck, 'auditResult', res.data.joinAuditResult === '0' ? res.data.joinAuditResult = '' : res.data.joinAuditResult);

            _this3.$set(_this3.startCheck, 'auditReason', res.data.joinAuditReason);

            _this3.isAllow = res.data.joinAuditResult === '1';
            _this3.isShow = res.data.joinAuditResult !== '';
          }
        });
      }
    },
    // * 离职终审 按钮
    auditFail: function auditFail(rows) {
      if (rows.resignApplicationStatus === '未提交') {
        this.$message({
          message: '当前代理人并未提交离职申请。'
        });
        return;
      } else if (rows.resignApplicationStatus === '终止离职申请') {
        this.$message({
          message: '当前代理人已终止离职申请（主动撤销）。'
        });
        return;
      } else if (rows.resignFinalAuditResult === '审核通过') {
        this.$message({
          message: '当前代理人已离职终审审核通过。'
        });
        return;
      } else if (rows.resignFinalAuditResult === '主动解约') {
        this.$message({
          message: '当前代理人已主动解约。'
        });
        return;
      }

      this.queryAgentInfo(rows); // 改变标题打开弹窗

      this.peopleInfo = '离职终审';
      this.dialogVisible = true; // 是否禁用离职申请的填写状态

      this.isShow = false;
      this.isAllow = 1; // 处理数据

      this.addForm.agentCode = rows.agentCode;
    },
    // * 主动解约 按钮
    activeTermination: function activeTermination(row) {
      var _this4 = this;

      if (row.resignFinalAuditResult === '主动解约') {
        this.$message({
          message: '当前代理人已主动解约。'
        });
        return;
      } // 清空上传数据


      this.$nextTick().then(function (res) {
        _this4.$refs['upload-notice'].clearFiles();
      }); // 查询上方表格数据

      this.queryAgentInfo(row); // 打开窗口

      this.peopleInfo = '主动解约';
      this.dialogVisible = true; // 处理数据

      this.addForm.agentCode = row.agentCode;
      this.addForm.reason = row.reason;
      this.addForm.agentName = row.agentName;
    },
    // * 上传离职申请书
    clickNoticeFile: function clickNoticeFile(file) {
      var url = URL.createObjectURL(file.raw);
      window.open(url, '_blank');
      URL.revokeObjectURL(url);
      console.log(url);
    },
    upSuccess: function upSuccess(response, file, fileList) {
      this.addForm.resignNotice = file.response.data;
    },
    // * 点击保存
    saveAction: function saveAction() {
      var _this5 = this;

      switch (this.peopleInfo) {
        case '修改渠道人员':
          this.check('请输入名称', this.addForm.agentName);
          this.check('请输入身份证号码', this.addForm.identNo);
          this.check('请输入手机号码', this.addForm.phone);
          this.check('请输入入司时间', this.addForm.entryTime);

          if (this.addForm.agentType === 'CME') {
            this.check('请输入所属渠道公司的名称', this.addForm.channelCompanyName);
            this.check('请输入所属渠道团队名称', this.addForm.channelGroupName);
          }

          var _data = JSON.parse(JSON.stringify(this.addForm));

          this.addAction(_data);
          break;

        case '离职终审':
          this.check('终审结果为空', this.addForm.auditResult);

          if (!this.isAllow) {
            this.check('拒绝原因为空', this.addForm.auditReason);
          }

          Object(api_JoinApply__WEBPACK_IMPORTED_MODULE_17__["resignAuditResultApi"])(this.addForm.agentCode, this.addForm.auditResult, this.addForm.auditReason).then(function (res) {
            if (res.code === 200) {
              _this5.dialogVisible = false;

              _this5.$message({
                type: 'success',
                message: '审核成功'
              });

              _this5.dataInit();
            }
          });
          break;

        case '主动解约':
          if (!this.addForm.reason) {
            this.$message({
              type: 'error',
              message: '请填写主动解约原因!'
            });
            return;
          }

          this.$confirm("\u8BF7\u786E\u8BA4\u662F\u5426\u8981\u4E0E".concat(this.addForm.agentName, "\u89E3\u7EA6\uFF0C\u786E\u8BA4\u540E\u4E0D\u53EF\u64A4\u9500\uFF01"), '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(function () {
            Object(api_JoinApply__WEBPACK_IMPORTED_MODULE_17__["leaveTerminateTheContractApi"])(_this5.addForm.agentCode, _this5.addForm.reason, _this5.addForm.resignNotice).then(function (res) {
              if (res.code === 200) {
                _this5.dialogVisible = false;

                _this5.$message({
                  type: 'success',
                  message: '已经成功解约!'
                });
              }
            });
          }).catch(function () {
            _this5.$message({
              type: 'info',
              message: '已取消解约'
            });
          });
          break;

        default:
          break;
      }
    },
    // * 入职终审确定
    sure: function sure() {
      var _this6 = this;

      if (this.isAllow) {
        this.startCheck.auditReason = '';
      }

      switch (this.currentName) {
        case '入职终审':
          this.check('初审结果为空', this.startCheck.auditResult);

          if (!this.isAllow) {
            this.check('拒绝原因为空', this.startCheck.auditReason);
          }

          Object(api_JoinApply__WEBPACK_IMPORTED_MODULE_17__["getModifyResult"])(this.startCheck).then(function (res) {
            if (res.code === 200) {
              _this6.editDialog2 = false;

              _this6.$message({
                type: 'success',
                message: '审核成功'
              });

              _this6.dataInit();
            }
          });
          break;
      }
    },
    // * 去某个url
    goUrl: function goUrl(e, data) {
      var url;
      var iframe;
      var pdfFile;

      switch (e.target.firstChild.nodeValue) {
        case '身份证人像面':
          window.open(data.cardFrontUrl, '_blank');
          break;

        case '身份证国徽面':
          window.open(data.cardReverseUrl, '_blank');
          break;

        case '学历证照片':
          window.open(data.educationUrl, '_blank');
          break;

        case '1寸免冠照片':
          window.open(data.personalPicUrl, '_blank');
          break;

        case '线上离职申请表':
          if (!data.onlineLeaveBase64URL) return;
          window.open(URL.createObjectURL(data.onlineLeaveBase64URL), 'pdf');
          break;

        case '主动解约文件':
          if (!data.initiativeBase64URL) return;
          window.open(URL.createObjectURL(data.initiativeBase64URL), 'pdf');
          break;
      }
    },
    // * 模版下载
    downLoad: function downLoad() {
      Object(api_common__WEBPACK_IMPORTED_MODULE_14__["download"])('', this.downParams);
    },
    // 人员类型值改变时候
    agentTypeHandle: function agentTypeHandle(v) {
      if (v !== 'DLA') {
        this.addForm.isTutor = '';
        this.addForm.isLecturer = '';
        this.addForm.tutorName = '';
        this.addForm.lecturerName = '';
      } else if (v === 'DLA') {
        queryData.agentType = 'DLA';
      }
    },
    // 点击选择导师讲师
    selectPeople: function selectPeople(e, v) {
      var _this7 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                if (!(v === '导师' && _this7.addForm.isTutor !== '0')) {
                  _context2.next = 2;
                  break;
                }

                return _context2.abrupt("return");

              case 2:
                if (!(v === '讲师' && _this7.addForm.isLecturer !== '0')) {
                  _context2.next = 4;
                  break;
                }

                return _context2.abrupt("return");

              case 4:
                _this7.currentSelect = v;
                _this7.dialogVisible10 = true;

                _this7.requestDeploy(1, v);

              case 7:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    //导师讲师表格查询
    requestDeploy: function requestDeploy(current, type) {
      switch (type) {
        case '导师':
          this.selectPeopleDate = {};
          this.selectPeopleDate.isTutorOrLecturer = 'T';
          break;

        case '讲师':
          this.selectPeopleDate = {};
          this.selectPeopleDate.isTutorOrLecturer = 'L';
          break;
      } //api、查询表格、页、表格数据、当前页、时间数组，过滤函数


      this.getList(_api_mgaApi__WEBPACK_IMPORTED_MODULE_13__["selectPeopleApi"], this.selectPeopleDate, this.pageOption, this.tableDataOne, current);
    },
    //!---------------------------------------------------旧
    handleSelectionChange: function handleSelectionChange(v) {
      this.currentCode = {
        agentName: v.agentName,
        agentCode: v.agentCode
      };
    },
    isYesOrNoLecturer: function isYesOrNoLecturer(v) {
      if (v === '1' && this.noRecommendAndIsAlone) {
        this.$set(this.addForm, 'lecturerName', this.addForm.agentName);
        this.$set(this.addForm, 'lecturer', this.addForm.agentCode);
      } else if (v === '0' && this.noRecommendAndIsAlone) {
        this.$set(this.addForm, 'lecturerName', '');
        this.$set(this.addForm, 'lecturer', '');
      }
    },
    isYesOrNoTutor: function isYesOrNoTutor(v) {
      if (v === '1' && this.noRecommendAndIsAlone) {
        this.$set(this.addForm, 'tutorName', this.addForm.agentName);
        this.$set(this.addForm, 'tutor', this.addForm.agentCode);
      } else if (v === '0' && this.noRecommendAndIsAlone) {
        this.$set(this.addForm, 'tutorName', '');
        this.$set(this.addForm, 'tutor', '');
      }
    },
    isAllowHandle: function isAllowHandle(val) {
      this.isAllow = val === '1';
    },
    handleClose: function handleClose() {
      this.errorMessage = [];
      this.errorVisible = false;
    },
    //更改渠道公司
    changChanelCompany: function changChanelCompany(val) {
      var _this8 = this;

      this.addForm.channelCompanyCode = val;
      this.companyList.map(function (item) {
        if (item.channelCompanyCode == val) {
          _this8.addForm.channelCompanyName = item.channelCompanyName;
        }
      });
      this.$set(this.addForm, 'channelGroupName', '');
      this.groupSelectList();
    },
    //更改渠道团队
    changeGroup: function changeGroup(val) {
      var _this9 = this;

      this.addForm.channelGroupCode = val;
      var arr = this.groupList.map(function (item) {
        if (item.channelGroupCode == val) {
          _this9.addForm.channelGroupName = item.channelGroupName;
        }
      });

      if (arr.length === 0) {
        console.log(111);
      }
    },
    //获取渠道公司列表
    getCompanyList: function getCompanyList() {
      var _this10 = this;

      var data = {
        model: '1'
      };
      Object(_api_mgaApi__WEBPACK_IMPORTED_MODULE_13__["companyListApi"])(data).then(function (res) {
        if (res.code === 200) {
          _this10.companyList = res.data;
        }
      });
    },
    //获取渠道团队
    groupSelectList: function groupSelectList() {
      var _this11 = this;

      var req = {
        channelCompanyCode: this.addForm.channelCompanyCode
      };
      Object(_api_mgaApi__WEBPACK_IMPORTED_MODULE_13__["groupSelectListApi"])(req).then(function (res) {
        console.log(res, '1111');
        _this11.groupList = res.data;
      });
    },
    //点击了新增
    handleAdd: function handleAdd() {
      this.addForm = {};
      this.isEdit = false;
      this.sdialogConfig.title = '新增渠道人员';
      this.addForm.agentCode = '';
      this.dialogVisible = true;
    },
    //新增保存
    addAction: function addAction(params) {
      var _this12 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
        var result;
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.next = 2;
                return Object(_api_mgaApi__WEBPACK_IMPORTED_MODULE_13__["channelAgentSaveApi"])(params);

              case 2:
                result = _context3.sent;

                if (result.code === 200) {
                  _this12.dialogVisible = false;
                  _this12.searchForm = {};

                  _this12.dataInit();

                  _this12.$message({
                    type: 'success',
                    message: '操作成功'
                  });

                  _this12.tbOptionData.currentTableData = data;
                  _this12.tbOptionData.total = result.data.total;
                }

              case 4:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3);
      }))();
    },
    //确认删除
    confiremAudit: function confiremAudit(data) {
      var _this13 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
        var result;
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return Object(_api_mgaApi__WEBPACK_IMPORTED_MODULE_13__["channelAgentAuditApi"])(data);

              case 2:
                result = _context4.sent;

                if (result.code === 200) {
                  _this13.dataInit();
                }

              case 4:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4);
      }))();
    },
    onSubmit: function onSubmit() {
      //查询
      this.tbOptionData.currentTableData = this.tableData;
      this.tbOptionData.currentPage = 1; //每次查询重置当前页

      this.dataInit();
    },
    handlPageChange: function handlPageChange(cur, size) {
      //页码改变
      var params = JSON.parse(JSON.stringify(this.searchForm));
      params.pageNum = cur;
      this.tbOptionData.currentPage = cur; //给当前页赋值

      params.pageSize = this.tbOptionData.pageSize;
      this.getList1(params);
    },
    //列表数据更新
    dataInit: function dataInit() {
      var params = JSON.parse(JSON.stringify(this.searchForm));
      params.pageNum = this.tbOptionData.currentPage; //当前页面

      params.pageSize = this.tbOptionData.pageSize; //没页显示的条数

      this.getList1(params);
    },
    //查询列表
    getList1: function getList1(params) {
      var _this14 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
        var result, _data2;

        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.next = 2;
                return Object(_api_mgaApi__WEBPACK_IMPORTED_MODULE_13__["channelAgentListApi"])(params);

              case 2:
                result = _context5.sent;

                if (result.code == 200) {
                  _data2 = JSON.parse(JSON.stringify(result.data.records));
                  _this14.tbOptionData.currentTableData = _data2;
                  _this14.tbOptionData.total = result.data.total;
                }

              case 4:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5);
      }))();
    },
    //模版导入成功
    uploadSuccess: function uploadSuccess(response, file, fileList) {
      console.log(response, 'response');

      if (response.code == '200') {
        this.dataInit();
        this.$message({
          type: 'success',
          message: '人员导入成功'
        });
      } else {
        var arr = response.msg.split(';');
        this.errorMessage = arr;
        this.errorVisible = true;
        console.log(arr); // this.$message({
        //   type: "error",
        //   message: response.msg,
        // });
      }
    },
    //table 过滤器
    dataFilter: function dataFilter(id, val) {
      //id代表字段名 val代表字段值
      switch (id) {
        case 'state':
          return val === '1' ? '在职' : '离职';

        case 'joinAuditResult':
          return val === '1' ? '审核通过' : val === '2' ? '审核拒绝' : val === '0' ? '待审核' : '';
          break;

        case 'joinApplyType':
          return val === '1' ? '签约' : val === '2' ? '认证' : '';
          break;

        case 'agentType':
          return val === 'CME' ? '小B渠道团队成员' : val === 'AGE' ? '普通小A代理人' : val === 'CMA' ? '小B渠道团队负责人' : val === 'DLA' ? '独代' : '';
          break;

        case 'isGroupLeader':
          return val === '0' ? '否' : val === '1' ? '是' : '';
          break;
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"b9734f90-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/channelPeople.vue?vue&type=template&id=340c4d30&":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"b9734f90-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/mga-manage/channelPeople.vue?vue&type=template&id=340c4d30& ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { attrs: { id: "container_channelPeople" } },
    [
      _c("div", { staticClass: "queryHeading" }, [_vm._v("查询条件")]),
      _c(
        "div",
        [
          _c(
            "el-form",
            {
              staticClass: "demo-form-inline",
              attrs: {
                inline: true,
                model: _vm.searchForm,
                "label-width": "120px"
              }
            },
            [
              _c(
                "el-form-item",
                { attrs: { label: "人员名称:" } },
                [
                  _c("el-input", {
                    attrs: { placeholder: "请输入内容", clearable: "" },
                    model: {
                      value: _vm.searchForm.agentName,
                      callback: function($$v) {
                        _vm.$set(_vm.searchForm, "agentName", $$v)
                      },
                      expression: "searchForm.agentName"
                    }
                  })
                ],
                1
              ),
              _c(
                "el-form-item",
                { attrs: { label: "人员编码:" } },
                [
                  _c("el-input", {
                    attrs: { placeholder: "请输入内容", clearable: "" },
                    model: {
                      value: _vm.searchForm.agentCode,
                      callback: function($$v) {
                        _vm.$set(_vm.searchForm, "agentCode", $$v)
                      },
                      expression: "searchForm.agentCode"
                    }
                  })
                ],
                1
              ),
              _c(
                "el-form-item",
                { attrs: { label: "销售人员编码:" } },
                [
                  _c("el-input", {
                    attrs: { placeholder: "请输入内容", clearable: "" },
                    model: {
                      value: _vm.searchForm.hxAgentCode,
                      callback: function($$v) {
                        _vm.$set(_vm.searchForm, "hxAgentCode", $$v)
                      },
                      expression: "searchForm.hxAgentCode"
                    }
                  })
                ],
                1
              ),
              _c(
                "el-form-item",
                { attrs: { label: "手机号:" } },
                [
                  _c("el-input", {
                    attrs: { placeholder: "请输入内容", clearable: "" },
                    model: {
                      value: _vm.searchForm.phone,
                      callback: function($$v) {
                        _vm.$set(_vm.searchForm, "phone", $$v)
                      },
                      expression: "searchForm.phone"
                    }
                  })
                ],
                1
              ),
              _c(
                "el-form-item",
                { attrs: { label: "身份证号:" } },
                [
                  _c("el-input", {
                    attrs: { placeholder: "请输入内容", clearable: "" },
                    model: {
                      value: _vm.searchForm.identNo,
                      callback: function($$v) {
                        _vm.$set(_vm.searchForm, "identNo", $$v)
                      },
                      expression: "searchForm.identNo"
                    }
                  })
                ],
                1
              ),
              _c(
                "el-form-item",
                { attrs: { label: "所属渠道公司名称:" } },
                [
                  _c("el-input", {
                    attrs: { placeholder: "请输入内容", clearable: "" },
                    model: {
                      value: _vm.searchForm.channelCompanyName,
                      callback: function($$v) {
                        _vm.$set(_vm.searchForm, "channelCompanyName", $$v)
                      },
                      expression: "searchForm.channelCompanyName"
                    }
                  })
                ],
                1
              ),
              _c(
                "el-form-item",
                { attrs: { label: "所属渠道团队名称:" } },
                [
                  _c("el-input", {
                    attrs: { placeholder: "请输入内容", clearable: "" },
                    model: {
                      value: _vm.searchForm.channelGroupName,
                      callback: function($$v) {
                        _vm.$set(_vm.searchForm, "channelGroupName", $$v)
                      },
                      expression: "searchForm.channelGroupName"
                    }
                  })
                ],
                1
              ),
              _c(
                "el-form-item",
                { attrs: { label: "入职终审状态:" } },
                [
                  _c(
                    "el-select",
                    {
                      attrs: { placeholder: "请选择", clearable: "" },
                      model: {
                        value: _vm.searchForm.joinAuditResult,
                        callback: function($$v) {
                          _vm.$set(_vm.searchForm, "joinAuditResult", $$v)
                        },
                        expression: "searchForm.joinAuditResult"
                      }
                    },
                    _vm._l(_vm.joinAuditResultList, function(item) {
                      return _c("el-option", {
                        key: item.value,
                        attrs: { label: item.name, value: item.value }
                      })
                    }),
                    1
                  )
                ],
                1
              ),
              _c(
                "el-form-item",
                { attrs: { label: "在职状态:" } },
                [
                  _c(
                    "el-select",
                    {
                      attrs: { placeholder: "请选择", clearable: "" },
                      model: {
                        value: _vm.searchForm.state,
                        callback: function($$v) {
                          _vm.$set(_vm.searchForm, "state", $$v)
                        },
                        expression: "searchForm.state"
                      }
                    },
                    _vm._l(_vm.stateList, function(item) {
                      return _c("el-option", {
                        key: item.value,
                        attrs: { label: item.name, value: item.value }
                      })
                    }),
                    1
                  )
                ],
                1
              ),
              _c(
                "el-form-item",
                { attrs: { label: "申请日期起期:" } },
                [
                  _c("el-date-picker", {
                    attrs: {
                      type: "date",
                      placeholder: "选择日期",
                      format: "yyyy-MM-dd",
                      "value-format": "yyyy-MM-dd"
                    },
                    model: {
                      value: _vm.searchForm.joinApplyDateStart,
                      callback: function($$v) {
                        _vm.$set(_vm.searchForm, "joinApplyDateStart", $$v)
                      },
                      expression: "searchForm.joinApplyDateStart"
                    }
                  })
                ],
                1
              ),
              _c(
                "el-form-item",
                { attrs: { label: "申请日期止期:" } },
                [
                  _c("el-date-picker", {
                    attrs: {
                      type: "date",
                      placeholder: "选择日期",
                      format: "yyyy-MM-dd",
                      "value-format": "yyyy-MM-dd"
                    },
                    model: {
                      value: _vm.searchForm.joinApplyDateEnd,
                      callback: function($$v) {
                        _vm.$set(_vm.searchForm, "joinApplyDateEnd", $$v)
                      },
                      expression: "searchForm.joinApplyDateEnd"
                    }
                  })
                ],
                1
              ),
              _c(
                "el-form-item",
                { attrs: { label: "离职终审日期起期:" } },
                [
                  _c("el-date-picker", {
                    attrs: {
                      type: "date",
                      placeholder: "选择日期",
                      format: "yyyy-MM-dd",
                      "value-format": "yyyy-MM-dd"
                    },
                    model: {
                      value: _vm.searchForm.resignFinalAuditDateBegin,
                      callback: function($$v) {
                        _vm.$set(
                          _vm.searchForm,
                          "resignFinalAuditDateBegin",
                          $$v
                        )
                      },
                      expression: "searchForm.resignFinalAuditDateBegin"
                    }
                  })
                ],
                1
              ),
              _c(
                "el-form-item",
                { attrs: { label: "离职终审日期止期:" } },
                [
                  _c("el-date-picker", {
                    attrs: {
                      type: "date",
                      placeholder: "选择日期",
                      format: "yyyy-MM-dd",
                      "value-format": "yyyy-MM-dd"
                    },
                    model: {
                      value: _vm.searchForm.resignFinalAuditDateEnd,
                      callback: function($$v) {
                        _vm.$set(_vm.searchForm, "resignFinalAuditDateEnd", $$v)
                      },
                      expression: "searchForm.resignFinalAuditDateEnd"
                    }
                  })
                ],
                1
              ),
              _c(
                "el-form-item",
                [
                  _c(
                    "el-button",
                    {
                      attrs: {
                        type: "primary",
                        icon: "el-icon-search",
                        size: "samll"
                      },
                      on: { click: _vm.onSubmit }
                    },
                    [_vm._v("查询")]
                  )
                ],
                1
              )
            ],
            1
          )
        ],
        1
      ),
      _c("div", { staticClass: "queryHeading" }, [_vm._v("查询结果")]),
      _c("stable", {
        ref: "result",
        attrs: { config: _vm.tbConfig, optionData: _vm.tbOptionData }
      }),
      _c(
        "el-dialog",
        {
          attrs: {
            title: _vm.peopleInfo,
            visible: _vm.dialogVisible,
            width: "60%"
          },
          on: {
            "update:visible": function($event) {
              _vm.dialogVisible = $event
            }
          }
        },
        [
          _c("Input", {
            attrs: { queryData: _vm.addForm },
            scopedSlots: _vm._u([
              {
                key: "up",
                fn: function(ref) {
                  var queryData = ref.queryData
                  return [
                    _c("div", { staticClass: "border" }, [
                      _c(
                        "div",
                        [
                          _c("div", { staticClass: "look_title" }, [
                            _c("span", [_vm._v("基础信息")])
                          ]),
                          _c(
                            "el-form",
                            {
                              attrs: {
                                "label-width": "250px",
                                model: queryData,
                                "label-position": "right",
                                inline: true,
                                "show-message": false
                              }
                            },
                            [
                              _c(
                                "el-form-item",
                                { attrs: { label: "姓名:", required: "" } },
                                [
                                  _c("el-input", {
                                    attrs: {
                                      placeholder: "请输入内容",
                                      clearable: "",
                                      disabled: ""
                                    },
                                    model: {
                                      value: queryData.agentName,
                                      callback: function($$v) {
                                        _vm.$set(queryData, "agentName", $$v)
                                      },
                                      expression: "queryData.agentName"
                                    }
                                  })
                                ],
                                1
                              ),
                              _c(
                                "el-form-item",
                                {
                                  attrs: { label: "身份证号码:", required: "" }
                                },
                                [
                                  _c("el-input", {
                                    attrs: {
                                      placeholder: "请输入内容",
                                      clearable: "",
                                      disabled: ""
                                    },
                                    model: {
                                      value: queryData.identNo,
                                      callback: function($$v) {
                                        _vm.$set(queryData, "identNo", $$v)
                                      },
                                      expression: "queryData.identNo"
                                    }
                                  })
                                ],
                                1
                              ),
                              _c(
                                "el-form-item",
                                { attrs: { label: "手机号:", required: "" } },
                                [
                                  _c("el-input", {
                                    attrs: {
                                      placeholder: "请输入内容",
                                      clearable: ""
                                    },
                                    model: {
                                      value: queryData.phone,
                                      callback: function($$v) {
                                        _vm.$set(queryData, "phone", $$v)
                                      },
                                      expression: "queryData.phone"
                                    }
                                  })
                                ],
                                1
                              ),
                              _c(
                                "el-form-item",
                                { attrs: { label: "邮箱:" } },
                                [
                                  _c("el-input", {
                                    attrs: {
                                      placeholder: "请输入内容",
                                      clearable: ""
                                    },
                                    model: {
                                      value: queryData.email,
                                      callback: function($$v) {
                                        _vm.$set(queryData, "email", $$v)
                                      },
                                      expression: "queryData.email"
                                    }
                                  })
                                ],
                                1
                              ),
                              _c(
                                "el-form-item",
                                { attrs: { label: "学历:" } },
                                [
                                  _c(
                                    "el-select",
                                    {
                                      attrs: {
                                        placeholder: "请选择",
                                        clearable: ""
                                      },
                                      model: {
                                        value: queryData.education,
                                        callback: function($$v) {
                                          _vm.$set(queryData, "education", $$v)
                                        },
                                        expression: "queryData.education"
                                      }
                                    },
                                    _vm._l(_vm.educationList, function(item) {
                                      return _c("el-option", {
                                        key: item.value,
                                        attrs: {
                                          label: item.label,
                                          value: item.value,
                                          clearable: ""
                                        }
                                      })
                                    }),
                                    1
                                  )
                                ],
                                1
                              ),
                              _c(
                                "el-form-item",
                                { attrs: { label: "民族:" } },
                                [
                                  _c(
                                    "el-select",
                                    {
                                      attrs: {
                                        placeholder: "请选择",
                                        clearable: ""
                                      },
                                      model: {
                                        value: queryData.nation,
                                        callback: function($$v) {
                                          _vm.$set(queryData, "nation", $$v)
                                        },
                                        expression: "queryData.nation"
                                      }
                                    },
                                    _vm._l(_vm.nationList, function(item) {
                                      return _c("el-option", {
                                        key: item.dictCode,
                                        attrs: {
                                          label: item.dictValue,
                                          value: item.dictCode,
                                          clearable: ""
                                        }
                                      })
                                    }),
                                    1
                                  )
                                ],
                                1
                              ),
                              _c(
                                "el-form-item",
                                { attrs: { label: "证件有效期:" } },
                                [
                                  _c("el-input", {
                                    attrs: {
                                      placeholder: "请输入内容",
                                      clearable: ""
                                    },
                                    model: {
                                      value: queryData.certExpiryDate,
                                      callback: function($$v) {
                                        _vm.$set(
                                          queryData,
                                          "certExpiryDate",
                                          $$v
                                        )
                                      },
                                      expression: "queryData.certExpiryDate"
                                    }
                                  })
                                ],
                                1
                              ),
                              _c(
                                "el-form-item",
                                { attrs: { label: "住址:" } },
                                [
                                  _c("el-input", {
                                    attrs: {
                                      type: "textarea",
                                      placeholder: "请输入内容",
                                      clearable: "",
                                      autosize: { minRows: 2, maxRows: 4 }
                                    },
                                    model: {
                                      value: queryData.addrees,
                                      callback: function($$v) {
                                        _vm.$set(queryData, "addrees", $$v)
                                      },
                                      expression: "queryData.addrees"
                                    }
                                  })
                                ],
                                1
                              ),
                              _c(
                                "el-form-item",
                                { attrs: { label: "人员编码:" } },
                                [
                                  _c("el-input", {
                                    attrs: {
                                      placeholder: "请输入内容",
                                      clearable: "",
                                      disabled: ""
                                    },
                                    model: {
                                      value: queryData.agentCode,
                                      callback: function($$v) {
                                        _vm.$set(queryData, "agentCode", $$v)
                                      },
                                      expression: "queryData.agentCode"
                                    }
                                  })
                                ],
                                1
                              ),
                              _c(
                                "el-form-item",
                                { attrs: { label: "人员类型:" } },
                                [
                                  _c(
                                    "el-select",
                                    {
                                      attrs: {
                                        disabled:
                                          _vm.isB(queryData) ||
                                          _vm.recommendAndIsAlone(queryData),
                                        clearable: "",
                                        placeholder: "请选择"
                                      },
                                      on: { change: _vm.agentTypeHandle },
                                      model: {
                                        value: queryData.agentType,
                                        callback: function($$v) {
                                          _vm.$set(queryData, "agentType", $$v)
                                        },
                                        expression: "queryData.agentType"
                                      }
                                    },
                                    _vm._l(_vm.agentType, function(item) {
                                      return _c("el-option", {
                                        key: item.value,
                                        attrs: {
                                          label: item.label,
                                          value: item.value,
                                          disabled: item.disabled
                                        }
                                      })
                                    }),
                                    1
                                  )
                                ],
                                1
                              ),
                              _c(
                                "el-form-item",
                                { attrs: { label: "是否导师:" } },
                                [
                                  _c(
                                    "el-radio-group",
                                    {
                                      on: { change: _vm.isYesOrNoTutor },
                                      model: {
                                        value: queryData.isTutor,
                                        callback: function($$v) {
                                          _vm.$set(queryData, "isTutor", $$v)
                                        },
                                        expression: "queryData.isTutor"
                                      }
                                    },
                                    [
                                      _c(
                                        "el-radio",
                                        {
                                          staticStyle: { width: "8em" },
                                          attrs: {
                                            disabled: !_vm.noRecommendAndIsAlone(
                                              queryData
                                            ),
                                            label: "1"
                                          }
                                        },
                                        [_vm._v("是")]
                                      ),
                                      _c(
                                        "el-radio",
                                        {
                                          staticStyle: { width: "10.5em" },
                                          attrs: {
                                            disabled: !_vm.noRecommendAndIsAlone(
                                              queryData
                                            ),
                                            label: "0"
                                          }
                                        },
                                        [_vm._v(" 否 ")]
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              ),
                              _c(
                                "el-form-item",
                                {
                                  attrs: {
                                    label: "导师姓名:",
                                    "label-width": "158px"
                                  }
                                },
                                [
                                  _c("el-input", {
                                    attrs: {
                                      placeholder: "请输入内容",
                                      clearable: "",
                                      disabled: !_vm.noRecommendAndIsAlone(
                                        queryData
                                      )
                                    },
                                    model: {
                                      value: queryData.tutorName,
                                      callback: function($$v) {
                                        _vm.$set(queryData, "tutorName", $$v)
                                      },
                                      expression: "queryData.tutorName"
                                    }
                                  })
                                ],
                                1
                              ),
                              _c(
                                "span",
                                {
                                  directives: [
                                    {
                                      name: "show",
                                      rawName: "v-show",
                                      value: !(
                                        queryData.isTutor === "1" &&
                                        _vm.noRecommendAndIsAlone(queryData)
                                      ),
                                      expression:
                                        "!(queryData.isTutor === '1' && noRecommendAndIsAlone(queryData))"
                                    }
                                  ],
                                  staticStyle: {
                                    display: "inline-block",
                                    "margin-top": "0.7em",
                                    cursor: "pointer",
                                    color: "#409eff"
                                  },
                                  on: {
                                    click: function($event) {
                                      return _vm.selectPeople($event, "导师")
                                    }
                                  }
                                },
                                [_vm._v(" 选择 ")]
                              ),
                              _c(
                                "el-form-item",
                                { attrs: { label: "是否讲师:" } },
                                [
                                  _c(
                                    "el-radio-group",
                                    {
                                      on: { change: _vm.isYesOrNoLecturer },
                                      model: {
                                        value: queryData.isLecturer,
                                        callback: function($$v) {
                                          _vm.$set(queryData, "isLecturer", $$v)
                                        },
                                        expression: "queryData.isLecturer"
                                      }
                                    },
                                    [
                                      _c(
                                        "el-radio",
                                        {
                                          staticStyle: { width: "8em" },
                                          attrs: {
                                            disabled: !_vm.noRecommendAndIsAlone(
                                              queryData
                                            ),
                                            label: "1"
                                          }
                                        },
                                        [_vm._v("是")]
                                      ),
                                      _c(
                                        "el-radio",
                                        {
                                          staticStyle: { width: "10.5em" },
                                          attrs: {
                                            disabled: !_vm.noRecommendAndIsAlone(
                                              queryData
                                            ),
                                            label: "0"
                                          }
                                        },
                                        [_vm._v(" 否 ")]
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              ),
                              _c(
                                "el-form-item",
                                {
                                  attrs: {
                                    label: "讲师姓名:",
                                    "label-width": "158px"
                                  }
                                },
                                [
                                  _c("el-input", {
                                    attrs: {
                                      placeholder: "请输入内容",
                                      clearable: "",
                                      disabled: !_vm.noRecommendAndIsAlone(
                                        queryData
                                      )
                                    },
                                    model: {
                                      value: queryData.lecturerName,
                                      callback: function($$v) {
                                        _vm.$set(queryData, "lecturerName", $$v)
                                      },
                                      expression: "queryData.lecturerName"
                                    }
                                  })
                                ],
                                1
                              ),
                              _c(
                                "span",
                                {
                                  directives: [
                                    {
                                      name: "show",
                                      rawName: "v-show",
                                      value: !(
                                        queryData.isLecturer === "1" &&
                                        _vm.noRecommendAndIsAlone(queryData)
                                      ),
                                      expression:
                                        "!(queryData.isLecturer === '1' && noRecommendAndIsAlone(queryData))"
                                    }
                                  ],
                                  staticStyle: {
                                    display: "inline-block",
                                    "margin-top": "0.7em",
                                    cursor: "pointer",
                                    color: "#409eff"
                                  },
                                  on: {
                                    click: function($event) {
                                      return _vm.selectPeople($event, "讲师")
                                    }
                                  }
                                },
                                [_vm._v(" 选择 ")]
                              ),
                              _c(
                                "el-form-item",
                                { attrs: { label: "销售人员编码:" } },
                                [
                                  _c("el-input", {
                                    attrs: { clearable: "", disabled: "" },
                                    model: {
                                      value: queryData.hxAgentCode,
                                      callback: function($$v) {
                                        _vm.$set(queryData, "hxAgentCode", $$v)
                                      },
                                      expression: "queryData.hxAgentCode"
                                    }
                                  })
                                ],
                                1
                              )
                            ],
                            1
                          )
                        ],
                        1
                      ),
                      _c(
                        "div",
                        [
                          _c("div", { staticClass: "look_title" }, [
                            _c("span", [_vm._v("执业信息")])
                          ]),
                          _c(
                            "el-form",
                            {
                              attrs: {
                                "label-width": "250px",
                                model: queryData,
                                "label-position": "right",
                                inline: true,
                                "show-message": false
                              }
                            },
                            [
                              _c(
                                "el-form-item",
                                { attrs: { label: "考试成绩:" } },
                                [
                                  _c("el-input", {
                                    attrs: {
                                      placeholder: "请输入内容",
                                      clearable: "",
                                      disabled: ""
                                    },
                                    model: {
                                      value: queryData.examResults,
                                      callback: function($$v) {
                                        _vm.$set(queryData, "examResults", $$v)
                                      },
                                      expression: "queryData.examResults"
                                    }
                                  })
                                ],
                                1
                              ),
                              _c(
                                "el-form-item",
                                { attrs: { label: "入司时间:", required: "" } },
                                [
                                  _c(
                                    "el-col",
                                    { attrs: { span: 22 } },
                                    [
                                      _c("el-date-picker", {
                                        attrs: {
                                          placeholder: "选择日期",
                                          type: "date",
                                          "value-format": "yyyy-MM-dd"
                                        },
                                        model: {
                                          value: queryData.entryTime,
                                          callback: function($$v) {
                                            _vm.$set(
                                              queryData,
                                              "entryTime",
                                              $$v
                                            )
                                          },
                                          expression: "queryData.entryTime"
                                        }
                                      })
                                    ],
                                    1
                                  )
                                ],
                                1
                              ),
                              _c(
                                "el-form-item",
                                { attrs: { label: "执业证状态:" } },
                                [
                                  _c(
                                    "el-radio",
                                    {
                                      staticStyle: { width: "8em" },
                                      attrs: { label: "1" },
                                      model: {
                                        value: queryData.licenseStatus,
                                        callback: function($$v) {
                                          _vm.$set(
                                            queryData,
                                            "licenseStatus",
                                            $$v
                                          )
                                        },
                                        expression: "queryData.licenseStatus"
                                      }
                                    },
                                    [_vm._v("有效")]
                                  ),
                                  _c(
                                    "el-radio",
                                    {
                                      staticStyle: { width: "10.5em" },
                                      attrs: { label: "0" },
                                      model: {
                                        value: queryData.licenseStatus,
                                        callback: function($$v) {
                                          _vm.$set(
                                            queryData,
                                            "licenseStatus",
                                            $$v
                                          )
                                        },
                                        expression: "queryData.licenseStatus"
                                      }
                                    },
                                    [_vm._v("无效")]
                                  )
                                ],
                                1
                              ),
                              _c(
                                "el-form-item",
                                {
                                  attrs: {
                                    label: "执业证失效日期:",
                                    "label-width": "158px"
                                  }
                                },
                                [
                                  _c(
                                    "el-col",
                                    { attrs: { span: 22 } },
                                    [
                                      _c("el-date-picker", {
                                        attrs: {
                                          placeholder: "选择日期",
                                          type: "date",
                                          "value-format": "yyyy-MM-dd"
                                        },
                                        model: {
                                          value: queryData.licenseDate,
                                          callback: function($$v) {
                                            _vm.$set(
                                              queryData,
                                              "licenseDate",
                                              $$v
                                            )
                                          },
                                          expression: "queryData.licenseDate"
                                        }
                                      })
                                    ],
                                    1
                                  )
                                ],
                                1
                              ),
                              _c(
                                "el-form-item",
                                { attrs: { label: "执业证编号:" } },
                                [
                                  _c("el-input", {
                                    attrs: {
                                      placeholder: "请输入内容",
                                      clearable: ""
                                    },
                                    model: {
                                      value: queryData.licenseNumber,
                                      callback: function($$v) {
                                        _vm.$set(
                                          queryData,
                                          "licenseNumber",
                                          $$v
                                        )
                                      },
                                      expression: "queryData.licenseNumber"
                                    }
                                  })
                                ],
                                1
                              ),
                              _c(
                                "el-form-item",
                                { attrs: { label: "登记区域:" } },
                                [
                                  _c("el-input", {
                                    attrs: {
                                      placeholder: "请输入内容",
                                      clearable: ""
                                    },
                                    model: {
                                      value: queryData.regArea,
                                      callback: function($$v) {
                                        _vm.$set(queryData, "regArea", $$v)
                                      },
                                      expression: "queryData.regArea"
                                    }
                                  })
                                ],
                                1
                              ),
                              _c(
                                "el-form-item",
                                {
                                  staticClass: "login-date",
                                  attrs: { label: "执业证登记时间:" }
                                },
                                [
                                  _c("el-date-picker", {
                                    attrs: {
                                      placeholder: "选择日期",
                                      type: "date",
                                      "value-format": "yyyy-MM-dd"
                                    },
                                    model: {
                                      value: queryData.licenseDate,
                                      callback: function($$v) {
                                        _vm.$set(queryData, "licenseDate", $$v)
                                      },
                                      expression: "queryData.licenseDate"
                                    }
                                  })
                                ],
                                1
                              )
                            ],
                            1
                          )
                        ],
                        1
                      ),
                      _c(
                        "div",
                        [
                          _c("div", { staticClass: "look_title" }, [
                            _c("span", [_vm._v("银行信息")])
                          ]),
                          _c(
                            "el-form",
                            {
                              attrs: {
                                "label-width": "250px",
                                model: queryData,
                                "label-position": "right",
                                inline: true,
                                "show-message": false
                              }
                            },
                            [
                              _c(
                                "el-form-item",
                                { attrs: { label: "银行卡号:" } },
                                [
                                  _c("el-input", {
                                    attrs: {
                                      disabled: true,
                                      clearable: "",
                                      placeholder: "请输入内容"
                                    },
                                    model: {
                                      value: queryData.bankCode,
                                      callback: function($$v) {
                                        _vm.$set(queryData, "bankCode", $$v)
                                      },
                                      expression: "queryData.bankCode"
                                    }
                                  })
                                ],
                                1
                              ),
                              _c(
                                "el-form-item",
                                { attrs: { label: "开户行:" } },
                                [
                                  _c(
                                    "el-select",
                                    {
                                      attrs: {
                                        disabled: true,
                                        clearable: "",
                                        placeholder: "请选择"
                                      },
                                      model: {
                                        value: queryData.openBank,
                                        callback: function($$v) {
                                          _vm.$set(queryData, "openBank", $$v)
                                        },
                                        expression: "queryData.openBank"
                                      }
                                    },
                                    _vm._l(_vm.bank, function(item) {
                                      return _c("el-option", {
                                        key: item.value,
                                        attrs: {
                                          label: item.label,
                                          value: item.value
                                        }
                                      })
                                    }),
                                    1
                                  )
                                ],
                                1
                              ),
                              _c(
                                "el-form-item",
                                { attrs: { label: "支行名称:" } },
                                [
                                  _c("el-input", {
                                    attrs: {
                                      disabled: true,
                                      clearable: "",
                                      placeholder: "请输入内容"
                                    },
                                    model: {
                                      value: queryData.bankNet,
                                      callback: function($$v) {
                                        _vm.$set(queryData, "bankNet", $$v)
                                      },
                                      expression: "queryData.bankNet"
                                    }
                                  })
                                ],
                                1
                              )
                            ],
                            1
                          )
                        ],
                        1
                      ),
                      _c(
                        "div",
                        [
                          _c("div", { staticClass: "look_title" }, [
                            _c("span", [_vm._v("行政信息")])
                          ]),
                          _c(
                            "el-form",
                            {
                              attrs: {
                                "label-width": "250px",
                                model: queryData,
                                "label-position": "right",
                                inline: true,
                                "show-message": false
                              }
                            },
                            [
                              _c(
                                "el-form-item",
                                {
                                  attrs: {
                                    label: "所属渠道公司名称:",
                                    required: ""
                                  }
                                },
                                [
                                  _c(
                                    "el-select",
                                    {
                                      attrs: {
                                        placeholder: "请选择",
                                        clearable: "",
                                        disabled: true
                                      },
                                      on: { change: _vm.changChanelCompany },
                                      model: {
                                        value: queryData.channelCompanyName,
                                        callback: function($$v) {
                                          _vm.$set(
                                            queryData,
                                            "channelCompanyName",
                                            $$v
                                          )
                                        },
                                        expression:
                                          "queryData.channelCompanyName"
                                      }
                                    },
                                    _vm._l(_vm.companyList, function(item) {
                                      return _c("el-option", {
                                        key: item.channelCompanyCode,
                                        attrs: {
                                          label: item.channelCompanyName,
                                          value: item.channelCompanyCode
                                        }
                                      })
                                    }),
                                    1
                                  )
                                ],
                                1
                              ),
                              _c(
                                "el-form-item",
                                { attrs: { label: "所属渠道公司编码:" } },
                                [
                                  _c("el-input", {
                                    attrs: {
                                      placeholder: "请输入内容",
                                      clearable: "",
                                      disabled: ""
                                    },
                                    model: {
                                      value: queryData.channelCompanyCode,
                                      callback: function($$v) {
                                        _vm.$set(
                                          queryData,
                                          "channelCompanyCode",
                                          $$v
                                        )
                                      },
                                      expression: "queryData.channelCompanyCode"
                                    }
                                  })
                                ],
                                1
                              ),
                              _c(
                                "el-form-item",
                                {
                                  attrs: {
                                    label: "所属渠道团队名称:",
                                    required: ""
                                  }
                                },
                                [
                                  _c(
                                    "el-select",
                                    {
                                      attrs: {
                                        placeholder: "请选择",
                                        clearable: "",
                                        disabled: true
                                      },
                                      on: { change: _vm.changeGroup },
                                      model: {
                                        value: queryData.channelGroupName,
                                        callback: function($$v) {
                                          _vm.$set(
                                            queryData,
                                            "channelGroupName",
                                            $$v
                                          )
                                        },
                                        expression: "queryData.channelGroupName"
                                      }
                                    },
                                    _vm._l(_vm.groupList, function(item) {
                                      return _c("el-option", {
                                        key: item.channelGroupCode,
                                        attrs: {
                                          label: item.channelGroupName,
                                          value: item.channelGroupCode
                                        }
                                      })
                                    }),
                                    1
                                  )
                                ],
                                1
                              ),
                              _c(
                                "el-form-item",
                                { attrs: { label: "所属渠道团队编码:" } },
                                [
                                  _c("el-input", {
                                    attrs: {
                                      placeholder: "请输入内容",
                                      clearable: "",
                                      disabled: ""
                                    },
                                    model: {
                                      value: queryData.channelGroupCode,
                                      callback: function($$v) {
                                        _vm.$set(
                                          queryData,
                                          "channelGroupCode",
                                          $$v
                                        )
                                      },
                                      expression: "queryData.channelGroupCode"
                                    }
                                  })
                                ],
                                1
                              )
                            ],
                            1
                          )
                        ],
                        1
                      ),
                      _c(
                        "div",
                        {
                          staticClass: "bottom_info",
                          on: {
                            click: function($event) {
                              return _vm.goUrl($event, queryData)
                            }
                          }
                        },
                        [
                          _c("span", [_vm._v("身份证人像面")]),
                          _c("span", [_vm._v("身份证国徽面")]),
                          _c("span", [_vm._v("学历证照片")]),
                          _c("span", [_vm._v("1寸免冠照片")]),
                          _c("span", [_vm._v("线上离职申请表")]),
                          _c(
                            "span",
                            {
                              style: queryData.initiativeBase64URL
                                ? ""
                                : { color: "#7c7c7c" }
                            },
                            [_vm._v("主动解约文件")]
                          )
                        ]
                      )
                    ]),
                    _c(
                      "div",
                      {
                        directives: [
                          {
                            name: "show",
                            rawName: "v-show",
                            value: _vm.peopleInfo === "离职终审",
                            expression: "peopleInfo === '离职终审'"
                          }
                        ],
                        staticClass: "leave-add-info"
                      },
                      [
                        _c("span", { staticClass: "title" }, [
                          _vm._v("离职终审结果")
                        ]),
                        _c(
                          "div",
                          { staticClass: "border" },
                          [
                            _c(
                              "el-form",
                              {
                                attrs: {
                                  "label-width": "80px",
                                  model: queryData,
                                  "label-position": "left",
                                  inline: false
                                }
                              },
                              [
                                _c(
                                  "el-row",
                                  [
                                    _c(
                                      "el-col",
                                      { attrs: { span: 8 } },
                                      [
                                        _c(
                                          "el-form-item",
                                          { attrs: { label: _vm.checkTitle } },
                                          [
                                            _c(
                                              "el-select",
                                              {
                                                attrs: {
                                                  clearable: "",
                                                  placeholder: "请选择内容",
                                                  disabled: _vm.isShow,
                                                  filterable: ""
                                                },
                                                on: {
                                                  change: _vm.isAllowHandle
                                                },
                                                model: {
                                                  value: queryData.auditResult,
                                                  callback: function($$v) {
                                                    _vm.$set(
                                                      queryData,
                                                      "auditResult",
                                                      $$v
                                                    )
                                                  },
                                                  expression:
                                                    "queryData.auditResult"
                                                }
                                              },
                                              _vm._l(_vm.auditType, function(
                                                item
                                              ) {
                                                return _c("el-option", {
                                                  key: item.value,
                                                  attrs: {
                                                    label: item.label,
                                                    value: item.value
                                                  }
                                                })
                                              }),
                                              1
                                            )
                                          ],
                                          1
                                        )
                                      ],
                                      1
                                    )
                                  ],
                                  1
                                ),
                                _c(
                                  "el-form-item",
                                  {
                                    directives: [
                                      {
                                        name: "show",
                                        rawName: "v-show",
                                        value: !_vm.isAllow,
                                        expression: "!isAllow"
                                      }
                                    ],
                                    attrs: { label: "拒绝原因" }
                                  },
                                  [
                                    _c("el-input", {
                                      attrs: {
                                        type: "textarea",
                                        placeholder: "请输入内容",
                                        clearable: "",
                                        rows: 3,
                                        maxlength: "80",
                                        disabled: _vm.isAllow || _vm.isShow,
                                        "show-word-limit": ""
                                      },
                                      model: {
                                        value: queryData.auditReason,
                                        callback: function($$v) {
                                          _vm.$set(
                                            queryData,
                                            "auditReason",
                                            $$v
                                          )
                                        },
                                        expression: "queryData.auditReason"
                                      }
                                    })
                                  ],
                                  1
                                ),
                                _c("span", { staticClass: "rej_info" }, [
                                  _vm._v(
                                    "* 如果初审结果为拒绝,需填写拒绝原因,最多80个字。通过无需填写"
                                  )
                                ])
                              ],
                              1
                            )
                          ],
                          1
                        )
                      ]
                    ),
                    _c(
                      "div",
                      {
                        directives: [
                          {
                            name: "show",
                            rawName: "v-show",
                            value: _vm.peopleInfo === "主动解约",
                            expression: "peopleInfo === '主动解约'"
                          }
                        ],
                        staticClass: "leave-add-info"
                      },
                      [
                        _c("span", { staticClass: "title" }, [
                          _vm._v("主动解约")
                        ]),
                        _c(
                          "div",
                          { staticClass: "border" },
                          [
                            _c(
                              "el-form",
                              {
                                attrs: {
                                  "label-width": "100px",
                                  model: queryData,
                                  "label-position": "left",
                                  inline: false
                                }
                              },
                              [
                                _c(
                                  "el-form-item",
                                  { attrs: { label: "主动解约原因：" } },
                                  [
                                    _c("el-input", {
                                      attrs: {
                                        type: "textarea",
                                        placeholder: "请输入内容",
                                        clearable: "",
                                        rows: 3,
                                        maxlength: "80",
                                        "show-word-limit": ""
                                      },
                                      model: {
                                        value: queryData.reason,
                                        callback: function($$v) {
                                          _vm.$set(queryData, "reason", $$v)
                                        },
                                        expression: "queryData.reason"
                                      }
                                    })
                                  ],
                                  1
                                ),
                                _c(
                                  "el-upload",
                                  {
                                    ref: "upload-notice",
                                    staticClass: "upload-notice",
                                    attrs: {
                                      action: _vm.upAddress,
                                      "on-preview": _vm.clickNoticeFile,
                                      accept: _vm.acceptType,
                                      limit: 1,
                                      "on-success": _vm.upSuccess
                                    }
                                  },
                                  [
                                    _c(
                                      "el-button",
                                      {
                                        attrs: {
                                          size: "small",
                                          type: "primary"
                                        }
                                      },
                                      [_vm._v("点击上传")]
                                    )
                                  ],
                                  1
                                ),
                                _c("span", { staticClass: "rej_info" }, [
                                  _vm._v(
                                    " * 主动解约时需填写主动解约原因(限80字)，且需上传《解约通知书》的影像件(只能上传文件，且不超过20MB)。 "
                                  )
                                ])
                              ],
                              1
                            )
                          ],
                          1
                        )
                      ]
                    )
                  ]
                }
              }
            ])
          }),
          _c(
            "span",
            {
              staticClass: "dialog-footer",
              attrs: { slot: "footer" },
              slot: "footer"
            },
            [
              _c(
                "el-button",
                {
                  on: {
                    click: function($event) {
                      _vm.dialogVisible = false
                    }
                  }
                },
                [_vm._v("关 闭")]
              ),
              _c(
                "el-button",
                { attrs: { type: "primary" }, on: { click: _vm.saveAction } },
                [_vm._v("保存")]
              )
            ],
            1
          )
        ],
        1
      ),
      _c(
        "el-dialog",
        {
          attrs: {
            title: _vm.currentName,
            visible: _vm.editDialog2,
            width: "30%"
          },
          on: {
            "update:visible": function($event) {
              _vm.editDialog2 = $event
            }
          }
        },
        [
          _c("Input", {
            attrs: { queryData: _vm.startCheck },
            scopedSlots: _vm._u([
              {
                key: "up",
                fn: function(ref) {
                  var queryData = ref.queryData
                  return [
                    _c(
                      "el-form",
                      {
                        attrs: {
                          "label-width": "80px",
                          model: queryData,
                          "label-position": "left",
                          inline: false
                        }
                      },
                      [
                        _c(
                          "el-form-item",
                          { attrs: { label: _vm.checkTitle } },
                          [
                            _c(
                              "el-col",
                              { attrs: { span: 10 } },
                              [
                                _c(
                                  "el-select",
                                  {
                                    attrs: {
                                      clearable: "",
                                      placeholder: "请选择内容",
                                      disabled: _vm.isShow,
                                      filterable: ""
                                    },
                                    on: { change: _vm.isAllowHandle },
                                    model: {
                                      value: queryData.auditResult,
                                      callback: function($$v) {
                                        _vm.$set(queryData, "auditResult", $$v)
                                      },
                                      expression: "queryData.auditResult"
                                    }
                                  },
                                  _vm._l(_vm.auditType, function(item) {
                                    return _c("el-option", {
                                      key: item.value,
                                      attrs: {
                                        label: item.label,
                                        value: item.value
                                      }
                                    })
                                  }),
                                  1
                                )
                              ],
                              1
                            )
                          ],
                          1
                        ),
                        _c(
                          "el-form-item",
                          {
                            directives: [
                              {
                                name: "show",
                                rawName: "v-show",
                                value: !_vm.isAllow,
                                expression: "!isAllow"
                              }
                            ],
                            attrs: { label: "拒绝原因" }
                          },
                          [
                            _c("el-input", {
                              attrs: {
                                type: "textarea",
                                placeholder: "请输入内容",
                                clearable: "",
                                rows: 3,
                                maxlength: "80",
                                disabled: _vm.isAllow || _vm.isShow,
                                "show-word-limit": ""
                              },
                              model: {
                                value: queryData.auditReason,
                                callback: function($$v) {
                                  _vm.$set(queryData, "auditReason", $$v)
                                },
                                expression: "queryData.auditReason"
                              }
                            })
                          ],
                          1
                        ),
                        _c("span", { staticClass: "rej_info" }, [
                          _vm._v(
                            "* 如果初审结果为拒绝,需填写拒绝原因,最多80个字。通过无需填写"
                          )
                        ])
                      ],
                      1
                    )
                  ]
                }
              }
            ])
          }),
          _c(
            "span",
            {
              staticClass: "dialog-footer",
              attrs: { slot: "footer" },
              slot: "footer"
            },
            [
              _c(
                "el-button",
                {
                  on: {
                    click: function($event) {
                      _vm.editDialog2 = false
                    }
                  }
                },
                [_vm._v("关 闭")]
              ),
              _c(
                "el-button",
                { attrs: { type: "primary" }, on: { click: _vm.sure } },
                [_vm._v("确 定")]
              )
            ],
            1
          )
        ],
        1
      ),
      _c(
        "el-dialog",
        {
          attrs: {
            title: "请选择导师/讲师",
            visible: _vm.dialogVisible10,
            width: "50%"
          },
          on: {
            "update:visible": function($event) {
              _vm.dialogVisible10 = $event
            }
          }
        },
        [
          _c("Input", {
            attrs: { queryData: _vm.selectPeopleDate },
            scopedSlots: _vm._u([
              {
                key: "up",
                fn: function(ref) {
                  var queryData = ref.queryData
                  return [
                    _c(
                      "el-form",
                      {
                        attrs: {
                          "label-width": "120px",
                          model: queryData,
                          "label-position": "right",
                          inline: true
                        }
                      },
                      [
                        _c(
                          "el-form-item",
                          { attrs: { label: "代理人姓名" } },
                          [
                            _c("el-input", {
                              attrs: {
                                clearable: "",
                                placeholder: "请输入内容"
                              },
                              model: {
                                value: queryData.agentName,
                                callback: function($$v) {
                                  _vm.$set(queryData, "agentName", $$v)
                                },
                                expression: "queryData.agentName"
                              }
                            })
                          ],
                          1
                        ),
                        _c(
                          "el-form-item",
                          { attrs: { label: "代理人编号" } },
                          [
                            _c("el-input", {
                              attrs: {
                                clearable: "",
                                placeholder: "请输入内容"
                              },
                              model: {
                                value: queryData.agentCode,
                                callback: function($$v) {
                                  _vm.$set(queryData, "agentCode", $$v)
                                },
                                expression: "queryData.agentCode"
                              }
                            })
                          ],
                          1
                        ),
                        _c(
                          "el-button",
                          {
                            staticStyle: { "margin-bottom": "10px" },
                            attrs: { type: "primary" },
                            on: { click: _vm.queryButton }
                          },
                          [_vm._v("查询")]
                        )
                      ],
                      1
                    )
                  ]
                }
              }
            ])
          }),
          _c("Table", {
            attrs: { tableData: _vm.tableDataOne, "is-radio": true },
            on: { handleSelectionChange: _vm.handleSelectionChange }
          }),
          _c("Pagination", {
            attrs: { pageOption: _vm.pageOption },
            on: { currentPageChange: _vm.currentPageChange }
          }),
          _c(
            "span",
            {
              staticClass: "dialog-footer",
              attrs: { slot: "footer" },
              slot: "footer"
            },
            [
              _c(
                "el-button",
                {
                  on: {
                    click: function($event) {
                      _vm.dialogVisible10 = false
                    }
                  }
                },
                [_vm._v("取 消")]
              ),
              _c(
                "el-button",
                { attrs: { type: "primary" }, on: { click: _vm.sureSelect } },
                [_vm._v("确 定")]
              )
            ],
            1
          )
        ],
        1
      ),
      _c(
        "el-dialog",
        {
          attrs: {
            "before-close": _vm.handleClose,
            visible: _vm.errorVisible,
            title: "导入出错,信息如下",
            width: "700px"
          },
          on: {
            "update:visible": function($event) {
              _vm.errorVisible = $event
            }
          }
        },
        [
          _c(
            "div",
            { staticStyle: { overflow: "auto", height: "400px" } },
            [
              _vm._l(_vm.errorMessage, function(item, index) {
                return [
                  _c("p", { key: index, staticClass: "errorMessage-p" }, [
                    _vm._v(_vm._s(item))
                  ])
                ]
              })
            ],
            2
          ),
          _c(
            "span",
            {
              staticClass: "dialog-footer",
              attrs: { slot: "footer" },
              slot: "footer"
            },
            [
              _c(
                "el-button",
                {
                  attrs: { type: "primary" },
                  on: {
                    click: function($event) {
                      _vm.errorVisible = false
                    }
                  }
                },
                [_vm._v("确 定")]
              )
            ],
            1
          )
        ]
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/channelPeople.vue?vue&type=style&index=0&lang=less&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--10-oneOf-1-2!./node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/mga-manage/channelPeople.vue?vue&type=style&index=0&lang=less& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".allcover {\n  position: absolute;\n  top: 0;\n  right: 0;\n}\n.ctt {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n}\n.tb {\n  position: absolute;\n  top: 50%;\n  transform: translateY(-50%);\n}\n.lr {\n  position: absolute;\n  left: 50%;\n  transform: translateX(-50%);\n}\n.el-form-item__label {\n  white-space: nowrap;\n}\n.el-select {\n  width: 100%;\n}\n#container_channelPeople {\n  padding: 15px;\n  /*编辑显示图像*/\n}\n#container_channelPeople .look_title {\n  font-size: 1.5em;\n  font-weight: bold;\n  margin-left: 12%;\n  margin-bottom: 3%;\n}\n#container_channelPeople .login-date .el-form-item__content .el-date-editor input {\n  width: 200px;\n}\n#container_channelPeople .bottom_info {\n  color: #409eff;\n  font-size: 1.2em;\n  cursor: pointer;\n  display: grid;\n  text-align: center;\n  grid-template-rows: repeat(2, 100);\n  grid-template-columns: repeat(4, 25%);\n  justify-content: center;\n  grid-gap: 20px;\n}\n#container_channelPeople .leave-add-info .title {\n  font-size: 18px;\n  font-weight: bolder;\n  margin: 10px 0;\n  display: inline-block;\n}\n#container_channelPeople .leave-add-info .upload-notice {\n  margin-bottom: 20px;\n}\n#container_channelPeople .border {\n  border: 1px solid #eee;\n  border-radius: 5px;\n  padding: 30px;\n}\n#container_channelPeople .rej_info {\n  color: red;\n}\n#container_channelPeople .demo-form-inline .el-input__inner {\n  width: 180px;\n}\n#container_channelPeople .queryHeading {\n  background-color: #f4f4f5;\n  color: #909399;\n  font-size: 14px;\n  padding: 10px 10px;\n  margin-bottom: 15px;\n}\n#container_channelPeople .pagination {\n  margin-top: 15px;\n  float: right;\n}\n#container_channelPeople .editinfo {\n  margin-bottom: 15px;\n}\n#container_channelPeople .dialog-content .list {\n  margin-bottom: 15px;\n}\n#container_channelPeople .dialog-title {\n  font-size: 20px;\n}\n#container_channelPeople .dialog-footer {\n  padding-top: 20px;\n  display: flex;\n  justify-content: flex-end;\n}\n#container_channelPeople /deep/ .el-transfer-panel {\n  height: 400px !important;\n}\n#container_channelPeople .el-transfer-panel__list.is-filterable {\n  height: 300px;\n}\n#container_channelPeople .el-date-editor.el-input {\n  width: 100% !important;\n  color: red;\n}\n#container_channelPeople .el-select {\n  width: 100%;\n}\n#container_channelPeople .toolGroup {\n  padding: 10px;\n  border-top: 1px solid #ececec;\n}\n#container_channelPeople .toolGroup .timeInput {\n  margin-top: 10px;\n}\n#container_channelPeople .toolGroup .timeInput label {\n  display: inline-block;\n  width: 180px;\n}\n#container_channelPeople .toolGroup .import {\n  margin-top: 20px;\n  display: flex;\n}\n#container_channelPeople .toolGroup .import label {\n  display: inline-block;\n  width: 140px;\n}\n#container_channelPeople .toolGroup .import .upload-demo {\n  display: inline-block;\n}\n#container_channelPeople .toolGroup .import .el-upload-list {\n  display: none;\n}\n#container_channelPeople .toolGroup .export {\n  margin-top: 10px;\n  display: flex;\n}\n#container_channelPeople .toolGroup .export label {\n  display: inline-block;\n  width: 140px;\n}\n#container_channelPeople .toolGroup .export .export > button {\n  margin-left: 0 !important;\n}\n#container_channelPeople .toolGroup .tips {\n  margin-left: 10px;\n  display: inline-block;\n  font-size: 12px;\n  color: red;\n}\n#container_channelPeople .imgShow {\n  margin-top: 40px;\n  padding: 0 80px;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n}\n#container_channelPeople .imgShow .title {\n  text-align: left;\n  color: #409eff;\n}\n#container_channelPeople .imgShow .con > img {\n  width: 100%;\n  height: 100%;\n}\n.errorMessage-p {\n  margin-bottom: 10px;\n  border-bottom: 1px solid #cdcdcd;\n}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/channelPeople.vue?vue&type=style&index=0&lang=less&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--10-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--10-oneOf-1-2!./node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/mga-manage/channelPeople.vue?vue&type=style&index=0&lang=less& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--10-oneOf-1-2!../../../node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../node_modules/vue-loader/lib??vue-loader-options!./channelPeople.vue?vue&type=style&index=0&lang=less& */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/channelPeople.vue?vue&type=style&index=0&lang=less&");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("0596f6ae", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/views/mga-manage/channelPeople.vue":
/*!************************************************!*\
  !*** ./src/views/mga-manage/channelPeople.vue ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _channelPeople_vue_vue_type_template_id_340c4d30___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./channelPeople.vue?vue&type=template&id=340c4d30& */ "./src/views/mga-manage/channelPeople.vue?vue&type=template&id=340c4d30&");
/* harmony import */ var _channelPeople_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./channelPeople.vue?vue&type=script&lang=js& */ "./src/views/mga-manage/channelPeople.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _channelPeople_vue_vue_type_style_index_0_lang_less___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./channelPeople.vue?vue&type=style&index=0&lang=less& */ "./src/views/mga-manage/channelPeople.vue?vue&type=style&index=0&lang=less&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _channelPeople_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _channelPeople_vue_vue_type_template_id_340c4d30___WEBPACK_IMPORTED_MODULE_0__["render"],
  _channelPeople_vue_vue_type_template_id_340c4d30___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/mga-manage/channelPeople.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/mga-manage/channelPeople.vue?vue&type=script&lang=js&":
/*!*************************************************************************!*\
  !*** ./src/views/mga-manage/channelPeople.vue?vue&type=script&lang=js& ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_12_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_channelPeople_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--12-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../node_modules/vue-loader/lib??vue-loader-options!./channelPeople.vue?vue&type=script&lang=js& */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/channelPeople.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_12_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_channelPeople_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/mga-manage/channelPeople.vue?vue&type=style&index=0&lang=less&":
/*!**********************************************************************************!*\
  !*** ./src/views/mga-manage/channelPeople.vue?vue&type=style&index=0&lang=less& ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_channelPeople_vue_vue_type_style_index_0_lang_less___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--10-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--10-oneOf-1-2!../../../node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../node_modules/vue-loader/lib??vue-loader-options!./channelPeople.vue?vue&type=style&index=0&lang=less& */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/channelPeople.vue?vue&type=style&index=0&lang=less&");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_channelPeople_vue_vue_type_style_index_0_lang_less___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_channelPeople_vue_vue_type_style_index_0_lang_less___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_channelPeople_vue_vue_type_style_index_0_lang_less___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_channelPeople_vue_vue_type_style_index_0_lang_less___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/mga-manage/channelPeople.vue?vue&type=template&id=340c4d30&":
/*!*******************************************************************************!*\
  !*** ./src/views/mga-manage/channelPeople.vue?vue&type=template&id=340c4d30& ***!
  \*******************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_channelPeople_vue_vue_type_template_id_340c4d30___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"b9734f90-vue-loader-template"}!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../node_modules/vue-loader/lib??vue-loader-options!./channelPeople.vue?vue&type=template&id=340c4d30& */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"b9734f90-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/channelPeople.vue?vue&type=template&id=340c4d30&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_channelPeople_vue_vue_type_template_id_340c4d30___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_channelPeople_vue_vue_type_template_id_340c4d30___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=68.js.map