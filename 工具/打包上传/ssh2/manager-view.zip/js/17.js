(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[17],{

/***/ "./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js":
/*!******************************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _createForOfIteratorHelper; });
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.symbol.js */ "./node_modules/core-js/modules/es.symbol.js");
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.symbol.description.js */ "./node_modules/core-js/modules/es.symbol.description.js");
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_symbol_iterator_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.symbol.iterator.js */ "./node_modules/core-js/modules/es.symbol.iterator.js");
/* harmony import */ var core_js_modules_es_symbol_iterator_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_iterator_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _unsupportedIterableToArray_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./unsupportedIterableToArray.js */ "./node_modules/@babel/runtime/helpers/esm/unsupportedIterableToArray.js");







function _createForOfIteratorHelper(o, allowArrayLike) {
  var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"];

  if (!it) {
    if (Array.isArray(o) || (it = Object(_unsupportedIterableToArray_js__WEBPACK_IMPORTED_MODULE_6__["default"])(o)) || allowArrayLike && o && typeof o.length === "number") {
      if (it) o = it;
      var i = 0;

      var F = function F() {};

      return {
        s: F,
        n: function n() {
          if (i >= o.length) return {
            done: true
          };
          return {
            done: false,
            value: o[i++]
          };
        },
        e: function e(_e) {
          throw _e;
        },
        f: F
      };
    }

    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }

  var normalCompletion = true,
      didErr = false,
      err;
  return {
    s: function s() {
      it = it.call(o);
    },
    n: function n() {
      var step = it.next();
      normalCompletion = step.done;
      return step;
    },
    e: function e(_e2) {
      didErr = true;
      err = _e2;
    },
    f: function f() {
      try {
        if (!normalCompletion && it["return"] != null) it["return"]();
      } finally {
        if (didErr) throw err;
      }
    }
  };
}

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/Announcements.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--12-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/mga-manage/Announcements.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper */ "./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js");
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! regenerator-runtime/runtime.js */ "./node_modules/regenerator-runtime/runtime.js");
/* harmony import */ var regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.object.entries.js */ "./node_modules/core-js/modules/es.object.entries.js");
/* harmony import */ var core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _api_api__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/api/api */ "./src/api/api.js");
/* harmony import */ var _api_Announcements__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @/api/Announcements */ "./src/api/Announcements.js");
/* harmony import */ var _common_dictionary__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @/common/dictionary */ "./src/common/dictionary.js");
/* harmony import */ var common_mixin_edit_handle_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! common/mixin/edit/handle.js */ "./src/common/mixin/edit/handle.js");













//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
 //导入请求




/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'Announcements',
  mixins: [common_mixin_edit_handle_js__WEBPACK_IMPORTED_MODULE_16__["createEdit"]],
  components: {},
  data: function data() {
    return {
      // todo 字典
      noticeType: _common_dictionary__WEBPACK_IMPORTED_MODULE_15__["noticeType"],
      receiverType: _common_dictionary__WEBPACK_IMPORTED_MODULE_15__["receiverType"],
      Onliestatus: _common_dictionary__WEBPACK_IMPORTED_MODULE_15__["Onliestatus"],
      upOnlieStatus: _common_dictionary__WEBPACK_IMPORTED_MODULE_15__["upOnlieStatus"],
      publishBy: _common_dictionary__WEBPACK_IMPORTED_MODULE_15__["publishBy"],
      transferData: [],
      transferValue: [],
      transferShow: [],
      imageFileList: [],
      // todo 文件上传
      fileLists: [],
      uploadUrl: _api_api__WEBPACK_IMPORTED_MODULE_13__["uploadUrl"],
      //文件上传路径
      imageFiles: [],
      //上传图片的保存
      currentid: '',
      picUploadData: {},
      //上传图片的地址
      searchForm: {},
      //搜索表单
      // todo 需要展示的按钮
      needButton: {
        field: 'publishBy',
        controlShow: [''],
        button: ['查看']
      },
      tbConfig: {
        //表格组件配置项
        height: '530px',
        // table高度
        select: false,
        // 是否可以多选择
        isSingleSelect: false,
        //是否可以单选
        isCommands: true,
        //是否需要操作列
        commandsWidth: '300',
        //操作列宽度
        isOrder: true,
        showPagenation: true,
        //是否需要显示分页器
        layout: 'total, prev, pager, next, jumper',
        //分页器控件
        requestCurData: true,
        // 每次分页数据是否请求后台 true:每次都请求后台
        columns: [// 后台字段属性、表头名、长度、颜色、是否过长隐藏、是否需要字典转换、点击事件的处理函数
        ['noticeTitle', '标题', '', '', true, false], ['noticeType', '公告类型', '', '', true, true], ['publishBy', '发布人', '', '', true, true], ['receiverType', '接收人类型', '', '', true, true], ['status', '状态', '', '', true, true], ['createTime', '创建时间', '', '', true, true]],
        // table行按钮：color 文字 处理点击的事件函数名  elementUicon
        commands: [['#409eff', '查看', 'Look', 'el-icon-edit', 'el-icon-search'], ['#409eff', '编辑', 'handleEdit', 'el-icon-edit', 'wxApplet-banner-update'], ['#ff5600', '上线/下线', 'handleisShow', 'el-icon-setting', 'wxApplet-banner-publish'], ['#ff5600', '删除', 'handleDelete', 'el-icon-delete', 'wxApplet-banner-update']]
      },
      tbOptionData: {
        selectData: '',
        //页面单选函数
        currentTableData: [],
        //当前表格数据
        TransValtoDesc: 'dataFilter',
        //数据字典过滤函数
        pageSize: 10,
        // 每页行数
        currentPage: 1,
        // 当前页
        total: 0,
        //总数据量
        pagenationChange: 'handlPageChange' //处理分页器长度改变或页码改变的函数

      },
      // todo 状态判断
      isEdit: false,
      dialogVisible: false,
      form: {
        noticeTitle: '',
        noticeType: '',
        receiverType: ''
      },
      //新增存储数据
      domButton: {//页面button权限
      },
      tableButton: {//表格button权限
      },
      sdialogConfig: {
        //新增用户弹窗组件配置项
        dialogVisible: false,
        width: '590px',
        title: '新增公告',
        buttonPosition: 'flex-end',
        ismodal: true,
        modalClose: false,
        Button: [{
          name: '取消',
          methods: 'addCancel'
        }, {
          name: '确定',
          methods: 'addDetermine',
          type: 'primary'
        }]
      },
      tableData: [],
      //代理人类型区分
      receiverTypeList: _common_dictionary__WEBPACK_IMPORTED_MODULE_15__["default"].receiverTypeList,
      isShow: false,
      dialogVisible1: false,
      currentRow: {},
      isDisable: false
    };
  },
  mounted: function mounted() {
    this.querySelect();
    this.dataInit();
  },
  methods: {
    changeSelect: function changeSelect(v) {
      this.isDisable = v === 'AGE' || v === 'ALL';
      this.currentRow.receiverType = v;
      this.transferData = [];
      this.transferValue = [];
      this.transferShow = [];
    },
    //todo 通用列表数据初始化
    getSelectList: function getSelectList(api, list, value, label, params, key) {
      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
        var _yield$api, data;

        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return api(params);

              case 2:
                _yield$api = _context.sent;
                data = _yield$api.data;

                if (list.length === 0) {
                  data.forEach(function (i) {
                    var obj = {};
                    obj[key] = i[value];
                    obj.label = i[label];
                    list.push(obj);
                  });
                }

              case 5:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    finish: function finish() {
      var _this = this;

      this.dialogVisible1 = false;
      Object(_api_Announcements__WEBPACK_IMPORTED_MODULE_14__["noticeUserList"])({
        agentType: this.currentRow.receiverType
      }).then(function (res) {
        _this.transferShow = res.data.filter(function (item) {
          var _iterator = Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper__WEBPACK_IMPORTED_MODULE_1__["default"])(_this.transferValue),
              _step;

          try {
            for (_iterator.s(); !(_step = _iterator.n()).done;) {
              var i = _step.value;

              if (item.userCode === i) {
                return i;
              }
            }
          } catch (err) {
            _iterator.e(err);
          } finally {
            _iterator.f();
          }
        });
      });
    },
    // todo add
    activeClick: function activeClick() {
      this.getSelectList(_api_Announcements__WEBPACK_IMPORTED_MODULE_14__["noticeUserList"], this.transferData, 'userCode', 'userName', {
        agentType: this.currentRow.receiverType
      }, 'key');
      this.dialogVisible1 = true;
    },
    querySelect: function querySelect() {
      var _this2 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
        var _iterator2, _step2, item;

        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return _this2.getSelectList(_api_Announcements__WEBPACK_IMPORTED_MODULE_14__["publishByApi"], _common_dictionary__WEBPACK_IMPORTED_MODULE_15__["publishBy"], 'publishByCode', 'publishBy', {}, 'value');

              case 2:
                _iterator2 = Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper__WEBPACK_IMPORTED_MODULE_1__["default"])(_common_dictionary__WEBPACK_IMPORTED_MODULE_15__["publishBy"]);

                try {
                  for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                    item = _step2.value;

                    if (item.label !== '众保') {
                      _this2.needButton.controlShow.push(item.label);
                    }
                  }
                } catch (err) {
                  _iterator2.e(err);
                } finally {
                  _iterator2.f();
                }

              case 4:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    handleUplodSuccess: function handleUplodSuccess(response, file, fileList) {
      this.form.thumbnail = response.data.accessPath;
    },
    //图片删除
    handleRemove: function handleRemove(file, fileList) {
      this.form.thumbnail = '';
      this.imageFileList = [];
    },
    //*-------------------------------------------------------------------编辑 查看 新增
    handleAdd: function handleAdd() {
      var _this3 = this;

      this.isShow = false;
      this.isEdit = false;
      this.sdialogConfig.title = '新增公告';

      for (var _i = 0, _Object$entries = Object.entries(this.form); _i < _Object$entries.length; _i++) {
        var _Object$entries$_i = Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__["default"])(_Object$entries[_i], 2),
            key = _Object$entries$_i[0],
            value = _Object$entries$_i[1];

        this.$set(this.form, key, '');
      }

      if (this.searchForm.receiverType === '' || this.searchForm.receiverType === undefined) {
        this.isDisable = true;
      }

      this.dialogVisible = true;
      this.imageFileList = [];
      this.transferShow = [];
      this.transferValue = [];
      this.activePeople = [];
      this.activityRisk = [];
      this.$nextTick(function () {
        _this3.RichTextEditor.txt.html('');
      }); //初始化富文本编辑器

      this.$nextTick(function () {
        _this3.initEdit();
      });
    },
    Look: function Look(row) {
      var _this4 = this;

      // this.sdialogConfig.title = "查看公告";
      this.dialogVisible = true;
      this.isShow = true;
      this.currentRow = row;
      this.sdialogConfig.title = '查看公告';
      var noticeId = row.noticeId;
      this.isEdit = false;
      this.imageFileList = [];
      this.transferShow = [];
      this.transferValue = [];
      this.transferShow = row.noticeUserList;

      if (row.noticeUserList.length > 0) {
        row.noticeUserList.map(function (item) {
          _this4.transferValue.push(item.userCode);
        });
      }

      var data = {
        noticeId: noticeId
      };
      this.currentid = noticeId;
      this.getDetail(data);
      this.$nextTick(function () {
        _this4.initEdit();
      });
    },
    handleEdit: function handleEdit(row) {
      var _this5 = this;

      this.isShow = false;
      this.isDisable = row.receiverType === 'AGE' || row.receiverType === 'ALL';
      this.currentRow = row;
      this.sdialogConfig.title = '修改公告';
      var noticeId = row.noticeId;

      if (row.status === '上线' || row.status === '1') {
        this.$message({
          type: 'warning',
          message: '上线公告不能修改,如需修改请先下线'
        });
      } else {
        this.isEdit = true;
        this.dialogVisible = true;
        this.imageFileList = [];
        this.transferShow = [];
        this.transferValue = [];
        this.transferShow = row.noticeUserList;

        if (row.noticeUserList.length > 0) {
          row.noticeUserList.map(function (item) {
            _this5.transferValue.push(item.userCode);
          });
        }

        var data = {
          noticeId: noticeId
        };
        this.currentid = noticeId;
        this.getDetail(data);
        this.$nextTick(function () {
          _this5.initEdit();
        });
      }
    },
    //获取详情接口
    getDetail: function getDetail(param) {
      var _this6 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
        var result, data;
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.next = 2;
                return Object(_api_Announcements__WEBPACK_IMPORTED_MODULE_14__["editApi"])(param);

              case 2:
                result = _context3.sent;
                data = result.data.records[0];

                if (result.code === 200) {
                  // this.form.thumbnail = result.data.thumbnail;
                  _this6.form.noticeTitle = data.noticeTitle;
                  _this6.form.noticeType = data.noticeType;
                  _this6.form.receiverType = data.receiverType;

                  _this6.RichTextEditor.txt.html(data.noticeText);

                  if (data.thumbnail !== '') {
                    _this6.imageFileList = [{
                      url: data.thumbnail
                    }];
                  }
                }

              case 5:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3);
      }))();
    },
    //编辑公告
    editAction: function editAction(data) {
      var _this7 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
        var result;
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return Object(_api_Announcements__WEBPACK_IMPORTED_MODULE_14__["changeEditApi"])(data);

              case 2:
                result = _context4.sent;

                if (result.code === 200) {
                  _this7.dialogVisible = false;

                  _this7.$message({
                    type: 'success',
                    message: '操作成功'
                  }); // this.searchForm = {};


                  _this7.dataInit(); //新增时候重置数据防止下次新增时候添加有残余数据


                  _this7.activePeople = [];
                  _this7.activityRisk = [];
                }

              case 4:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4);
      }))();
    },
    close: function close() {
      var _this8 = this;

      this.$nextTick(function () {
        _this8.RichTextEditor.txt.html();
      });
      this.imageFileList = [];
      this.dialogVisible = false;
    },
    //*-------------------------------------------------------------------删除
    handleDelete: function handleDelete(row) {
      var _this9 = this;

      var noticeId = row.noticeId;

      if (row.status == '上线' || row.status == '1') {
        this.$message({
          type: 'warning',
          message: '上线公告不能删除,如需删除请先下线'
        });
      } else {
        this.confirm('确定删除吗', '提示').then(function () {
          var data = {
            noticeId: noticeId
          };

          _this9.confiremDelete(data);
        });
      }
    },
    //确认删除
    confiremDelete: function confiremDelete(data) {
      var _this10 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
        var result;
        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.next = 2;
                return Object(_api_Announcements__WEBPACK_IMPORTED_MODULE_14__["deleteId"])(data);

              case 2:
                result = _context5.sent;

                if (result.code == 200) {
                  _this10.dataInit();
                }

              case 4:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5);
      }))();
    },
    //*-------------------------------------------------------------------上线下线
    handleisShow: function handleisShow(row) {
      var _this11 = this;

      var status = row.status == '1' ? '0' : row.status == '上线' ? '0' : '1';
      var statusName = status == 1 ? '上线' : '下线';
      this.confirm('确定' + statusName + '吗', '提示').then(function () {
        var params = {
          noticeId: row.noticeId,
          status: status
        };

        _this11.updateStatus(params);
      });
    },
    //更改上下架状态
    updateStatus: function updateStatus(data) {
      var _this12 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
        var result;
        return regeneratorRuntime.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                _context6.next = 2;
                return Object(_api_Announcements__WEBPACK_IMPORTED_MODULE_14__["upDownOnlie"])(data);

              case 2:
                result = _context6.sent;

                if (result.code == 200) {
                  _this12.dataInit();
                }

              case 4:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6);
      }))();
    },
    //点击保存按钮
    saveAction: function saveAction() {
      this.check('请添加标题', this.form.noticeTitle);
      this.check('请选择公告类型', this.form.noticeType);
      this.check('请选择接收人类型', this.form.receiverType);
      this.check('请选填写文章内容', this.RichTextEditor.txt.html(), '<p><br></p>');

      if (!this.isDisable) {
        this.check('请添加公告对象', this.transferValue.length.toString(), '0');
      }

      var editContent = this.RichTextEditor.txt.html();

      if (editContent !== '<p><br></p>') {
        this.form.noticeText = editContent;
      }

      this.form.noticeUserList = this.transferShow === '' ? [] : this.transferShow;

      if (!this.isEdit) {
        //处理新增
        var data = JSON.parse(JSON.stringify(this.form));
        this.addAction(data);
      } else {
        //处理修改
        this.form.noticeId = this.currentid;

        var _data = JSON.parse(JSON.stringify(this.form));

        this.editAction(_data);
      }
    },
    //添加公告
    addAction: function addAction(data) {
      var _this13 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
        var result;
        return regeneratorRuntime.wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                _context7.next = 2;
                return Object(_api_Announcements__WEBPACK_IMPORTED_MODULE_14__["newPage"])(data);

              case 2:
                result = _context7.sent;

                if (result.code == 200) {
                  _this13.form = {};
                  _this13.imageFileList = [];
                  _this13.dialogVisible = false;

                  _this13.$message({
                    type: 'success',
                    message: '操作成功'
                  });

                  _this13.searchForm = {};

                  _this13.dataInit(); //新增时候重置数据防止下次新增时候添加有残余数据


                  _this13.activePeople = [];
                  _this13.activityRisk = [];
                }

              case 4:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee7);
      }))();
    },
    //*-------------------------------------------------------------------查询
    //查询
    onSubmit: function onSubmit() {
      this.tbOptionData.currentTableData = this.tableData;
      this.tbOptionData.currentPage = 1; //每次查询重置当前页

      this.dataInit();
    },
    //页码改变
    handlPageChange: function handlPageChange(cur, size) {
      var params = JSON.parse(JSON.stringify(this.searchForm));
      params.pageNum = cur;
      this.tbOptionData.currentPage = cur;
      params.pageSize = this.tbOptionData.pageSize;
      this.getList(params);
    },
    //列表数据更新
    dataInit: function dataInit() {
      var params = JSON.parse(JSON.stringify(this.searchForm));
      params.pageNum = this.tbOptionData.currentPage; //当前页面

      params.pageSize = this.tbOptionData.pageSize; //没页显示的条数

      this.getList(params);
    },
    //查询列表
    getList: function getList(params) {
      var _this14 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee8() {
        var result, data;
        return regeneratorRuntime.wrap(function _callee8$(_context8) {
          while (1) {
            switch (_context8.prev = _context8.next) {
              case 0:
                _context8.next = 2;
                return Object(_api_Announcements__WEBPACK_IMPORTED_MODULE_14__["noticeQuery"])(params);

              case 2:
                result = _context8.sent;

                if (result.code == 200) {
                  data = JSON.parse(JSON.stringify(result.data.records));
                  _this14.tbOptionData.currentTableData = data;
                  _this14.tbOptionData.total = result.data.total;
                }

              case 4:
              case "end":
                return _context8.stop();
            }
          }
        }, _callee8);
      }))();
    },
    //数据过滤
    dataFilter: function dataFilter(id, val) {
      if (id == 'noticeType') {
        var array = this.noticeType.find(function (item) {
          return item.value === val;
        });
        return array === undefined ? '' : array.name;
      }

      if (id == 'receiverType') {
        var _array = this.receiverType.find(function (item) {
          return item.value === val;
        });

        return _array === undefined ? '' : _array.name;
      }

      if (id == 'status') {
        var _array2 = this.upOnlieStatus.find(function (item) {
          return item.value === val;
        });

        return _array2 === undefined ? '' : _array2.name;
      }

      if (id == 'createTime') {
        return val.slice(0, 10);
      }
    },
    // todo 通用校验
    check: function check(message, key, value) {
      if (value === undefined && (key === '' || key === null || key === undefined)) {
        this.$message({
          type: 'error',
          message: message
        });
        throw new TypeError('填写的内容为空');
      } else if (value && key === value) {
        this.$message({
          type: 'error',
          message: message
        });
        throw new TypeError(message);
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"b9734f90-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/Announcements.vue?vue&type=template&id=88c1ea3c&":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"b9734f90-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/mga-manage/Announcements.vue?vue&type=template&id=88c1ea3c& ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "selfCon", attrs: { id: "container" } },
    [
      _c("div", { staticClass: "queryHeading" }, [_vm._v("查询条件")]),
      _c(
        "div",
        [
          _c(
            "el-form",
            {
              staticClass: "demo-form-inline",
              attrs: {
                inline: true,
                model: _vm.searchForm,
                "label-width": "120px"
              }
            },
            [
              _c(
                "el-form-item",
                { attrs: { label: "公告标题:" } },
                [
                  _c("el-input", {
                    attrs: { placeholder: "请输入内容", clearable: "" },
                    model: {
                      value: _vm.searchForm.noticeTitle,
                      callback: function($$v) {
                        _vm.$set(_vm.searchForm, "noticeTitle", $$v)
                      },
                      expression: "searchForm.noticeTitle"
                    }
                  })
                ],
                1
              ),
              _c(
                "el-form-item",
                { attrs: { label: "公告类型:" } },
                [
                  _c(
                    "el-select",
                    {
                      staticStyle: { width: "180px !important" },
                      attrs: { clearable: "", placeholder: "请选择" },
                      model: {
                        value: _vm.searchForm.noticeType,
                        callback: function($$v) {
                          _vm.$set(_vm.searchForm, "noticeType", $$v)
                        },
                        expression: "searchForm.noticeType"
                      }
                    },
                    _vm._l(_vm.noticeType, function(item) {
                      return _c("el-option", {
                        key: item.name,
                        attrs: { label: item.name, value: item.value }
                      })
                    }),
                    1
                  )
                ],
                1
              ),
              _c(
                "el-form-item",
                { attrs: { label: "接收人类型:" } },
                [
                  _c(
                    "el-select",
                    {
                      staticStyle: { width: "180px !important" },
                      attrs: { clearable: "", placeholder: "请选择" },
                      model: {
                        value: _vm.searchForm.receiverType,
                        callback: function($$v) {
                          _vm.$set(_vm.searchForm, "receiverType", $$v)
                        },
                        expression: "searchForm.receiverType"
                      }
                    },
                    _vm._l(_vm.receiverType, function(item) {
                      return _c("el-option", {
                        key: item.name,
                        attrs: { label: item.name, value: item.value }
                      })
                    }),
                    1
                  )
                ],
                1
              ),
              _c(
                "el-form-item",
                { attrs: { label: "状态:" } },
                [
                  _c(
                    "el-select",
                    {
                      staticStyle: { width: "180px !important" },
                      attrs: { clearable: "", placeholder: "请选择" },
                      model: {
                        value: _vm.searchForm.status,
                        callback: function($$v) {
                          _vm.$set(_vm.searchForm, "status", $$v)
                        },
                        expression: "searchForm.status"
                      }
                    },
                    _vm._l(_vm.Onliestatus, function(item) {
                      return _c("el-option", {
                        key: item.name,
                        attrs: { label: item.name, value: item.value }
                      })
                    }),
                    1
                  )
                ],
                1
              ),
              _c(
                "el-form-item",
                { attrs: { label: "发布人:" } },
                [
                  _c(
                    "el-select",
                    {
                      staticStyle: { width: "180px !important" },
                      attrs: { clearable: "", placeholder: "请选择" },
                      model: {
                        value: _vm.searchForm.publishBy,
                        callback: function($$v) {
                          _vm.$set(_vm.searchForm, "publishBy", $$v)
                        },
                        expression: "searchForm.publishBy"
                      }
                    },
                    _vm._l(_vm.publishBy, function(item) {
                      return _c("el-option", {
                        key: item.name,
                        attrs: { label: item.name, value: item.value }
                      })
                    }),
                    1
                  )
                ],
                1
              ),
              _c(
                "el-form-item",
                { attrs: { label: "创建时间:" } },
                [
                  _c("el-date-picker", {
                    attrs: {
                      format: "yyyy-MM-dd HH:mm:ss",
                      placeholder: "选择日期时间",
                      type: "date",
                      "value-format": "yyyy-MM-dd HH:mm:ss"
                    },
                    model: {
                      value: _vm.searchForm.createTime,
                      callback: function($$v) {
                        _vm.$set(_vm.searchForm, "createTime", $$v)
                      },
                      expression: "searchForm.createTime"
                    }
                  })
                ],
                1
              ),
              _c(
                "el-form-item",
                { attrs: { label: "至:" } },
                [
                  _c("el-date-picker", {
                    attrs: {
                      format: "yyyy-MM-dd HH:mm:ss",
                      placeholder: "选择日期时间",
                      type: "date",
                      "value-format": "yyyy-MM-dd HH:mm:ss"
                    },
                    model: {
                      value: _vm.searchForm.createTimeEnd,
                      callback: function($$v) {
                        _vm.$set(_vm.searchForm, "createTimeEnd", $$v)
                      },
                      expression: "searchForm.createTimeEnd"
                    }
                  })
                ],
                1
              ),
              _c(
                "el-form-item",
                [
                  _c(
                    "el-button",
                    {
                      attrs: {
                        icon: "el-icon-search",
                        size: "samll",
                        type: "primary"
                      },
                      on: { click: _vm.onSubmit }
                    },
                    [_vm._v("查询")]
                  )
                ],
                1
              ),
              _c(
                "el-form-item",
                [
                  _c(
                    "el-button",
                    {
                      attrs: { size: "samll", type: "primary" },
                      on: { click: _vm.handleAdd }
                    },
                    [_vm._v("新增")]
                  )
                ],
                1
              )
            ],
            1
          )
        ],
        1
      ),
      _c("div", { staticClass: "queryHeading" }, [_vm._v("查询结果")]),
      _c("stable", {
        ref: "result",
        attrs: {
          "button-is-filter": true,
          config: _vm.tbConfig,
          "need-button": _vm.needButton,
          optionData: _vm.tbOptionData
        }
      }),
      _c(
        "el-dialog",
        {
          attrs: {
            "before-close": _vm.close,
            title: _vm.sdialogConfig.title,
            visible: _vm.dialogVisible,
            width: "60%"
          },
          on: {
            "update:visible": function($event) {
              _vm.dialogVisible = $event
            }
          }
        },
        [
          _c(
            "el-form",
            {
              ref: "form",
              attrs: {
                model: _vm.form,
                "label-positio": "left",
                "label-width": "120px"
              }
            },
            [
              _c(
                "el-row",
                [
                  _c(
                    "el-col",
                    { attrs: { span: 22 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { required: true, label: "公告标题:" } },
                        [
                          _c("el-input", {
                            attrs: {
                              disabled: _vm.isShow,
                              placeholder: "请输入公告名称"
                            },
                            model: {
                              value: _vm.form.noticeTitle,
                              callback: function($$v) {
                                _vm.$set(_vm.form, "noticeTitle", $$v)
                              },
                              expression: "form.noticeTitle"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                [
                  _c(
                    "el-col",
                    { attrs: { span: 10 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { required: true, label: "公告类型:" } },
                        [
                          _c(
                            "el-select",
                            {
                              attrs: {
                                disabled: _vm.isShow,
                                clearable: "",
                                placeholder: "请选择"
                              },
                              model: {
                                value: _vm.form.noticeType,
                                callback: function($$v) {
                                  _vm.$set(_vm.form, "noticeType", $$v)
                                },
                                expression: "form.noticeType"
                              }
                            },
                            _vm._l(_vm.noticeType, function(item) {
                              return _c("el-option", {
                                key: item.value,
                                attrs: { label: item.name, value: item.value }
                              })
                            }),
                            1
                          )
                        ],
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                [
                  _c(
                    "el-col",
                    { attrs: { span: 10 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { required: true, label: "接收人类型:" } },
                        [
                          _c(
                            "el-select",
                            {
                              attrs: {
                                disabled: _vm.isShow,
                                clearable: "",
                                placeholder: "请选择"
                              },
                              on: { change: _vm.changeSelect },
                              model: {
                                value: _vm.form.receiverType,
                                callback: function($$v) {
                                  _vm.$set(_vm.form, "receiverType", $$v)
                                },
                                expression: "form.receiverType"
                              }
                            },
                            _vm._l(_vm.receiverType, function(item) {
                              return _c("el-option", {
                                key: item.value,
                                attrs: { label: item.name, value: item.value }
                              })
                            }),
                            1
                          )
                        ],
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              ),
              _c("el-row", [
                _c(
                  "span",
                  {
                    staticClass: "tips",
                    staticStyle: { color: "red", "margin-bottom": "10px" }
                  },
                  [_vm._v("* 文章内单张图片不能超过3M")]
                ),
                _c(
                  "div",
                  {
                    staticClass: "text-editor",
                    attrs: { id: "editContent", required: true }
                  },
                  [
                    _c("div", { attrs: { id: "div1" } }),
                    _c("div", { attrs: { id: "div2" } })
                  ]
                )
              ]),
              _c(
                "div",
                { staticClass: "transfer-button" },
                [
                  _c("span", { staticClass: "name" }, [_vm._v("公告对象")]),
                  _c(
                    "el-button",
                    {
                      staticClass: "button",
                      attrs: {
                        disabled: _vm.isDisable,
                        size: "mini",
                        type: "primary"
                      },
                      on: { click: _vm.activeClick }
                    },
                    [_vm._v(" 添加 ")]
                  ),
                  _vm._l(_vm.transferShow, function(item) {
                    return _c("div", [_vm._v(_vm._s(item.userName))])
                  })
                ],
                2
              )
            ],
            1
          ),
          _c(
            "span",
            {
              directives: [
                {
                  name: "show",
                  rawName: "v-show",
                  value: !_vm.isShow,
                  expression: "!isShow"
                }
              ],
              staticClass: "dialog-footer",
              attrs: { slot: "footer" },
              slot: "footer"
            },
            [
              _c(
                "el-button",
                {
                  on: {
                    click: function($event) {
                      _vm.dialogVisible = false
                    }
                  }
                },
                [_vm._v("取消")]
              ),
              _c(
                "el-button",
                { attrs: { type: "primary" }, on: { click: _vm.saveAction } },
                [_vm._v("保存")]
              )
            ],
            1
          )
        ],
        1
      ),
      _c(
        "el-dialog",
        {
          attrs: { visible: _vm.dialogVisible1, title: "提示", width: "45%" },
          on: {
            "update:visible": function($event) {
              _vm.dialogVisible1 = $event
            }
          }
        },
        [
          _c("el-transfer", {
            attrs: { data: _vm.transferData },
            model: {
              value: _vm.transferValue,
              callback: function($$v) {
                _vm.transferValue = $$v
              },
              expression: "transferValue"
            }
          }),
          _c(
            "span",
            {
              staticClass: "dialog-footer",
              attrs: { slot: "footer" },
              slot: "footer"
            },
            [
              _c(
                "el-button",
                {
                  attrs: { type: "primary" },
                  on: {
                    click: function($event) {
                      return _vm.finish()
                    }
                  }
                },
                [_vm._v("完成")]
              )
            ],
            1
          )
        ],
        1
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/core-js/internals/inherit-if-required.js":
/*!***************************************************************!*\
  !*** ./node_modules/core-js/internals/inherit-if-required.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");
var setPrototypeOf = __webpack_require__(/*! ../internals/object-set-prototype-of */ "./node_modules/core-js/internals/object-set-prototype-of.js");

// makes subclassing work correct for wrapped built-ins
module.exports = function ($this, dummy, Wrapper) {
  var NewTarget, NewTargetPrototype;
  if (
    // it can work only with native `setPrototypeOf`
    setPrototypeOf &&
    // we haven't completely correct pre-ES6 way for getting `new.target`, so use this
    typeof (NewTarget = dummy.constructor) == 'function' &&
    NewTarget !== Wrapper &&
    isObject(NewTargetPrototype = NewTarget.prototype) &&
    NewTargetPrototype !== Wrapper.prototype
  ) setPrototypeOf($this, NewTargetPrototype);
  return $this;
};


/***/ }),

/***/ "./node_modules/core-js/internals/is-regexp.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/internals/is-regexp.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");
var classof = __webpack_require__(/*! ../internals/classof-raw */ "./node_modules/core-js/internals/classof-raw.js");
var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");

var MATCH = wellKnownSymbol('match');

// `IsRegExp` abstract operation
// https://tc39.es/ecma262/#sec-isregexp
module.exports = function (it) {
  var isRegExp;
  return isObject(it) && ((isRegExp = it[MATCH]) !== undefined ? !!isRegExp : classof(it) == 'RegExp');
};


/***/ }),

/***/ "./node_modules/core-js/modules/es.array.filter.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es.array.filter.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var $filter = __webpack_require__(/*! ../internals/array-iteration */ "./node_modules/core-js/internals/array-iteration.js").filter;
var arrayMethodHasSpeciesSupport = __webpack_require__(/*! ../internals/array-method-has-species-support */ "./node_modules/core-js/internals/array-method-has-species-support.js");

var HAS_SPECIES_SUPPORT = arrayMethodHasSpeciesSupport('filter');

// `Array.prototype.filter` method
// https://tc39.es/ecma262/#sec-array.prototype.filter
// with adding support of @@species
$({ target: 'Array', proto: true, forced: !HAS_SPECIES_SUPPORT }, {
  filter: function filter(callbackfn /* , thisArg */) {
    return $filter(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es.array.find.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/es.array.find.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var $find = __webpack_require__(/*! ../internals/array-iteration */ "./node_modules/core-js/internals/array-iteration.js").find;
var addToUnscopables = __webpack_require__(/*! ../internals/add-to-unscopables */ "./node_modules/core-js/internals/add-to-unscopables.js");

var FIND = 'find';
var SKIPS_HOLES = true;

// Shouldn't skip holes
if (FIND in []) Array(1)[FIND](function () { SKIPS_HOLES = false; });

// `Array.prototype.find` method
// https://tc39.es/ecma262/#sec-array.prototype.find
$({ target: 'Array', proto: true, forced: SKIPS_HOLES }, {
  find: function find(callbackfn /* , that = undefined */) {
    return $find(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});

// https://tc39.es/ecma262/#sec-array.prototype-@@unscopables
addToUnscopables(FIND);


/***/ }),

/***/ "./node_modules/core-js/modules/es.array.map.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/es.array.map.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var $map = __webpack_require__(/*! ../internals/array-iteration */ "./node_modules/core-js/internals/array-iteration.js").map;
var arrayMethodHasSpeciesSupport = __webpack_require__(/*! ../internals/array-method-has-species-support */ "./node_modules/core-js/internals/array-method-has-species-support.js");

var HAS_SPECIES_SUPPORT = arrayMethodHasSpeciesSupport('map');

// `Array.prototype.map` method
// https://tc39.es/ecma262/#sec-array.prototype.map
// with adding support of @@species
$({ target: 'Array', proto: true, forced: !HAS_SPECIES_SUPPORT }, {
  map: function map(callbackfn /* , thisArg */) {
    return $map(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es.object.keys.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es.object.keys.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var toObject = __webpack_require__(/*! ../internals/to-object */ "./node_modules/core-js/internals/to-object.js");
var nativeKeys = __webpack_require__(/*! ../internals/object-keys */ "./node_modules/core-js/internals/object-keys.js");
var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");

var FAILS_ON_PRIMITIVES = fails(function () { nativeKeys(1); });

// `Object.keys` method
// https://tc39.es/ecma262/#sec-object.keys
$({ target: 'Object', stat: true, forced: FAILS_ON_PRIMITIVES }, {
  keys: function keys(it) {
    return nativeKeys(toObject(it));
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es.regexp.constructor.js":
/*!***************************************************************!*\
  !*** ./node_modules/core-js/modules/es.regexp.constructor.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/core-js/internals/descriptors.js");
var global = __webpack_require__(/*! ../internals/global */ "./node_modules/core-js/internals/global.js");
var isForced = __webpack_require__(/*! ../internals/is-forced */ "./node_modules/core-js/internals/is-forced.js");
var inheritIfRequired = __webpack_require__(/*! ../internals/inherit-if-required */ "./node_modules/core-js/internals/inherit-if-required.js");
var defineProperty = __webpack_require__(/*! ../internals/object-define-property */ "./node_modules/core-js/internals/object-define-property.js").f;
var getOwnPropertyNames = __webpack_require__(/*! ../internals/object-get-own-property-names */ "./node_modules/core-js/internals/object-get-own-property-names.js").f;
var isRegExp = __webpack_require__(/*! ../internals/is-regexp */ "./node_modules/core-js/internals/is-regexp.js");
var getFlags = __webpack_require__(/*! ../internals/regexp-flags */ "./node_modules/core-js/internals/regexp-flags.js");
var stickyHelpers = __webpack_require__(/*! ../internals/regexp-sticky-helpers */ "./node_modules/core-js/internals/regexp-sticky-helpers.js");
var redefine = __webpack_require__(/*! ../internals/redefine */ "./node_modules/core-js/internals/redefine.js");
var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
var enforceInternalState = __webpack_require__(/*! ../internals/internal-state */ "./node_modules/core-js/internals/internal-state.js").enforce;
var setSpecies = __webpack_require__(/*! ../internals/set-species */ "./node_modules/core-js/internals/set-species.js");
var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");

var MATCH = wellKnownSymbol('match');
var NativeRegExp = global.RegExp;
var RegExpPrototype = NativeRegExp.prototype;
var re1 = /a/g;
var re2 = /a/g;

// "new" should create a new object, old webkit bug
var CORRECT_NEW = new NativeRegExp(re1) !== re1;

var UNSUPPORTED_Y = stickyHelpers.UNSUPPORTED_Y;

var FORCED = DESCRIPTORS && isForced('RegExp', (!CORRECT_NEW || UNSUPPORTED_Y || fails(function () {
  re2[MATCH] = false;
  // RegExp constructor can alter flags and IsRegExp works correct with @@match
  return NativeRegExp(re1) != re1 || NativeRegExp(re2) == re2 || NativeRegExp(re1, 'i') != '/a/i';
})));

// `RegExp` constructor
// https://tc39.es/ecma262/#sec-regexp-constructor
if (FORCED) {
  var RegExpWrapper = function RegExp(pattern, flags) {
    var thisIsRegExp = this instanceof RegExpWrapper;
    var patternIsRegExp = isRegExp(pattern);
    var flagsAreUndefined = flags === undefined;
    var sticky;

    if (!thisIsRegExp && patternIsRegExp && pattern.constructor === RegExpWrapper && flagsAreUndefined) {
      return pattern;
    }

    if (CORRECT_NEW) {
      if (patternIsRegExp && !flagsAreUndefined) pattern = pattern.source;
    } else if (pattern instanceof RegExpWrapper) {
      if (flagsAreUndefined) flags = getFlags.call(pattern);
      pattern = pattern.source;
    }

    if (UNSUPPORTED_Y) {
      sticky = !!flags && flags.indexOf('y') > -1;
      if (sticky) flags = flags.replace(/y/g, '');
    }

    var result = inheritIfRequired(
      CORRECT_NEW ? new NativeRegExp(pattern, flags) : NativeRegExp(pattern, flags),
      thisIsRegExp ? this : RegExpPrototype,
      RegExpWrapper
    );

    if (UNSUPPORTED_Y && sticky) {
      var state = enforceInternalState(result);
      state.sticky = true;
    }

    return result;
  };
  var proxy = function (key) {
    key in RegExpWrapper || defineProperty(RegExpWrapper, key, {
      configurable: true,
      get: function () { return NativeRegExp[key]; },
      set: function (it) { NativeRegExp[key] = it; }
    });
  };
  var keys = getOwnPropertyNames(NativeRegExp);
  var index = 0;
  while (keys.length > index) proxy(keys[index++]);
  RegExpPrototype.constructor = RegExpWrapper;
  RegExpWrapper.prototype = RegExpPrototype;
  redefine(global, 'RegExp', RegExpWrapper);
}

// https://tc39.es/ecma262/#sec-get-regexp-@@species
setSpecies('RegExp');


/***/ }),

/***/ "./node_modules/core-js/modules/es.regexp.to-string.js":
/*!*************************************************************!*\
  !*** ./node_modules/core-js/modules/es.regexp.to-string.js ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var redefine = __webpack_require__(/*! ../internals/redefine */ "./node_modules/core-js/internals/redefine.js");
var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/core-js/internals/an-object.js");
var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
var flags = __webpack_require__(/*! ../internals/regexp-flags */ "./node_modules/core-js/internals/regexp-flags.js");

var TO_STRING = 'toString';
var RegExpPrototype = RegExp.prototype;
var nativeToString = RegExpPrototype[TO_STRING];

var NOT_GENERIC = fails(function () { return nativeToString.call({ source: 'a', flags: 'b' }) != '/a/b'; });
// FF44- RegExp#toString has a wrong name
var INCORRECT_NAME = nativeToString.name != TO_STRING;

// `RegExp.prototype.toString` method
// https://tc39.es/ecma262/#sec-regexp.prototype.tostring
if (NOT_GENERIC || INCORRECT_NAME) {
  redefine(RegExp.prototype, TO_STRING, function toString() {
    var R = anObject(this);
    var p = String(R.source);
    var rf = R.flags;
    var f = String(rf === undefined && R instanceof RegExp && !('flags' in RegExpPrototype) ? flags.call(R) : rf);
    return '/' + p + '/' + f;
  }, { unsafe: true });
}


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/Announcements.vue?vue&type=style&index=0&lang=less&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--10-oneOf-1-2!./node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/mga-manage/Announcements.vue?vue&type=style&index=0&lang=less& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".allcover {\n  position: absolute;\n  top: 0;\n  right: 0;\n}\n.ctt {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n}\n.tb {\n  position: absolute;\n  top: 50%;\n  transform: translateY(-50%);\n}\n.lr {\n  position: absolute;\n  left: 50%;\n  transform: translateX(-50%);\n}\n.el-form-item__label {\n  white-space: nowrap;\n}\n.el-select {\n  width: 100%;\n}\n#container {\n  padding: 15px;\n}\n#container .queryHeading {\n  background-color: #f4f4f5;\n  color: #909399;\n  font-size: 14px;\n  padding: 10px 10px;\n  margin-bottom: 15px;\n}\n#container .pagination {\n  margin-top: 15px;\n  float: right;\n}\n#container .editinfo {\n  margin-bottom: 15px;\n}\n#container .dialog-content .list {\n  margin-bottom: 15px;\n}\n#container .dialog-title {\n  font-size: 20px;\n}\n#container .dialog-footer {\n  padding-top: 20px;\n  display: flex;\n  justify-content: flex-end;\n}\n#container /deep/ .el-transfer-panel {\n  height: 400px !important;\n}\n#container /deep/ .el-checkbox-group {\n  height: 358px;\n}\n#container .el-transfer-panel__list.is-filterable {\n  height: 300px;\n}\n#container .el-date-editor.el-input {\n  width: 180px !important;\n}\n#container .el-select {\n  width: 180px;\n}\n#container .self .el-input--prefix .el-input__inner {\n  width: 230px;\n}\n#container .self .el-date-editor.el-input {\n  width: 220px !important;\n}\n#container .transfer-button {\n  margin-top: 2%;\n}\n#container .transfer-button .name::before {\n  content: '*\\a0';\n  display: inline-block;\n  vertical-align: center;\n  color: red;\n}\n#container .transfer-button .button {\n  margin-left: 3%;\n}\n#container .transfer-button div {\n  margin-top: 2%;\n  margin-left: 9.5%;\n}\n.text-editor {\n  min-height: 220px;\n  margin-bottom: 30px;\n  border: 1px solid #ececec;\n}\n.selRow {\n  margin: 20px auto;\n}\n.selRow label {\n  display: inline-block;\n  width: 100px;\n  text-align: right;\n}\n.selfCon .el-form-item__content .el-select {\n  position: relative;\n  font-size: 14px;\n  display: inline-block;\n  width: 100% !important;\n}\n.addBtn {\n  margin-left: 50px;\n}\n.selProduct {\n  margin-top: 10px;\n  margin-left: 160px;\n  max-height: 265px;\n  overflow: auto;\n}\n.selProduct .selItem {\n  margin-top: 10px;\n}\n.el-transfer-panel {\n  width: 36%;\n}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/Announcements.vue?vue&type=style&index=0&lang=less&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--10-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--10-oneOf-1-2!./node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/mga-manage/Announcements.vue?vue&type=style&index=0&lang=less& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--10-oneOf-1-2!../../../node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../node_modules/vue-loader/lib??vue-loader-options!./Announcements.vue?vue&type=style&index=0&lang=less& */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/Announcements.vue?vue&type=style&index=0&lang=less&");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("6312f169", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/api/Announcements.js":
/*!**********************************!*\
  !*** ./src/api/Announcements.js ***!
  \**********************************/
/*! exports provided: noticeQuery, editApi, newPage, upDownOnlie, deleteId, changeEditApi, publishByApi, noticeUserList */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "noticeQuery", function() { return noticeQuery; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "editApi", function() { return editApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "newPage", function() { return newPage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "upDownOnlie", function() { return upDownOnlie; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "deleteId", function() { return deleteId; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "changeEditApi", function() { return changeEditApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "publishByApi", function() { return publishByApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "noticeUserList", function() { return noticeUserList; });
/* harmony import */ var _config_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/config/service */ "./src/config/service.js");
/* harmony import */ var _config_env__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/config/env */ "./src/config/env.js");
 //axios


var loginBase = _config_env__WEBPACK_IMPORTED_MODULE_1__["baseUrl"];
function noticeQuery(params) {
  var url = "".concat(loginBase, "/admin/notice/list");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_0__["Service"])({
    url: url,
    method: method,
    params: params
  });
}
function editApi(params) {
  var url = "".concat(loginBase, "/admin/notice/list");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_0__["Service"])({
    url: url,
    method: method,
    params: params
  });
}
function newPage(data) {
  var url = "".concat(loginBase, "/admin/notice/insert");
  var method = "post";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_0__["Service"])({
    url: url,
    method: method,
    data: data
  });
}
function upDownOnlie(data) {
  var url = "".concat(loginBase, "/admin/notice/online");
  var method = "post";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_0__["Service"])({
    url: url,
    method: method,
    data: data
  });
}
function deleteId(params) {
  var url = "".concat(loginBase, "/admin/notice/delete");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_0__["Service"])({
    url: url,
    method: method,
    params: params
  });
}
function changeEditApi(data) {
  var url = "".concat(loginBase, "/admin/notice/updateList");
  var method = "post";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_0__["Service"])({
    url: url,
    method: method,
    data: data
  });
}
function publishByApi(params) {
  var url = "".concat(loginBase, "/admin/notice/publishByList");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_0__["Service"])({
    url: url,
    method: method,
    params: params
  });
}
function noticeUserList(params) {
  var url = "".concat(loginBase, "/admin/activity/queryNoticeUserList");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_0__["Service"])({
    url: url,
    method: method,
    params: params
  });
}

/***/ }),

/***/ "./src/common/mixin/edit/deploy.js":
/*!*****************************************!*\
  !*** ./src/common/mixin/edit/deploy.js ***!
  \*****************************************/
/*! exports provided: imgDeploy, menu */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "imgDeploy", function() { return imgDeploy; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "menu", function() { return menu; });
/* harmony import */ var api_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! api/api */ "./src/api/api.js");
/* harmony import */ var _config_env__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/config/env */ "./src/config/env.js");


var imgDeploy = {
  Server: api_api__WEBPACK_IMPORTED_MODULE_0__["uploadUrl"],
  MaxLength: 3,
  Params: {
    midAddr: _config_env__WEBPACK_IMPORTED_MODULE_1__["uploadPicPath"].picPath
  },
  MaxSize: 2 * 1024 * 1024,
  ImgHooks: {
    customInsert: function customInsert(insertLink, result, editor) {
      var url = result.data.accessPath;
      insertLink(url);
    },
    before: function before(xhr, editor, files) {},
    success: function success(xhr, editor, result) {
      console.log('上传成功');
    },
    fail: function fail(xhr, editor, result) {
      console.log('上传失败,原因是' + result);
    },
    error: function error(xhr, editor) {
      console.log('上传出错');
    },
    timeout: function timeout(xhr, editor) {
      console.log('上传超时');
    }
  }
};
var menu = [// 'head',
'bold', 'fontSize', 'fontName', // 'italic',
'underline', // 'strikeThrough',
'indent', // 'lineHeight',
'foreColor', // 'backColor',
// 'link',
// 'list',
// 'todo',
'justify', // 'quote',
// 'emoticon',
'image', 'video', 'table', // 'code',
// 'splitLine',
'undo', 'redo'];

/***/ }),

/***/ "./src/common/mixin/edit/handle.js":
/*!*****************************************!*\
  !*** ./src/common/mixin/edit/handle.js ***!
  \*****************************************/
/*! exports provided: createEdit */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createEdit", function() { return createEdit; });
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_regexp_constructor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.regexp.constructor.js */ "./node_modules/core-js/modules/es.regexp.constructor.js");
/* harmony import */ var core_js_modules_es_regexp_constructor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_constructor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var wangeditor__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! wangeditor */ "./node_modules/wangeditor/dist/wangEditor.js");
/* harmony import */ var wangeditor__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(wangeditor__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var common_mixin_edit_deploy__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! common/mixin/edit/deploy */ "./src/common/mixin/edit/deploy.js");







var createEdit = {
  data: function data() {
    return {
      E: wangeditor__WEBPACK_IMPORTED_MODULE_5___default.a,
      RichTextEditor: {}
    };
  },
  methods: {
    initEdit: function initEdit() {
      if (Object.keys(this.RichTextEditor).length === 0) {
        this.CreateEdit();
      }
    },
    CreateEdit: function CreateEdit() {
      var editor = new wangeditor__WEBPACK_IMPORTED_MODULE_5___default.a('#div1');
      editor.config.uploadFileName = 'file';
      editor.config.withCredentials = true;
      editor.config.menus = common_mixin_edit_deploy__WEBPACK_IMPORTED_MODULE_6__["menu"];
      editor.config.uploadImgServer = common_mixin_edit_deploy__WEBPACK_IMPORTED_MODULE_6__["imgDeploy"].Server;
      editor.config.uploadImgMaxLength = common_mixin_edit_deploy__WEBPACK_IMPORTED_MODULE_6__["imgDeploy"].MaxLength;
      editor.config.uploadImgParams = common_mixin_edit_deploy__WEBPACK_IMPORTED_MODULE_6__["imgDeploy"].Params;
      editor.config.uploadImgMaxSize = common_mixin_edit_deploy__WEBPACK_IMPORTED_MODULE_6__["imgDeploy"].MaxSize;
      editor.config.uploadImgHooks = common_mixin_edit_deploy__WEBPACK_IMPORTED_MODULE_6__["imgDeploy"].ImgHooks;
      editor.create();

      String.prototype.replaceAll = function (FindText, RepText) {
        return this.replace(new RegExp(FindText, 'g'), RepText);
      };

      this.RichTextEditor = editor;
    }
  }
};

/***/ }),

/***/ "./src/views/mga-manage/Announcements.vue":
/*!************************************************!*\
  !*** ./src/views/mga-manage/Announcements.vue ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Announcements_vue_vue_type_template_id_88c1ea3c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Announcements.vue?vue&type=template&id=88c1ea3c& */ "./src/views/mga-manage/Announcements.vue?vue&type=template&id=88c1ea3c&");
/* harmony import */ var _Announcements_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Announcements.vue?vue&type=script&lang=js& */ "./src/views/mga-manage/Announcements.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _Announcements_vue_vue_type_style_index_0_lang_less___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Announcements.vue?vue&type=style&index=0&lang=less& */ "./src/views/mga-manage/Announcements.vue?vue&type=style&index=0&lang=less&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Announcements_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Announcements_vue_vue_type_template_id_88c1ea3c___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Announcements_vue_vue_type_template_id_88c1ea3c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/mga-manage/Announcements.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/mga-manage/Announcements.vue?vue&type=script&lang=js&":
/*!*************************************************************************!*\
  !*** ./src/views/mga-manage/Announcements.vue?vue&type=script&lang=js& ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_12_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Announcements_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--12-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../node_modules/vue-loader/lib??vue-loader-options!./Announcements.vue?vue&type=script&lang=js& */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/Announcements.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_12_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Announcements_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/mga-manage/Announcements.vue?vue&type=style&index=0&lang=less&":
/*!**********************************************************************************!*\
  !*** ./src/views/mga-manage/Announcements.vue?vue&type=style&index=0&lang=less& ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Announcements_vue_vue_type_style_index_0_lang_less___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--10-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--10-oneOf-1-2!../../../node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../node_modules/vue-loader/lib??vue-loader-options!./Announcements.vue?vue&type=style&index=0&lang=less& */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/Announcements.vue?vue&type=style&index=0&lang=less&");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Announcements_vue_vue_type_style_index_0_lang_less___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Announcements_vue_vue_type_style_index_0_lang_less___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Announcements_vue_vue_type_style_index_0_lang_less___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Announcements_vue_vue_type_style_index_0_lang_less___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/mga-manage/Announcements.vue?vue&type=template&id=88c1ea3c&":
/*!*******************************************************************************!*\
  !*** ./src/views/mga-manage/Announcements.vue?vue&type=template&id=88c1ea3c& ***!
  \*******************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Announcements_vue_vue_type_template_id_88c1ea3c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"b9734f90-vue-loader-template"}!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../node_modules/vue-loader/lib??vue-loader-options!./Announcements.vue?vue&type=template&id=88c1ea3c& */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"b9734f90-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/Announcements.vue?vue&type=template&id=88c1ea3c&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Announcements_vue_vue_type_template_id_88c1ea3c___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Announcements_vue_vue_type_template_id_88c1ea3c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=17.js.map