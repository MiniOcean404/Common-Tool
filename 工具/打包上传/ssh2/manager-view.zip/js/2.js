(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[2],{

/***/ "./node_modules/core-js/modules/es.array.join.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/es.array.join.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var IndexedObject = __webpack_require__(/*! ../internals/indexed-object */ "./node_modules/core-js/internals/indexed-object.js");
var toIndexedObject = __webpack_require__(/*! ../internals/to-indexed-object */ "./node_modules/core-js/internals/to-indexed-object.js");
var arrayMethodIsStrict = __webpack_require__(/*! ../internals/array-method-is-strict */ "./node_modules/core-js/internals/array-method-is-strict.js");

var nativeJoin = [].join;

var ES3_STRINGS = IndexedObject != Object;
var STRICT_METHOD = arrayMethodIsStrict('join', ',');

// `Array.prototype.join` method
// https://tc39.es/ecma262/#sec-array.prototype.join
$({ target: 'Array', proto: true, forced: ES3_STRINGS || !STRICT_METHOD }, {
  join: function join(separator) {
    return nativeJoin.call(toIndexedObject(this), separator === undefined ? ',' : separator);
  }
});


/***/ }),

/***/ "./src/api/api.js":
/*!************************!*\
  !*** ./src/api/api.js ***!
  \************************/
/*! exports provided: uploadUrl, uploadReceiptUrl, uploadReVisitUrl, uploadSettleUrl, importAgentUrl, importRiskRateUrl, importFreelookDate, importInscDataUrl, importExcel, login, logout, menu, password, userInfoShwo, userInfoUp, button, adminExportUser, checkpassApi, gzhbannerlist, gzhbanneradd, gzhbannerdetail, bannerDelApi, appbannerdeleteApi, gzhbannerupdata, gzhbannerpulish, proBannerList, proBannerAdd, proBannerDetail, proBannerUp, proBannerpublish, searchprolist, addpronews, BgProDetailById, updateProNews, delProNews, searchBannerList, addBannerList, reBannerDetail, updateBannerList, offTheShelfConf, searchRelationList, addRelationPro, searchProListView, updateInsrelationpro, addInsrelationpro, saveRecommend, searchClock, updateClock, getdirectorylist, getCompanylists, getPosterlists, putPosteradd, putPosterremove, updatestatus, getPosterdetail, addTestForm, getAnswerList, getAnswerDetail, removeTestForm, updateStatus, answerNameList, getQueTypeList, removeRueTypeId, getqueTypedetail, addqueType, getqueTypeselect, updateuseType, getQuestionList, addquestion, removeQuestionId, getquestiondetail, updateuseQuestion, getAnswersList, addAnswers, getquestionAnswers, getAnswersdetail, updateuseAnswers, removeAnswer, getRecordList, addOrUpdateRecord, getRecorddetail, removeRecordId, searchLiveList, addLiveList, returnNewsById, updateLiveList, deleteLiveList, searchAgentList, searchAgentById, updateAgentStatus, editAgentById, allType, searchDictList, addDictList, updatedictlist, deletdictlist, getProList, updateHoldTime, getOutProList, updateOutProduct, saveOutProduct, getInsuranceCompany, getInsuranceCompanyThree, getpaymentperiod, selectrisktype, updateOutUse, getOutDetail, saveCommission, getOutCompanyByCode, deleteCommission, deleteEnsure, bgsearchlist, showdetail, updatedetail, uploaddata, deletedetail, searchAppointList, reDetailAppoint, searchFeedList, updateAppointList, orderList, searchOrderDetail, searchOrderDetailByOrder, searchOrderApi, orderBindAgent, searchProxyList, searchUserList, addUserList, updateUserStatus, setRole, userIncludeRole, addUserRoleList, refreshUserList, updateUserList, searchRoleList, addRoleList, upRoleList, exRoleStatus, getUserTree, permissionUp, tree, update, add, remove, agentListApi, goldenAgentApi, appTeamListApi, appTeamOrderApi, knowledgeListApi, knowledgeSettingApi, konwledgeUpdateApi, knowledgeRemoveApi, knowledgePublishApi, knowledgeDetailApi, signCardListApi, signCardSettingApi, signCardDetailApi, microShopListApi, microShopExamineApi, microShopDetailApi, agentCardListApi, agentCardAuditApi, agentCardDetailApi, searchRelationListApp, addRelationProApp, searchProListViewApp, updateInsrelationproApp, addInsrelationproApp, saveRecommendApp, receiptListApi, signedReceiptDateApi, revisitListApi, signedRevisitDateApi, revisitDownload, receiptDownload, freelookDownload, supplierInfo, formalAssessApi, reWithdrawalCalculation */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "uploadUrl", function() { return uploadUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "uploadReceiptUrl", function() { return uploadReceiptUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "uploadReVisitUrl", function() { return uploadReVisitUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "uploadSettleUrl", function() { return uploadSettleUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "importAgentUrl", function() { return importAgentUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "importRiskRateUrl", function() { return importRiskRateUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "importFreelookDate", function() { return importFreelookDate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "importInscDataUrl", function() { return importInscDataUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "importExcel", function() { return importExcel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "login", function() { return login; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "logout", function() { return logout; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "menu", function() { return menu; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "password", function() { return password; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "userInfoShwo", function() { return userInfoShwo; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "userInfoUp", function() { return userInfoUp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "button", function() { return button; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "adminExportUser", function() { return adminExportUser; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "checkpassApi", function() { return checkpassApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "gzhbannerlist", function() { return gzhbannerlist; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "gzhbanneradd", function() { return gzhbanneradd; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "gzhbannerdetail", function() { return gzhbannerdetail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bannerDelApi", function() { return bannerDelApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "appbannerdeleteApi", function() { return appbannerdeleteApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "gzhbannerupdata", function() { return gzhbannerupdata; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "gzhbannerpulish", function() { return gzhbannerpulish; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "proBannerList", function() { return proBannerList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "proBannerAdd", function() { return proBannerAdd; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "proBannerDetail", function() { return proBannerDetail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "proBannerUp", function() { return proBannerUp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "proBannerpublish", function() { return proBannerpublish; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchprolist", function() { return searchprolist; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addpronews", function() { return addpronews; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BgProDetailById", function() { return BgProDetailById; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateProNews", function() { return updateProNews; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "delProNews", function() { return delProNews; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchBannerList", function() { return searchBannerList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addBannerList", function() { return addBannerList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "reBannerDetail", function() { return reBannerDetail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateBannerList", function() { return updateBannerList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "offTheShelfConf", function() { return offTheShelfConf; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchRelationList", function() { return searchRelationList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addRelationPro", function() { return addRelationPro; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchProListView", function() { return searchProListView; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateInsrelationpro", function() { return updateInsrelationpro; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addInsrelationpro", function() { return addInsrelationpro; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "saveRecommend", function() { return saveRecommend; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchClock", function() { return searchClock; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateClock", function() { return updateClock; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getdirectorylist", function() { return getdirectorylist; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCompanylists", function() { return getCompanylists; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getPosterlists", function() { return getPosterlists; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "putPosteradd", function() { return putPosteradd; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "putPosterremove", function() { return putPosterremove; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updatestatus", function() { return updatestatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getPosterdetail", function() { return getPosterdetail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addTestForm", function() { return addTestForm; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getAnswerList", function() { return getAnswerList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getAnswerDetail", function() { return getAnswerDetail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeTestForm", function() { return removeTestForm; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateStatus", function() { return updateStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "answerNameList", function() { return answerNameList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getQueTypeList", function() { return getQueTypeList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeRueTypeId", function() { return removeRueTypeId; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getqueTypedetail", function() { return getqueTypedetail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addqueType", function() { return addqueType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getqueTypeselect", function() { return getqueTypeselect; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateuseType", function() { return updateuseType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getQuestionList", function() { return getQuestionList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addquestion", function() { return addquestion; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeQuestionId", function() { return removeQuestionId; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getquestiondetail", function() { return getquestiondetail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateuseQuestion", function() { return updateuseQuestion; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getAnswersList", function() { return getAnswersList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addAnswers", function() { return addAnswers; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getquestionAnswers", function() { return getquestionAnswers; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getAnswersdetail", function() { return getAnswersdetail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateuseAnswers", function() { return updateuseAnswers; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeAnswer", function() { return removeAnswer; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getRecordList", function() { return getRecordList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addOrUpdateRecord", function() { return addOrUpdateRecord; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getRecorddetail", function() { return getRecorddetail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeRecordId", function() { return removeRecordId; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchLiveList", function() { return searchLiveList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addLiveList", function() { return addLiveList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "returnNewsById", function() { return returnNewsById; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateLiveList", function() { return updateLiveList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "deleteLiveList", function() { return deleteLiveList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchAgentList", function() { return searchAgentList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchAgentById", function() { return searchAgentById; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateAgentStatus", function() { return updateAgentStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "editAgentById", function() { return editAgentById; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "allType", function() { return allType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchDictList", function() { return searchDictList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addDictList", function() { return addDictList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updatedictlist", function() { return updatedictlist; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "deletdictlist", function() { return deletdictlist; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getProList", function() { return getProList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateHoldTime", function() { return updateHoldTime; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getOutProList", function() { return getOutProList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateOutProduct", function() { return updateOutProduct; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "saveOutProduct", function() { return saveOutProduct; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getInsuranceCompany", function() { return getInsuranceCompany; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getInsuranceCompanyThree", function() { return getInsuranceCompanyThree; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getpaymentperiod", function() { return getpaymentperiod; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectrisktype", function() { return selectrisktype; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateOutUse", function() { return updateOutUse; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getOutDetail", function() { return getOutDetail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "saveCommission", function() { return saveCommission; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getOutCompanyByCode", function() { return getOutCompanyByCode; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "deleteCommission", function() { return deleteCommission; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "deleteEnsure", function() { return deleteEnsure; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bgsearchlist", function() { return bgsearchlist; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "showdetail", function() { return showdetail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updatedetail", function() { return updatedetail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "uploaddata", function() { return uploaddata; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "deletedetail", function() { return deletedetail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchAppointList", function() { return searchAppointList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "reDetailAppoint", function() { return reDetailAppoint; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchFeedList", function() { return searchFeedList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateAppointList", function() { return updateAppointList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "orderList", function() { return orderList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchOrderDetail", function() { return searchOrderDetail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchOrderDetailByOrder", function() { return searchOrderDetailByOrder; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchOrderApi", function() { return searchOrderApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "orderBindAgent", function() { return orderBindAgent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchProxyList", function() { return searchProxyList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchUserList", function() { return searchUserList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addUserList", function() { return addUserList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateUserStatus", function() { return updateUserStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setRole", function() { return setRole; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "userIncludeRole", function() { return userIncludeRole; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addUserRoleList", function() { return addUserRoleList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "refreshUserList", function() { return refreshUserList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateUserList", function() { return updateUserList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchRoleList", function() { return searchRoleList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addRoleList", function() { return addRoleList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "upRoleList", function() { return upRoleList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "exRoleStatus", function() { return exRoleStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getUserTree", function() { return getUserTree; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "permissionUp", function() { return permissionUp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tree", function() { return tree; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "update", function() { return update; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "add", function() { return add; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "remove", function() { return remove; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "agentListApi", function() { return agentListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "goldenAgentApi", function() { return goldenAgentApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "appTeamListApi", function() { return appTeamListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "appTeamOrderApi", function() { return appTeamOrderApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "knowledgeListApi", function() { return knowledgeListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "knowledgeSettingApi", function() { return knowledgeSettingApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "konwledgeUpdateApi", function() { return konwledgeUpdateApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "knowledgeRemoveApi", function() { return knowledgeRemoveApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "knowledgePublishApi", function() { return knowledgePublishApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "knowledgeDetailApi", function() { return knowledgeDetailApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "signCardListApi", function() { return signCardListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "signCardSettingApi", function() { return signCardSettingApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "signCardDetailApi", function() { return signCardDetailApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "microShopListApi", function() { return microShopListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "microShopExamineApi", function() { return microShopExamineApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "microShopDetailApi", function() { return microShopDetailApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "agentCardListApi", function() { return agentCardListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "agentCardAuditApi", function() { return agentCardAuditApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "agentCardDetailApi", function() { return agentCardDetailApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchRelationListApp", function() { return searchRelationListApp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addRelationProApp", function() { return addRelationProApp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchProListViewApp", function() { return searchProListViewApp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateInsrelationproApp", function() { return updateInsrelationproApp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addInsrelationproApp", function() { return addInsrelationproApp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "saveRecommendApp", function() { return saveRecommendApp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "receiptListApi", function() { return receiptListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "signedReceiptDateApi", function() { return signedReceiptDateApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "revisitListApi", function() { return revisitListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "signedRevisitDateApi", function() { return signedRevisitDateApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "revisitDownload", function() { return revisitDownload; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "receiptDownload", function() { return receiptDownload; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "freelookDownload", function() { return freelookDownload; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "supplierInfo", function() { return supplierInfo; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "formalAssessApi", function() { return formalAssessApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "reWithdrawalCalculation", function() { return reWithdrawalCalculation; });
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _config_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/config/service */ "./src/config/service.js");
/* harmony import */ var _config_env__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/config/env */ "./src/config/env.js");



 //axios


var adminBase = _config_env__WEBPACK_IMPORTED_MODULE_4__["baseUrl"]; //"http://10.10.200.210:8086" //http://10.20.110.112:8089    http://115.159.235.37:8089 杨浩

var accountBase = _config_env__WEBPACK_IMPORTED_MODULE_4__["baseUrl"]; //"http://10.10.200.210:8086"  //http://115.159.235.37:8002

var orderBase = _config_env__WEBPACK_IMPORTED_MODULE_4__["baseUrl"]; //"http://10.10.200.210:8086"    //http://115.159.235.37:8001

var productBase = _config_env__WEBPACK_IMPORTED_MODULE_4__["baseUrl"]; //"http://10.10.200.210:8086" //http://10.20.110.52:8004 http://115.159.235.37:8004 李广昌
// const loginBase = 'http://10.10.200.217:8086' //"http://10.20.110.94:8088" //http://10.20.110.94:8088 李必攀

var loginBase = _config_env__WEBPACK_IMPORTED_MODULE_4__["baseUrl"]; //"http://10.20.110.94:8088" //http://10.20.110.94:8088 李必攀

var downloadBase = "".concat(_config_env__WEBPACK_IMPORTED_MODULE_4__["baseUrl"], "/admin/zyUser/export"); //excel下载地址

var uploadUrl = "".concat(_config_env__WEBPACK_IMPORTED_MODULE_4__["baseUrl"], "/admin/go/upload"); //文件上传路径 http://115.159.235.37:8089/admin/go/

var uploadReceiptUrl = "".concat(_config_env__WEBPACK_IMPORTED_MODULE_4__["baseUrl"], "/admin/receipt/importReceiptDate"); //回执上传路径

var uploadReVisitUrl = "".concat(_config_env__WEBPACK_IMPORTED_MODULE_4__["baseUrl"], "/admin/revisit/importRevisitDate"); //回执上传路径

var uploadSettleUrl = "".concat(_config_env__WEBPACK_IMPORTED_MODULE_4__["baseUrl"], "/admin/settlement/importSettlementDate"); //回执上传路径

var importAgentUrl = "".concat(_config_env__WEBPACK_IMPORTED_MODULE_4__["baseUrl"], "/admin/agent/importAgent"); //mga 人员管理导入

var importRiskRateUrl = "".concat(_config_env__WEBPACK_IMPORTED_MODULE_4__["baseUrl"], "/admin/product/importRiskRate"); //mga 费率上传

var importFreelookDate = "".concat(_config_env__WEBPACK_IMPORTED_MODULE_4__["baseUrl"], "/admin/freelook/importFreelookDate"); //犹豫期上传路径

var importInscDataUrl = "".concat(_config_env__WEBPACK_IMPORTED_MODULE_4__["baseUrl"], "/admin/reconciliation/importInscData"); //对账管理 -上传保司对账

var importExcel = "".concat(_config_env__WEBPACK_IMPORTED_MODULE_4__["baseUrl"], "/admin/preservation/importExcel"); //------------------------------------------------------------------------进入-------------------------------------------------------------------------------
//登录

function login(data) {
  var url = "".concat(loginBase, "/admin/login");
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //登出

function logout(data) {
  var url = "".concat(loginBase, "/admin/logout");
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //菜单渲染

function menu(params) {
  var url = "".concat(loginBase, "/admin/home/menu/list");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //修改密码

function password(data) {
  var url = "".concat(adminBase, "/admin/home/password");
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //修改用户信息回显

function userInfoShwo(params) {
  var url = "".concat(adminBase, "/admin/home/userInfo/detail");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //修改用户信息

function userInfoUp(data) {
  var url = "".concat(adminBase, "/admin/home/userInfo/update");
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //根据权限获取单个页面存在的按钮

function button(params) {
  var url = "".concat(loginBase, "/admin/home/menu/button");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //导出数据

function adminExportUser(params) {
  function jsontoQuery(params) {
    //定义一个空数组
    var ary = [];
    var str; //对象的遍历操作

    for (var i in params) {
      //将对象名push到数组里
      ary.push(i); //对象的值

      ary.push("=".concat(params[i], "& "));
    } //将数组转变成字符串


    str = ary.join(""); //将字符串最后一个&符剪切走

    str = str.slice(0, str.length - 1);
    return str;
  }

  var queryString = jsontoQuery(params);
  console.log(queryString);
  var url = "".concat(downloadBase, "?").concat(queryString, " ");
  window.location.href = url;
} //banner图删除 app管理模块banner删除

function checkpassApi(params) {
  var url = adminBase + "/admin/home/userInfo/checkpass";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //------------------------------------------------------------------------微信公众号管理-----------------------------------------------------------------------

/* Bannder图配置*/
//banner图列表

function gzhbannerlist(params) {
  var url = adminBase + "/admin/app/banner/list";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //banner图新增

function gzhbanneradd(data) {
  var url = adminBase + "/admin/app/banner/add";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //banner图修改回显

function gzhbannerdetail(params) {
  var url = adminBase + "/admin/app/banner/detail";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //banner删除

function bannerDelApi(params) {
  var url = adminBase + "/admin/app/banner/delete";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //banner图删除 app管理模块banner删除

function appbannerdeleteApi(params) {
  var url = adminBase + "/admin/app/homePage/delete";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //banner修改

function gzhbannerupdata(data) {
  var url = adminBase + "/admin/app/banner/update";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //banner图发布/下架

function gzhbannerpulish(params) {
  var url = adminBase + "/admin/app/banner/publish";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
}
/* 产品轮播图配置*/
//产品banner图列表

function proBannerList(params) {
  var url = adminBase + "/admin/app/banner/list";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //产品banner图新增

function proBannerAdd(data) {
  var url = adminBase + "/admin/app/banner/add";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //产品banner图修改回显

function proBannerDetail(params) {
  var url = adminBase + "/admin/app/banner/detail";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //产品banner修改

function proBannerUp(data) {
  var url = adminBase + "/admin/app/banner/update";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //产品banner图发布/下架

function proBannerpublish(params) {
  var url = adminBase + "/admin/app/banner/publish";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //------------------------------------------------------------------------微信公众号管理-----------------------------------------------------------------------

/* 财保头条上传*/
//查询财保头条

function searchprolist(params) {
  var url = adminBase + "/admin/wxAccount/faeIns/list";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //新建财保头条

function addpronews(data) {
  var url = adminBase + "/admin/wxAccount/faeIns/add";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //编辑财保头条

function BgProDetailById(params) {
  var url = adminBase + "/admin/wxAccount/faeIns/detail";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //更新财保头条

function updateProNews(data) {
  var url = adminBase + "/admin/wxAccount/faeIns/update";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //删除财保头条

function delProNews(params) {
  var url = adminBase + "/admin/wxAccount/faeIns/remove";
  var method = "delete";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
}
/* 财保商城banner图配置*/
//查询财保商城banner图列表

function searchBannerList(params) {
  var url = adminBase + "/admin/wxAccount/mallBanner/list";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //财保商城banner图新增

function addBannerList(data) {
  var url = adminBase + "/admin/wxAccount/mallBanner/add";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //财保商城banner图修改回显

function reBannerDetail(params) {
  var url = adminBase + "/admin/wxAccount/mallBanner/detail";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //财保商城banner修改

function updateBannerList(data) {
  var url = adminBase + "/admin/wxAccount/mallBanner/update";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //banner图发布/下架

function offTheShelfConf(params) {
  var url = adminBase + "/admin/wxAccount/mallBanner/publish";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
}
/* 财保商城模块配置*/
//查询模块配置页面信息

function searchRelationList(params) {
  var url = adminBase + "/admin/wxAccount/mallModule/list";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //保存模块配置样式信息

function addRelationPro(data) {
  var url = adminBase + "/admin/wxAccount/mallModule/save";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //产品列表查询

function searchProListView(params) {
  var url = adminBase + "/admin/wxAccount/mallModule/settings/proListView";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //批量取消

function updateInsrelationpro(data) {
  var url = adminBase + "/admin/wxAccount/mallModule/settings/updateInsrelationpro";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //批量关联

function addInsrelationpro(data) {
  var url = adminBase + "/admin/wxAccount/mallModule/settings/addInsrelationpro";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //保存推荐状态

function saveRecommend(data) {
  var url = adminBase + "/admin/wxAccount/mallModule/settings/saveRecommend";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
}
/* 续期续保提醒时间段配置*/
//续期续保列表查询

function searchClock(params) {
  var url = adminBase + "/admin/wxAccount/RenewIns/list";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //修改续保提醒时间提交

function updateClock(data) {
  var url = productBase + "/admin/wxAccount/RenewIns/settings";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //获取字典列表

function getdirectorylist(params) {
  var url = productBase + "/admin/dict/fValueList";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //获取保险公司列表

function getCompanylists(params) {
  var url = productBase + "/admin/wxAccount/RenewIns/listCom";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //------------------------------------------------------------------------海报管理-----------------------------------------------------------------------

function getPosterlists(params) {
  var url = productBase + "/admin/poster/list";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
}
/*新增海报*/

function putPosteradd(data) {
  var url = productBase + "/admin/poster/add";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
}
/*删除海报*/

function putPosterremove(data) {
  var url = productBase + "/admin/poster/remove";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //海报上架/下架

function updatestatus(params) {
  var url = productBase + "/admin/poster/updatestatus";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
}
/*信息内容回显*/

function getPosterdetail(params) {
  var url = productBase + "/admin/poster/detail";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //------------------------------------------------------------------------考试管理-----------------------------------------------------------------------
// 1.题库信息提交

function addTestForm(data) {
  var url = productBase + "/admin/answer/add";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //1.

function getAnswerList(params) {
  var url = productBase + "/admin/answer/answerexam/list";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //1.获取题库信息回显

function getAnswerDetail(params) {
  var url = productBase + "/admin/answer/answerexam/detail";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //1.

function removeTestForm(params) {
  var url = productBase + "/admin/answer/answerexam/del";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //1、题库上下架状态改变

function updateStatus(params) {
  var url = productBase + "/admin/answer/editisuse";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //1、题库的数据信息

function answerNameList(params) {
  var url = productBase + "/admin/answer/answernamelist";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //2.题目类型

function getQueTypeList(params) {
  var url = productBase + "/admin/questionType/list";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
}
function removeRueTypeId(params) {
  var url = productBase + "/admin/questionType/remove";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //修改的数据回显

function getqueTypedetail(params) {
  var url = productBase + "/admin/questionType/detail";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //新增或修改

function addqueType(data) {
  var url = productBase + "/admin/questionType/add";
  var method = "post";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //选择的题目类型选择

function getqueTypeselect(params) {
  var url = productBase + "/admin/questionType/select";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //2.上下架

function updateuseType(params) {
  var url = productBase + "/admin/questionType/updateuse";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //3.题目管理

function getQuestionList(params) {
  var url = productBase + "/admin/questionManage/list";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //新增或更新

function addquestion(data) {
  var url = productBase + "/admin/questionManage/add";
  var method = "post";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //删除

function removeQuestionId(params) {
  var url = productBase + "/admin/questionManage/remove";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //修改的数据回显

function getquestiondetail(params) {
  var url = productBase + "/admin/questionManage/detail";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //2.上下架

function updateuseQuestion(params) {
  var url = productBase + "/admin/questionManage/updateuse";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //4.答案管理

function getAnswersList(params) {
  var url = productBase + "/admin/answers/list";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //新增或更新

function addAnswers(data) {
  var url = productBase + "/admin/answers/add";
  var method = "post";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //获取题目列表

function getquestionAnswers(data) {
  var url = productBase + "/admin/questionManage/select";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //修改的数据回显

function getAnswersdetail(params) {
  var url = productBase + "/admin/answers/detail";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //4.上下架

function updateuseAnswers(params) {
  var url = productBase + "/admin/answers/updateuse";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //删除答案

function removeAnswer(params) {
  var url = productBase + "/admin/answers/remove";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //5.答题记录管理

function getRecordList(params) {
  var url = productBase + "/admin/questionRecord/list";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //新增或更新

function addOrUpdateRecord(data) {
  var url = productBase + "/admin/questionRecord/add";
  var method = "post";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //修改的数据回显

function getRecorddetail(params) {
  var url = productBase + "/admin/questionRecord/detail";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
}
function removeRecordId(params) {
  var url = productBase + "/admin/questionRecord/remove";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //--------------------------------------------------------------------------直播管理---------------------------------------------------------------

/* 直播列表*/
//查询直播列表

function searchLiveList(params) {
  var url = adminBase + "/admin/live/list";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //添加直播内容

function addLiveList(data) {
  var url = adminBase + "/admin/live/add";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //直播数据回显

function returnNewsById(params) {
  var url = adminBase + "/admin/live/detail";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //直播数据修改

function updateLiveList(data) {
  var url = adminBase + "/admin/live/update";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //直播数据删除

function deleteLiveList(params) {
  var url = adminBase + "/admin/live/remove";
  var method = "delete";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //--------------------------------------------------------------------------注册用户管理---------------------------------------------------------------

/* 注册用户列表*/
//查询注册用户列表

function searchAgentList(data) {
  var url = accountBase + "/admin/zyUser/list";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //注册用户列表信息回显

function searchAgentById(params) {
  var url = accountBase + "/admin/zyUser/detail";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //注册用户禁用启用

function updateAgentStatus(params) {
  var url = accountBase + "/admin/zyUser/changeUserStatus";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //注册用户修改

function editAgentById(data) {
  var url = accountBase + "/admin/zyUser/update";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //--------------------------------------------------------------------------数据字典管理---------------------------------------------------------------

/* 数据字典管理*/
//查询字典类型下拉列表

function allType() {
  var url = adminBase + "/admin/dict/allType";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method
  });
} //查询数据字典列表

function searchDictList(params) {
  var url = adminBase + "/admin/dict/list";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //添加字典信息

function addDictList(data) {
  var url = adminBase + "/admin/dict/add";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //修改字典列表

function updatedictlist(data) {
  var url = adminBase + "/admin/dict/update";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //删除数据字典列表

function deletdictlist(params) {
  var url = adminBase + "/admin/dict/remove";
  var method = "delete";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //--------------------------------------------------------------------------产品管理---------------------------------------------------------------

/* 产品列表*/
//查询产品列表

function getProList(params) {
  var url = productBase + "/admin/product/list";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //产品列表修改保存

function updateHoldTime(data) {
  var url = productBase + "/admin/product/update";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //查询外部产品列表

function getOutProList(params) {
  var url = productBase + "/admin/outfmrisk/list";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //更新外部产品

function updateOutProduct(data) {
  var url = productBase + "/admin/outfmrisk/update";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //保存外部产品

function saveOutProduct(data) {
  var url = productBase + "/admin/outfmrisk/save";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //获取供应商

function getInsuranceCompany(params) {
  var url = productBase + "/admin/outfmrisk/selectcompany";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} // 获取第三方供应商

function getInsuranceCompanyThree(params) {
  var url = productBase + "/admin/outfmrisk/selectcompanyThree";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //获取缴费期间

function getpaymentperiod(params) {
  var url = productBase + "/admin/outfmrisk/selectpaymentperiod";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //获取保险类型

function selectrisktype(params) {
  var url = productBase + "/admin/outfmrisk/selectrisktype";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
}
function updateOutUse(params) {
  var url = productBase + "/admin/outfmrisk/updatestatus";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //获取详细信息

function getOutDetail(params) {
  var url = productBase + "/admin/outfmrisk/detail";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //保存佣金政策

function saveCommission(data) {
  var url = productBase + "/admin/commission/save";
  var method = "post";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //查询佣金信息

function getOutCompanyByCode(params) {
  var url = productBase + "/admin/commission/usebycode";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //删除产品佣金政策

function deleteCommission(params) {
  var url = productBase + "/admin/commission/delete";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //删除保障期间

function deleteEnsure(params) {
  var url = productBase + "/admin/ensure/delete";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //--------------------------------------------------------------------------官网管理---------------------------------------------------------------

/* 新闻动态文章列表及上传*/
//查询新闻列表

function bgsearchlist(params) {
  var url = adminBase + "/admin/website/news/list";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //新闻列表编辑回显

function showdetail(params) {
  var url = adminBase + "/admin/website/news/detail";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //新闻列表修改保存

function updatedetail(data) {
  var url = adminBase + "/admin/website/news/update";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //新闻列表新建保存

function uploaddata(data) {
  var url = adminBase + "/admin/website/news/add";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //新闻列表删除

function deletedetail(params) {
  var url = adminBase + "/admin/website/news/remove";
  var method = "delete";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //修改推荐状态
//--------------------------------------------------------------------------预约投保管理---------------------------------------------------------------

/* 预约投保管理列表*/
//预约投保列表查询

function searchAppointList(data) {
  var url = accountBase + "/admin/bookIns/list";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //预约投保列表信息回显   暂时不用

function reDetailAppoint(params) {
  var url = accountBase + "/account/Appoint/reDetailAppoint";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //查询反馈接口

function searchFeedList(params) {
  var url = accountBase + "/admin/bookIns/cusResult";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //指定代理人确定

function updateAppointList(data) {
  var url = accountBase + "/admin/bookIns/agent/updateAppointList";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //--------------------------------------------------------------------------订单管理---------------------------------------------------------------

/* 订单列表*/
//查询订单列表

function orderList(data) {
  var url = orderBase + "/admin/order/list";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //列表数据回显

function searchOrderDetail(params) {
  var url = orderBase + "/admin/order/detail";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} ///
//列表数据回显

function searchOrderDetailByOrder(params) {
  var url = orderBase + "/admin/order/detailByOrder";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} ///

function searchOrderApi(data) {
  var url = '/admin/order/listSenior';
  var method = "post";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} ///
//指定代理人确定

function orderBindAgent(data) {
  var url = orderBase + "/admin/order/agent/orderBindAgent";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //--------------------------------------------------------------------------代理人查询---------------------------------------------------------------

/* 代理人查询*/

function searchProxyList(params) {
  var url = adminBase + "/admin/order/agent/orderAim";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //--------------------------------------------------------------------------权限管理---------------------------------------------------------------

/* 用户管理*/
//查询用户列表

function searchUserList(params) {
  var url = adminBase + "/admin/user/list";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //添加用户

function addUserList(data) {
  var url = adminBase + "/admin/user/add";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //启用禁用用户

function updateUserStatus(params) {
  var url = adminBase + "/admin/user/enable";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //设置角色的列表所有权限

function setRole(params) {
  var url = adminBase + "/admin/user/setRole";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //角色已拥有权限列表

function userIncludeRole(params) {
  var url = adminBase + "/admin/user/role/userIncludeRole";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //保存设置权限列表

function addUserRoleList(data) {
  var url = adminBase + "/admin/user/role/addUserRoleList";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //重置密码

function refreshUserList(data) {
  var url = adminBase + "/admin/user/password/reset";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //修改用户信息

function updateUserList(data) {
  var url = adminBase + "/admin/user/update";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
}
/* 角色管理*/
//查询角色列表

function searchRoleList(params) {
  var url = adminBase + "/admin/role/list";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //新增角色

function addRoleList(data) {
  var url = adminBase + "/admin/role/add";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //修改角色

function upRoleList(data) {
  var url = adminBase + "/admin/role/update";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //启用、禁用角色

function exRoleStatus(params) {
  var url = adminBase + "/admin/role/enable";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //获取角色权限树

function getUserTree(params) {
  var url = "".concat(loginBase, "/admin/role/permission/list");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //修改角色权限

function permissionUp(data) {
  var url = "".concat(loginBase, "/admin/role/permission/update");
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
}
/*资源管理*/
//请求权限列表

function tree(params) {
  var url = "".concat(loginBase, "/admin/permission/tree");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //修改权限列表

function update(data) {
  var url = "".concat(loginBase, "/admin/permission/update");
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //新增权限

function add(data) {
  var url = "".concat(loginBase, "/admin/permission/add");
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //删除权限

function remove(params) {
  var url = "".concat(loginBase, "/admin/permission/remove");
  var method = "delete";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //代理人列表

function agentListApi(params) {
  var url = "".concat(loginBase, "/admin/agent/list");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
}
function goldenAgentApi(params) {
  var url = "".concat(loginBase, "/admin/zyUser/goldenAgent");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //------------------------------------------------------------------------团队业绩排行方式设置-----------------------------------------------------------------------
//团队业绩排行列表

function appTeamListApi(params) {
  var url = "".concat(loginBase, "/admin/appTeam/list");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //团队业绩排行设置

function appTeamOrderApi(params) {
  var url = "".concat(loginBase, "/admin/appTeam/order");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //------------------------------------------------------------------------知识库管理-----------------------------------------------------------------------
// 知识库列表查询

function knowledgeListApi(params) {
  var url = "".concat(loginBase, "/admin/knowledge/list");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} // 知识库 -- 新增

function knowledgeSettingApi(data) {
  var url = "".concat(loginBase, "/admin/knowledge/add");
  var method = "post";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} // 知识库 -- 修改

function konwledgeUpdateApi(data) {
  var url = "".concat(loginBase, "/admin/knowledge/update");
  var method = "post";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} // 知识库 -- 删除

function knowledgeRemoveApi(params) {
  var url = "".concat(loginBase, "/admin/knowledge/remove");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} // 知识库 -- 上架/下架

function knowledgePublishApi(params) {
  var url = "".concat(loginBase, "/admin/knowledge/publish");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} // 知识库 -- 详情

function knowledgeDetailApi(params) {
  var url = "".concat(loginBase, "/admin/knowledge/detail");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //------------------------------------------------------------------------贺卡管理-----------------------------------------------------------------------
// 贺卡 -- 列表

function signCardListApi(params) {
  var url = "".concat(loginBase, "/admin/signCard/list");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} // 贺卡 --修改

function signCardSettingApi(data) {
  var url = "".concat(loginBase, "/admin/signCard/add");
  var method = "post";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //贺卡 -- 贺卡详情

function signCardDetailApi(data) {
  var url = "".concat(loginBase, "/admin/signCard/detail");
  var method = "post";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //-------------------------微店信息审核-----------------------
//微店列表

function microShopListApi(params) {
  var url = "".concat(loginBase, "/admin/shop/list");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //微店信息审核

function microShopExamineApi(params) {
  var url = "".concat(loginBase, "/admin/shop/audit");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //微店信息详情

function microShopDetailApi(params) {
  var url = "".concat(loginBase, "/admin/shop/detail");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //-------------------------个人名片审核-----------------------
//个人名片列表

function agentCardListApi(params) {
  var url = "".concat(loginBase, "/admin/agentCard/list");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //名片审核

function agentCardAuditApi(params) {
  var url = "".concat(loginBase, "/admin/agentCard/audit");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //名片详情

function agentCardDetailApi(params) {
  var url = "".concat(loginBase, "/admin/agentCard/detail");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //-------------------------APP 自定义模块配置-----------------------
//列表

function searchRelationListApp(params) {
  var url = adminBase + "/admin/app/moduleConf/list";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //保存模块配置样式信息

function addRelationProApp(data) {
  var url = adminBase + "/admin/app/moduleConf/save";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //产品列表查询

function searchProListViewApp(params) {
  var url = adminBase + "/admin/app/moduleConf/settings/proListView";
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //批量取消

function updateInsrelationproApp(data) {
  var url = adminBase + "/admin/app/moduleConf/settings/addInsrelationpro";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //批量关联

function addInsrelationproApp(data) {
  var url = adminBase + "/admin/app/moduleConf/settings/addInsrelationpro";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //保存推荐状态

function saveRecommendApp(data) {
  var url = adminBase + "/admin/app/moduleConf/settings/saveRecommend";
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //MGA管理
//回执管理

var loginURL = " http://10.20.150.87:8089";
function receiptListApi(data) {
  var url = "".concat(loginBase, "/admin/receipt/list");
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //回执日期填写

function signedReceiptDateApi(data) {
  var url = "".concat(loginBase, "/admin/receipt/signedReceiptDate");
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //保单回访列表

function revisitListApi(data) {
  var url = "".concat(loginBase, "/admin/revisit/list");
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //保单回访日期维护

function signedRevisitDateApi(data) {
  var url = "".concat(loginBase, "/admin/revisit/signedRevisitDate");
  var method = "POST";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //回访模版下载

function revisitDownload(params) {
  function jsontoQuery(params) {
    //定义一个空数组
    var ary = [];
    var str; //对象的遍历操作

    for (var i in params) {
      //将对象名push到数组里
      ary.push(i); //对象的值

      ary.push("=".concat(params[i], "& "));
    } //将数组转变成字符串


    str = ary.join(""); //将字符串最后一个&符剪切走

    str = str.slice(0, str.length - 1);
    return str;
  }

  var queryString = jsontoQuery(params);
  var url = "".concat(loginBase, "/admin/revisit/download");
  window.location.href = url;
} //回执导出数据

function receiptDownload(params) {
  function jsontoQuery(params) {
    //定义一个空数组
    var ary = [];
    var str; //对象的遍历操作

    for (var i in params) {
      //将对象名push到数组里
      ary.push(i); //对象的值

      ary.push("=".concat(params[i], "& "));
    } //将数组转变成字符串


    str = ary.join(""); //将字符串最后一个&符剪切走

    str = str.slice(0, str.length - 1);
    return str;
  }

  var queryString = jsontoQuery(params);
  var url = "".concat(loginBase, "/admin/receipt/download");
  window.location.href = url;
} //犹豫期导出数据

function freelookDownload(params) {
  function jsontoQuery(params) {
    //定义一个空数组
    var ary = [];
    var str; //对象的遍历操作

    for (var i in params) {
      //将对象名push到数组里
      ary.push(i); //对象的值

      ary.push("=".concat(params[i], "& "));
    } //将数组转变成字符串


    str = ary.join(""); //将字符串最后一个&符剪切走

    str = str.slice(0, str.length - 1);
    return str;
  }

  var queryString = jsontoQuery(params);
  var url = "".concat(loginBase, "/admin/freelook/download");
  window.location.href = url;
}
function supplierInfo(params) {
  var url = "".concat(loginBase, "/admin/outfmrisk/selectSupplier");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //----------------------------------------------------------------------- 渠道考核 -----------------------------------------------------------------------
//正式考核

function formalAssessApi() {
  var url = "".concat(loginBase, "/admin/channel/channelAssessment/formalAssessment");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method
  });
} //重新提数

function reWithdrawalCalculation(params) {
  var url = "".concat(loginBase, "/admin/channel/channelAssessment/againCalculation");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_3__["Service"])({
    url: url,
    method: method,
    params: params
  });
}

/***/ })

}]);
//# sourceMappingURL=2.js.map