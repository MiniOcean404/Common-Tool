(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[12],{

/***/ "./node_modules/core-js/internals/is-regexp.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/internals/is-regexp.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");
var classof = __webpack_require__(/*! ../internals/classof-raw */ "./node_modules/core-js/internals/classof-raw.js");
var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");

var MATCH = wellKnownSymbol('match');

// `IsRegExp` abstract operation
// https://tc39.es/ecma262/#sec-isregexp
module.exports = function (it) {
  var isRegExp;
  return isObject(it) && ((isRegExp = it[MATCH]) !== undefined ? !!isRegExp : classof(it) == 'RegExp');
};


/***/ }),

/***/ "./node_modules/core-js/modules/es.array.map.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/es.array.map.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var $map = __webpack_require__(/*! ../internals/array-iteration */ "./node_modules/core-js/internals/array-iteration.js").map;
var arrayMethodHasSpeciesSupport = __webpack_require__(/*! ../internals/array-method-has-species-support */ "./node_modules/core-js/internals/array-method-has-species-support.js");

var HAS_SPECIES_SUPPORT = arrayMethodHasSpeciesSupport('map');

// `Array.prototype.map` method
// https://tc39.es/ecma262/#sec-array.prototype.map
// with adding support of @@species
$({ target: 'Array', proto: true, forced: !HAS_SPECIES_SUPPORT }, {
  map: function map(callbackfn /* , thisArg */) {
    return $map(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es.string.split.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es.string.split.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var fixRegExpWellKnownSymbolLogic = __webpack_require__(/*! ../internals/fix-regexp-well-known-symbol-logic */ "./node_modules/core-js/internals/fix-regexp-well-known-symbol-logic.js");
var isRegExp = __webpack_require__(/*! ../internals/is-regexp */ "./node_modules/core-js/internals/is-regexp.js");
var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/core-js/internals/an-object.js");
var requireObjectCoercible = __webpack_require__(/*! ../internals/require-object-coercible */ "./node_modules/core-js/internals/require-object-coercible.js");
var speciesConstructor = __webpack_require__(/*! ../internals/species-constructor */ "./node_modules/core-js/internals/species-constructor.js");
var advanceStringIndex = __webpack_require__(/*! ../internals/advance-string-index */ "./node_modules/core-js/internals/advance-string-index.js");
var toLength = __webpack_require__(/*! ../internals/to-length */ "./node_modules/core-js/internals/to-length.js");
var callRegExpExec = __webpack_require__(/*! ../internals/regexp-exec-abstract */ "./node_modules/core-js/internals/regexp-exec-abstract.js");
var regexpExec = __webpack_require__(/*! ../internals/regexp-exec */ "./node_modules/core-js/internals/regexp-exec.js");
var stickyHelpers = __webpack_require__(/*! ../internals/regexp-sticky-helpers */ "./node_modules/core-js/internals/regexp-sticky-helpers.js");

var UNSUPPORTED_Y = stickyHelpers.UNSUPPORTED_Y;
var arrayPush = [].push;
var min = Math.min;
var MAX_UINT32 = 0xFFFFFFFF;

// @@split logic
fixRegExpWellKnownSymbolLogic('split', 2, function (SPLIT, nativeSplit, maybeCallNative) {
  var internalSplit;
  if (
    'abbc'.split(/(b)*/)[1] == 'c' ||
    // eslint-disable-next-line regexp/no-empty-group -- required for testing
    'test'.split(/(?:)/, -1).length != 4 ||
    'ab'.split(/(?:ab)*/).length != 2 ||
    '.'.split(/(.?)(.?)/).length != 4 ||
    // eslint-disable-next-line regexp/no-assertion-capturing-group, regexp/no-empty-group -- required for testing
    '.'.split(/()()/).length > 1 ||
    ''.split(/.?/).length
  ) {
    // based on es5-shim implementation, need to rework it
    internalSplit = function (separator, limit) {
      var string = String(requireObjectCoercible(this));
      var lim = limit === undefined ? MAX_UINT32 : limit >>> 0;
      if (lim === 0) return [];
      if (separator === undefined) return [string];
      // If `separator` is not a regex, use native split
      if (!isRegExp(separator)) {
        return nativeSplit.call(string, separator, lim);
      }
      var output = [];
      var flags = (separator.ignoreCase ? 'i' : '') +
                  (separator.multiline ? 'm' : '') +
                  (separator.unicode ? 'u' : '') +
                  (separator.sticky ? 'y' : '');
      var lastLastIndex = 0;
      // Make `global` and avoid `lastIndex` issues by working with a copy
      var separatorCopy = new RegExp(separator.source, flags + 'g');
      var match, lastIndex, lastLength;
      while (match = regexpExec.call(separatorCopy, string)) {
        lastIndex = separatorCopy.lastIndex;
        if (lastIndex > lastLastIndex) {
          output.push(string.slice(lastLastIndex, match.index));
          if (match.length > 1 && match.index < string.length) arrayPush.apply(output, match.slice(1));
          lastLength = match[0].length;
          lastLastIndex = lastIndex;
          if (output.length >= lim) break;
        }
        if (separatorCopy.lastIndex === match.index) separatorCopy.lastIndex++; // Avoid an infinite loop
      }
      if (lastLastIndex === string.length) {
        if (lastLength || !separatorCopy.test('')) output.push('');
      } else output.push(string.slice(lastLastIndex));
      return output.length > lim ? output.slice(0, lim) : output;
    };
  // Chakra, V8
  } else if ('0'.split(undefined, 0).length) {
    internalSplit = function (separator, limit) {
      return separator === undefined && limit === 0 ? [] : nativeSplit.call(this, separator, limit);
    };
  } else internalSplit = nativeSplit;

  return [
    // `String.prototype.split` method
    // https://tc39.es/ecma262/#sec-string.prototype.split
    function split(separator, limit) {
      var O = requireObjectCoercible(this);
      var splitter = separator == undefined ? undefined : separator[SPLIT];
      return splitter !== undefined
        ? splitter.call(separator, O, limit)
        : internalSplit.call(String(O), separator, limit);
    },
    // `RegExp.prototype[@@split]` method
    // https://tc39.es/ecma262/#sec-regexp.prototype-@@split
    //
    // NOTE: This cannot be properly polyfilled in engines that don't support
    // the 'y' flag.
    function (regexp, limit) {
      var res = maybeCallNative(internalSplit, regexp, this, limit, internalSplit !== nativeSplit);
      if (res.done) return res.value;

      var rx = anObject(regexp);
      var S = String(this);
      var C = speciesConstructor(rx, RegExp);

      var unicodeMatching = rx.unicode;
      var flags = (rx.ignoreCase ? 'i' : '') +
                  (rx.multiline ? 'm' : '') +
                  (rx.unicode ? 'u' : '') +
                  (UNSUPPORTED_Y ? 'g' : 'y');

      // ^(? + rx + ) is needed, in combination with some S slicing, to
      // simulate the 'y' flag.
      var splitter = new C(UNSUPPORTED_Y ? '^(?:' + rx.source + ')' : rx, flags);
      var lim = limit === undefined ? MAX_UINT32 : limit >>> 0;
      if (lim === 0) return [];
      if (S.length === 0) return callRegExpExec(splitter, S) === null ? [S] : [];
      var p = 0;
      var q = 0;
      var A = [];
      while (q < S.length) {
        splitter.lastIndex = UNSUPPORTED_Y ? 0 : q;
        var z = callRegExpExec(splitter, UNSUPPORTED_Y ? S.slice(q) : S);
        var e;
        if (
          z === null ||
          (e = min(toLength(splitter.lastIndex + (UNSUPPORTED_Y ? q : 0)), S.length)) === p
        ) {
          q = advanceStringIndex(S, q, unicodeMatching);
        } else {
          A.push(S.slice(p, q));
          if (A.length === lim) return A;
          for (var i = 1; i <= z.length - 1; i++) {
            A.push(z[i]);
            if (A.length === lim) return A;
          }
          q = p = e;
        }
      }
      A.push(S.slice(p));
      return A;
    }
  ];
}, UNSUPPORTED_Y);


/***/ }),

/***/ "./src/api/JoinApply.js":
/*!******************************!*\
  !*** ./src/api/JoinApply.js ***!
  \******************************/
/*! exports provided: baseUrl, getEldListList, getAgentDetail, getModifyResult, initialReviewOfResignation, exportResignApplicationForm, resignAuditResultApi, leaveFirstPassApi, leaveTerminateTheContractApi, getInitiativeFtpBase64Address, getOnlineLeaveFtpBase64Address */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getEldListList", function() { return getEldListList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getAgentDetail", function() { return getAgentDetail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getModifyResult", function() { return getModifyResult; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initialReviewOfResignation", function() { return initialReviewOfResignation; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "exportResignApplicationForm", function() { return exportResignApplicationForm; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resignAuditResultApi", function() { return resignAuditResultApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "leaveFirstPassApi", function() { return leaveFirstPassApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "leaveTerminateTheContractApi", function() { return leaveTerminateTheContractApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getInitiativeFtpBase64Address", function() { return getInitiativeFtpBase64Address; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getOnlineLeaveFtpBase64Address", function() { return getOnlineLeaveFtpBase64Address; });
/* harmony import */ var _config_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/config/service */ "./src/config/service.js");
/* harmony import */ var _config_env__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/config/env */ "./src/config/env.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "baseUrl", function() { return _config_env__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]; });

 //axios



function getEldListList(params) {
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_0__["Service"])({
    url: _config_env__WEBPACK_IMPORTED_MODULE_1__["baseUrl"] + '/admin/agent/eldList',
    method: 'GET',
    params: params
  });
}
function getAgentDetail(params) {
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_0__["Service"])({
    url: _config_env__WEBPACK_IMPORTED_MODULE_1__["baseUrl"] + '/admin/agent/detail',
    method: 'get',
    params: params
  });
}
function getModifyResult(data) {
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_0__["Service"])({
    url: _config_env__WEBPACK_IMPORTED_MODULE_1__["baseUrl"] + '/admin/agent/modifyResult',
    method: 'post',
    data: data
  });
} //开启代理人离职接口

function initialReviewOfResignation(params) {
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_0__["Service"])({
    url: '/admin/agent/initialReviewOfResignation',
    method: 'post',
    params: params
  });
} //导出离职申请表

function exportResignApplicationForm(params) {
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_0__["Service"])({
    url: '/admin/agent/exportResignApplicationForm',
    method: 'get',
    params: params
  });
} // * 离职终审核

function resignAuditResultApi(agentCode, auditResult, auditReason) {
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_0__["Service"])({
    url: '/admin/agent/resignFinal',
    method: 'get',
    params: {
      agentCode: agentCode,
      auditResult: auditResult,
      auditReason: auditReason
    }
  });
} // * 离职初审审核

function leaveFirstPassApi(agentCode) {
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_0__["Service"])({
    url: '/admin/agent/resignFirst',
    method: 'get',
    params: {
      agentCode: agentCode
    }
  });
} // * 主动解约

function leaveTerminateTheContractApi(agentCode, reason, resignNotice) {
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_0__["Service"])({
    url: '/admin/agent/cancel',
    method: 'get',
    params: {
      agentCode: agentCode,
      reason: reason,
      resignNotice: resignNotice
    }
  });
} // * 获取fpt主动解约的base64地址

function getInitiativeFtpBase64Address(url) {
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_0__["Service"])({
    url: '/admin/go/ftpDownload',
    method: 'get',
    responseType: 'blob',
    params: {
      url: url
    }
  });
} // * 获取fpt线上离职申请表的base64地址

function getOnlineLeaveFtpBase64Address(agentCode) {
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_0__["Service"])({
    url: '/admin/agent/export',
    method: 'get',
    responseType: 'arraybuffer',
    params: {
      agentCode: agentCode
    }
  });
}

/***/ }),

/***/ "./src/common/MixinUtils.js":
/*!**********************************!*\
  !*** ./src/common/MixinUtils.js ***!
  \**********************************/
/*! exports provided: tableMixin */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tableMixin", function() { return tableMixin; });
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! regenerator-runtime/runtime.js */ "./node_modules/regenerator-runtime/runtime.js");
/* harmony import */ var regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.entries.js */ "./node_modules/core-js/modules/es.object.entries.js");
/* harmony import */ var core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var components_common_Table__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/common/Table */ "./src/components/common/Table.vue");
/* harmony import */ var components_common_Pagination__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/common/Pagination */ "./src/components/common/Pagination.vue");
/* harmony import */ var components_common_Input__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/common/Input */ "./src/components/common/Input.vue");









var defaultDate = [{
  data: ['createDateBegin', 'createDateEnd']
}];
var tableMixin = {
  components: {
    Table: components_common_Table__WEBPACK_IMPORTED_MODULE_6__["default"],
    Pagination: components_common_Pagination__WEBPACK_IMPORTED_MODULE_7__["default"],
    Input: components_common_Input__WEBPACK_IMPORTED_MODULE_8__["default"]
  },
  data: function data() {
    return {
      // todo 查询的所有数据
      queryAllData: {},
      // todo 表格搜索数据
      queryData: {},
      cloneData: {},
      // todo 页码改变
      pageOption: {
        currentPage: 1,
        total: 0,
        pageSize: 10
      },
      // todo 时间选择
      pickerOptions: {
        shortcuts: [{
          text: '昨天',
          onClick: function onClick(picker) {
            var end = new Date();
            var start = new Date();
            start.setDate(start.getDate() - 1);
            end.setDate(end.getDate() - 1);
            picker.$emit('pick', [start, end]);
          }
        }, {
          text: '本周',
          onClick: function onClick(picker) {
            var end = new Date();
            var start = new Date();
            var currentDay = new Date().getDay() === 0 ? 7 : new Date().getDay();
            start.setDate(start.getDate() - currentDay + 1);
            end.setDate(end.getDate());
            picker.$emit('pick', [start, end]);
          }
        }, {
          text: '本月',
          onClick: function onClick(picker) {
            var end = new Date();
            var start = new Date();
            start.setDate(1);
            end.setMonth(end.getMonth() + 1);
            end.setDate(0);
            picker.$emit('pick', [start, end]);
          }
        }, {
          text: '上个月',
          onClick: function onClick(picker) {
            var end = new Date();
            var start = new Date();
            start.setMonth(start.getMonth() - 1);
            start.setDate(1);
            end.setDate(0);
            picker.$emit('pick', [start, end]);
          }
        }, {
          text: '最近三个月',
          onClick: function onClick(picker) {
            var end = new Date();
            var start = new Date();
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
            picker.$emit('pick', [start, end]);
          }
        }, {
          text: '本年',
          onClick: function onClick(picker) {
            var end = new Date();
            var start = new Date();
            start.setDate(1);
            start.setMonth(0);
            picker.$emit('pick', [start, end]);
          }
        }]
      }
    };
  },
  methods: {
    //todo 通用列表数据初始化
    getSelectList: function getSelectList(api, list, value, label, params) {
      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
        var _yield$api, data;

        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return api(params);

              case 2:
                _yield$api = _context.sent;
                data = _yield$api.data;

                if (list.length === 0) {
                  data.forEach(function (i) {
                    var obj = {};
                    obj.value = i[value];
                    obj.label = i[label];
                    list.push(obj);
                  });
                }

              case 5:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    // todo 通用查询
    getList: function getList(api, query, page, tableData, currentPage) {
      var _arguments = arguments,
          _this = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
        var dateArr, cb, data, result;
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                dateArr = _arguments.length > 5 && _arguments[5] !== undefined ? _arguments[5] : defaultDate;
                cb = _arguments.length > 6 ? _arguments[6] : undefined;
                data = JSON.parse(JSON.stringify(query)); // 处理页数

                data.pageNum = currentPage !== undefined ? page.currentPage = currentPage : page.currentPage = 1;
                data.pageSize = page.pageSize; // 处理时间

                dateArr.forEach(function (date) {
                  for (var _i = 0, _Object$entries = Object.entries(date); _i < _Object$entries.length; _i++) {
                    var _Object$entries$_i = Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__["default"])(_Object$entries[_i], 2),
                        key = _Object$entries$_i[0],
                        value = _Object$entries$_i[1];

                    if (data[key] !== null && data[key] !== undefined) {
                      data[value[0]] = data[key][0];
                      data[value[1]] = data[key][1];
                      delete data[key];
                    }
                  }
                }); // 请求结果

                _context2.next = 8;
                return api(data);

              case 8:
                result = _context2.sent;

                if (result !== null && result.code === 200 && result.data !== '') {
                  tableData.resultData = cb ? everyData(result.data.records, cb) : result.data.records;
                  page.total = result.data.total;
                  _this.queryAllData = result;
                } else if (result.data === '') {
                  tableData.resultData = [];
                  page.total = 0;
                }

                _this.cloneData = data;

              case 11:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    // todo 通用校验
    check: function check(message, key, value) {
      if (value === undefined && (key === '' || key === null || key === undefined)) {
        this.$message({
          type: 'error',
          message: message
        });
        throw new TypeError('填写的内容为空');
      } else if (value && key === value) {
        this.$message({
          type: 'error',
          message: message
        });
        throw new TypeError('填写的内容错误');
      }
    },
    // todo 点击查询按钮
    queryButton: function queryButton(e, apiNum) {
      this.requestDeploy();
    },
    // todo 页码改变
    currentPageChange: function currentPageChange(current) {
      this.requestDeploy(current);
    }
  }
}; // todo 过滤函数

function everyData(data, cb) {
  return data.map(function (item) {
    var arr = Object.entries(item);

    for (var _i2 = 0, _arr = arr; _i2 < _arr.length; _i2++) {
      var i = _arr[_i2];

      if (cb(i)) {
        item[cb(i)[0]] = cb(i)[1];
      }
    }

    return item;
  });
}

/***/ }),

/***/ "./src/common/dictionarieList/JoinApply.js":
/*!*************************************************!*\
  !*** ./src/common/dictionarieList/JoinApply.js ***!
  \*************************************************/
/*! exports provided: Model, joinCheck, ProfessionStatus, auditType, agentType, education, leaveOptions */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Model", function() { return Model; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "joinCheck", function() { return joinCheck; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfessionStatus", function() { return ProfessionStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "auditType", function() { return auditType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "agentType", function() { return agentType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "education", function() { return education; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "leaveOptions", function() { return leaveOptions; });
var Model = [{
  value: '0',
  label: '大B模式'
}, {
  value: '1',
  label: '小B模式'
}, {
  value: '2',
  label: '普通小A代理人'
}];
var joinCheck = [{
  value: '0',
  label: '待审核'
}, {
  value: '1',
  label: '审核通过'
}, {
  value: '2',
  label: '审核拒绝'
}];
var ProfessionStatus = [{
  value: '',
  label: '全部'
}, {
  value: '1',
  label: '在职'
}, {
  value: '0',
  label: '离职'
}, {
  value: '2',
  label: '未入驻'
}];
var auditType = [{
  value: '1',
  label: '审核通过'
}, {
  value: '2',
  label: '审核拒绝'
}];
var agentType = [{
  value: 'AGE',
  label: '普通小A代理人'
}, {
  value: 'DLA',
  label: '独代'
}, {
  value: 'CME',
  label: '小B渠道成员',
  disabled: true
}, {
  value: '',
  label: ''
}];
var education = [{
  value: '11',
  label: '博士'
}, {
  value: '17',
  label: '研究生'
}, {
  value: '21',
  label: '本科'
}, {
  value: '31',
  label: '大专'
}];
var leaveOptions = [{
  value: '1',
  label: '审核通过'
}];

/***/ })

}]);
//# sourceMappingURL=12.js.map