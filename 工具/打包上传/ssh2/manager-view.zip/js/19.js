(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[19],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/settleAccount/settleManger.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--12-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/mga-manage/settleAccount/settleManger.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! regenerator-runtime/runtime.js */ "./node_modules/regenerator-runtime/runtime.js");
/* harmony import */ var regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _api_mgaApi__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/api/mgaApi */ "./src/api/mgaApi.js");
/* harmony import */ var _api_api__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/api/api */ "./src/api/api.js");
/* harmony import */ var _api_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/api/common */ "./src/api/common.js");
/* harmony import */ var _common_utils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @/common/utils */ "./src/common/utils.js");
/* harmony import */ var _common_dictionary__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @/common/dictionary */ "./src/common/dictionary.js");
/* harmony import */ var common_dictionarieList_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! common/dictionarieList/common */ "./src/common/dictionarieList/common.js");
/* harmony import */ var common_tableDate_settleManger_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! common/tableDate/settleManger.js */ "./src/common/tableDate/settleManger.js");





//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//导入请求



 // 导入字典




/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'settleManger',
  data: function data() {
    return {
      fromState: common_dictionarieList_common__WEBPACK_IMPORTED_MODULE_10__["fromState"],
      inputName: '',
      // todo 表格内容
      tbConfig: {
        //表格组件配置项
        height: '530px',
        // table高度
        select: true,
        // 是否可以多选择
        isSingleSelect: false,
        //是否可以单选
        isCommands: false,
        //是否需要操作列
        commandsWidth: '200',
        //操作列宽度
        isOrder: true,
        showPagenation: true,
        //是否需要显示分页器
        layout: 'total, prev, pager, next, jumper',
        //分页器控件
        requestCurData: true,
        // 每次分页数据是否请求后台 true:每次都请求后台
        columns: [// 后台字段属性、表头名、长度、颜色、是否过长隐藏、是否需要字典转换、点击事件的处理函数
        ['orderId', '订单编号', '270px', '', true, false], ['wageBatch', '批次号', '230px', '', true, false], ['productName', '产品名称', '300px', '', true, false], ['esourceName', '产品类型', '100px', '', true, false], ['insCompanyName', '供应商', '180', '', true, true], ['policyNo', '保单号', '300px', '', true, true], ['holderName', '投保人', '100px', '', true, false], ['agentName', '代理人', '100px', false, false], ['wageAgentName', '收款人', '', '', true, false], ['phone', '手机号', '', '100px', true, false], ['isSplitName', '拆单状态', '', '', true, false], ['orderPayment', '保费（元）', '100px', '', true, false], ['wageAmount', '收入（元）', '100px', '', true, true], ['appStatusName', '保单状态', '100px', '', true, false], ['revisitStatus', '回访状态', '', '', true, false], ['modeName', '合作模式', '', '', true, false], ['agentType', '人员类型', '', '', true, true], ['wageSettleStatusName', '结算状态', '100px', '', true, false], ['insCompanySettleStatus', '收款状态', '100px', '', true, true], ['makeDate', '出单日期', '', '', true, false], ['channelGroupName', '团队名称', '100px', '', true, false], ['channelGroupCode', '团队编码', '100px', '', true, false], ['channelCompanyCode', '渠道编码', '100px', '', true, false], ['channelCompanyName', '渠道名称', '100px', '', true, false]] // table行按钮：color 文字 处理点击的事件函数名  elementUicon

      },
      tbOptionData: {
        selectDatas: '',
        //页面单选函数
        currentTableData: [],
        //当前表格数据
        TransValtoDesc: 'dataFilter',
        //数据字典过滤函数
        pageSize: 10,
        // 每页行数
        currentPage: 1,
        // 当前页
        total: 0,
        //总数据量
        pagenationChange: 'handlPageChange' //处理分页器长度改变或页码改变的函数

      },
      // todo: 字典数据
      peopleTypeList: _common_dictionary__WEBPACK_IMPORTED_MODULE_9__["default"].peopleType,
      channelCompanyNameList: [],
      teamNameList: [],
      appStatusNameList: _common_dictionary__WEBPACK_IMPORTED_MODULE_9__["default"].appStatusName,
      wageSettleStatusList: _common_dictionary__WEBPACK_IMPORTED_MODULE_9__["default"].wageSettleStatusList,
      //结算状态
      insCompanySettleStatusList: _common_dictionary__WEBPACK_IMPORTED_MODULE_9__["default"].insCompanySettleStatusList,
      esourceList: _common_dictionary__WEBPACK_IMPORTED_MODULE_9__["default"].eSourceList,
      isSplitList: _common_dictionary__WEBPACK_IMPORTED_MODULE_9__["default"].isSplitList,
      //拆单状态
      modeNameList: _common_dictionary__WEBPACK_IMPORTED_MODULE_9__["default"].modeNameList,
      visitStatus: _common_dictionary__WEBPACK_IMPORTED_MODULE_9__["default"].visitStatus,
      //todo 中间标题栏选择tab 被选择第几项 默认选择第一个
      selIndex: 'first',
      //todo 文件上传
      headers: {
        mimeType: 'multipart/form-data'
      },
      uploadSettleUrl: _api_api__WEBPACK_IMPORTED_MODULE_6__["uploadSettleUrl"],
      //文件上传路径
      fileList: [],
      allSelectId: [],
      dialogVisible: false,
      searchForm: {
        channelGroupCode: ''
      },
      //搜索表单
      tableData: [],
      form: {},
      //新增存储数据
      backupsData: [],
      csvS: [],
      state: ''
    };
  },
  mounted: function mounted() {
    this.tabInit();
    this.dataInit();
    this.queryChannelCompanyApi();
    this.queryTeamApi();
  },
  methods: {
    // todo 导出excel文件
    downLoad: function downLoad() {
      if (this.searchForm.wageSettleType === 1 || this.searchForm.wageSettleType === 2) {
        // let params = JSON.parse(JSON.stringify(this.searchForm));
        // wageSettleExportApi(params)
        Object(_api_common__WEBPACK_IMPORTED_MODULE_7__["download"])('/admin/wageSettle/wageSettleExport', this.searchForm, 'get');
      }

      if (this.searchForm.wageSettleType === 3) {
        var date = Object(_common_utils__WEBPACK_IMPORTED_MODULE_8__["formatDate"])(new Date(), 'yyyyMMdd');
        var name = '保单信息导出表单' + date;
        this.searchForm.pageSize = 100;
        this.searchForm.pageNo = 1;
        Object(_api_common__WEBPACK_IMPORTED_MODULE_7__["download"])('/admin/wageBatch/wageSettleExport', this.searchForm, 'post', name);
      }
    },
    //渠道模糊查询
    querySearchAsyncCompany: function querySearchAsyncCompany(queryString, cb) {
      var restaurants = this.channelCompanyNameList;
      var results = queryString ? restaurants.filter(this.createStateFilter(queryString)) : restaurants;
      clearTimeout(this.timeout);
      this.timeout = setTimeout(function () {
        cb(results);
      }, 200 * Math.random());
    },
    //团队模糊查询
    querySearchAsync: function querySearchAsync(queryString, cb) {
      var restaurants = this.teamNameList;
      var results = queryString ? restaurants.filter(this.createStateFilter(queryString)) : restaurants;
      clearTimeout(this.timeout);
      this.timeout = setTimeout(function () {
        cb(results);
      }, 200 * Math.random());
    },
    createStateFilter: function createStateFilter(queryString) {
      return function (state) {
        return state.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0;
      };
    },

    /**
     * @请求
     */
    // todo 初始化时候默认设置第一个tab为默认
    tabInit: function tabInit() {
      this.modeNameList = _common_dictionary__WEBPACK_IMPORTED_MODULE_9__["default"].modeNameList;
      this.$set(this.searchForm, 'wageSettleType', 1);
    },
    //todo 列表数据更新
    dataInit: function dataInit() {
      var params = JSON.parse(JSON.stringify(this.searchForm));
      params.pageNo = this.tbOptionData.currentPage;
      params.pageSize = this.tbOptionData.pageSize;

      if (this.searchForm.wageSettleType === 3) {
        this.getConstructionLis(params);
      } else {
        this.getList(params);
      }
    },
    //todo 页码改变
    handlPageChange: function handlPageChange(cur, size) {
      var params = JSON.parse(JSON.stringify(this.searchForm)); // 控制当前页是多少

      this.tbOptionData.currentPage = cur; // 控制特码转换

      params.pageNo = cur;
      params.pageSize = this.tbOptionData.pageSize;

      if (this.searchForm.wageSettleType === 3) {
        this.getConstructionLis(params);
      } else {
        this.getList(params);
      }
    },
    //todo 查询列表 代理人收入大B基础收入
    getList: function getList(params) {
      var _this = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
        var result, data;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return Object(_api_mgaApi__WEBPACK_IMPORTED_MODULE_5__["wageSettleApi"])(params);

              case 2:
                result = _context.sent;

                if (result.code === 200) {
                  data = JSON.parse(JSON.stringify(result.data.records));
                  _this.tbOptionData.currentTableData = data;
                  _this.tbOptionData.total = result.data.total;
                }

              case 4:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    // todo 查询列表 2 机构活动收入
    getConstructionLis: function getConstructionLis(params) {
      var _this2 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
        var result, data;
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return Object(_api_mgaApi__WEBPACK_IMPORTED_MODULE_5__["queryConstructionListApi"])(params);

              case 2:
                result = _context2.sent;

                if (result.code === 200) {
                  data = JSON.parse(JSON.stringify(result.data.records));
                  _this2.tbOptionData.currentTableData = data;
                  _this2.tbOptionData.total = result.data.total;
                }

              case 4:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    //todo 查询
    onSubmit: function onSubmit() {
      this.tbOptionData.currentTableData = this.tableData;
      this.tbOptionData.currentPage = 1;
      this.dataInit();
    },
    //todo tab 切换
    selTab: function selTab(tab, event) {
      this.searchForm = {
        channelGroupCode: ''
      };

      switch (this.selIndex) {
        case 'first':
          this.$set(this.searchForm, 'wageSettleType', 1);
          this.modeNameList = _common_dictionary__WEBPACK_IMPORTED_MODULE_9__["default"].modeNameList; // //todo 添加

          this.$set(this.tbConfig, 'columns', common_tableDate_settleManger_js__WEBPACK_IMPORTED_MODULE_11__["OneTab"]); // this.addArray('wageAgentName', 8, ['wageAgentName', '收款人', '', '', true, false])
          // this.addArray('isSplitName', 10, ['isSplitName', '拆单状态', '', '', true, false])
          // this.addArray('wageSettleStatusName', 12, ['wageSettleStatusName', '结算状态', '', '', true, false])
          // this.addArray('agentType', 14, ['agentType', '人员类型', '', '', true, false])
          // this.addArray('modeName', 14, ['modeName', '合作模式', '', '', true, false])
          //
          // const orderPaymentIndex = this.tbConfig.columns.findIndex(item => {
          // 	return item[0] === 'orderPayment'
          // })
          //
          // this.addArray('wageAmount', orderPaymentIndex, ['wageAmount', '收入（元）', '', '', true, true])
          //
          // this.addArray('wageBatch', 1, ['wageBatch', '批次号', '', '', true, false])
          //
          // this.deleteArray('premium')
          // this.addArray('orderPayment', 9, ['orderPayment', '保费（元）', '', '', true, false])

          break;

        case 'second':
          this.$set(this.searchForm, 'wageSettleType', 2);
          this.$set(this.tbConfig, 'columns', common_tableDate_settleManger_js__WEBPACK_IMPORTED_MODULE_11__["TwoTab"]); // // todo 删除
          // this.deleteArray('agentType')
          // this.deleteArray('modeName')
          // this.deleteArray('wageAgentName')
          // this.deleteArray('isSplitName')
          // this.deleteArray('wageSettleStatusName')
          //
          // // todo 添加
          // this.addArray('wageSettleStatusName', 12, ['wageSettleStatusName', '结算状态', '', '', true, false])
          //
          // this.addArray('wageBatch', 1, ['wageBatch', '批次号', '', '', true, false])
          // this.addArray('wageAmount', 10, ['wageAmount', '收入（元）', '', '', true, true])
          //
          // this.deleteArray('premium')
          // this.addArray('orderPayment', 9, ['orderPayment', '保费（元）', '', '', true, false])

          break;

        case 'three':
          this.$set(this.searchForm, 'wageSettleType', 3);
          this.modeNameList = _common_dictionary__WEBPACK_IMPORTED_MODULE_9__["default"].modeNameList2;
          this.$set(this.tbConfig, 'columns', common_tableDate_settleManger_js__WEBPACK_IMPORTED_MODULE_11__["ThreeTab"]); // // todo 添加
          // this.addArray('agentType', 7, ['agentType', '人员类型', '', '', true, false])
          // this.addArray('modeName', 17, ['modeName', '合作模式', '', '', true, false])
          //
          // // todo 删除
          // this.deleteArray('wageAgentName')
          // this.deleteArray('isSplitName')
          // this.deleteArray('wageSettleStatusName')
          // this.deleteArray('wageAmount')
          // this.deleteArray('wageBatch')
          // ;['orderPayment', '保费（元）', '', '', true, false], this.deleteArray('orderPayment')
          // this.addArray('premium', 9, ['premium', '保费（元）', '', '', true, false])

          break;
      }

      var params = JSON.parse(JSON.stringify(this.searchForm));
      this.tbOptionData.currentPage = 1;
      params.pageNo = 1;
      params.pageSize = 10;

      if (this.searchForm.wageSettleType === 3) {
        this.getConstructionLis(params);
      } else {
        this.getList(params);
      }

      this.queryChannelCompanyApi();
    },
    // // todo 表格中添加数据
    // addArray(str, index, array) {
    // 	const flag = this.tbConfig.columns.findIndex(item => {
    // 		return item[0] === str
    // 	})
    //
    // 	if (flag === -1) {
    // 		this.tbConfig.columns.splice(index, 0, array)
    // 	}
    // },
    //
    // //todo  表格中删除数据
    // deleteArray(str) {
    // 	const index = this.tbConfig.columns.findIndex(item => {
    // 		return item[0] === str
    // 	})
    //
    // 	if (index > -1) {
    // 		this.tbConfig.columns.splice(index, 1)
    // 	}
    // },
    //todo 选择渠道
    handleSelect: function handleSelect(data) {
      this.searchForm.channelCompanyCode = data.channelCompanyCode; //   this.searchForm.channelCompanyName = data.channelCompanyName;

      this.searchForm.channelGroupCode = '';
      this.searchForm.channelGroupName = '';
    },
    //选择团队
    handleSelectTeam: function handleSelectTeam(data) {
      this.searchForm.channelGroupCode = data.channelGroupCode; //   this.searchForm.channelGroupName = data.channelGroupName;
    },
    //todo 生成结算表点击按钮
    productSumWatchHandle: function productSumWatchHandle() {
      var _this3 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
        var state, res;
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                state = _this3.searchForm.wageSettleType;
                _context3.t0 = _this3.searchForm.wageSettleType;
                _context3.next = _context3.t0 === 1 ? 4 : _context3.t0 === 2 ? 4 : _context3.t0 === 3 ? 8 : 12;
                break;

              case 4:
                _context3.next = 6;
                return Object(_api_mgaApi__WEBPACK_IMPORTED_MODULE_5__["productSumTwoApi"])(_this3.searchForm);

              case 6:
                res = _context3.sent;
                return _context3.abrupt("break", 12);

              case 8:
                _context3.next = 10;
                return Object(_api_mgaApi__WEBPACK_IMPORTED_MODULE_5__["productSumApi"])(_this3.searchForm);

              case 10:
                res = _context3.sent;
                return _context3.abrupt("break", 12);

              case 12:
                if (res.code === 200) {
                  _this3.$message({
                    type: 'success',
                    message: '生成批次列表成功'
                  });

                  _this3.searchForm = {};

                  _this3.$set(_this3.searchForm, 'wageSettleType', state);

                  _this3.dataInit();
                }

              case 13:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3);
      }))();
    },
    //todo 数据过滤
    dataFilter: function dataFilter(id, val) {
      if (id === 'esource') {
        var typeValue = '';
        this.esourceList.map(function (item) {
          if (item.value === val) {
            typeValue = item.name;
          }
        });
        return typeValue; //长短险种
      } else if (id == 'status') {
        var _typeValue = '';
        this.settleStatusList.map(function (item) {
          if (item.value == val) {
            _typeValue = item.name;
          }
        });
        return _typeValue; //长短险种
      } else if (id == 'insCompanySettleStatus') {
        var _typeValue2 = '';
        this.insCompanySettleStatusList.map(function (item) {
          if (item.value == val) {
            _typeValue2 = item.name;
          }
        });
        return _typeValue2; //长短险种
      }
    },
    // todo  查询渠道公司下拉框列表接口
    queryChannelCompanyApi: function queryChannelCompanyApi() {
      var _this4 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
        var data, res;
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                data = {
                  wageSettleType: _this4.searchForm.wageSettleType
                };
                _context4.next = 3;
                return Object(_api_mgaApi__WEBPACK_IMPORTED_MODULE_5__["queryChannelCompanyApi"])(data);

              case 3:
                res = _context4.sent;

                if (res.code === 200) {
                  res.data.map(function (item) {
                    item.value = item.channelCompanyName;
                  });
                  _this4.channelCompanyNameList = res.data;
                }

              case 5:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4);
      }))();
    },
    // todo 查询团队下拉框接口
    queryTeamApi: function queryTeamApi() {
      var _this5 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
        var res;
        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.next = 2;
                return Object(_api_mgaApi__WEBPACK_IMPORTED_MODULE_5__["queryTeamApi"])();

              case 2:
                res = _context5.sent;

                if (res.code === 200) {
                  res.data.map(function (item) {
                    item.aName = item.channelGroupName; //   item.value = item.channelGroupCode;

                    item.value = item.channelGroupName;
                    item.label = item.channelGroupName;
                  });
                  _this5.teamNameList = res.data;
                  _this5.backupsData = res.data;
                }

              case 4:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5);
      }))();
    },
    // todo 上传
    uploadSuccess: function uploadSuccess(response, file, fileList) {
      if (response.code === '200') {
        this.dataInit();
        this.$message({
          type: 'success',
          message: '结算记录导入成功'
        });
      } else {
        this.$message({
          type: 'error',
          message: response.msg
        });
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"b9734f90-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/settleAccount/settleManger.vue?vue&type=template&id=428ba76c&scoped=true&":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"b9734f90-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/mga-manage/settleAccount/settleManger.vue?vue&type=template&id=428ba76c&scoped=true& ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "selfCon", attrs: { id: "container" } },
    [
      _c("div", { staticClass: "queryHeading" }, [_vm._v("查询条件")]),
      _c(
        "div",
        [
          _c(
            "el-form",
            {
              staticClass: "demo-form-inline",
              attrs: {
                inline: true,
                model: _vm.searchForm,
                "label-width": "120px"
              }
            },
            [
              _c(
                "el-row",
                [
                  _c(
                    "el-col",
                    { attrs: { span: 6 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: " 投保人:" } },
                        [
                          _c("el-input", {
                            attrs: { placeholder: "请输入内容" },
                            model: {
                              value: _vm.searchForm.holderName,
                              callback: function($$v) {
                                _vm.$set(_vm.searchForm, "holderName", $$v)
                              },
                              expression: "searchForm.holderName"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 6 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "代理人:" } },
                        [
                          _c("el-input", {
                            attrs: { placeholder: "请输入内容" },
                            model: {
                              value: _vm.searchForm.agentName,
                              callback: function($$v) {
                                _vm.$set(_vm.searchForm, "agentName", $$v)
                              },
                              expression: "searchForm.agentName"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: this.selIndex === "first",
                          expression: "this.selIndex === 'first'"
                        }
                      ],
                      attrs: { span: 6 }
                    },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "人员类型:" } },
                        [
                          _c(
                            "el-select",
                            {
                              attrs: { clearable: "", placeholder: "请选择" },
                              model: {
                                value: _vm.searchForm.agentType,
                                callback: function($$v) {
                                  _vm.$set(_vm.searchForm, "agentType", $$v)
                                },
                                expression: "searchForm.agentType"
                              }
                            },
                            _vm._l(_vm.peopleTypeList, function(item, index) {
                              return _c("el-option", {
                                key: index,
                                attrs: { label: item.name, value: item.value }
                              })
                            }),
                            1
                          )
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { staticClass: "position", attrs: { span: 6 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "供应商:" } },
                        [
                          _c("el-input", {
                            attrs: { placeholder: "请输入内容" },
                            model: {
                              value: _vm.searchForm.insCompanyName,
                              callback: function($$v) {
                                _vm.$set(_vm.searchForm, "insCompanyName", $$v)
                              },
                              expression: "searchForm.insCompanyName"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { staticClass: "position", attrs: { span: 6 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "渠道名称:" } },
                        [
                          _c("el-autocomplete", {
                            attrs: {
                              "fetch-suggestions": _vm.querySearchAsyncCompany,
                              placeholder: "请输入内容",
                              clearable: ""
                            },
                            on: { select: _vm.handleSelect },
                            model: {
                              value: _vm.searchForm.channelCompanyName,
                              callback: function($$v) {
                                _vm.$set(
                                  _vm.searchForm,
                                  "channelCompanyName",
                                  $$v
                                )
                              },
                              expression: "searchForm.channelCompanyName"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 6 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "团队名称:" } },
                        [
                          _c("el-autocomplete", {
                            attrs: {
                              "fetch-suggestions": _vm.querySearchAsync,
                              placeholder: "请输入内容"
                            },
                            on: { select: _vm.handleSelectTeam },
                            model: {
                              value: _vm.searchForm.channelGroupName,
                              callback: function($$v) {
                                _vm.$set(
                                  _vm.searchForm,
                                  "channelGroupName",
                                  $$v
                                )
                              },
                              expression: "searchForm.channelGroupName"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 6 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "订单编号:" } },
                        [
                          _c("el-input", {
                            attrs: { placeholder: "请输入内容" },
                            model: {
                              value: _vm.searchForm.orderId,
                              callback: function($$v) {
                                _vm.$set(_vm.searchForm, "orderId", $$v)
                              },
                              expression: "searchForm.orderId"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 6 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "产品名称:" } },
                        [
                          _c("el-input", {
                            attrs: { placeholder: "请输入内容" },
                            model: {
                              value: _vm.searchForm.productName,
                              callback: function($$v) {
                                _vm.$set(_vm.searchForm, "productName", $$v)
                              },
                              expression: "searchForm.productName"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { staticClass: "position", attrs: { span: 6 } },
                    [
                      _c(
                        "el-form-item",
                        {
                          staticClass: "key_point",
                          attrs: { label: " 出单日期:" }
                        },
                        [
                          _c("el-date-picker", {
                            attrs: {
                              placeholder: "开始时间",
                              type: "date",
                              "value-format": "yyyy-MM-dd"
                            },
                            model: {
                              value: _vm.searchForm.makeDateStart,
                              callback: function($$v) {
                                _vm.$set(_vm.searchForm, "makeDateStart", $$v)
                              },
                              expression: "searchForm.makeDateStart"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { staticClass: "position", attrs: { span: 6 } },
                    [
                      _c(
                        "el-form-item",
                        { staticClass: "key_point", attrs: { label: "至:" } },
                        [
                          _c("el-date-picker", {
                            attrs: {
                              placeholder: "结束时间",
                              type: "date",
                              "value-format": "yyyy-MM-dd"
                            },
                            model: {
                              value: _vm.searchForm.makeDateEnd,
                              callback: function($$v) {
                                _vm.$set(_vm.searchForm, "makeDateEnd", $$v)
                              },
                              expression: "searchForm.makeDateEnd"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 6 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "保单号:" } },
                        [
                          _c("el-input", {
                            attrs: { placeholder: "请输入内容" },
                            model: {
                              value: _vm.searchForm.policyNo,
                              callback: function($$v) {
                                _vm.$set(_vm.searchForm, "policyNo", $$v)
                              },
                              expression: "searchForm.policyNo"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  this.selIndex !== "three"
                    ? _c(
                        "el-col",
                        { attrs: { span: 6 } },
                        [
                          _c(
                            "el-form-item",
                            { attrs: { label: "保单状态:" } },
                            [
                              _c(
                                "el-select",
                                {
                                  attrs: {
                                    clearable: "",
                                    placeholder: "请选择"
                                  },
                                  model: {
                                    value: _vm.searchForm.appStatus,
                                    callback: function($$v) {
                                      _vm.$set(_vm.searchForm, "appStatus", $$v)
                                    },
                                    expression: "searchForm.appStatus"
                                  }
                                },
                                _vm._l(_vm.fromState, function(item, index) {
                                  return _c("el-option", {
                                    key: index,
                                    attrs: {
                                      label: item.label,
                                      value: item.value
                                    }
                                  })
                                }),
                                1
                              )
                            ],
                            1
                          )
                        ],
                        1
                      )
                    : _vm._e(),
                  this.selIndex === "three"
                    ? _c(
                        "el-col",
                        { attrs: { span: 6 } },
                        [
                          _c(
                            "el-form-item",
                            { attrs: { label: " 保单状态:" } },
                            [
                              _c(
                                "el-select",
                                {
                                  attrs: {
                                    clearable: "",
                                    placeholder: "请选择"
                                  },
                                  model: {
                                    value: _vm.searchForm.policyStatus,
                                    callback: function($$v) {
                                      _vm.$set(
                                        _vm.searchForm,
                                        "policyStatus",
                                        $$v
                                      )
                                    },
                                    expression: "searchForm.policyStatus"
                                  }
                                },
                                _vm._l(_vm.fromState, function(item, index) {
                                  return _c("el-option", {
                                    key: index,
                                    attrs: {
                                      label: item.label,
                                      value: item.value
                                    }
                                  })
                                }),
                                1
                              )
                            ],
                            1
                          )
                        ],
                        1
                      )
                    : _vm._e(),
                  _c(
                    "el-col",
                    { staticClass: "position", attrs: { span: 6 } },
                    [
                      _vm.selIndex != "three"
                        ? _c(
                            "el-form-item",
                            {
                              staticClass: "key_point",
                              attrs: { label: " 结算状态:" }
                            },
                            [
                              _c(
                                "el-select",
                                {
                                  attrs: {
                                    clearable: "",
                                    placeholder: "请选择"
                                  },
                                  model: {
                                    value: _vm.searchForm.wageSettleStatus,
                                    callback: function($$v) {
                                      _vm.$set(
                                        _vm.searchForm,
                                        "wageSettleStatus",
                                        $$v
                                      )
                                    },
                                    expression: "searchForm.wageSettleStatus"
                                  }
                                },
                                _vm._l(_vm.wageSettleStatusList, function(
                                  item,
                                  index
                                ) {
                                  return _c("el-option", {
                                    key: index,
                                    attrs: {
                                      label: item.name,
                                      value: item.value
                                    }
                                  })
                                }),
                                1
                              )
                            ],
                            1
                          )
                        : _vm._e()
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { staticClass: "position", attrs: { span: 6 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "收款状态:" } },
                        [
                          _c(
                            "el-select",
                            {
                              attrs: { clearable: "", placeholder: "请选择" },
                              model: {
                                value: _vm.searchForm.insCompanySettleStatus,
                                callback: function($$v) {
                                  _vm.$set(
                                    _vm.searchForm,
                                    "insCompanySettleStatus",
                                    $$v
                                  )
                                },
                                expression: "searchForm.insCompanySettleStatus"
                              }
                            },
                            _vm._l(_vm.insCompanySettleStatusList, function(
                              item,
                              index
                            ) {
                              return _c("el-option", {
                                key: index,
                                attrs: { label: item.name, value: item.value }
                              })
                            }),
                            1
                          )
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  this.selIndex !== "three"
                    ? _c(
                        "el-col",
                        { attrs: { span: 6 } },
                        [
                          _c(
                            "el-form-item",
                            { attrs: { label: " 产品类型:" } },
                            [
                              _c(
                                "el-select",
                                {
                                  attrs: {
                                    clearable: "",
                                    placeholder: "请选择"
                                  },
                                  model: {
                                    value: _vm.searchForm.eSource,
                                    callback: function($$v) {
                                      _vm.$set(_vm.searchForm, "eSource", $$v)
                                    },
                                    expression: "searchForm.eSource"
                                  }
                                },
                                _vm._l(_vm.esourceList, function(item, index) {
                                  return _c("el-option", {
                                    key: index,
                                    attrs: {
                                      label: item.name,
                                      value: item.value
                                    }
                                  })
                                }),
                                1
                              )
                            ],
                            1
                          )
                        ],
                        1
                      )
                    : _vm._e(),
                  this.selIndex === "three"
                    ? _c(
                        "el-col",
                        { attrs: { span: 6 } },
                        [
                          _c(
                            "el-form-item",
                            { attrs: { label: " 产品类型:" } },
                            [
                              _c(
                                "el-select",
                                {
                                  attrs: {
                                    clearable: "",
                                    placeholder: "请选择"
                                  },
                                  model: {
                                    value: _vm.searchForm.proType,
                                    callback: function($$v) {
                                      _vm.$set(_vm.searchForm, "proType", $$v)
                                    },
                                    expression: "searchForm.proType"
                                  }
                                },
                                _vm._l(_vm.esourceList, function(item, index) {
                                  return _c("el-option", {
                                    key: index,
                                    attrs: {
                                      label: item.name,
                                      value: item.value
                                    }
                                  })
                                }),
                                1
                              )
                            ],
                            1
                          )
                        ],
                        1
                      )
                    : _vm._e(),
                  _c(
                    "el-col",
                    { attrs: { span: 6 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "回访状态:" } },
                        [
                          _c(
                            "el-select",
                            {
                              attrs: { clearable: "", placeholder: "请选择" },
                              model: {
                                value: _vm.searchForm.revisitStatus,
                                callback: function($$v) {
                                  _vm.$set(_vm.searchForm, "revisitStatus", $$v)
                                },
                                expression: "searchForm.revisitStatus"
                              }
                            },
                            _vm._l(_vm.visitStatus, function(item, index) {
                              return _c("el-option", {
                                key: index,
                                attrs: { label: item.name, value: item.value }
                              })
                            }),
                            1
                          )
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: this.selIndex === "first",
                          expression: "this.selIndex === 'first'"
                        }
                      ],
                      attrs: { span: 6 }
                    },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "拆单状态:" } },
                        [
                          _c(
                            "el-select",
                            {
                              attrs: { clearable: "", placeholder: "请选择" },
                              model: {
                                value: _vm.searchForm.isSplit,
                                callback: function($$v) {
                                  _vm.$set(_vm.searchForm, "isSplit", $$v)
                                },
                                expression: "searchForm.isSplit"
                              }
                            },
                            _vm._l(_vm.isSplitList, function(item, index) {
                              return _c("el-option", {
                                key: index,
                                attrs: { label: item.name, value: item.value }
                              })
                            }),
                            1
                          )
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 6 } },
                    [
                      _c(
                        "el-form-item",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: this.selIndex !== "second",
                              expression: "this.selIndex !== 'second'"
                            }
                          ],
                          attrs: { label: " 合作模式:" }
                        },
                        [
                          _c(
                            "el-select",
                            {
                              attrs: { clearable: "", placeholder: "请选择" },
                              model: {
                                value: _vm.searchForm.modeName,
                                callback: function($$v) {
                                  _vm.$set(_vm.searchForm, "modeName", $$v)
                                },
                                expression: "searchForm.modeName"
                              }
                            },
                            _vm._l(_vm.modeNameList, function(item, index) {
                              return _c("el-option", {
                                key: index,
                                attrs: { label: item.name, value: item.value }
                              })
                            }),
                            1
                          )
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { staticClass: "button_position", attrs: { span: 12 } },
                    [
                      _c(
                        "el-button",
                        {
                          attrs: { type: "primary" },
                          on: { click: _vm.onSubmit }
                        },
                        [_vm._v("查询")]
                      ),
                      _c(
                        "el-button",
                        {
                          attrs: { type: "primary" },
                          on: { click: _vm.downLoad }
                        },
                        [_vm._v("导出")]
                      )
                    ],
                    1
                  )
                ],
                1
              )
            ],
            1
          )
        ],
        1
      ),
      _c(
        "div",
        { staticClass: "showTab" },
        [
          _c(
            "el-tabs",
            {
              attrs: { type: "card" },
              on: { "tab-click": _vm.selTab },
              model: {
                value: _vm.selIndex,
                callback: function($$v) {
                  _vm.selIndex = $$v
                },
                expression: "selIndex"
              }
            },
            [
              _c("el-tab-pane", {
                attrs: { label: "代理人收入", name: "first" }
              }),
              _c("el-tab-pane", {
                attrs: { label: "大B基础收入", name: "second" }
              }),
              _c("el-tab-pane", {
                attrs: { label: "机构活动收入", name: "three" }
              })
            ],
            1
          ),
          _c(
            "div",
            { staticClass: "buttonGroup" },
            [
              _c(
                "el-button",
                {
                  attrs: { size: "mini", type: "primary" },
                  on: { click: _vm.productSumWatchHandle }
                },
                [_vm._v("生成结算表")]
              ),
              _c(
                "span",
                {
                  directives: [
                    {
                      name: "show",
                      rawName: "v-show",
                      value: this.selIndex === "first",
                      expression: "this.selIndex === 'first'"
                    }
                  ]
                },
                [
                  _c(
                    "el-button",
                    { attrs: { size: "mini", type: "success" } },
                    [_vm._v("拆单结算")]
                  ),
                  _c("el-button", { attrs: { size: "mini", type: "info" } }, [
                    _vm._v("取消拆单")
                  ])
                ],
                1
              )
            ],
            1
          )
        ],
        1
      ),
      _c("div", { staticClass: "queryHeading" }, [_vm._v("查询结果")]),
      _c("stable", {
        ref: "result",
        attrs: { config: _vm.tbConfig, optionData: _vm.tbOptionData }
      })
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/core-js/internals/inherit-if-required.js":
/*!***************************************************************!*\
  !*** ./node_modules/core-js/internals/inherit-if-required.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");
var setPrototypeOf = __webpack_require__(/*! ../internals/object-set-prototype-of */ "./node_modules/core-js/internals/object-set-prototype-of.js");

// makes subclassing work correct for wrapped built-ins
module.exports = function ($this, dummy, Wrapper) {
  var NewTarget, NewTargetPrototype;
  if (
    // it can work only with native `setPrototypeOf`
    setPrototypeOf &&
    // we haven't completely correct pre-ES6 way for getting `new.target`, so use this
    typeof (NewTarget = dummy.constructor) == 'function' &&
    NewTarget !== Wrapper &&
    isObject(NewTargetPrototype = NewTarget.prototype) &&
    NewTargetPrototype !== Wrapper.prototype
  ) setPrototypeOf($this, NewTargetPrototype);
  return $this;
};


/***/ }),

/***/ "./node_modules/core-js/internals/is-regexp.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/internals/is-regexp.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");
var classof = __webpack_require__(/*! ../internals/classof-raw */ "./node_modules/core-js/internals/classof-raw.js");
var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");

var MATCH = wellKnownSymbol('match');

// `IsRegExp` abstract operation
// https://tc39.es/ecma262/#sec-isregexp
module.exports = function (it) {
  var isRegExp;
  return isObject(it) && ((isRegExp = it[MATCH]) !== undefined ? !!isRegExp : classof(it) == 'RegExp');
};


/***/ }),

/***/ "./node_modules/core-js/modules/es.array.filter.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es.array.filter.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var $filter = __webpack_require__(/*! ../internals/array-iteration */ "./node_modules/core-js/internals/array-iteration.js").filter;
var arrayMethodHasSpeciesSupport = __webpack_require__(/*! ../internals/array-method-has-species-support */ "./node_modules/core-js/internals/array-method-has-species-support.js");

var HAS_SPECIES_SUPPORT = arrayMethodHasSpeciesSupport('filter');

// `Array.prototype.filter` method
// https://tc39.es/ecma262/#sec-array.prototype.filter
// with adding support of @@species
$({ target: 'Array', proto: true, forced: !HAS_SPECIES_SUPPORT }, {
  filter: function filter(callbackfn /* , thisArg */) {
    return $filter(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es.array.map.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/es.array.map.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var $map = __webpack_require__(/*! ../internals/array-iteration */ "./node_modules/core-js/internals/array-iteration.js").map;
var arrayMethodHasSpeciesSupport = __webpack_require__(/*! ../internals/array-method-has-species-support */ "./node_modules/core-js/internals/array-method-has-species-support.js");

var HAS_SPECIES_SUPPORT = arrayMethodHasSpeciesSupport('map');

// `Array.prototype.map` method
// https://tc39.es/ecma262/#sec-array.prototype.map
// with adding support of @@species
$({ target: 'Array', proto: true, forced: !HAS_SPECIES_SUPPORT }, {
  map: function map(callbackfn /* , thisArg */) {
    return $map(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es.regexp.constructor.js":
/*!***************************************************************!*\
  !*** ./node_modules/core-js/modules/es.regexp.constructor.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/core-js/internals/descriptors.js");
var global = __webpack_require__(/*! ../internals/global */ "./node_modules/core-js/internals/global.js");
var isForced = __webpack_require__(/*! ../internals/is-forced */ "./node_modules/core-js/internals/is-forced.js");
var inheritIfRequired = __webpack_require__(/*! ../internals/inherit-if-required */ "./node_modules/core-js/internals/inherit-if-required.js");
var defineProperty = __webpack_require__(/*! ../internals/object-define-property */ "./node_modules/core-js/internals/object-define-property.js").f;
var getOwnPropertyNames = __webpack_require__(/*! ../internals/object-get-own-property-names */ "./node_modules/core-js/internals/object-get-own-property-names.js").f;
var isRegExp = __webpack_require__(/*! ../internals/is-regexp */ "./node_modules/core-js/internals/is-regexp.js");
var getFlags = __webpack_require__(/*! ../internals/regexp-flags */ "./node_modules/core-js/internals/regexp-flags.js");
var stickyHelpers = __webpack_require__(/*! ../internals/regexp-sticky-helpers */ "./node_modules/core-js/internals/regexp-sticky-helpers.js");
var redefine = __webpack_require__(/*! ../internals/redefine */ "./node_modules/core-js/internals/redefine.js");
var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
var enforceInternalState = __webpack_require__(/*! ../internals/internal-state */ "./node_modules/core-js/internals/internal-state.js").enforce;
var setSpecies = __webpack_require__(/*! ../internals/set-species */ "./node_modules/core-js/internals/set-species.js");
var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");

var MATCH = wellKnownSymbol('match');
var NativeRegExp = global.RegExp;
var RegExpPrototype = NativeRegExp.prototype;
var re1 = /a/g;
var re2 = /a/g;

// "new" should create a new object, old webkit bug
var CORRECT_NEW = new NativeRegExp(re1) !== re1;

var UNSUPPORTED_Y = stickyHelpers.UNSUPPORTED_Y;

var FORCED = DESCRIPTORS && isForced('RegExp', (!CORRECT_NEW || UNSUPPORTED_Y || fails(function () {
  re2[MATCH] = false;
  // RegExp constructor can alter flags and IsRegExp works correct with @@match
  return NativeRegExp(re1) != re1 || NativeRegExp(re2) == re2 || NativeRegExp(re1, 'i') != '/a/i';
})));

// `RegExp` constructor
// https://tc39.es/ecma262/#sec-regexp-constructor
if (FORCED) {
  var RegExpWrapper = function RegExp(pattern, flags) {
    var thisIsRegExp = this instanceof RegExpWrapper;
    var patternIsRegExp = isRegExp(pattern);
    var flagsAreUndefined = flags === undefined;
    var sticky;

    if (!thisIsRegExp && patternIsRegExp && pattern.constructor === RegExpWrapper && flagsAreUndefined) {
      return pattern;
    }

    if (CORRECT_NEW) {
      if (patternIsRegExp && !flagsAreUndefined) pattern = pattern.source;
    } else if (pattern instanceof RegExpWrapper) {
      if (flagsAreUndefined) flags = getFlags.call(pattern);
      pattern = pattern.source;
    }

    if (UNSUPPORTED_Y) {
      sticky = !!flags && flags.indexOf('y') > -1;
      if (sticky) flags = flags.replace(/y/g, '');
    }

    var result = inheritIfRequired(
      CORRECT_NEW ? new NativeRegExp(pattern, flags) : NativeRegExp(pattern, flags),
      thisIsRegExp ? this : RegExpPrototype,
      RegExpWrapper
    );

    if (UNSUPPORTED_Y && sticky) {
      var state = enforceInternalState(result);
      state.sticky = true;
    }

    return result;
  };
  var proxy = function (key) {
    key in RegExpWrapper || defineProperty(RegExpWrapper, key, {
      configurable: true,
      get: function () { return NativeRegExp[key]; },
      set: function (it) { NativeRegExp[key] = it; }
    });
  };
  var keys = getOwnPropertyNames(NativeRegExp);
  var index = 0;
  while (keys.length > index) proxy(keys[index++]);
  RegExpPrototype.constructor = RegExpWrapper;
  RegExpWrapper.prototype = RegExpPrototype;
  redefine(global, 'RegExp', RegExpWrapper);
}

// https://tc39.es/ecma262/#sec-get-regexp-@@species
setSpecies('RegExp');


/***/ }),

/***/ "./node_modules/core-js/modules/es.regexp.to-string.js":
/*!*************************************************************!*\
  !*** ./node_modules/core-js/modules/es.regexp.to-string.js ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var redefine = __webpack_require__(/*! ../internals/redefine */ "./node_modules/core-js/internals/redefine.js");
var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/core-js/internals/an-object.js");
var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
var flags = __webpack_require__(/*! ../internals/regexp-flags */ "./node_modules/core-js/internals/regexp-flags.js");

var TO_STRING = 'toString';
var RegExpPrototype = RegExp.prototype;
var nativeToString = RegExpPrototype[TO_STRING];

var NOT_GENERIC = fails(function () { return nativeToString.call({ source: 'a', flags: 'b' }) != '/a/b'; });
// FF44- RegExp#toString has a wrong name
var INCORRECT_NAME = nativeToString.name != TO_STRING;

// `RegExp.prototype.toString` method
// https://tc39.es/ecma262/#sec-regexp.prototype.tostring
if (NOT_GENERIC || INCORRECT_NAME) {
  redefine(RegExp.prototype, TO_STRING, function toString() {
    var R = anObject(this);
    var p = String(R.source);
    var rf = R.flags;
    var f = String(rf === undefined && R instanceof RegExp && !('flags' in RegExpPrototype) ? flags.call(R) : rf);
    return '/' + p + '/' + f;
  }, { unsafe: true });
}


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/settleAccount/settleManger.vue?vue&type=style&index=0&id=428ba76c&lang=less&scoped=true&":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--10-oneOf-1-2!./node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/mga-manage/settleAccount/settleManger.vue?vue&type=style&index=0&id=428ba76c&lang=less&scoped=true& ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "#container[data-v-428ba76c] {\n  padding: 15px;\n}\n#container .showTab[data-v-428ba76c] {\n  position: relative;\n  margin-bottom: 10px;\n}\n#container .showTab .buttonGroup[data-v-428ba76c] {\n  position: absolute;\n  right: 0;\n  top: 10px;\n}\n#container .queryHeading[data-v-428ba76c] {\n  background-color: #f4f4f5;\n  color: #909399;\n  font-size: 14px;\n  padding: 10px;\n  margin-bottom: 15px;\n}\n#container .pagination[data-v-428ba76c] {\n  margin-top: 15px;\n  float: right;\n}\n#container .editinfo[data-v-428ba76c] {\n  margin-bottom: 15px;\n}\n#container .dialog-content .list[data-v-428ba76c] {\n  margin-bottom: 15px;\n}\n#container .dialog-title[data-v-428ba76c] {\n  font-size: 20px;\n}\n#container .dialog-footer[data-v-428ba76c] {\n  padding-top: 20px;\n  display: flex;\n  justify-content: flex-end;\n}\n#container[data-v-428ba76c] .el-transfer-panel {\n  height: 400px !important;\n}\n#container .el-transfer-panel__list.is-filterable[data-v-428ba76c] {\n  height: 300px;\n}\n#container .el-date-editor.el-input[data-v-428ba76c] {\n  width: 180px !important;\n}\n#container .el-select[data-v-428ba76c] {\n  width: 180px;\n}\n#container .self .el-input--prefix .el-input__inner[data-v-428ba76c] {\n  width: 230px;\n}\n#container .self .el-date-editor.el-input[data-v-428ba76c] {\n  width: 220px !important;\n}\n.text-editor[data-v-428ba76c] {\n  min-height: 220px;\n  margin-bottom: 30px;\n  border: 1px solid #ececec;\n}\n.selRow[data-v-428ba76c] {\n  margin: 20px auto;\n}\n.selRow label[data-v-428ba76c] {\n  display: inline-block;\n  width: 100px;\n  text-align: right;\n}\n.selfCon .el-form-item__content .el-select[data-v-428ba76c] {\n  position: relative;\n  font-size: 14px;\n  display: inline-block;\n  width: 100% !important;\n}\n.addBtn[data-v-428ba76c] {\n  margin-left: 50px;\n}\n.selProduct[data-v-428ba76c] {\n  margin-top: 10px;\n  margin-left: 160px;\n}\n.selProduct .selItem[data-v-428ba76c] {\n  margin-top: 10px;\n}\n.el-transfer-panel[data-v-428ba76c] {\n  width: 36%;\n}\n.el-upload-list__item-name[data-v-428ba76c] {\n  display: none;\n}\n.position[data-v-428ba76c] {\n  position: relative;\n}\n.button_position[data-v-428ba76c] {\n  display: block;\n  margin-left: 3%;\n  margin-bottom: 20px;\n}\n.key_point[data-v-428ba76c]::before {\n  content: '*';\n  position: absolute;\n  top: 12px;\n  left: 30px;\n  color: red;\n}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/settleAccount/settleManger.vue?vue&type=style&index=0&id=428ba76c&lang=less&scoped=true&":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--10-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--10-oneOf-1-2!./node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/mga-manage/settleAccount/settleManger.vue?vue&type=style&index=0&id=428ba76c&lang=less&scoped=true& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--10-oneOf-1-2!../../../../node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!../../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./settleManger.vue?vue&type=style&index=0&id=428ba76c&lang=less&scoped=true& */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/settleAccount/settleManger.vue?vue&type=style&index=0&id=428ba76c&lang=less&scoped=true&");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("5551e2d6", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/common/dictionarieList/common.js":
/*!**********************************************!*\
  !*** ./src/common/dictionarieList/common.js ***!
  \**********************************************/
/*! exports provided: companyList, insuranceCompanyList, teamList, riskType, supplier, fromState */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "companyList", function() { return companyList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "insuranceCompanyList", function() { return insuranceCompanyList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "teamList", function() { return teamList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "riskType", function() { return riskType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "supplier", function() { return supplier; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fromState", function() { return fromState; });
var companyList = []; //渠道名称

var insuranceCompanyList = []; //公司名称

var teamList = []; //团队名称

var riskType = []; //险种类别

var supplier = []; //供应商名称
//保单状态

var fromState = [{
  value: 'UNINSURED',
  label: '未承保'
}, {
  value: 'ACPTINSD_FAILURE',
  label: '承保失败'
}, {
  value: 'ACPTINSD_SUCCESS',
  label: '承保成功'
}, {
  value: 'SURRENDER_FAILURE',
  label: '退保失败'
}, {
  value: 'SURRENDER_SUCCESS',
  label: '犹豫期退保成功'
}, {
  value: 'REVISIT_SUCCESS',
  label: '已回访'
}, {
  value: 'RECEIPT_SUCCESS',
  label: '回执成功'
}, {
  value: 'REFUNDPOLICY_SUCCESS',
  label: '退保终止'
}];

/***/ }),

/***/ "./src/common/tableDate/settleManger.js":
/*!**********************************************!*\
  !*** ./src/common/tableDate/settleManger.js ***!
  \**********************************************/
/*! exports provided: OneTab, TwoTab, ThreeTab */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OneTab", function() { return OneTab; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TwoTab", function() { return TwoTab; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ThreeTab", function() { return ThreeTab; });
var OneTab = [// 表格展示属性:列名、长度、颜色、是否需要点击事件、是否需要操作列、操作列名称
['orderId', '订单编号', '270px', '', true, false], ['wageBatch', '批次号', '230px', '', true, false], ['productName', '产品名称', '300px', '', true, false], ['esourceName', '产品类型', '100px', '', true, false], ['insCompanyName', '供应商', '180', '', true, true], ['policyNo', '保单号', '300px', '', true, true], ['holderName', '投保人', '100px', '', true, false], ['agentName', '代理人', '100px', false, false], ['wageAgentName', '收款人', '', '', true, false], ['phone', '手机号', '', '100px', true, false], ['isSplitName', '拆单状态', '', '', true, false], ['orderPayment', '保费（元）', '100px', '', true, false], ['wageAmount', '收入（元）', '100px', '', true, true], ['appStatusName', '保单状态', '100px', '', true, false], ['revisitStatus', '回访状态', '', '', true, false], ['modeName', '合作模式', '', '', true, false], ['agentType', '人员类型', '', '', true, true], ['wageSettleStatusName', '结算状态', '100px', '', true, false], ['insCompanySettleStatus', '收款状态', '100px', '', true, true], ['makeDate', '出单日期', '', '', true, false], ['channelGroupName', '团队名称', '100px', '', true, false], ['channelGroupCode', '团队编码', '100px', '', true, false], ['channelCompanyCode', '渠道编码', '100px', '', true, false], ['channelCompanyName', '渠道名称', '100px', '', true, false]];
var TwoTab = [// 表格展示属性:列名、长度、颜色、是否需要点击事件、是否需要操作列、操作列名称
['orderId', '订单编号', '270px', '', true, false], ['wageBatch', '批次号', '230px', '', true, false], ['productName', '产品名称', '300px', '', true, false], ['esourceName', '产品类型', '100px', '', true, false], ['insCompanyName', '供应商', '180', '', true, true], ['policyNo', '保单号', '300px', '', true, true], ['holderName', '投保人', '100px', '', true, false], ['agentName', '代理人', '100px', false, false], ['phone', '手机号', '', '100px', true, false], ['orderPayment', '保费（元）', '100px', '', true, false], ['wageAmount', '收入（元）', '100px', '', true, true], ['appStatusName', '保单状态', '100px', '', true, false], ['revisitStatus', '回访状态', '', '', true, false], ['insCompanySettleStatus', '收款状态', '100px', '', true, true], ['makeDate', '出单日期', '150px', '', true, false], ['wageSettleStatusName', '结算状态', '100px', '', true, false], ['channelGroupName', '团队名称', '100px', '', true, false], ['channelGroupCode', '团队编码', '100px', '', true, false], ['channelCompanyCode', '渠道编码', '100px', '', true, false], ['channelCompanyName', '渠道名称', '100px', '', true, false]];
var ThreeTab = [// 表格展示属性:列名、长度、颜色、是否需要点击事件、是否需要操作列、操作列名称
['orderId', '订单编号', '270px', '', true, false], ['productName', '产品名称', '300px', '', true, false], ['esourceName', '产品类型', '100px', '', true, false], ['insCompanyName', '供应商', '180', '', true, true], ['policyNo', '保单号', '300px', '', true, true], ['holderName', '投保人', '100px', '', true, false], ['agentType', '人员类型', '', '', true, true], ['agentName', '代理人', '100px', false, false], ['phone', '手机号', '', '100px', true, false], ['orderPayment', '保费（元）', '100px', '', true, false], ['appStatusName', '保单状态', '', '', true, false], ['revisitStatus', '回访状态', '', '', true, false], ['insCompanySettleStatus', '收款状态', '', '', true, true], ['makeDate', '出单日期', '150px', '', true, false], ['modeName', '合作模式', '', '', true, false], ['channelGroupName', '团队名称', '100px', '', true, false], ['channelGroupCode', '团队编码', '100px', '', true, false], ['channelCompanyCode', '渠道编码', '100px', '', true, false], ['channelCompanyName', '渠道名称', '100px', '', true, false]];

/***/ }),

/***/ "./src/common/utils.js":
/*!*****************************!*\
  !*** ./src/common/utils.js ***!
  \*****************************/
/*! exports provided: filterHandle, copyUrl, Storage, formatDate */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "filterHandle", function() { return filterHandle; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "copyUrl", function() { return copyUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Storage", function() { return Storage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "formatDate", function() { return formatDate; });
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.object.entries.js */ "./node_modules/core-js/modules/es.object.entries.js");
/* harmony import */ var core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_regexp_constructor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.regexp.constructor.js */ "./node_modules/core-js/modules/es.regexp.constructor.js");
/* harmony import */ var core_js_modules_es_regexp_constructor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_constructor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_7__);








function filterHandle(tableData, dictionaryData) {
  for (var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
    args[_key - 2] = arguments[_key];
  }

  args.forEach(function (item) {
    dictionaryData.forEach(function (i) {
      if (tableData[item[0]] === i.value) {
        tableData[item[0]] = i.label;
      }
    });
  });
} // 复制URL

function copyUrl(url) {
  // 创建一个 Input标签
  var cInput = document.createElement("input");
  cInput.value = url;
  document.body.appendChild(cInput);
  cInput.select(); // 选取文本域内容;
  // 执行浏览器复制命令
  // 复制命令会将当前选中的内容复制到剪切板中（这里就是创建的input标签）
  // Input要在正常的编辑状态下原生复制方法才会生效

  document.execCommand("Copy"); /// 复制成功后再将构造的标签 移除

  cInput.remove();
} // 设置SessionStrong

var Storage = {
  set: function set(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  },
  get: function get(key) {
    return JSON.parse(localStorage.getItem(key));
  },
  remove: function remove(key) {
    localStorage.removeItem(key);
  }
};
function formatDate(date, format) {
  var RegAndValue = null;

  if (date instanceof Date) {
    RegAndValue = {
      'y+': date.getFullYear(),
      'M+': date.getMonth() + 1,
      'd+': date.getDate(),
      'h+': date.getHours(),
      'm+': date.getMinutes(),
      's+': date.getSeconds()
    };
  } else {
    RegAndValue = {
      'h+': date / 3600,
      'm+': date % 3600 / 60,
      's+': date % 60
    };
  }

  for (var _i = 0, _Object$entries = Object.entries(RegAndValue); _i < _Object$entries.length; _i++) {
    var _Object$entries$_i = Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__["default"])(_Object$entries[_i], 2),
        key = _Object$entries$_i[0],
        value = _Object$entries$_i[1];

    var reg = new RegExp("(".concat(key, ")"), 'gms');

    if (reg.test(format)) {
      var str = date instanceof Date ? value.toString() : Math.round(value).toString();
      var match = RegExp.$1;
      var replace = replaceV(RegExp.$1.length, str);
      format = format.replace(match, replace);
    }
  } // 在不足两位的前面加0


  function replaceV(currentLength, str) {
    if (str.length === 4) {
      var start = 4 - RegExp.$1.length;
      return str.substr(start);
    } else if (0 < str.length < 4) {
      return ('00' + str).substr(str.length);
    }
  }

  return format;
}

/***/ }),

/***/ "./src/views/mga-manage/settleAccount/settleManger.vue":
/*!*************************************************************!*\
  !*** ./src/views/mga-manage/settleAccount/settleManger.vue ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _settleManger_vue_vue_type_template_id_428ba76c_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./settleManger.vue?vue&type=template&id=428ba76c&scoped=true& */ "./src/views/mga-manage/settleAccount/settleManger.vue?vue&type=template&id=428ba76c&scoped=true&");
/* harmony import */ var _settleManger_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./settleManger.vue?vue&type=script&lang=js& */ "./src/views/mga-manage/settleAccount/settleManger.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _settleManger_vue_vue_type_style_index_0_id_428ba76c_lang_less_scoped_true___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./settleManger.vue?vue&type=style&index=0&id=428ba76c&lang=less&scoped=true& */ "./src/views/mga-manage/settleAccount/settleManger.vue?vue&type=style&index=0&id=428ba76c&lang=less&scoped=true&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _settleManger_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _settleManger_vue_vue_type_template_id_428ba76c_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _settleManger_vue_vue_type_template_id_428ba76c_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "428ba76c",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/mga-manage/settleAccount/settleManger.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/mga-manage/settleAccount/settleManger.vue?vue&type=script&lang=js&":
/*!**************************************************************************************!*\
  !*** ./src/views/mga-manage/settleAccount/settleManger.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_12_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_settleManger_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--12-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./settleManger.vue?vue&type=script&lang=js& */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/settleAccount/settleManger.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_12_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_settleManger_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/mga-manage/settleAccount/settleManger.vue?vue&type=style&index=0&id=428ba76c&lang=less&scoped=true&":
/*!***********************************************************************************************************************!*\
  !*** ./src/views/mga-manage/settleAccount/settleManger.vue?vue&type=style&index=0&id=428ba76c&lang=less&scoped=true& ***!
  \***********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_settleManger_vue_vue_type_style_index_0_id_428ba76c_lang_less_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-style-loader??ref--10-oneOf-1-0!../../../../node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--10-oneOf-1-2!../../../../node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!../../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./settleManger.vue?vue&type=style&index=0&id=428ba76c&lang=less&scoped=true& */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/settleAccount/settleManger.vue?vue&type=style&index=0&id=428ba76c&lang=less&scoped=true&");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_settleManger_vue_vue_type_style_index_0_id_428ba76c_lang_less_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_settleManger_vue_vue_type_style_index_0_id_428ba76c_lang_less_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_settleManger_vue_vue_type_style_index_0_id_428ba76c_lang_less_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_settleManger_vue_vue_type_style_index_0_id_428ba76c_lang_less_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/mga-manage/settleAccount/settleManger.vue?vue&type=template&id=428ba76c&scoped=true&":
/*!********************************************************************************************************!*\
  !*** ./src/views/mga-manage/settleAccount/settleManger.vue?vue&type=template&id=428ba76c&scoped=true& ***!
  \********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_settleManger_vue_vue_type_template_id_428ba76c_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"b9734f90-vue-loader-template"}!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./settleManger.vue?vue&type=template&id=428ba76c&scoped=true& */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"b9734f90-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/settleAccount/settleManger.vue?vue&type=template&id=428ba76c&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_settleManger_vue_vue_type_template_id_428ba76c_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_settleManger_vue_vue_type_template_id_428ba76c_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=19.js.map