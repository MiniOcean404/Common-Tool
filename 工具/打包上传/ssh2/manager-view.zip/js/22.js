(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[22],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/product-manage/outproductList.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--12-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/product-manage/outproductList.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! regenerator-runtime/runtime.js */ "./node_modules/regenerator-runtime/runtime.js");
/* harmony import */ var regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.string.split.js */ "./node_modules/core-js/modules/es.string.split.js");
/* harmony import */ var core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _api_api__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @/api/api */ "./src/api/api.js");
/* harmony import */ var _api_policyAdd__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @/api/policyAdd */ "./src/api/policyAdd.js");
/* harmony import */ var _api_mgaApi__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @/api/mgaApi */ "./src/api/mgaApi.js");
/* harmony import */ var _common_dictionary__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @/common/dictionary */ "./src/common/dictionary.js");
/* harmony import */ var _config_env__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/config/env */ "./src/config/env.js");
/* harmony import */ var _policy_add__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./policy-add */ "./src/views/product-manage/policy-add.vue");
/* harmony import */ var _common_MixinUtils__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @/common/MixinUtils */ "./src/common/MixinUtils.js");
/* harmony import */ var _api_outproductListApi__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @/api/outproductListApi */ "./src/api/outproductListApi.js");
/* harmony import */ var common_dictionarieList_outproductList__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! common/dictionarieList/outproductList */ "./src/common/dictionarieList/outproductList.js");
/* harmony import */ var _common_tableDate_outproductList__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @/common/tableDate/outproductList */ "./src/common/tableDate/outproductList.js");









//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
 //导入请求

 //导入请求


 //数据字典

 // 导入组件

 // import { riskType} from "@/common/dictionarieList/common";
//todo 导入混入

 // todo api




/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'outproductList',
  mixins: [_common_MixinUtils__WEBPACK_IMPORTED_MODULE_15__["tableMixin"]],
  components: {
    PolicyAdd: _policy_add__WEBPACK_IMPORTED_MODULE_14__["default"]
  },
  data: function data() {
    return {
      //销售对象
      checkList: [],
      handlingFeeForm: {},

      /**
       * @上传
       */
      fileList: [],
      //todo:文件上传
      headers: {
        mimeType: 'multipart/form-data' //todo:头部信息

      },
      importRiskRateUrl: _api_api__WEBPACK_IMPORTED_MODULE_9__["importRiskRateUrl"],
      //todo:上传文件链接地址
      codeId: '',
      getValueOptions: [],
      getValueDataAge: _common_dictionary__WEBPACK_IMPORTED_MODULE_12__["default"].getValueDataAge,
      getValueDataYear: _common_dictionary__WEBPACK_IMPORTED_MODULE_12__["default"].getValueDataYear,
      // commands: [
      // 	['#409eff', '预览 ', 'isHandleLook', 'el-icon-edit', 'wxApplet-banner-update'],
      // 	['#409eff', '编辑 ', 'isHandleEdit', 'el-icon-edit', 'wxApplet-banner-update'],
      // 	['#ff5600', ' 上架/下架 ', 'handleisShow', 'el-icon-setting', 'wxApplet-banner-publish'],
      // 	['#67c23a', ' 佣金政策 ', 'CommissionEdit', 'el-icon-edit-outline', 'wxApplet-banner-update'],
      // 	['#e6a23c', ' 手续费率 ', 'servicecChargeHandle', 'el-icon-setting', 'wxApplet-banner-update'],
      // 	['#e6a23c', ' 产品考核 ', 'servicecChargeHandle1', 'el-icon-magic-stick', 'wxApplet-banner-update'],
      // 	['#909399', ' 可售卖渠道公司 ', 'isBuyHandle', 'el-icon-setting', 'wxApplet-banner-update']
      // ],
      dataRule: {
        couponType: [{
          required: true,
          message: '优惠卷类型不能为空',
          trigger: 'blur'
        }],
        couponImg: [{
          required: true,
          message: '优惠券图片不能为空',
          trigger: 'blur'
        }],
        couponName: [{
          required: true,
          message: '优惠卷名字不能为空',
          trigger: 'blur'
        }]
      },
      // 手续费率dialog弹窗控制
      servicecChargeDialogVisible: false,
      productAssessmentPopup: false,
      isPolicyVisible: false,
      isVisible: false,
      uploadUrl: _api_api__WEBPACK_IMPORTED_MODULE_9__["uploadUrl"],
      //文件上传地址
      picUploadData: {
        midAddr: _config_env__WEBPACK_IMPORTED_MODULE_13__["uploadPicPath"].picPath
      },
      //上传图片的地址
      detailInfo: {
        outProductCode: ''
      },
      imageFileList: [],
      searchForm: {
        //查询表单
        outProductType: '',
        outProductName: ''
      },
      codeName: [],
      upDataForm: {
        //编辑的表单
        codeName: '',
        outProductCode: '',
        outProductName: '',
        outInitPrem: '',
        isHot: '',
        outTag: '',
        outImageUrl: '',
        outLinkAddr: '',
        insProCode: '',
        outRiskCompany: '',
        outCompanyCode: '',
        outItemDesc: '',
        outAppntMinimumAge: '',
        outAppntMaxAge: '',
        outHesitationPeriod: '',
        outRiskType: '',
        outProductDes: '',
        outRiskPeriod: '',
        outGroupRisk: '',
        outDiscern: 1,
        outProductType: '',
        isOnline: '',
        salesScope: '',
        level1: '',
        level2: '',
        level3: '',
        level4: '',
        level5: '',
        periodEntities: [{
          index: '',
          ensureId: '',
          outProductCode: '',
          riskYearType: '',
          dyear: '',
          upyear: '',
          value: ''
        }]
      },
      productAssess: {
        level1: '',
        level2: '',
        level3: '',
        level4: '',
        level5: '',
        outProductCode: '',
        discern: 'Y'
      },
      detailForm: {
        //点击查看的展示表单
        demo: 'demo'
      },
      options: [],
      RiskTypeOptions: [],
      ProductTypeOptions: _common_dictionary__WEBPACK_IMPORTED_MODULE_12__["default"].ProductTypeOptions,
      //财寿险标志
      stateOptions: _common_dictionary__WEBPACK_IMPORTED_MODULE_12__["default"].stateOptions,
      isOnlineList: _common_dictionary__WEBPACK_IMPORTED_MODULE_12__["default"].isOnlineType,
      riskPeriodOptions: _common_dictionary__WEBPACK_IMPORTED_MODULE_12__["default"].riskPeriodOptions,
      groupRiskOptions: _common_dictionary__WEBPACK_IMPORTED_MODULE_12__["default"].groupRiskOptions,
      isMainRisk: _common_dictionary__WEBPACK_IMPORTED_MODULE_12__["isMainRisk"],
      tbConfig: {
        //表格组件配置项
        height: '530px',
        // table高度
        select: false,
        // 是否可以多选择
        isSingleSelect: false,
        //是否可以单选
        isOrder: true,
        isCommands: true,
        //是否需要操作列
        commandsWidth: '680px',
        //操作列宽度
        showPagenation: true,
        //是否需要显示分页器
        layout: 'total, prev, pager, next, jumper',
        //分页器控件
        requestCurData: true,
        // 每次分页数据是否请求后台 true:每次都请求后台
        columns: [// 后台字段属性、表头名、长度、颜色、是否过长隐藏、是否需要字典转换、点击事件的处理函数
        ['outProductCode', '产品编码', '', '', true, false], ['outProductName', '产品名称', '', '', true, false], ['supplierName', '所属保险公司', '', '', true, true], ['supplierCode', '保险公司编码', '', '', true, true], ['outCompanyCode', '供应商编码', '', '', true, true], ['outRiskCompany', '供应商名字', '', '', true, true], ['outRiskPeriod', '长短险标志', '', '', true, true], ['outGroupRisk', '个团险标志', '', '', true, true], ['outRiskType', '险种类别', '', '', true, true], ['outDiscern', '内外部标识', '', '', true, true], // ['isOnline', '线上线下标志', '', '', true, true],
        // ['salesScope', '销售对象', '', '', true, true,'clickSalesScope'],
        ['outIsUse', '状态', '', '', true, true]],
        commands: [['#409eff', '预览 ', 'isHandleLook', 'el-icon-edit', 'wxApplet-banner-update'], ['#409eff', '编辑 ', 'isHandleEdit', 'el-icon-edit', 'wxApplet-banner-update'], ['#ff5600', ' 上架/下架 ', 'handleisShow', 'el-icon-setting', 'wxApplet-banner-publish'], ['#67c23a', ' 佣金政策 ', 'CommissionEdit', 'el-icon-edit-outline', 'wxApplet-banner-update'], ['#e6a23c', ' 手续费率 ', 'servicecChargeHandle', 'el-icon-setting', 'wxApplet-banner-update'], // ['#e6a23c', ' 产品考核 ', 'productAssessment', 'el-icon-magic-stick', 'wxApplet-banner-update'],
        ['#909399', ' 可售卖渠道公司 ', 'isBuyHandle', 'el-icon-setting', 'wxApplet-banner-update']]
      },
      isEdit: false,
      tbOptionData: {
        currentTableData: [],
        //当前表格数据
        TransValtoDesc: 'dataFilter',
        //数据字典过滤函数
        selectData: 'handleSelect',
        //单选处理函数
        selectDatas: 'handleSelects',
        //多选处理函数
        sizesCtrl: [5, 10, 20, 30, 40, 50, 100],
        //分页器控件的长度控制器
        pageSize: 10,
        // 每页行数
        currentPage: 1,
        // 当前页
        total: 0,
        //总数据量
        pagenationChange: 'handlPageChange' //处理分页器长度改变或页码改变的函数

      },
      detailConfig: {
        //详情查看弹窗组件配置项
        dialogVisible: false,
        width: '630px',
        buttonPosition: 'flex-end',
        ismodal: true,
        modalClose: false,
        Button: [{
          name: '取消',
          methods: 'permCancel'
        }, {
          name: '提交',
          methods: 'outProductUpdataOrAdd',
          type: 'primary'
        }]
      },
      riskType: _common_dictionary__WEBPACK_IMPORTED_MODULE_12__["default"].riskType,
      salesScopeList: _common_dictionary__WEBPACK_IMPORTED_MODULE_12__["default"].salesScopeType,
      componenyList: [],
      //保险公司列表
      rateDetail: {
        hargeRateInfoList: [],
        riskRateAuditInfo: {
          riskName: '',
          auditStatus: ''
        }
      },
      //费率详情
      // !配置可售卖渠道公司
      productDialog: false,
      // todo 传递的数据
      queryParams: {},
      //todo 字典
      model: common_dictionarieList_outproductList__WEBPACK_IMPORTED_MODULE_17__["model"],
      saleStatus: common_dictionarieList_outproductList__WEBPACK_IMPORTED_MODULE_17__["saleStatus"],
      //todo 表格展示数据
      tableData: {
        resultData: [],
        needData: _common_tableDate_outproductList__WEBPACK_IMPORTED_MODULE_18__["table"]
      },
      productCode: '',
      channelCompanyCodeList: [],
      isShow: '',
      sales: ''
    };
  },
  created: function created() {
    this.getSupplierInfo();
    this.selectrisktype();
  },
  methods: {
    // !配置可售卖渠道公司
    isBuyHandle: function isBuyHandle(row) {
      this.productDialog = true;
      this.queryData = {};
      this.queryData.productCode = this.productCode = row.outProductCode;
      this.requestDeploy();
    },
    installBuy: function installBuy(status) {
      var _this = this;

      if (this.channelCompanyCodeList.length === 0) {
        this.$message({
          type: 'error',
          message: '列表选择不能为空'
        });
        return;
      }

      var data = {
        productCode: this.productCode,
        channelCompanyCodeList: this.channelCompanyCodeList
      };

      switch (status) {
        case 'yes':
          data.opType = 1;
          break;

        case 'no':
          data.opType = 0;
          break;
      }

      Object(_api_outproductListApi__WEBPACK_IMPORTED_MODULE_16__["setOperation"])(data).then(function (res, rej) {
        if (res.code === 200) {
          switch (status) {
            case 'yes':
              _this.$message({
                type: 'success',
                message: '设置可售卖成功'
              });

              break;

            case 'no':
              _this.$message({
                type: 'success',
                message: '设置不可售卖成功'
              });

              break;
          }

          _this.requestDeploy();
        }
      });
    },
    selectChange: function selectChange(val) {
      var proxy = new Proxy(val, {
        get: function get(target, p, receiver) {
          if (target.length > 0) {
            return target.map(function (item) {
              return item.channelCompanyCode;
            });
          }

          return target;
        }
      });
      this.channelCompanyCodeList = proxy[0];
    },
    // todo 当前表格请求配置
    requestDeploy: function requestDeploy(current) {
      //api、查询表格、页、表格数据、当前页、时间数组，过滤函数
      this.getList(_api_outproductListApi__WEBPACK_IMPORTED_MODULE_16__["getSelectCompanyList"], this.queryData, this.pageOption, this.tableData, current, undefined, this.filter);
    },
    // todo 点击查询按钮
    queryButton: function queryButton(e, apiNum) {
      this.requestDeploy();
    },
    // todo 过滤函数
    filter: function filter(v) {
      if (v[0].toLowerCase().indexOf('date') > 0 && v[1] !== '') {
        return [v[0], v[1].split(' ')[0]];
      }
    },
    // todo 页码改变
    currentPageChange: function currentPageChange(current) {
      this.requestDeploy(current);
    },
    // !其他
    //鼠标滑过提示框
    mouserEnter: function mouserEnter() {// alert(123);
    },
    changeSupplier: function changeSupplier(e) {
      var _this2 = this;

      this.upDataForm.supplierCode = e;
      this.codeName.map(function (item) {
        if (item.codeValue == e) {
          _this2.upDataForm.supplierName = item.codeName;
        }
      });
    },
    getSupplierInfo: function getSupplierInfo() {
      var _this3 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
        var _yield$supplierInfo, data;

        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return Object(_api_api__WEBPACK_IMPORTED_MODULE_9__["supplierInfo"])();

              case 2:
                _yield$supplierInfo = _context.sent;
                data = _yield$supplierInfo.data;
                data.map(function (item) {
                  item.label = item.codeName;
                  item.value = item.codeValue;
                });
                _this3.codeName = data;

              case 6:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    //获取产品手续费率详情
    getRateDetail: function getRateDetail(id) {
      var _this4 = this;

      var req = {
        riskCode: id
      };
      this.rateDetail.hargeRateInfoList = [];
      this.rateDetail.riskRateAuditInfo.riskName = '';
      this.rateDetail.riskRateAuditInfo.auditStatus = '';
      Object(_api_mgaApi__WEBPACK_IMPORTED_MODULE_11__["getRateByRiskCodeApi"])(req).then(function (res) {
        if (res.data !== '') {
          _this4.rateDetail = res.data;
        }
      });
    },
    getProductRateLeven: function getProductRateLeven(id) {
      var req = {
        riskCode: id
      };
    },

    /**
     * @upload上传下载
     */
    submitUpload: function submitUpload() {
      this.$refs.upload.submit();
    },
    //todo:文件删除的钩子
    handleRemove: function handleRemove(file, fileList) {
      this.$message({
        type: 'info',
        message: "\u6587\u4EF6".concat(file.name, "\u5220\u9664\u6210\u529F")
      });
    },
    // todo：费率表文件上传成功的钩子
    uploadSuccess: function uploadSuccess(response, file, fileList) {
      if (response.code == '200') {
        this.getRateDetail(this.detailInfo.outProductCode);
        this.$message({
          type: 'success',
          message: '文件导入成功'
        });
      } else {
        this.$message({
          type: 'error',
          message: response.msg
        });
      }
    },
    // todo：文件下载
    downLoad: function downLoad() {
      Object(_api_mgaApi__WEBPACK_IMPORTED_MODULE_11__["downRiskRateTemplateApi"])();
    },

    /**
     * @dialog弹窗
     */
    servicecChargeHandle: function servicecChargeHandle(row) {
      this.servicecChargeDialogVisible = true;
      this.detailInfo = row;
      this.getRateDetail(row.outProductCode);
      var params = {
        riskCode: row.outProductCode
      };
      this.getHandlingFee(params);
    },
    //产品考核保费
    productAssessment: function productAssessment(row) {
      this.productAssessmentPopup = true; //获取外部渠道编码

      this.productAssess.outProductCode = row.outProductCode;
    },
    //产品考核提交
    productAssessmentSub: function productAssessmentSub() {
      if (this.productAssess.level1 === '' || this.productAssess.level2 === '' || this.productAssess.level3 === '' || this.productAssess.level4 === '' || this.productAssess.level5 === '') {
        this.$message({
          type: 'error',
          message: '请输入产品考核保费'
        });
        return false;
      }

      var params = this.productAssess;
      this.updateProductAssessmentSub(params);
      this.productAssess = {
        discern: 'Y'
      };
    },
    updateProductAssessmentSub: function updateProductAssessmentSub(params) {
      var _this5 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
        var result;
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return Object(_api_outproductListApi__WEBPACK_IMPORTED_MODULE_16__["updateProductAssessment"])(params);

              case 2:
                result = _context2.sent;

                if (result.code === 200) {
                  _this5.productAssessmentPopup = false;
                }

              case 4:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    getHandlingFee: function getHandlingFee(params) {
      var _this6 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
        var result;
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.next = 2;
                return Object(_api_policyAdd__WEBPACK_IMPORTED_MODULE_10__["getHandlingFee"])(params);

              case 2:
                result = _context3.sent;

                if (result.code === 200) {
                  _this6.handlingFeeForm = result.data;
                }

              case 4:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3);
      }))();
    },
    onProductName: function onProductName(value) {
      if (value == undefined) {
        this.$message({
          type: 'error',
          message: '请输入产品名称'
        });
      }
    },
    onOutTag: function onOutTag(value) {
      if (value == undefined && value == '') {
        this.$message({
          type: 'error',
          message: '请选择产品使用范围'
        });
      }
    },
    onInitPrem: function onInitPrem(value) {
      if (value == undefined) {
        this.$message({
          type: 'error',
          message: '请输入产品初始金额'
        });
      }
    },
    onRiskType: function onRiskType(value) {
      if (value == undefined && value == '') {
        this.$message({
          type: 'error',
          message: '请选择保险类型'
        });
      }
    },
    onProductType: function onProductType(value) {
      if (value == undefined && value == '') {
        this.$message({
          type: 'error',
          message: '请选择财寿险标识'
        });
      }
    },
    onLinkAddr: function onLinkAddr(value) {
      if (value == undefined) {
        this.$message({
          type: 'error',
          message: '请输入产品链接'
        });
      }
    },
    onImage: function onImage(value) {
      if (value == undefined) {
        this.$message({
          type: 'error',
          message: '请上传图片'
        });
      }
    },
    onRiskCompany: function onRiskCompany(value) {
      if (value == undefined && value == '') {
        this.$message({
          type: 'error',
          message: '请选择保险公司'
        });
      }
    },
    onHesitationPeriod: function onHesitationPeriod(value) {
      if (value == undefined) {
        this.$message({
          type: 'error',
          message: '请输入犹豫天数'
        });
      }
    },
    insProCodePeriod: function insProCodePeriod(value) {
      if (value == undefined) {
        this.$message({
          type: 'error',
          message: '请输入保险公司产品编码'
        });
      }
    },
    onLevel: function onLevel(value) {
      if (value == undefined) {
        this.$message({
          type: 'error',
          message: '请输入产品考核保费'
        });
      }
    },
    //更改公司
    changeComponeny: function changeComponeny(e) {
      var _this7 = this;

      this.upDataForm.outCompanyCode = e;
      this.componenyList.map(function (item) {
        if (item.codeValue == e) {
          _this7.upDataForm.outRiskCompany = item.codeName;
        }
      });
    },
    dataFilter: function dataFilter(id, val) {
      if (id == 'outRiskPeriod') {
        return val == 'L' ? '长险' : val == '' ? '' : '短险'; //长短险种
      }

      if (id == 'outGroupRisk') {
        return val == 'G' ? '团险' : '个险'; //个团险
      }

      if (id == 'outRiskType') {
        var name1 = '';
        this.riskType.map(function (item) {
          if (item.value == val) {
            name1 = item.name;
          }
        });
        return name1; //险种类别
      }

      if (id == 'outDiscern') {
        return val == '1' ? '外部' : '内部'; //内外部标示
      }

      if (id == 'outIsUse') {
        return val == '1' ? '已上架' : val == '0' ? '未上架' : '未上架'; //内外部标示
      } // if (id == 'isOnline') {
      // 	return val == '0' ? '线上' : val == '1' ? '线下' : '' //线上线下标志
      // }
      // if (id == 'salesScope') {
      // 	let sales = ''
      //   let s = ''
      // 	this.salesScopeList.map((item) => {
      // 		for (let i = 0; i < val.length; i++) {
      // 			if (item.value == val[i]) {
      // 				sales = sales + item.name
      //         s = s + item.name + '<br>' 
      // 			}
      // 		}
      // 	})
      //   this.sales = s
      // 	return sales //销售对象
      // }

    },
    clickSalesScope: function clickSalesScope() {
      this.$confirm(this.sales, '销售对象', {
        dangerouslyUseHTMLString: true,
        center: true
      });
    },
    getValueName: function getValueName(value, index) {
      this.upDataForm.periodEntities[index - 1].riskYearType = value;
    },
    //添加行数
    addLine: function addLine() {
      var num = this.upDataForm.periodEntities.length + 1;
      var outProductCode = this.upDataForm.outProductCode;
      var newValue = {
        index: num,
        ensureId: '',
        outProductCode: outProductCode,
        riskYearType: '',
        value: '',
        indexDesc: num
      }; //添加新的行数

      this.upDataForm.periodEntities.push(newValue);
    },
    //删除行数
    handleDelete: function handleDelete(index, row) {
      var _this8 = this;

      this.confirm('确定删除么', '提示').then(function () {
        var params = {
          id: row.ensureId
        };

        _this8.deleteEnsure(params, index);
      });
    },
    deleteEnsure: function deleteEnsure(params, index) {
      var _this9 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
        var result;
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return Object(_api_api__WEBPACK_IMPORTED_MODULE_9__["deleteEnsure"])(params);

              case 2:
                result = _context4.sent;

                if (result.code == 200) {
                  _this9.upDataForm.periodEntities.splice(index, 1);
                }

              case 4:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4);
      }))();
    },
    handleEdit: function handleEdit(index, row) {},
    CommissionEdit: function CommissionEdit(row) {
      var _this10 = this;

      this.isPolicyVisible = true;
      this.$nextTick(function () {
        _this10.$refs.PolicyAdd.init(row.outProductCode, row.outDiscern);
      });
    },
    handleCurrentChange: function handleCurrentChange(row, event, column) {},
    //新增外部产品
    handleAddOutProduct: function handleAddOutProduct() {
      this.isShow = '新增';
      this.isEdit = false;
      this.upDataForm = {};
      this.upDataForm.periodEntities = [];
      this.imageFileList = [];
      this.detailConfig.dialogVisible = true;
      this.selectrisktype();
      this.getInsuranceCompanyThree();
    },
    handleUplodSuccess: function handleUplodSuccess(response, file, fileList) {
      //图片上传成功
      this.upDataForm.outImageUrl = response.data.accessPath;
    },
    onSubmit: function onSubmit() {
      //点击查询
      this.dataInit();
    },
    //点击发布/下架
    handleisShow: function handleisShow(row) {
      if (row.outDiscern == 0) {
        this.$message({
          type: 'warning',
          message: '内部产品暂不支持修改'
        });
      } else {
        var params = {
          id: row.outProductCode
        };
        this.getOutCompanyByCode(params);
      }
    },
    //编辑/新增点击了保存
    outProductUpdataOrAdd: function outProductUpdataOrAdd() {
      var _this11 = this;

      this.detailConfig.Button = [{
        name: '取消',
        methods: 'permCancel'
      }, {
        name: '提交',
        methods: 'outProductUpdataOrAdd',
        type: 'primary'
      }]; //校验销售对象多选
      // if (this.checkList.length > 0 && this.checkList != undefined) {
      // 	let str = ''
      // 	this.checkList.map((item) => {
      // 		str = str + item + ','
      // 	})
      // 	this.upDataForm.salesScope = str.substr(0, str.length - 1)
      // } else {
      // 	this.$message({
      // 		type: 'error',
      // 		message: '请选择销售对象'
      // 	})
      // 	return false
      // }
      //校验 线上线下标志
      // if (this.upDataForm.isOnline == '' || this.upDataForm.isOnline == undefined) {
      // 	this.$message({
      // 		type: 'error',
      // 		message: '请选择线上线下标志'
      // 	})
      // 	return false
      // }

      var data = JSON.parse(JSON.stringify(this.upDataForm));

      if (this.upDataForm.outProductName == '' || this.upDataForm.outProductName == undefined) {
        this.$message({
          type: 'error',
          message: '请填写产品名称'
        });
        return false;
      }

      if (this.upDataForm.outTag == '' || this.upDataForm.outTag == undefined) {
        this.$message({
          type: 'error',
          message: '请选择使用范围'
        });
        return false;
      }

      if (this.upDataForm.outInitPrem == '' || this.upDataForm.outInitPrem == undefined) {
        this.$message({
          type: 'error',
          message: '请填写产品初始金额'
        });
        return false;
      }

      if (this.upDataForm.outRiskCompany == '' || this.upDataForm.outRiskCompany == undefined) {
        this.$message({
          type: 'error',
          message: '请选择保险公司'
        });
        return false;
      }

      if (this.upDataForm.outRiskType == '' || this.upDataForm.outRiskType == undefined) {
        this.$message({
          type: 'error',
          message: '请选择保险类型'
        });
        return false;
      }

      if (this.upDataForm.outProductType == '' || this.upDataForm.outProductType == undefined) {
        this.$message({
          type: 'error',
          message: '请选择财产寿险类型'
        });
        return false;
      }

      if ((this.upDataForm.outHesitationPeriod == '' || this.upDataForm.outHesitationPeriod == undefined) && this.upDataForm.outHesitationPeriod != 0) {
        this.$message({
          type: 'error',
          message: '请填写犹豫天数'
        });
        return false;
      }

      if (this.upDataForm.insProCode == '' || this.upDataForm.insProCode == undefined) {
        this.$message({
          type: 'error',
          message: '请填写保险公司产品编码'
        });
        return false;
      }

      if (this.upDataForm.mainProduct == '' || this.upDataForm.mainProduct == undefined) {
        this.$message({
          type: 'error',
          message: '请选择主附险'
        });
        return false;
      }

      if (this.upDataForm.outImageUrl == '' || this.upDataForm.outImageUrl == undefined) {
        this.$message({
          type: 'error',
          message: '请上传图片'
        });
        return false;
      }

      if (this.upDataForm.outLinkAddr == '' || this.upDataForm.outLinkAddr == undefined) {
        this.$message({
          type: 'error',
          message: '请填写产品链接'
        });
        return false;
      } else {
        if (!this.isEdit) {
          //处理新增保存
          this.confirm('确定提交的外部产品数据', '提示').then(function () {
            _this11.saveOutProduct(data);
          });
        } else {
          //处理修改
          this.confirm('确定提交的外部产品数据', '提示').then(function () {
            _this11.saveOutProduct(data);
          });
        }
      }
    },
    handlPageChange: function handlPageChange(cur, size) {
      //处理页码改变
      var params = JSON.parse(JSON.stringify(this.searchForm));
      params.pageNo = cur;
      params.pageSize = this.tbOptionData.pageSize;
      this.tbOptionData.currentPage = cur;
      this.getOutProList(params);
    },
    //列表数据更新
    dataInit: function dataInit() {
      var params = JSON.parse(JSON.stringify(this.searchForm));
      params.pageNo = this.tbOptionData.currentPage = 1;
      params.pageSize = this.tbOptionData.pageSize;
      this.getOutProList(params);
    },
    isHandleLook: function isHandleLook(row) {
      if (row.outIsUse === 1) {
        this.detailConfig.Button = [{
          name: '取消',
          methods: 'permCancel'
        }];
      } else {
        this.detailConfig.Button = [{
          name: '编辑',
          methods: 'startEdit'
        }, {
          name: '取消',
          methods: 'permCancel'
        }, {
          name: '提交',
          methods: 'outProductUpdataOrAdd',
          type: 'primary'
        }];
      }

      this.detailConfig.dialogVisible = true;
      this.isShow = '预览'; // 234

      this.isEdit = true;
      this.imageFileList = [];
      var params = {
        id: row.outProductCode
      };
      this.getOutDetail(params);
      this.getInsuranceCompanyThree();
      this.selectrisktype(); // if (row.outDiscern == 0) {
      //     this.$message({
      //         type: "warning",
      //         message: "内部产品暂不支持修改",
      //     });
      // } else if (row.outIsUse == 1) {
      //     this.$message({
      //         type: "warning",
      //         message: "上架产品不能编辑，待下架后编辑",
      //     });
      // } else {
      //
      // }
    },
    startEdit: function startEdit() {
      this.isShow = '编辑';
    },
    isHandleEdit: function isHandleEdit(row) {
      this.isShow = '编辑';

      if (row.outDiscern == 0) {
        this.$message({
          type: 'warning',
          message: '内部产品暂不支持修改'
        });
      } else if (row.outIsUse == 1) {
        this.$message({
          type: 'warning',
          message: '上架产品不能编辑，待下架后编辑'
        });
      } else {
        // 234
        this.isEdit = true;
        this.detailConfig.dialogVisible = true;
        this.imageFileList = [];
        var params = {
          id: row.outProductCode
        };
        this.getOutDetail(params);
        this.getInsuranceCompanyThree();
        this.selectrisktype();
      }
    },
    //取消编辑
    permCancel: function permCancel() {
      this.detailConfig.Button = [{
        name: '取消',
        methods: 'permCancel'
      }, {
        name: '提交',
        methods: 'outProductUpdataOrAdd',
        type: 'primary'
      }];
      this.detailConfig.dialogVisible = false;
    },
    getOutCompanyByCode: function getOutCompanyByCode(params) {
      var _this12 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
        var result;
        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.next = 2;
                return Object(_api_api__WEBPACK_IMPORTED_MODULE_9__["getOutCompanyByCode"])(params);

              case 2:
                result = _context5.sent;

                if (result.data === 1) {
                  _this12.confirm('确定发布或下架么', '提示').then(function () {
                    _this12.updateOutUse(params);
                  });
                } else {
                  _this12.$message({
                    type: 'warning',
                    message: '请先完善产品佣金政策，再进行上架'
                  });
                }

              case 4:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5);
      }))();
    },
    updateOutUse: function updateOutUse(params) {
      var _this13 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
        var result;
        return regeneratorRuntime.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                _context6.next = 2;
                return Object(_api_api__WEBPACK_IMPORTED_MODULE_9__["updateOutUse"])(params);

              case 2:
                result = _context6.sent;

                if (result.code == 200) {
                  _this13.$message({
                    type: 'success',
                    message: '操作成功'
                  });

                  _this13.dataInit();
                }

              case 4:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6);
      }))();
    },
    getOutProList: function getOutProList(params) {
      var _this14 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
        var result;
        return regeneratorRuntime.wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                _context7.next = 2;
                return Object(_api_api__WEBPACK_IMPORTED_MODULE_9__["getOutProList"])(params);

              case 2:
                result = _context7.sent;
                _this14.tbOptionData.currentTableData = result.data.records;
                _this14.tbOptionData.total = result.data.total;

              case 5:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee7);
      }))();
    },
    //获取公司信息列表
    getInsuranceCompanyThree: function getInsuranceCompanyThree() {
      var _this15 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee8() {
        var result;
        return regeneratorRuntime.wrap(function _callee8$(_context8) {
          while (1) {
            switch (_context8.prev = _context8.next) {
              case 0:
                _context8.next = 2;
                return Object(_api_api__WEBPACK_IMPORTED_MODULE_9__["getInsuranceCompanyThree"])();

              case 2:
                result = _context8.sent;

                if (result.code == 200) {
                  _this15.componenyList = result.data;
                }

              case 4:
              case "end":
                return _context8.stop();
            }
          }
        }, _callee8);
      }))();
    },
    //获取类型信息列表
    selectrisktype: function selectrisktype() {
      var _this16 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee9() {
        var result;
        return regeneratorRuntime.wrap(function _callee9$(_context9) {
          while (1) {
            switch (_context9.prev = _context9.next) {
              case 0:
                _this16.RiskTypeOptions = [];
                _context9.next = 3;
                return Object(_api_api__WEBPACK_IMPORTED_MODULE_9__["selectrisktype"])();

              case 3:
                result = _context9.sent;

                if (result.code == 200) {
                  result.data.forEach(function (index) {
                    _this16.RiskTypeOptions.push({
                      value: index.codeValue,
                      label: index.codeName
                    });
                  });
                }

              case 5:
              case "end":
                return _context9.stop();
            }
          }
        }, _callee9);
      }))();
    },
    //列表详细编辑保存
    getOutDetail: function getOutDetail(params) {
      var _this17 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee10() {
        var result, saleScope;
        return regeneratorRuntime.wrap(function _callee10$(_context10) {
          while (1) {
            switch (_context10.prev = _context10.next) {
              case 0:
                _this17.imageFileList = [];
                _context10.next = 3;
                return Object(_api_api__WEBPACK_IMPORTED_MODULE_9__["getOutDetail"])(params);

              case 3:
                result = _context10.sent;

                if (result.code == 200) {
                  //获取销售对象
                  saleScope = result.data.salesScope.split(','); //逗号分割 转成数组

                  result.data.salesScope = saleScope;
                  delete result.data.salesScope;
                  _this17.upDataForm = JSON.parse(JSON.stringify(result.data)); //获取选中的数据

                  _this17.checkList = _this17.upDataForm.salesScope;

                  if (result.data.outImageUrl) {
                    _this17.imageFileList.push({
                      url: result.data.outImageUrl
                    });
                  }
                }

              case 5:
              case "end":
                return _context10.stop();
            }
          }
        }, _callee10);
      }))();
    },
    saveOutProduct: function saveOutProduct(data) {
      var _this18 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee11() {
        var result;
        return regeneratorRuntime.wrap(function _callee11$(_context11) {
          while (1) {
            switch (_context11.prev = _context11.next) {
              case 0:
                _context11.next = 2;
                return Object(_api_api__WEBPACK_IMPORTED_MODULE_9__["saveOutProduct"])(data);

              case 2:
                result = _context11.sent;

                if (result.code == 200) {
                  _this18.$message({
                    type: 'success',
                    message: '保存成功'
                  });

                  _this18.detailConfig.dialogVisible = false;

                  _this18.dataInit();
                } else {
                  _this18.$message({
                    type: 'error',
                    message: result.msg
                  });
                }

              case 4:
              case "end":
                return _context11.stop();
            }
          }
        }, _callee11);
      }))();
    }
  },
  mounted: function mounted() {
    this.dataInit();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"b9734f90-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/product-manage/outproductList.vue?vue&type=template&id=ad849efe&scoped=true&":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"b9734f90-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/product-manage/outproductList.vue?vue&type=template&id=ad849efe&scoped=true& ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "container selfCon" },
    [
      _c("h3", [_vm._v("产品列表")]),
      _c("div", { staticClass: "search-grid-top" }, [
        _c("div", { staticStyle: { "grid-area": "a" } }, [
          _c(
            "div",
            { staticClass: "item-right" },
            [
              _c(
                "el-button",
                {
                  attrs: { plain: "", type: "primary" },
                  on: { click: _vm.handleAddOutProduct }
                },
                [_vm._v(" 新增外部产品 ")]
              )
            ],
            1
          )
        ]),
        _c("div", { staticStyle: { "grid-area": "b" } }, [
          _c("span", [_vm._v("产品名称:")]),
          _c(
            "div",
            { staticClass: "item-right" },
            [
              _c("el-input", {
                attrs: { placeholder: "请输入内容", clearable: "" },
                model: {
                  value: _vm.searchForm.outProductName,
                  callback: function($$v) {
                    _vm.$set(_vm.searchForm, "outProductName", $$v)
                  },
                  expression: "searchForm.outProductName"
                }
              })
            ],
            1
          )
        ]),
        _c("div", { staticStyle: { "grid-area": "c" } }, [
          _c("span", [_vm._v("险种类别:")]),
          _c(
            "div",
            { staticClass: "item-right" },
            [
              _c(
                "el-select",
                {
                  attrs: {
                    clearable: "",
                    filterable: "",
                    placeholder: "请选择"
                  },
                  model: {
                    value: _vm.searchForm.outRiskType,
                    callback: function($$v) {
                      _vm.$set(_vm.searchForm, "outRiskType", $$v)
                    },
                    expression: "searchForm.outRiskType"
                  }
                },
                _vm._l(_vm.riskType, function(item) {
                  return _c("el-option", {
                    key: item.value,
                    attrs: { label: item.name, value: item.value }
                  })
                }),
                1
              )
            ],
            1
          )
        ]),
        _c("div", { staticStyle: { "grid-area": "d" } }, [
          _c("span", [_vm._v("状态:")]),
          _c(
            "div",
            { staticClass: "item-right" },
            [
              _c(
                "el-select",
                {
                  attrs: {
                    clearable: "",
                    filterable: "",
                    placeholder: "请选择"
                  },
                  model: {
                    value: _vm.searchForm.status,
                    callback: function($$v) {
                      _vm.$set(_vm.searchForm, "status", $$v)
                    },
                    expression: "searchForm.status"
                  }
                },
                _vm._l(_vm.stateOptions, function(item) {
                  return _c("el-option", {
                    key: item.value,
                    attrs: { label: item.label, value: item.value }
                  })
                }),
                1
              )
            ],
            1
          )
        ]),
        _c(
          "div",
          { staticStyle: { "grid-area": "e" } },
          [
            _c(
              "el-button",
              {
                attrs: { icon: "el-icon-search", type: "primary" },
                on: { click: _vm.onSubmit }
              },
              [_vm._v(" 查询 ")]
            )
          ],
          1
        )
      ]),
      _c("stable", {
        ref: "result",
        attrs: { config: _vm.tbConfig, optionData: _vm.tbOptionData }
      }),
      _c(
        "el-dialog",
        {
          attrs: {
            config: _vm.detailConfig,
            visible: _vm.productAssessmentPopup,
            height: "60%",
            title: "产品考核等级保费",
            width: "40%"
          },
          on: {
            "update:visible": function($event) {
              _vm.productAssessmentPopup = $event
            }
          }
        },
        [
          _c(
            "div",
            { staticClass: "center-dialog" },
            [
              _c(
                "el-row",
                [
                  _c(
                    "el-col",
                    { attrs: { span: 20 } },
                    [
                      _c("span", { staticClass: "strang" }, [_vm._v("A+:")]),
                      _c("el-input", {
                        attrs: {
                          disabled: _vm.isShow === "预览",
                          onkeyup: "value=value.replace(/[^\\d.]/g,'')",
                          placeholder: "只能输入数字"
                        },
                        on: {
                          blur: function($event) {
                            return _vm.onLevel(_vm.productAssess.level5)
                          }
                        },
                        model: {
                          value: _vm.productAssess.level5,
                          callback: function($$v) {
                            _vm.$set(_vm.productAssess, "level5", $$v)
                          },
                          expression: "productAssess.level5"
                        }
                      })
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                [
                  _c(
                    "el-col",
                    { attrs: { span: 20 } },
                    [
                      _c("span", { staticClass: "strang" }, [_vm._v("A")]),
                      _c("el-input", {
                        attrs: {
                          disabled: _vm.isShow === "预览",
                          onkeyup: "value=value.replace(/[^\\d.]/g,'')",
                          placeholder: "只能输入数字"
                        },
                        on: {
                          blur: function($event) {
                            return _vm.onLevel(_vm.productAssess.level4)
                          }
                        },
                        model: {
                          value: _vm.productAssess.level4,
                          callback: function($$v) {
                            _vm.$set(_vm.productAssess, "level4", $$v)
                          },
                          expression: "productAssess.level4"
                        }
                      })
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                [
                  _c(
                    "el-col",
                    { attrs: { span: 20 } },
                    [
                      _c("span", { staticClass: "strang" }, [_vm._v("B+:")]),
                      _c("el-input", {
                        attrs: {
                          disabled: _vm.isShow === "预览",
                          onkeyup: "value=value.replace(/[^\\d.]/g,'')",
                          placeholder: "只能输入数字"
                        },
                        on: {
                          blur: function($event) {
                            return _vm.onLevel(_vm.productAssess.level3)
                          }
                        },
                        model: {
                          value: _vm.productAssess.level3,
                          callback: function($$v) {
                            _vm.$set(_vm.productAssess, "level3", $$v)
                          },
                          expression: "productAssess.level3"
                        }
                      })
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                [
                  _c(
                    "el-col",
                    { attrs: { span: 20 } },
                    [
                      _c("span", { staticClass: "strang" }, [_vm._v("B:")]),
                      _c("el-input", {
                        attrs: {
                          disabled: _vm.isShow === "预览",
                          onkeyup: "value=value.replace(/[^\\d.]/g,'')",
                          placeholder: "只能输入数字"
                        },
                        on: {
                          blur: function($event) {
                            return _vm.onLevel(_vm.productAssess.level2)
                          }
                        },
                        model: {
                          value: _vm.productAssess.level2,
                          callback: function($$v) {
                            _vm.$set(_vm.productAssess, "level2", $$v)
                          },
                          expression: "productAssess.level2"
                        }
                      })
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                [
                  _c(
                    "el-col",
                    { attrs: { span: 20 } },
                    [
                      _c("span", { staticClass: "strang" }, [_vm._v("B-:")]),
                      _c("el-input", {
                        attrs: {
                          disabled: _vm.isShow === "预览",
                          onkeyup: "value=value.replace(/[^\\d.]/g,'')",
                          placeholder: "只能输入数字",
                          value: ""
                        },
                        on: {
                          blur: function($event) {
                            return _vm.onLevel(_vm.productAssess.level1)
                          }
                        },
                        model: {
                          value: _vm.productAssess.level1,
                          callback: function($$v) {
                            _vm.$set(_vm.productAssess, "level1", $$v)
                          },
                          expression: "productAssess.level1"
                        }
                      })
                    ],
                    1
                  )
                ],
                1
              )
            ],
            1
          ),
          _c(
            "el-button",
            {
              on: {
                click: function($event) {
                  _vm.productAssessmentPopup = false
                }
              }
            },
            [_vm._v("取 消")]
          ),
          _c(
            "el-button",
            {
              attrs: { type: "primary" },
              on: { click: _vm.productAssessmentSub }
            },
            [_vm._v("提交")]
          )
        ],
        1
      ),
      _c(
        "el-dialog",
        {
          attrs: {
            visible: _vm.servicecChargeDialogVisible,
            title: "手续费率配置",
            width: "60%"
          },
          on: {
            "update:visible": function($event) {
              _vm.servicecChargeDialogVisible = $event
            }
          }
        },
        [
          _c(
            "div",
            { staticClass: "center-dialog" },
            [
              _c(
                "el-row",
                [
                  _c("el-col", { attrs: { span: 5 } }, [
                    _c("div", { staticClass: "servicecCharge-left" }, [
                      _vm._v("产品名称:")
                    ])
                  ]),
                  _c("el-col", { attrs: { span: 19 } }, [
                    _c("div", { staticClass: "servicecCharge-right" }, [
                      _vm._v(
                        " " +
                          _vm._s(_vm.rateDetail.riskRateAuditInfo.riskName) +
                          " "
                      )
                    ])
                  ])
                ],
                1
              ),
              _c(
                "el-row",
                [
                  _c("el-col", { attrs: { span: 5 } }, [
                    _c("div", { staticClass: "servicecCharge-left" }, [
                      _vm._v("审核状态:")
                    ])
                  ]),
                  _c("el-col", { attrs: { span: 19 } }, [
                    _c("div", { staticClass: "servicecCharge-right" }, [
                      _vm._v(
                        " " +
                          _vm._s(_vm.rateDetail.riskRateAuditInfo.auditStatus) +
                          " "
                      )
                    ])
                  ])
                ],
                1
              ),
              _c(
                "el-row",
                [
                  _c("el-col", { attrs: { span: 5 } }, [
                    _c("div", { staticClass: "servicecCharge-left" }, [
                      _vm._v("手续费率:")
                    ])
                  ]),
                  _c("el-col", { attrs: { span: 19 } }, [
                    _c(
                      "div",
                      { staticClass: "import" },
                      [
                        _c("label", [_vm._v("费率导入")]),
                        _c(
                          "el-upload",
                          {
                            ref: "upload",
                            staticClass: "upload-demo",
                            attrs: {
                              action: _vm.importRiskRateUrl,
                              data: {
                                riskCode: this.detailInfo.outProductCode
                              },
                              "file-list": _vm.fileList,
                              headers: _vm.headers,
                              "on-success": _vm.uploadSuccess,
                              "with-credentials": true,
                              accept: ".xlsx,.xls",
                              multiple: "",
                              name: "uploadFile"
                            }
                          },
                          [
                            _c(
                              "el-button",
                              { attrs: { size: "mini", type: "primary" } },
                              [_vm._v("导入")]
                            )
                          ],
                          1
                        )
                      ],
                      1
                    ),
                    _c(
                      "div",
                      { staticClass: "export" },
                      [
                        _c("label", { attrs: { for: "" } }, [
                          _vm._v("模版下载")
                        ]),
                        _c(
                          "el-button",
                          {
                            staticStyle: { "margin-left": "20px" },
                            attrs: { size: "mini", type: "primary" },
                            on: { click: _vm.downLoad }
                          },
                          [_vm._v("下载")]
                        )
                      ],
                      1
                    )
                  ])
                ],
                1
              ),
              _c(
                "el-row",
                [
                  _c("el-col", { attrs: { span: 5 } }),
                  _c("el-col", { attrs: { span: 16 } }, [
                    _c(
                      "table",
                      {
                        staticClass: "tab-cla",
                        attrs: { border: "1", cellspacing: "1" }
                      },
                      [
                        _c("tr", { attrs: { bgcolor: "white" } }, [
                          _c("th", { attrs: { rowspan: "2" } }, [
                            _vm._v("保障期间")
                          ]),
                          _c("th", { attrs: { rowspan: "2" } }, [
                            _vm._v("缴费年限")
                          ]),
                          _c("th", { attrs: { colspan: "5" } }, [
                            _vm._v("保单年度")
                          ])
                        ]),
                        _c("tr", { attrs: { bgcolor: "white" } }, [
                          _c("th", [_vm._v("第一年")]),
                          _c("th", [_vm._v("第二年")]),
                          _c("th", [_vm._v("第三年")]),
                          _c("th", [_vm._v("第四年")]),
                          _c("th", [_vm._v("第五年")])
                        ]),
                        _vm._l(_vm.rateDetail.hargeRateInfoList, function(
                          i,
                          index
                        ) {
                          return _c(
                            "tr",
                            {
                              directives: [
                                {
                                  name: "show",
                                  rawName: "v-show",
                                  value:
                                    _vm.rateDetail.hargeRateInfoList.length > 0,
                                  expression:
                                    "rateDetail.hargeRateInfoList.length > 0"
                                }
                              ],
                              key: index
                            },
                            [
                              _c(
                                "td",
                                {
                                  directives: [
                                    {
                                      name: "show",
                                      rawName: "v-show",
                                      value: i.period !== "",
                                      expression: "i.period !== ''"
                                    }
                                  ],
                                  attrs: { rowspan: i.periodSize }
                                },
                                [_vm._v(_vm._s(i.period))]
                              ),
                              _c("td", [_vm._v(_vm._s(i.payYear))]),
                              _c("td", [_vm._v(_vm._s(i.fristYearRate))]),
                              _c("td", [_vm._v(_vm._s(i.secondYearRate))]),
                              _c("td", [_vm._v(_vm._s(i.thirdYearRate))]),
                              _c("td", [_vm._v(_vm._s(i.fourthYearRate))]),
                              _c("td", [_vm._v(_vm._s(i.fifthYearRate))])
                            ]
                          )
                        }),
                        _vm.rateDetail.hargeRateInfoList.length <= 0
                          ? _c("tr", { attrs: { bgcolor: "white" } }, [
                              _c("td", { attrs: { colspan: "20" } }, [
                                _vm._v("暂无数据")
                              ])
                            ])
                          : _vm._e()
                      ],
                      2
                    )
                  ])
                ],
                1
              )
            ],
            1
          )
        ]
      ),
      _c(
        "el-dialog",
        {
          attrs: { visible: _vm.isVisible, title: "保障期间" },
          on: {
            "update:visible": function($event) {
              _vm.isVisible = $event
            }
          }
        },
        [
          _c(
            "div",
            {},
            [
              _c(
                "el-button",
                {
                  staticStyle: {
                    "background-color": "#20a0ff",
                    color: "#f0f7ff"
                  },
                  on: { click: _vm.addLine }
                },
                [_vm._v("添加行数")]
              ),
              _c(
                "el-table",
                {
                  staticStyle: { width: "100%" },
                  attrs: { data: _vm.upDataForm.periodEntities }
                },
                [
                  _c("el-table-column", {
                    attrs: { label: "保障类型", prop: "Method" },
                    scopedSlots: _vm._u([
                      {
                        key: "default",
                        fn: function(scope) {
                          return [
                            _c(
                              "el-select",
                              {
                                attrs: { placeholder: "保障类型" },
                                on: {
                                  change: function($event) {
                                    return _vm.getValueName(
                                      scope.row.riskYearType,
                                      scope.row.index
                                    )
                                  }
                                },
                                model: {
                                  value: scope.row.riskYearType,
                                  callback: function($$v) {
                                    _vm.$set(scope.row, "riskYearType", $$v)
                                  },
                                  expression: "scope.row.riskYearType"
                                }
                              },
                              [
                                _c("el-option", {
                                  attrs: { label: "年龄", value: "01" }
                                }),
                                _c("el-option", {
                                  attrs: { label: "年期", value: "02" }
                                })
                              ],
                              1
                            )
                          ]
                        }
                      }
                    ])
                  }),
                  _c("el-table-column", {
                    attrs: { label: "值", prop: "thirdYear" },
                    scopedSlots: _vm._u([
                      {
                        key: "default",
                        fn: function(scope) {
                          return [
                            scope.row.riskYearType == "01"
                              ? _c(
                                  "el-select",
                                  {
                                    attrs: { placeholder: "值" },
                                    model: {
                                      value: scope.row.value,
                                      callback: function($$v) {
                                        _vm.$set(scope.row, "value", $$v)
                                      },
                                      expression: "scope.row.value"
                                    }
                                  },
                                  _vm._l(_vm.getValueDataAge, function(item) {
                                    return _c("el-option", {
                                      key: item.value,
                                      attrs: {
                                        label: item.label,
                                        value: item.value
                                      }
                                    })
                                  }),
                                  1
                                )
                              : _vm._e(),
                            scope.row.riskYearType == "02"
                              ? _c(
                                  "el-select",
                                  {
                                    attrs: { placeholder: "值" },
                                    model: {
                                      value: scope.row.value,
                                      callback: function($$v) {
                                        _vm.$set(scope.row, "value", $$v)
                                      },
                                      expression: "scope.row.value"
                                    }
                                  },
                                  _vm._l(_vm.getValueDataYear, function(item) {
                                    return _c("el-option", {
                                      key: item.value,
                                      attrs: {
                                        label: item.label,
                                        value: item.value
                                      }
                                    })
                                  }),
                                  1
                                )
                              : _vm._e()
                          ]
                        }
                      }
                    ])
                  }),
                  _c("el-table-column", {
                    attrs: { label: "操作", prop: "bookbuytime" },
                    scopedSlots: _vm._u([
                      {
                        key: "default",
                        fn: function(scope) {
                          return [
                            !scope.row.editing
                              ? _c(
                                  "el-button",
                                  {
                                    attrs: {
                                      icon: "el-icon-delete",
                                      size: "mini",
                                      type: "danger"
                                    },
                                    on: {
                                      click: function($event) {
                                        return _vm.handleDelete(
                                          scope.$index,
                                          scope.row
                                        )
                                      }
                                    }
                                  },
                                  [_vm._v(" 删除 ")]
                                )
                              : _vm._e()
                          ]
                        }
                      }
                    ])
                  })
                ],
                1
              )
            ],
            1
          ),
          _c(
            "div",
            {
              staticClass: "dialog-footer",
              attrs: { slot: "footer" },
              slot: "footer"
            },
            [
              _c(
                "el-button",
                {
                  attrs: { type: "primary" },
                  on: {
                    click: function($event) {
                      _vm.isVisible = false
                    }
                  }
                },
                [_vm._v("确 定")]
              )
            ],
            1
          )
        ]
      ),
      _vm.isPolicyVisible
        ? _c("PolicyAdd", {
            ref: "PolicyAdd",
            on: { refreshDataList: _vm.dataInit }
          })
        : _vm._e(),
      _c(
        "sdialog",
        { staticClass: "dialog-edit", attrs: { config: _vm.detailConfig } },
        [
          _c(
            "div",
            { staticClass: "detaiConfig-wrap" },
            [
              _c(
                "el-row",
                { staticClass: "el-row" },
                [
                  _c("el-col", { attrs: { span: 6 } }, [
                    _c("span", { staticClass: "star" }, [_vm._v("*")]),
                    _c("span", { staticClass: "strang" }, [_vm._v("产品名称:")])
                  ]),
                  _c(
                    "el-col",
                    { attrs: { span: 18 } },
                    [
                      _c("el-input", {
                        attrs: { disabled: _vm.isShow === "预览" },
                        on: {
                          blur: function($event) {
                            return _vm.onProductName(
                              _vm.upDataForm.outProductName
                            )
                          }
                        },
                        model: {
                          value: _vm.upDataForm.outProductName,
                          callback: function($$v) {
                            _vm.$set(_vm.upDataForm, "outProductName", $$v)
                          },
                          expression: "upDataForm.outProductName"
                        }
                      })
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                { staticClass: "el-row" },
                [
                  _c("el-col", { attrs: { span: 6 } }, [
                    _c("span", { staticClass: "strang" }, [_vm._v("产品描述:")])
                  ]),
                  _c(
                    "el-col",
                    { attrs: { span: 18 } },
                    [
                      _c("el-input", {
                        attrs: { disabled: _vm.isShow === "预览" },
                        model: {
                          value: _vm.upDataForm.outProductDes,
                          callback: function($$v) {
                            _vm.$set(_vm.upDataForm, "outProductDes", $$v)
                          },
                          expression: "upDataForm.outProductDes"
                        }
                      })
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                { staticClass: "el-row" },
                [
                  _c("el-col", { attrs: { span: 6 } }, [
                    _c("span", { staticClass: "star" }, [_vm._v("*")]),
                    _c("span", { staticClass: "strang" }, [_vm._v("使用范围:")])
                  ]),
                  _c(
                    "el-col",
                    { attrs: { span: 18 } },
                    [
                      _c(
                        "el-select",
                        {
                          attrs: { disabled: _vm.isShow === "预览" },
                          on: {
                            blur: function($event) {
                              return _vm.onOutTag(_vm.upDataForm.outTag)
                            }
                          },
                          model: {
                            value: _vm.upDataForm.outTag,
                            callback: function($$v) {
                              _vm.$set(_vm.upDataForm, "outTag", $$v)
                            },
                            expression: "upDataForm.outTag"
                          }
                        },
                        [
                          _c("el-option", {
                            attrs: { label: "公众号ToA和APP", value: "A" }
                          }),
                          _c("el-option", {
                            attrs: { label: "全部", value: "O" }
                          }),
                          _c("el-option", {
                            attrs: { label: "公众号ToC", value: "C" }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                { staticClass: "el-row" },
                [
                  _c("el-col", { attrs: { span: 6 } }, [
                    _c("span", { staticClass: "star" }, [_vm._v("*")]),
                    _c("span", { staticClass: "strang" }, [
                      _vm._v("产品初始价格:")
                    ])
                  ]),
                  _c(
                    "el-col",
                    { attrs: { span: 18 } },
                    [
                      _c("el-input-number", {
                        attrs: { disabled: _vm.isShow === "预览" },
                        on: {
                          blur: function($event) {
                            return _vm.onInitPrem(_vm.upDataForm.outInitPrem)
                          }
                        },
                        model: {
                          value: _vm.upDataForm.outInitPrem,
                          callback: function($$v) {
                            _vm.$set(_vm.upDataForm, "outInitPrem", $$v)
                          },
                          expression: "upDataForm.outInitPrem"
                        }
                      })
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                { staticClass: "el-row" },
                [
                  _c("el-col", { attrs: { span: 6 } }, [
                    _c("span", { staticClass: "star" }, [_vm._v("*")]),
                    _c(
                      "span",
                      {
                        staticClass: "strang",
                        on: {
                          blur: function($event) {
                            return _vm.onRiskCompany(
                              _vm.upDataForm.outRiskCompany
                            )
                          }
                        }
                      },
                      [_vm._v("供应商信息:")]
                    )
                  ]),
                  _c(
                    "el-col",
                    { attrs: { span: 18 } },
                    [
                      _c(
                        "el-select",
                        {
                          attrs: {
                            disabled: _vm.isShow === "预览",
                            placeholder: "请选择"
                          },
                          on: {
                            blur: function($event) {
                              return _vm.onOutTag()
                            },
                            change: _vm.changeComponeny
                          },
                          model: {
                            value: _vm.upDataForm.outRiskCompany,
                            callback: function($$v) {
                              _vm.$set(_vm.upDataForm, "outRiskCompany", $$v)
                            },
                            expression: "upDataForm.outRiskCompany"
                          }
                        },
                        _vm._l(_vm.componenyList, function(item, index) {
                          return _c("el-option", {
                            key: index,
                            attrs: {
                              label: item.codeName,
                              value: item.codeValue
                            }
                          })
                        }),
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                { staticClass: "el-row" },
                [
                  _c("el-col", { attrs: { span: 6 } }, [
                    _c("span", { staticClass: "star" }, [_vm._v("*")]),
                    _c("span", { staticClass: "strang" }, [_vm._v("保险类型:")])
                  ]),
                  _c(
                    "el-col",
                    { attrs: { span: 18 } },
                    [
                      _c(
                        "el-select",
                        {
                          attrs: {
                            disabled: _vm.isShow === "预览",
                            placeholder: "请选择"
                          },
                          on: {
                            blur: function($event) {
                              return _vm.onRiskType(_vm.upDataForm.outRiskType)
                            }
                          },
                          model: {
                            value: _vm.upDataForm.outRiskType,
                            callback: function($$v) {
                              _vm.$set(_vm.upDataForm, "outRiskType", $$v)
                            },
                            expression: "upDataForm.outRiskType"
                          }
                        },
                        _vm._l(_vm.RiskTypeOptions, function(item) {
                          return _c("el-option", {
                            key: item.value,
                            attrs: { label: item.label, value: item.value }
                          })
                        }),
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                { staticClass: "el-row" },
                [
                  _c("el-col", { attrs: { span: 6 } }, [
                    _c("span", { staticClass: "star" }, [_vm._v("*")]),
                    _c("span", { staticClass: "strang" }, [_vm._v("保险公司:")])
                  ]),
                  _c(
                    "el-col",
                    { attrs: { span: 18 } },
                    [
                      _c(
                        "el-select",
                        {
                          attrs: {
                            disabled: _vm.isShow === "预览",
                            placeholder: "请选择"
                          },
                          on: { change: _vm.changeSupplier },
                          model: {
                            value: _vm.upDataForm.supplierCode,
                            callback: function($$v) {
                              _vm.$set(_vm.upDataForm, "supplierCode", $$v)
                            },
                            expression: "upDataForm.supplierCode"
                          }
                        },
                        _vm._l(_vm.codeName, function(item) {
                          return _c("el-option", {
                            key: item.value,
                            attrs: { label: item.label, value: item.value }
                          })
                        }),
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                { staticClass: "el-row" },
                [
                  _c("el-col", { attrs: { span: 6 } }, [
                    _c("span", { staticClass: "strang" }, [
                      _vm._v("投保最小年龄:")
                    ])
                  ]),
                  _c(
                    "el-col",
                    { attrs: { span: 18 } },
                    [
                      _c("el-input", {
                        attrs: {
                          disabled: _vm.isShow === "预览",
                          oninput: "value=value.replace(/[^0-9.]/g,'')"
                        },
                        model: {
                          value: _vm.upDataForm.outAppntMinimumAge,
                          callback: function($$v) {
                            _vm.$set(_vm.upDataForm, "outAppntMinimumAge", $$v)
                          },
                          expression: "upDataForm.outAppntMinimumAge"
                        }
                      })
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                { staticClass: "el-row" },
                [
                  _c("el-col", { attrs: { span: 6 } }, [
                    _c("span", { staticClass: "strang" }, [
                      _vm._v("投保最大年龄:")
                    ])
                  ]),
                  _c(
                    "el-col",
                    { attrs: { span: 18 } },
                    [
                      _c("el-input", {
                        attrs: {
                          disabled: _vm.isShow === "预览",
                          oninput: "value=value.replace(/[^0-9.]/g,'')"
                        },
                        model: {
                          value: _vm.upDataForm.outAppntMaxAge,
                          callback: function($$v) {
                            _vm.$set(_vm.upDataForm, "outAppntMaxAge", $$v)
                          },
                          expression: "upDataForm.outAppntMaxAge"
                        }
                      })
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                { staticClass: "el-row" },
                [
                  _c("el-col", { attrs: { span: 6 } }, [
                    _c("span", { staticClass: "star" }, [_vm._v("*")]),
                    _c("span", { staticClass: "strang" }, [
                      _vm._v("犹豫期天数:")
                    ])
                  ]),
                  _c(
                    "el-col",
                    { attrs: { span: 18 } },
                    [
                      _c("el-input", {
                        attrs: {
                          disabled: _vm.isShow === "预览",
                          oninput: "value=value.replace(/[^0-9.]/g,'')"
                        },
                        on: {
                          blur: function($event) {
                            return _vm.onHesitationPeriod(
                              _vm.upDataForm.outHesitationPeriod
                            )
                          }
                        },
                        model: {
                          value: _vm.upDataForm.outHesitationPeriod,
                          callback: function($$v) {
                            _vm.$set(
                              _vm.upDataForm,
                              "outHesitationPeriod",
                              _vm._n($$v)
                            )
                          },
                          expression: "upDataForm.outHesitationPeriod"
                        }
                      })
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                { staticClass: "el-row" },
                [
                  _c("el-col", { attrs: { span: 6 } }, [
                    _c("span", { staticClass: "star" }, [_vm._v("*")]),
                    _c("span", { staticClass: "strang" }, [
                      _vm._v("保险公司产品编码:")
                    ])
                  ]),
                  _c(
                    "el-col",
                    { attrs: { span: 18 } },
                    [
                      _c("el-input", {
                        attrs: {
                          disabled: _vm.isShow === "预览",
                          placeholder: "请输入保险公司产品编码"
                        },
                        on: {
                          blur: function($event) {
                            return _vm.insProCodePeriod(
                              _vm.upDataForm.insProCode
                            )
                          }
                        },
                        model: {
                          value: _vm.upDataForm.insProCode,
                          callback: function($$v) {
                            _vm.$set(_vm.upDataForm, "insProCode", $$v)
                          },
                          expression: "upDataForm.insProCode"
                        }
                      })
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                { staticClass: "el-row" },
                [
                  _c("el-col", { attrs: { span: 6 } }, [
                    _c("span", { staticClass: "strang" }, [
                      _vm._v("产品所属标签:")
                    ])
                  ]),
                  _c(
                    "el-col",
                    { attrs: { span: 18 } },
                    [
                      _c("el-input", {
                        attrs: { disabled: _vm.isShow === "预览" },
                        model: {
                          value: _vm.upDataForm.outItemDesc,
                          callback: function($$v) {
                            _vm.$set(_vm.upDataForm, "outItemDesc", $$v)
                          },
                          expression: "upDataForm.outItemDesc"
                        }
                      })
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                { staticClass: "el-row" },
                [
                  _c("el-col", { attrs: { span: 6 } }, [
                    _c("span", { staticClass: "star" }, [_vm._v("*")]),
                    _c("span", { staticClass: "strang" }, [
                      _vm._v("财寿险标志:")
                    ])
                  ]),
                  _c(
                    "el-col",
                    { attrs: { span: 18 } },
                    [
                      _c(
                        "el-select",
                        {
                          attrs: {
                            disabled: _vm.isShow === "预览",
                            placeholder: "请选择"
                          },
                          on: {
                            blur: function($event) {
                              return _vm.onProductType(
                                _vm.upDataForm.outProductType
                              )
                            }
                          },
                          model: {
                            value: _vm.upDataForm.outProductType,
                            callback: function($$v) {
                              _vm.$set(_vm.upDataForm, "outProductType", $$v)
                            },
                            expression: "upDataForm.outProductType"
                          }
                        },
                        _vm._l(_vm.ProductTypeOptions, function(item) {
                          return _c("el-option", {
                            key: item.value,
                            attrs: { label: item.label, value: item.value }
                          })
                        }),
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                { staticClass: "el-row" },
                [
                  _c("el-col", { attrs: { span: 6 } }, [
                    _c("span", { staticClass: "strang" }, [_vm._v("是否热门:")])
                  ]),
                  _c(
                    "el-col",
                    { attrs: { span: 12 } },
                    [
                      _c(
                        "el-radio-group",
                        {
                          attrs: { disabled: _vm.isShow === "预览" },
                          model: {
                            value: _vm.upDataForm.isHot,
                            callback: function($$v) {
                              _vm.$set(_vm.upDataForm, "isHot", $$v)
                            },
                            expression: "upDataForm.isHot"
                          }
                        },
                        [
                          _c("el-radio", { attrs: { label: "N" } }, [
                            _vm._v("否")
                          ]),
                          _c("el-radio", { attrs: { label: "Y" } }, [
                            _vm._v("是")
                          ])
                        ],
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                { staticClass: "el-row" },
                [
                  _c("el-col", { attrs: { span: 6 } }, [
                    _c("span", { staticClass: "star" }, [_vm._v("*")]),
                    _c("span", { staticClass: "strang" }, [
                      _vm._v("是否主附险:")
                    ])
                  ]),
                  _c(
                    "el-col",
                    { attrs: { span: 18 } },
                    [
                      _c(
                        "el-select",
                        {
                          attrs: {
                            disabled: _vm.isShow === "预览",
                            clearable: "",
                            placeholder: "请选择",
                            disabled: _vm.isGrounding
                          },
                          model: {
                            value: _vm.upDataForm.mainProduct,
                            callback: function($$v) {
                              _vm.$set(_vm.upDataForm, "mainProduct", $$v)
                            },
                            expression: "upDataForm.mainProduct"
                          }
                        },
                        _vm._l(_vm.isMainRisk, function(item) {
                          return _c("el-option", {
                            key: item.value,
                            attrs: { label: item.label, value: item.value }
                          })
                        }),
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                { staticClass: "el-row" },
                [
                  _c("el-col", { attrs: { span: 6 } }, [
                    _c("span", { staticClass: "strang" }, [
                      _vm._v("长短险标识:")
                    ])
                  ]),
                  _c(
                    "el-col",
                    { attrs: { span: 18 } },
                    [
                      _c(
                        "el-select",
                        {
                          attrs: {
                            disabled: _vm.isShow === "预览",
                            placeholder: "请选择"
                          },
                          model: {
                            value: _vm.upDataForm.outRiskPeriod,
                            callback: function($$v) {
                              _vm.$set(_vm.upDataForm, "outRiskPeriod", $$v)
                            },
                            expression: "upDataForm.outRiskPeriod"
                          }
                        },
                        _vm._l(_vm.riskPeriodOptions, function(item) {
                          return _c("el-option", {
                            key: item.value,
                            attrs: { label: item.label, value: item.value }
                          })
                        }),
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                { staticClass: "el-row" },
                [
                  _c("el-col", { attrs: { span: 6 } }, [
                    _c("span", { staticClass: "strang" }, [
                      _vm._v("团个险标识:")
                    ])
                  ]),
                  _c(
                    "el-col",
                    { attrs: { span: 18 } },
                    [
                      _c(
                        "el-select",
                        {
                          attrs: {
                            disabled: _vm.isShow === "预览",
                            placeholder: "请选择"
                          },
                          model: {
                            value: _vm.upDataForm.outGroupRisk,
                            callback: function($$v) {
                              _vm.$set(_vm.upDataForm, "outGroupRisk", $$v)
                            },
                            expression: "upDataForm.outGroupRisk"
                          }
                        },
                        _vm._l(_vm.groupRiskOptions, function(item) {
                          return _c("el-option", {
                            key: item.value,
                            attrs: { label: item.label, value: item.value }
                          })
                        }),
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                { staticClass: "el-row" },
                [
                  _c("el-col", { attrs: { span: 6 } }, [
                    _c("span", { staticClass: "strang" }, [_vm._v("保障期间:")])
                  ]),
                  _c(
                    "el-col",
                    { attrs: { span: 18 } },
                    [
                      _c(
                        "el-button",
                        {
                          attrs: { disabled: _vm.isShow === "预览" },
                          on: {
                            click: function($event) {
                              _vm.isVisible = true
                            }
                          }
                        },
                        [_vm._v("点击编辑保障期间")]
                      )
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                { staticClass: "el-row" },
                [
                  _c("el-col", { attrs: { span: 6 } }, [
                    _c("span", { staticClass: "star" }, [_vm._v("*")]),
                    _c("span", { staticClass: "strang" }, [_vm._v("产品图:")])
                  ]),
                  _c(
                    "el-col",
                    { attrs: { span: 18 } },
                    [
                      _c(
                        "el-upload",
                        {
                          ref: "uploadModel",
                          attrs: {
                            action: _vm.uploadUrl,
                            data: _vm.picUploadData,
                            "file-list": _vm.imageFileList,
                            limit: 1,
                            multiple: false,
                            "on-success": _vm.handleUplodSuccess,
                            "list-type": "picture-card",
                            name: "file",
                            "with-credentials": ""
                          },
                          on: {
                            blur: function($event) {
                              return _vm.onImage(_vm.upDataForm.outImageUrl)
                            }
                          }
                        },
                        [_c("i", { staticClass: "el-icon-plus" })]
                      )
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                { staticClass: "el-row" },
                [
                  _c("el-col", { attrs: { span: 6 } }, [
                    _c("span", { staticClass: "star" }, [_vm._v("*")]),
                    _c("span", { staticClass: "strang" }, [_vm._v("产品链接:")])
                  ]),
                  _c(
                    "el-col",
                    { attrs: { span: 16 } },
                    [
                      _c("el-input", {
                        attrs: { disabled: _vm.isShow === "预览" },
                        on: {
                          blur: function($event) {
                            return _vm.onLinkAddr(_vm.upDataForm.outLinkAddr)
                          }
                        },
                        model: {
                          value: _vm.upDataForm.outLinkAddr,
                          callback: function($$v) {
                            _vm.$set(_vm.upDataForm, "outLinkAddr", $$v)
                          },
                          expression: "upDataForm.outLinkAddr"
                        }
                      })
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 2 } },
                    [
                      _c(
                        "el-popover",
                        {
                          attrs: {
                            content:
                              "1、力码产品：复制链接之后在最后补加&bizTag= 组合之后的链接，粘贴到文本框中。\n    2、渤海人寿产品：复制链接之后在最后补加&bizContent= 组合之后的链接，粘贴到文本框中。3.慧择产品：复制链接之后在最后补加&data= 组合之后的链接，粘贴到文本框中。",
                            placement: "top-start",
                            title: "提示",
                            trigger: "hover",
                            width: "200"
                          }
                        },
                        [
                          _c(
                            "el-button",
                            { attrs: { slot: "reference" }, slot: "reference" },
                            [_vm._v("?")]
                          )
                        ],
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              )
            ],
            1
          )
        ]
      ),
      _c(
        "el-dialog",
        {
          attrs: {
            visible: _vm.productDialog,
            title: "渠道公司列表",
            width: "80%"
          },
          on: {
            "update:visible": function($event) {
              _vm.productDialog = $event
            }
          }
        },
        [
          _c("Input", {
            attrs: { queryData: _vm.queryData },
            scopedSlots: _vm._u([
              {
                key: "up",
                fn: function(ref) {
                  var queryData = ref.queryData
                  return [
                    _c(
                      "el-form",
                      {
                        attrs: {
                          inline: true,
                          model: queryData,
                          "label-position": "right",
                          "label-width": "100px"
                        }
                      },
                      [
                        _c(
                          "el-form-item",
                          { attrs: { label: "渠道公司名称:" } },
                          [
                            _c("el-input", {
                              attrs: { placeholder: "请输入内容" },
                              model: {
                                value: queryData.channelCompanyName,
                                callback: function($$v) {
                                  _vm.$set(queryData, "channelCompanyName", $$v)
                                },
                                expression: "queryData.channelCompanyName"
                              }
                            })
                          ],
                          1
                        ),
                        _c(
                          "el-form-item",
                          { attrs: { label: "合作模式" } },
                          [
                            _c(
                              "el-select",
                              {
                                attrs: {
                                  clearable: "",
                                  filterable: "",
                                  placeholder: "请选择内容"
                                },
                                model: {
                                  value: queryData.model,
                                  callback: function($$v) {
                                    _vm.$set(queryData, "model", $$v)
                                  },
                                  expression: "queryData.model"
                                }
                              },
                              _vm._l(_vm.model, function(item) {
                                return _c("el-option", {
                                  key: item.value,
                                  attrs: {
                                    label: item.label,
                                    value: item.value
                                  }
                                })
                              }),
                              1
                            )
                          ],
                          1
                        ),
                        _c(
                          "el-form-item",
                          { attrs: { label: "产品状态" } },
                          [
                            _c(
                              "el-select",
                              {
                                attrs: {
                                  clearable: "",
                                  filterable: "",
                                  placeholder: "请选择内容"
                                },
                                model: {
                                  value: queryData.saleStatus,
                                  callback: function($$v) {
                                    _vm.$set(queryData, "saleStatus", $$v)
                                  },
                                  expression: "queryData.saleStatus"
                                }
                              },
                              _vm._l(_vm.saleStatus, function(item) {
                                return _c("el-option", {
                                  key: item.value,
                                  attrs: {
                                    label: item.label,
                                    value: item.value
                                  }
                                })
                              }),
                              1
                            )
                          ],
                          1
                        ),
                        _c(
                          "el-button",
                          {
                            style: { marginBottom: "10px" },
                            attrs: { type: "primary" },
                            on: { click: _vm.queryButton }
                          },
                          [_vm._v("查询")]
                        )
                      ],
                      1
                    )
                  ]
                }
              },
              {
                key: "button",
                fn: function() {
                  return undefined
                },
                proxy: true
              }
            ])
          }),
          _c("Table", {
            attrs: { isCheckbox: true, tableData: _vm.tableData },
            on: { handleSelectionChange: _vm.selectChange }
          }),
          _c("Pagination", {
            attrs: { pageOption: _vm.pageOption },
            on: { currentPageChange: _vm.currentPageChange }
          }),
          _c(
            "span",
            {
              staticClass: "dialog-footer",
              attrs: { slot: "footer" },
              slot: "footer"
            },
            [
              _c(
                "el-button",
                {
                  attrs: { type: "success" },
                  on: {
                    click: function($event) {
                      return _vm.installBuy("yes")
                    }
                  }
                },
                [_vm._v("设为可售卖")]
              ),
              _c(
                "el-button",
                {
                  attrs: { type: "danger" },
                  on: {
                    click: function($event) {
                      return _vm.installBuy("no")
                    }
                  }
                },
                [_vm._v("设为不可售卖")]
              ),
              _c(
                "el-button",
                {
                  attrs: { type: "primary" },
                  on: {
                    click: function($event) {
                      _vm.productDialog = false
                    }
                  }
                },
                [_vm._v("确 定")]
              )
            ],
            1
          )
        ],
        1
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/core-js/internals/is-regexp.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/internals/is-regexp.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");
var classof = __webpack_require__(/*! ../internals/classof-raw */ "./node_modules/core-js/internals/classof-raw.js");
var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");

var MATCH = wellKnownSymbol('match');

// `IsRegExp` abstract operation
// https://tc39.es/ecma262/#sec-isregexp
module.exports = function (it) {
  var isRegExp;
  return isObject(it) && ((isRegExp = it[MATCH]) !== undefined ? !!isRegExp : classof(it) == 'RegExp');
};


/***/ }),

/***/ "./node_modules/core-js/modules/es.array.filter.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es.array.filter.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var $filter = __webpack_require__(/*! ../internals/array-iteration */ "./node_modules/core-js/internals/array-iteration.js").filter;
var arrayMethodHasSpeciesSupport = __webpack_require__(/*! ../internals/array-method-has-species-support */ "./node_modules/core-js/internals/array-method-has-species-support.js");

var HAS_SPECIES_SUPPORT = arrayMethodHasSpeciesSupport('filter');

// `Array.prototype.filter` method
// https://tc39.es/ecma262/#sec-array.prototype.filter
// with adding support of @@species
$({ target: 'Array', proto: true, forced: !HAS_SPECIES_SUPPORT }, {
  filter: function filter(callbackfn /* , thisArg */) {
    return $filter(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es.array.map.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/es.array.map.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var $map = __webpack_require__(/*! ../internals/array-iteration */ "./node_modules/core-js/internals/array-iteration.js").map;
var arrayMethodHasSpeciesSupport = __webpack_require__(/*! ../internals/array-method-has-species-support */ "./node_modules/core-js/internals/array-method-has-species-support.js");

var HAS_SPECIES_SUPPORT = arrayMethodHasSpeciesSupport('map');

// `Array.prototype.map` method
// https://tc39.es/ecma262/#sec-array.prototype.map
// with adding support of @@species
$({ target: 'Array', proto: true, forced: !HAS_SPECIES_SUPPORT }, {
  map: function map(callbackfn /* , thisArg */) {
    return $map(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es.string.split.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es.string.split.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var fixRegExpWellKnownSymbolLogic = __webpack_require__(/*! ../internals/fix-regexp-well-known-symbol-logic */ "./node_modules/core-js/internals/fix-regexp-well-known-symbol-logic.js");
var isRegExp = __webpack_require__(/*! ../internals/is-regexp */ "./node_modules/core-js/internals/is-regexp.js");
var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/core-js/internals/an-object.js");
var requireObjectCoercible = __webpack_require__(/*! ../internals/require-object-coercible */ "./node_modules/core-js/internals/require-object-coercible.js");
var speciesConstructor = __webpack_require__(/*! ../internals/species-constructor */ "./node_modules/core-js/internals/species-constructor.js");
var advanceStringIndex = __webpack_require__(/*! ../internals/advance-string-index */ "./node_modules/core-js/internals/advance-string-index.js");
var toLength = __webpack_require__(/*! ../internals/to-length */ "./node_modules/core-js/internals/to-length.js");
var callRegExpExec = __webpack_require__(/*! ../internals/regexp-exec-abstract */ "./node_modules/core-js/internals/regexp-exec-abstract.js");
var regexpExec = __webpack_require__(/*! ../internals/regexp-exec */ "./node_modules/core-js/internals/regexp-exec.js");
var stickyHelpers = __webpack_require__(/*! ../internals/regexp-sticky-helpers */ "./node_modules/core-js/internals/regexp-sticky-helpers.js");

var UNSUPPORTED_Y = stickyHelpers.UNSUPPORTED_Y;
var arrayPush = [].push;
var min = Math.min;
var MAX_UINT32 = 0xFFFFFFFF;

// @@split logic
fixRegExpWellKnownSymbolLogic('split', 2, function (SPLIT, nativeSplit, maybeCallNative) {
  var internalSplit;
  if (
    'abbc'.split(/(b)*/)[1] == 'c' ||
    // eslint-disable-next-line regexp/no-empty-group -- required for testing
    'test'.split(/(?:)/, -1).length != 4 ||
    'ab'.split(/(?:ab)*/).length != 2 ||
    '.'.split(/(.?)(.?)/).length != 4 ||
    // eslint-disable-next-line regexp/no-assertion-capturing-group, regexp/no-empty-group -- required for testing
    '.'.split(/()()/).length > 1 ||
    ''.split(/.?/).length
  ) {
    // based on es5-shim implementation, need to rework it
    internalSplit = function (separator, limit) {
      var string = String(requireObjectCoercible(this));
      var lim = limit === undefined ? MAX_UINT32 : limit >>> 0;
      if (lim === 0) return [];
      if (separator === undefined) return [string];
      // If `separator` is not a regex, use native split
      if (!isRegExp(separator)) {
        return nativeSplit.call(string, separator, lim);
      }
      var output = [];
      var flags = (separator.ignoreCase ? 'i' : '') +
                  (separator.multiline ? 'm' : '') +
                  (separator.unicode ? 'u' : '') +
                  (separator.sticky ? 'y' : '');
      var lastLastIndex = 0;
      // Make `global` and avoid `lastIndex` issues by working with a copy
      var separatorCopy = new RegExp(separator.source, flags + 'g');
      var match, lastIndex, lastLength;
      while (match = regexpExec.call(separatorCopy, string)) {
        lastIndex = separatorCopy.lastIndex;
        if (lastIndex > lastLastIndex) {
          output.push(string.slice(lastLastIndex, match.index));
          if (match.length > 1 && match.index < string.length) arrayPush.apply(output, match.slice(1));
          lastLength = match[0].length;
          lastLastIndex = lastIndex;
          if (output.length >= lim) break;
        }
        if (separatorCopy.lastIndex === match.index) separatorCopy.lastIndex++; // Avoid an infinite loop
      }
      if (lastLastIndex === string.length) {
        if (lastLength || !separatorCopy.test('')) output.push('');
      } else output.push(string.slice(lastLastIndex));
      return output.length > lim ? output.slice(0, lim) : output;
    };
  // Chakra, V8
  } else if ('0'.split(undefined, 0).length) {
    internalSplit = function (separator, limit) {
      return separator === undefined && limit === 0 ? [] : nativeSplit.call(this, separator, limit);
    };
  } else internalSplit = nativeSplit;

  return [
    // `String.prototype.split` method
    // https://tc39.es/ecma262/#sec-string.prototype.split
    function split(separator, limit) {
      var O = requireObjectCoercible(this);
      var splitter = separator == undefined ? undefined : separator[SPLIT];
      return splitter !== undefined
        ? splitter.call(separator, O, limit)
        : internalSplit.call(String(O), separator, limit);
    },
    // `RegExp.prototype[@@split]` method
    // https://tc39.es/ecma262/#sec-regexp.prototype-@@split
    //
    // NOTE: This cannot be properly polyfilled in engines that don't support
    // the 'y' flag.
    function (regexp, limit) {
      var res = maybeCallNative(internalSplit, regexp, this, limit, internalSplit !== nativeSplit);
      if (res.done) return res.value;

      var rx = anObject(regexp);
      var S = String(this);
      var C = speciesConstructor(rx, RegExp);

      var unicodeMatching = rx.unicode;
      var flags = (rx.ignoreCase ? 'i' : '') +
                  (rx.multiline ? 'm' : '') +
                  (rx.unicode ? 'u' : '') +
                  (UNSUPPORTED_Y ? 'g' : 'y');

      // ^(? + rx + ) is needed, in combination with some S slicing, to
      // simulate the 'y' flag.
      var splitter = new C(UNSUPPORTED_Y ? '^(?:' + rx.source + ')' : rx, flags);
      var lim = limit === undefined ? MAX_UINT32 : limit >>> 0;
      if (lim === 0) return [];
      if (S.length === 0) return callRegExpExec(splitter, S) === null ? [S] : [];
      var p = 0;
      var q = 0;
      var A = [];
      while (q < S.length) {
        splitter.lastIndex = UNSUPPORTED_Y ? 0 : q;
        var z = callRegExpExec(splitter, UNSUPPORTED_Y ? S.slice(q) : S);
        var e;
        if (
          z === null ||
          (e = min(toLength(splitter.lastIndex + (UNSUPPORTED_Y ? q : 0)), S.length)) === p
        ) {
          q = advanceStringIndex(S, q, unicodeMatching);
        } else {
          A.push(S.slice(p, q));
          if (A.length === lim) return A;
          for (var i = 1; i <= z.length - 1; i++) {
            A.push(z[i]);
            if (A.length === lim) return A;
          }
          q = p = e;
        }
      }
      A.push(S.slice(p));
      return A;
    }
  ];
}, UNSUPPORTED_Y);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/product-manage/outproductList.vue?vue&type=style&index=0&id=ad849efe&lang=scss&scoped=true&":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--8-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--8-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--8-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/product-manage/outproductList.vue?vue&type=style&index=0&id=ad849efe&lang=scss&scoped=true& ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".container[data-v-ad849efe] {\n  padding: 15px;\n}\n.selfCon .search-grid-top[data-v-ad849efe] {\n  display: grid;\n  grid-template-columns: 130px repeat(4, 300px);\n  grid-template-rows: repeat(2, 50px);\n  -moz-column-gap: 20px;\n       column-gap: 20px;\n  grid-template-areas: \"a b c d e \" \"f g h i j \";\n  align-items: center;\n  border-bottom: 40px solid #f4f4f5;\n  border-top: 40px solid #f4f4f5;\n}\n.selfCon .search-grid-top > div[data-v-ad849efe] {\n  height: 50px;\n  line-height: 50px;\n  display: flex;\n  justify-content: flex-start;\n  flex-flow: row nowrap;\n}\n.selfCon .search-grid-top > div span[data-v-ad849efe] {\n  display: inline-block;\n  width: 110px;\n}\n.selfCon .search-grid-top > div .item-right[data-v-ad849efe] {\n  display: inline-block;\n  width: 190px;\n}\n.selfCon[data-v-ad849efe]  .dialog-edit .el-dialog .el-dialog__header .el-dialog__headerbtn {\n  display: none;\n}\n.selfCon .detaiConfig-wrap[data-v-ad849efe] {\n  font-size: 16px;\n}\n.selfCon .detaiConfig-wrap .star[data-v-ad849efe] {\n  color: #f00c0c;\n}\n.selfCon .detaiConfig-wrap .strang[data-v-ad849efe] {\n  line-height: 40px;\n  font-weight: 600;\n}\n.selfCon .detaiConfig-wrap .strang1[data-v-ad849efe] {\n  line-height: 40px;\n  font-weight: 600;\n  margin-right: 50px;\n}\n.selfCon .el-row[data-v-ad849efe] {\n  margin: 10px 0;\n}\n.selfCon .servicecCharge-left[data-v-ad849efe] {\n  font-size: 14px;\n  font-weight: 900;\n}\n.selfCon .import[data-v-ad849efe] {\n  margin-top: 20px;\n  display: flex;\n}\n.selfCon .import label[data-v-ad849efe] {\n  display: inline-block;\n  width: 120px;\n}\n.selfCon .import .upload-demo[data-v-ad849efe] {\n  display: inline-block;\n}\n.selfCon .import .el-upload-list[data-v-ad849efe] {\n  display: none;\n}\n.selfCon .import[data-v-ad849efe]  .el-upload-list__item {\n  display: none !important;\n}\n.selfCon .export[data-v-ad849efe] {\n  margin-top: 10px;\n  display: flex;\n}\n.selfCon .export label[data-v-ad849efe] {\n  display: inline-block;\n  width: 120px;\n}\n.selfCon .export > button[data-v-ad849efe] {\n  margin-left: 0 !important;\n}\n.selfCon .el-col-19[data-v-ad849efe] {\n  float: right;\n}\n.selfCon .servicecCharge-left[data-v-ad849efe] {\n  margin-left: 20px;\n}\n.selfCon .delete-button[data-v-ad849efe] {\n  margin-left: 10px;\n}\n.selfCon[data-v-ad849efe]  .el-upload-list__item-status-label {\n  display: none;\n}\n.tab-cla[data-v-ad849efe] {\n  margin-left: 30%;\n  border-collapse: collapse;\n  text-align: center;\n  width: 110%;\n  height: 300px;\n}\n.tab-cla .innerTable td[data-v-ad849efe] {\n  height: 40px;\n}\n.tab-cla1[data-v-ad849efe] {\n  border-collapse: collapse;\n  text-align: center;\n  width: 130%;\n  height: 300px;\n}\n[data-v-ad849efe] .commands-style {\n  display: inline-block;\n  flex-wrap: wrap !important;\n}\n[data-v-ad849efe] .commands-style .links {\n  display: inline-block;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/product-manage/outproductList.vue?vue&type=style&index=0&id=ad849efe&lang=scss&scoped=true&":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--8-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--8-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--8-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--8-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/product-manage/outproductList.vue?vue&type=style&index=0&id=ad849efe&lang=scss&scoped=true& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--8-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--8-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--8-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../node_modules/vue-loader/lib??vue-loader-options!./outproductList.vue?vue&type=style&index=0&id=ad849efe&lang=scss&scoped=true& */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/product-manage/outproductList.vue?vue&type=style&index=0&id=ad849efe&lang=scss&scoped=true&");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("5434a016", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/api/outproductListApi.js":
/*!**************************************!*\
  !*** ./src/api/outproductListApi.js ***!
  \**************************************/
/*! exports provided: getSelectCompanyList, setOperation, updateProductAssessment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSelectCompanyList", function() { return getSelectCompanyList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setOperation", function() { return setOperation; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateProductAssessment", function() { return updateProductAssessment; });
/* harmony import */ var _config_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/config/service */ "./src/config/service.js");
/* harmony import */ var _config_env__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/config/env */ "./src/config/env.js");
 //axios


function getSelectCompanyList(params) {
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_0__["Service"])({
    url: _config_env__WEBPACK_IMPORTED_MODULE_1__["baseUrl"] + "/admin/outfmrisk/sale/selectCompany",
    method: "get",
    params: params
  });
}
function setOperation(data) {
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_0__["Service"])({
    url: _config_env__WEBPACK_IMPORTED_MODULE_1__["baseUrl"] + "/admin/outfmrisk/sale/operation",
    method: "post",
    data: data
  });
} //更新产品考核保费

function updateProductAssessment(params) {
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_0__["Service"])({
    url: _config_env__WEBPACK_IMPORTED_MODULE_1__["baseUrl"] + "/admin/outfmrisk/updateRiskLevel",
    method: "post",
    params: params
  });
}

/***/ }),

/***/ "./src/common/MixinUtils.js":
/*!**********************************!*\
  !*** ./src/common/MixinUtils.js ***!
  \**********************************/
/*! exports provided: tableMixin */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tableMixin", function() { return tableMixin; });
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! regenerator-runtime/runtime.js */ "./node_modules/regenerator-runtime/runtime.js");
/* harmony import */ var regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.entries.js */ "./node_modules/core-js/modules/es.object.entries.js");
/* harmony import */ var core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var components_common_Table__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/common/Table */ "./src/components/common/Table.vue");
/* harmony import */ var components_common_Pagination__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/common/Pagination */ "./src/components/common/Pagination.vue");
/* harmony import */ var components_common_Input__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/common/Input */ "./src/components/common/Input.vue");









var defaultDate = [{
  data: ['createDateBegin', 'createDateEnd']
}];
var tableMixin = {
  components: {
    Table: components_common_Table__WEBPACK_IMPORTED_MODULE_6__["default"],
    Pagination: components_common_Pagination__WEBPACK_IMPORTED_MODULE_7__["default"],
    Input: components_common_Input__WEBPACK_IMPORTED_MODULE_8__["default"]
  },
  data: function data() {
    return {
      // todo 查询的所有数据
      queryAllData: {},
      // todo 表格搜索数据
      queryData: {},
      cloneData: {},
      // todo 页码改变
      pageOption: {
        currentPage: 1,
        total: 0,
        pageSize: 10
      },
      // todo 时间选择
      pickerOptions: {
        shortcuts: [{
          text: '昨天',
          onClick: function onClick(picker) {
            var end = new Date();
            var start = new Date();
            start.setDate(start.getDate() - 1);
            end.setDate(end.getDate() - 1);
            picker.$emit('pick', [start, end]);
          }
        }, {
          text: '本周',
          onClick: function onClick(picker) {
            var end = new Date();
            var start = new Date();
            var currentDay = new Date().getDay() === 0 ? 7 : new Date().getDay();
            start.setDate(start.getDate() - currentDay + 1);
            end.setDate(end.getDate());
            picker.$emit('pick', [start, end]);
          }
        }, {
          text: '本月',
          onClick: function onClick(picker) {
            var end = new Date();
            var start = new Date();
            start.setDate(1);
            end.setMonth(end.getMonth() + 1);
            end.setDate(0);
            picker.$emit('pick', [start, end]);
          }
        }, {
          text: '上个月',
          onClick: function onClick(picker) {
            var end = new Date();
            var start = new Date();
            start.setMonth(start.getMonth() - 1);
            start.setDate(1);
            end.setDate(0);
            picker.$emit('pick', [start, end]);
          }
        }, {
          text: '最近三个月',
          onClick: function onClick(picker) {
            var end = new Date();
            var start = new Date();
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
            picker.$emit('pick', [start, end]);
          }
        }, {
          text: '本年',
          onClick: function onClick(picker) {
            var end = new Date();
            var start = new Date();
            start.setDate(1);
            start.setMonth(0);
            picker.$emit('pick', [start, end]);
          }
        }]
      }
    };
  },
  methods: {
    //todo 通用列表数据初始化
    getSelectList: function getSelectList(api, list, value, label, params) {
      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
        var _yield$api, data;

        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return api(params);

              case 2:
                _yield$api = _context.sent;
                data = _yield$api.data;

                if (list.length === 0) {
                  data.forEach(function (i) {
                    var obj = {};
                    obj.value = i[value];
                    obj.label = i[label];
                    list.push(obj);
                  });
                }

              case 5:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    // todo 通用查询
    getList: function getList(api, query, page, tableData, currentPage) {
      var _arguments = arguments,
          _this = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
        var dateArr, cb, data, result;
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                dateArr = _arguments.length > 5 && _arguments[5] !== undefined ? _arguments[5] : defaultDate;
                cb = _arguments.length > 6 ? _arguments[6] : undefined;
                data = JSON.parse(JSON.stringify(query)); // 处理页数

                data.pageNum = currentPage !== undefined ? page.currentPage = currentPage : page.currentPage = 1;
                data.pageSize = page.pageSize; // 处理时间

                dateArr.forEach(function (date) {
                  for (var _i = 0, _Object$entries = Object.entries(date); _i < _Object$entries.length; _i++) {
                    var _Object$entries$_i = Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__["default"])(_Object$entries[_i], 2),
                        key = _Object$entries$_i[0],
                        value = _Object$entries$_i[1];

                    if (data[key] !== null && data[key] !== undefined) {
                      data[value[0]] = data[key][0];
                      data[value[1]] = data[key][1];
                      delete data[key];
                    }
                  }
                }); // 请求结果

                _context2.next = 8;
                return api(data);

              case 8:
                result = _context2.sent;

                if (result !== null && result.code === 200 && result.data !== '') {
                  tableData.resultData = cb ? everyData(result.data.records, cb) : result.data.records;
                  page.total = result.data.total;
                  _this.queryAllData = result;
                } else if (result.data === '') {
                  tableData.resultData = [];
                  page.total = 0;
                }

                _this.cloneData = data;

              case 11:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    // todo 通用校验
    check: function check(message, key, value) {
      if (value === undefined && (key === '' || key === null || key === undefined)) {
        this.$message({
          type: 'error',
          message: message
        });
        throw new TypeError('填写的内容为空');
      } else if (value && key === value) {
        this.$message({
          type: 'error',
          message: message
        });
        throw new TypeError('填写的内容错误');
      }
    },
    // todo 点击查询按钮
    queryButton: function queryButton(e, apiNum) {
      this.requestDeploy();
    },
    // todo 页码改变
    currentPageChange: function currentPageChange(current) {
      this.requestDeploy(current);
    }
  }
}; // todo 过滤函数

function everyData(data, cb) {
  return data.map(function (item) {
    var arr = Object.entries(item);

    for (var _i2 = 0, _arr = arr; _i2 < _arr.length; _i2++) {
      var i = _arr[_i2];

      if (cb(i)) {
        item[cb(i)[0]] = cb(i)[1];
      }
    }

    return item;
  });
}

/***/ }),

/***/ "./src/common/dictionarieList/outproductList.js":
/*!******************************************************!*\
  !*** ./src/common/dictionarieList/outproductList.js ***!
  \******************************************************/
/*! exports provided: model, saleStatus */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "model", function() { return model; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "saleStatus", function() { return saleStatus; });
var model = [{
  value: "0",
  label: "大B模式"
}, {
  value: "1",
  label: "小B模式"
}];
var saleStatus = [{
  value: "0",
  label: "不可售卖"
}, {
  value: "1",
  label: "可售卖"
}];

/***/ }),

/***/ "./src/common/tableDate/outproductList.js":
/*!************************************************!*\
  !*** ./src/common/tableDate/outproductList.js ***!
  \************************************************/
/*! exports provided: table */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "table", function() { return table; });
var table = [// 表格展示属性:列名、长度、颜色、是否需要点击事件、是否需要操作列、操作列名称
["channelCompanyName", "渠道公司名称", "", "", false, false], ["channelCompanyCode", "渠道公司编码", "", "", false, false], ["modelName", "合作模式", "", "", false, false], ["saleStatus", "产品状态", "", "", false, false]];

/***/ }),

/***/ "./src/views/product-manage/outproductList.vue":
/*!*****************************************************!*\
  !*** ./src/views/product-manage/outproductList.vue ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _outproductList_vue_vue_type_template_id_ad849efe_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./outproductList.vue?vue&type=template&id=ad849efe&scoped=true& */ "./src/views/product-manage/outproductList.vue?vue&type=template&id=ad849efe&scoped=true&");
/* harmony import */ var _outproductList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./outproductList.vue?vue&type=script&lang=js& */ "./src/views/product-manage/outproductList.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _outproductList_vue_vue_type_style_index_0_id_ad849efe_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./outproductList.vue?vue&type=style&index=0&id=ad849efe&lang=scss&scoped=true& */ "./src/views/product-manage/outproductList.vue?vue&type=style&index=0&id=ad849efe&lang=scss&scoped=true&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _outproductList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _outproductList_vue_vue_type_template_id_ad849efe_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _outproductList_vue_vue_type_template_id_ad849efe_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "ad849efe",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/product-manage/outproductList.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/product-manage/outproductList.vue?vue&type=script&lang=js&":
/*!******************************************************************************!*\
  !*** ./src/views/product-manage/outproductList.vue?vue&type=script&lang=js& ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_12_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_outproductList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--12-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../node_modules/vue-loader/lib??vue-loader-options!./outproductList.vue?vue&type=script&lang=js& */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/product-manage/outproductList.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_12_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_outproductList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/product-manage/outproductList.vue?vue&type=style&index=0&id=ad849efe&lang=scss&scoped=true&":
/*!***************************************************************************************************************!*\
  !*** ./src/views/product-manage/outproductList.vue?vue&type=style&index=0&id=ad849efe&lang=scss&scoped=true& ***!
  \***************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_8_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_8_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_outproductList_vue_vue_type_style_index_0_id_ad849efe_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--8-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--8-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--8-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--8-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../node_modules/vue-loader/lib??vue-loader-options!./outproductList.vue?vue&type=style&index=0&id=ad849efe&lang=scss&scoped=true& */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/product-manage/outproductList.vue?vue&type=style&index=0&id=ad849efe&lang=scss&scoped=true&");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_8_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_8_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_outproductList_vue_vue_type_style_index_0_id_ad849efe_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_8_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_8_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_outproductList_vue_vue_type_style_index_0_id_ad849efe_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_8_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_8_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_outproductList_vue_vue_type_style_index_0_id_ad849efe_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_8_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_8_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_outproductList_vue_vue_type_style_index_0_id_ad849efe_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/product-manage/outproductList.vue?vue&type=template&id=ad849efe&scoped=true&":
/*!************************************************************************************************!*\
  !*** ./src/views/product-manage/outproductList.vue?vue&type=template&id=ad849efe&scoped=true& ***!
  \************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_outproductList_vue_vue_type_template_id_ad849efe_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"b9734f90-vue-loader-template"}!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../node_modules/vue-loader/lib??vue-loader-options!./outproductList.vue?vue&type=template&id=ad849efe&scoped=true& */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"b9734f90-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/product-manage/outproductList.vue?vue&type=template&id=ad849efe&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_outproductList_vue_vue_type_template_id_ad849efe_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_outproductList_vue_vue_type_template_id_ad849efe_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=22.js.map