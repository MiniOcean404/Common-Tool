(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[30],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/channelcomponeny.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--12-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/mga-manage/channelcomponeny.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! regenerator-runtime/runtime.js */ "./node_modules/regenerator-runtime/runtime.js");
/* harmony import */ var regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _config_env__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @/config/env */ "./src/config/env.js");
/* harmony import */ var _api_api__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @/api/api */ "./src/api/api.js");
/* harmony import */ var _api_mgaApi__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @/api/mgaApi */ "./src/api/mgaApi.js");
/* harmony import */ var _api_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @/api/common */ "./src/api/common.js");
/* harmony import */ var _assets_staticFilter__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/assets/staticFilter */ "./src/assets/staticFilter.js");
/* harmony import */ var _common_dictionary__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @/common/dictionary */ "./src/common/dictionary.js");
/* harmony import */ var wangeditor__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! wangeditor */ "./node_modules/wangeditor/dist/wangEditor.js");
/* harmony import */ var wangeditor__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(wangeditor__WEBPACK_IMPORTED_MODULE_15__);









//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

 //导入请求

 //导入请求

 //导入请求

 //静态数据过滤器



/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      E: wangeditor__WEBPACK_IMPORTED_MODULE_15___default.a,
      editor: {},
      productCode: '',
      searchRowData: {},
      //渠道数据
      componeyModelList: _common_dictionary__WEBPACK_IMPORTED_MODULE_14__["default"].componeyModel,
      //公司合作模式
      riskType: _common_dictionary__WEBPACK_IMPORTED_MODULE_14__["default"].riskType,
      rateLevenType: _common_dictionary__WEBPACK_IMPORTED_MODULE_14__["default"].rateLeven,
      rateSwitchType: _common_dictionary__WEBPACK_IMPORTED_MODULE_14__["default"].rateSwitch,
      picUploadData: {
        midAddr: _config_env__WEBPACK_IMPORTED_MODULE_9__["uploadPicPath"].uploadfile
      },
      //上传图片的地址
      fileList: [],
      headers: {
        mimeType: 'multipart/form-data'
      },
      uploadReceiptUrl: _api_api__WEBPACK_IMPORTED_MODULE_10__["uploadReceiptUrl"],
      uploadUrl: _api_api__WEBPACK_IMPORTED_MODULE_10__["uploadUrl"],
      //文件上传路径
      id: '',
      //设置角色时用户的id
      isEdit: false,
      isInitialLevel: false,
      //费率等标准级弹窗
      rateGradeForm: {
        level5: '',
        //A+费率等级
        level4: '',
        //A费率等级
        level3: '',
        //B+费率等级
        level2: '',
        //B费率等级
        level1: '',
        //B-费率等级
        channelCompanyCode: '' //产品编码

      },
      searchForm: {
        initialLevel: '',
        currentLevel: '',
        rateStatus: '',
        //费率开关
        channelCompanyCode: '' //产品编码

      },
      //搜索表单
      addForm: {
        signingDate: '' //签约时间

      },
      //新建表单
      tbConfig: {
        //表格组件配置项
        height: '530px',
        // table高度
        select: false,
        // 是否可以多选择
        isSingleSelect: false,
        //是否可以单选
        isCommands: true,
        //是否需要操作列
        commandsWidth: '200',
        //操作列宽度400
        isOrder: true,
        showPagenation: true,
        //是否需要显示分页器
        layout: 'total, prev, pager, next, jumper',
        //分页器控件
        requestCurData: true,
        // 每次分页数据是否请求后台 true:每次都请求后台
        columns: [// 后台字段属性、表头名、长度、颜色、是否过长隐藏、是否需要字典转换、点击事件的处理函数
        ['channelCompanyName', '渠道公司名称', '', '', true, false], ['channelCompanyCode', '渠道公司编码', '', '', true, false], ['areaProvinceCode', '渠道所在省', '', '', true, true], ['model', '合作模式', '', '', true, true], ['closeFlag', '停业标志', '', '', true, true], ['createDate', '创建时间', '', '', true, true], ['managerName', '渠道公司负责人', '', '', true, true], ['address', '渠道地址', '', '', true, true] // ['initialLevel', '初始等级', '', '', true, true],
        // ['currentLevel', '当前等级', '', '', true, true],
        // ['rateStatus', '费率开关状态', '', '', true, true],
        ],
        // table行按钮：color 文字 处理点击的事件函数名  elementUicon
        commands: [['#409eff', '编辑', 'handleEdit', 'el-icon-edit', 'wxApplet-banner-update'], ['#409eff', '配置产品', 'handleConfig', 'el-icon-setting', 'wxApplet-banner-update'] // ['#409eff', '调整等级标准', 'adjustGradeStandard', 'el-icon-s-tools', 'wxApplet-banner-update'],
        // ['#409eff', '费率开关', 'rateSwitchBtn', 'el-icon-setting', 'wxApplet-banner-update'],
        // [
        // 	"#ff5600",
        // 	"删除",
        // 	"handleDelete",
        // 	"el-icon-delete",
        // 	"wxApplet-banner-update",
        // ],
        ]
      },
      tbOptionData: {
        selectData: '',
        //页面单选函数
        currentTableData: [],
        //当前表格数据
        TransValtoDesc: 'dataFilter',
        //数据字典过滤函数
        pageSize: 10,
        // 每页行数
        currentPage: 1,
        // 当前页
        total: 0,
        //总数据量
        pagenationChange: 'handlPageChange' //处理分页器长度改变或页码改变的函数

      },
      dialogVisible: false,
      //是否显示弹出框
      productDialogVisible: false,
      //配置产品弹出框是否显示
      adjustGradeStandardPopup: false,
      //调整等级标准弹出框显示
      adjustGradeStandardPopupB: false,
      //调整等级标准弹出框显示
      sdialogConfig: {
        //新增用户弹窗组件配置项
        dialogVisible: false,
        width: '590px',
        title: '新增渠道',
        buttonPosition: 'flex-end',
        ismodal: true,
        modalClose: false,
        Button: [{
          name: '取消',
          methods: 'addCancel'
        }, {
          name: '确定',
          methods: 'addDetermine',
          type: 'primary'
        }],
        curPage: '1' //当前第几页

      },
      renderFunc: function renderFunc(h, option) {
        //穿梭框渲染函数
        return h('span', "\u6743\u9650".concat(option.id, " - ").concat(option.roleName, " "));
      },
      dialogFormVisible: false,
      tableData: [],
      //代理人类型区分
      receiverTypeList: [],
      dictList: [],
      //省列表
      tableDataDetail: [],
      productStateList: [{
        name: '全部',
        value: '0'
      }, {
        name: '已上线',
        value: '1'
      }, {
        name: '已下线',
        value: '2'
      }],
      radio: '',
      productCodeList: [],
      channelCompanyNameList: [],
      allSelectId: [],
      allSelect: []
    };
  },
  mounted: function mounted() {
    this.dataInit();
    this.clear();
    this.getDict();
    this.getData();
  },
  methods: {
    //todo 通用列表数据初始化通用
    getSelectList: function getSelectList(api, list, value, label, params) {
      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
        var _yield$api, data;

        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return api(params);

              case 2:
                _yield$api = _context.sent;
                data = _yield$api.data;

                if (list.length === 0) {
                  data.forEach(function (i) {
                    var obj = {};
                    obj.value = i[label];
                    list.push(obj);
                  });
                }

              case 5:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    getData: function getData() {
      this.getSelectList(_api_common__WEBPACK_IMPORTED_MODULE_12__["selectCompanyInfo"], this.channelCompanyNameList, 'codeValue', 'codeName');
    },
    //todo 选择数据
    handleSelect: function handleSelect(data) {
      var _this = this;

      this.allSelectId = [];
      this.allSelect = [];
      var selectData = this.allSelect = JSON.parse(JSON.stringify(data));
      selectData.forEach(function (value, index) {
        _this.allSelectId.push(value.id);
      });
    },
    //todo 渠道模糊查询
    querySearchAsyncCompany: function querySearchAsyncCompany(queryString, cb) {
      var restaurants = this.channelCompanyNameList;
      var results = queryString ? restaurants.filter(this.createStateFilter(queryString)) : restaurants;
      clearTimeout(this.timeout);
      this.timeout = setTimeout(function () {
        cb(results);
      }, 200 * Math.random());
    },
    createStateFilter: function createStateFilter(queryString) {
      return function (state) {
        return state.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0;
      };
    },
    //批次详情分页
    handleCurrentChange: function handleCurrentChange(val) {
      this.getChannelProductInfo(val);
    },
    //查询渠道产品
    goSearchDetail: function goSearchDetail() {
      this.getChannelProductInfo();
    },
    //获取渠道产品
    getChannelProductInfo: function getChannelProductInfo(val) {
      var _this2 = this;

      this.curPage = val;
      var curVal = '';

      if (val != '') {
        curVal = val;
      } else {
        curVal = '';
      }

      var req = {
        channelCompanyCode: this.channelCompanyCode,
        productState: this.searchRowData.productState,
        productName: this.searchRowData.productName,
        productCode: this.searchRowData.productCode,
        supplierName: this.searchRowData.supplierName,
        productType: this.searchRowData.productType,
        companyName: this.searchRowData.companyName,
        currentLevel: this.searchRowData.currentLevel,
        initialLevel: this.searchRowData.initialLevel,
        rateStatus: this.searchRowData.rateStatus,
        pageSize: '10',
        pageNum: curVal
      };
      Object(_api_mgaApi__WEBPACK_IMPORTED_MODULE_11__["getChannelProductInfoApi"])(req).then(function (res) {
        if (res.code == '200') {
          _this2.tableDataDetail = res.data.records;
          _this2.detailTotal = res.data.total;
          res.data.records.map(function (item) {
            item.checked = '';

            _this2.riskType.map(function (item1) {
              if (item1.value == item.productType) {
                item.productTypeName = item1.name;
              }
            });
          });
        }
      });
    },
    //配置产品
    handleSingleSelect: function handleSingleSelect(row) {
      var codeList = [];
      row.map(function (item) {
        codeList.push(item.productCode);
      });
      this.productCodeList = codeList;
    },
    //产品上线下限
    goChange: function goChange(type) {
      var _this3 = this;

      if (this.productCodeList.length > 0) {
        var req = {
          channelCompanyCode: this.channelCompanyCode,
          productCodeList: this.productCodeList,
          operationType: type
        };
        Object(_api_mgaApi__WEBPACK_IMPORTED_MODULE_11__["channelCompanyProductOperApi"])(req).then(function (res) {
          if (res.code == '200') {
            _this3.$message({
              type: 'success',
              message: '修改成功'
            });

            _this3.getChannelProductInfo();
          }
        });
      } else {
        this.$message({
          type: 'warning',
          message: '请至少选择一个产品'
        });
      }
    },
    //获取地区列表
    getDict: function getDict() {
      var _this4 = this;

      var req = {
        gradenum: '1',
        parentid: ''
      };
      Object(_api_mgaApi__WEBPACK_IMPORTED_MODULE_11__["bgDictApi"])(req).then(function (res) {
        if (res.code == '200') {
          _this4.dictList = res.data;
        }
      });
    },
    //配置产品
    handleConfig: function handleConfig(row) {
      this.channelCompanyCode = row.channelCompanyCode;
      console.log(row, 'row999090900');
      this.productDialogVisible = true;
      this.getChannelProductInfo(1);
    },
    // 调整等级
    adjustGradeStandard: function adjustGradeStandard(row) {
      var _this5 = this;

      //清空数据
      this.rateGradeForm = {}; //查询渠道公司当前等级,费率等级

      var rateGrade = row.currentLevel;
      this.rateGradeForm.channelCompanyCode = row.channelCompanyCode; //获取渠道公司考核保费

      Object(_api_mgaApi__WEBPACK_IMPORTED_MODULE_11__["getChannelPremData"])(this.rateGradeForm).then(function (res) {
        if (res.code == 200 && res.data != '') {
          _this5.rateGradeForm = res.data;
        }
      });

      if ('4' === rateGrade || '3' === rateGrade) {
        //大B渠道公司
        this.adjustGradeStandardPopup = true;
      } else if ('0' === rateGrade || '1' === rateGrade || '2' === rateGrade) {
        //小B渠道公司
        this.adjustGradeStandardPopupB = true;
      }
    },
    //调整费率等级  大B渠道公司 提交
    adjustGradeStandardSub: function adjustGradeStandardSub() {
      var _this6 = this;

      if (this.rateGradeForm.level5 == '' || this.rateGradeForm.level5 == undefined || this.rateGradeForm.level4 == '' || this.rateGradeForm.level4 == undefined) {
        this.$message({
          type: 'warning',
          message: '请填写保费'
        });
        return false;
      }

      var params = JSON.parse(JSON.stringify(this.rateGradeForm));
      Object(_api_mgaApi__WEBPACK_IMPORTED_MODULE_11__["updatePremGrade"])(params).then(function (result) {
        if (result.code == 200) {
          _this6.adjustGradeStandardPopup = false;
        }
      });
    },
    //调整费率等级  小B渠道公司 提交
    adjustGradeStandardBSub: function adjustGradeStandardBSub() {
      var _this7 = this;

      if (this.rateGradeForm.level3 == '' || this.rateGradeForm.level3 == undefined || this.rateGradeForm.level2 == '' || this.rateGradeForm.level2 == undefined || this.rateGradeForm.level1 == '' || this.rateGradeForm.level1 == undefined) {
        this.$message({
          type: 'warning',
          message: '请填写保费'
        });
        return false;
      }

      var params = JSON.parse(JSON.stringify(this.rateGradeForm));
      Object(_api_mgaApi__WEBPACK_IMPORTED_MODULE_11__["updatePremGrade"])(params).then(function (result) {
        if (result.code == 200) {
          _this7.adjustGradeStandardPopupB = false;
        }
      });
    },
    //费率开关
    rateSwitchBtn: function rateSwitchBtn(row) {
      if ('2' == row.currentLevel || '4' == row.currentLevel) {
        this.$message({
          type: 'warning',
          message: '当前等级已经为该合作模式下的最高等级'
        });
        return false;
      }

      var params = {
        channelCompanyCode: row.channelCompanyCode,
        rateStatus: row.rateStatus
      };
      this.updateRateSwitchData(params);
    },
    //更新费率开关
    updateRateSwitchData: function updateRateSwitchData(params) {
      var _this8 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
        var result;
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return Object(_api_mgaApi__WEBPACK_IMPORTED_MODULE_11__["updateRateSwitch"])(params);

              case 2:
                result = _context2.sent;

                if (result.code == 200) {
                  _this8.dataInit();
                }

              case 4:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    //点击了新增
    handleAdd: function handleAdd() {
      this.addForm = {};
      this.sdialogConfig.title = '新增渠道公司';
      this.isEdit = false;
      this.isInitialLevel = false;
      this.dialogVisible = true;
    },
    //点击了修改
    handleEdit: function handleEdit(row) {
      this.isEdit = true;
      this.isInitialLevel = true;
      this.sdialogConfig.title = '修改渠道公司';
      this.dialogVisible = true;
      var params = {
        channelCompanyCode: row.channelCompanyCode
      };
      this.getDetail(params);
    },
    //获取详情
    getDetail: function getDetail(params) {
      var _this9 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
        var result;
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.next = 2;
                return Object(_api_mgaApi__WEBPACK_IMPORTED_MODULE_11__["channelCompanyDetailApi"])(params);

              case 2:
                result = _context3.sent;

                if (result.code == 200) {
                  _this9.addForm = result.data;
                  console.log(result, 'result');
                }

              case 4:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3);
      }))();
    },
    //点击保存
    saveAction: function saveAction() {
      //初始等级
      if (!this.addForm.initialLevel) {
        this.$message({
          type: 'error',
          message: '请选择初始等级'
        });
        return false;
      } //当前等级


      if (!this.addForm.currentLevel) {
        this.$message({
          type: 'error',
          message: '请选择当前等级'
        });
        return false;
      }

      if (!this.isInitialLevel) {
        //新增初始等级 和 当前等级相同
        if (this.addForm.currentLevel != this.addForm.initialLevel) {
          console.log('-------' + this.addForm.currentLevel);
          console.log('=======' + this.addForm.initialLevel);
          this.$message({
            type: 'error',
            message: '新增初始等级与当前等级相同'
          });
          return false;
        }
      }

      if (!this.addForm.channelCompanyName) {
        this.$message({
          type: 'error',
          message: '请输入渠道公司名称'
        });
        return false;
      } else if (!this.addForm.model) {
        this.$message({
          type: 'error',
          message: '请选择合作模式'
        });
        return false;
      } else if (!this.addForm.areaProvinceCode) {
        this.$message({
          type: 'error',
          message: '请选择渠道公司所在地区'
        });
        return false;
      } else if (!this.addForm.createDate) {
        this.$message({
          type: 'error',
          message: '请选择渠道公司创建时间'
        });
        return false;
      } else if (!this.addForm.signingDate) {
        this.$message({
          type: 'error',
          message: '请选择渠道公司签约时间'
        });
        return false;
      } else if (!this.addForm.closeFlag) {
        this.$message({
          type: 'error',
          message: '请选择是否停业标志'
        });
        return false;
      } else {
        if (!this.isEdit) {
          //处理添加
          var _data = JSON.parse(JSON.stringify(this.addForm));

          console.log(_data, 'data');
          this.addAction(_data);
        } else {
          //处理修改
          var _data2 = JSON.parse(JSON.stringify(this.addForm));

          this.editAction(_data2);
        }
      }
    },
    //新增保存
    addAction: function addAction(params) {
      var _this10 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
        var result;
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return Object(_api_mgaApi__WEBPACK_IMPORTED_MODULE_11__["channelCompanySaveApi"])(params);

              case 2:
                result = _context4.sent;

                if (result.code == 200) {
                  _this10.dialogVisible = false;
                  _this10.searchForm = {};

                  _this10.dataInit();

                  _this10.$message({
                    type: 'success',
                    message: '操作成功'
                  });

                  _this10.tbOptionData.currentTableData = data;
                  _this10.tbOptionData.total = result.data.total;
                }

              case 4:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4);
      }))();
    },
    //编辑保存
    editAction: function editAction(params) {
      var _this11 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
        var result, _data3;

        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.next = 2;
                return Object(_api_mgaApi__WEBPACK_IMPORTED_MODULE_11__["channelCompanyModifyApi"])(params);

              case 2:
                result = _context5.sent;

                if (result.code == 200) {
                  _this11.searchForm = {};

                  _this11.dataInit();

                  _this11.dialogVisible = false;
                  _data3 = JSON.parse(JSON.stringify(result.data.records));
                  _this11.tbOptionData.currentTableData = _data3;
                  _this11.tbOptionData.total = result.data.total;
                }

              case 4:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5);
      }))();
    },
    //点击删除
    handleDelete: function handleDelete(row) {
      var _this12 = this;

      this.confirm('确定删除吗', '提示').then(function () {
        var data = {
          channelCompanyCode: row.channelCompanyCode
        };

        _this12.confiremDelete(data);
      });
    },
    //确认删除
    confiremDelete: function confiremDelete(data) {
      var _this13 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
        var result;
        return regeneratorRuntime.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                _context6.next = 2;
                return Object(_api_mgaApi__WEBPACK_IMPORTED_MODULE_11__["channelCompanyDeleteApi"])(data);

              case 2:
                result = _context6.sent;

                if (result.code == 200) {
                  _this13.dataInit();
                }

              case 4:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6);
      }))();
    },
    //table 过滤器
    dataFilter: function dataFilter(id, val) {
      function formatDate(date) {
        date = new Date(Date.parse(date.replace(/-/g, '/'))); //转换成Data();

        var y = date.getFullYear();
        var m = date.getMonth() + 1;
        m = m < 10 ? '0' + m : m;
        var d = date.getDate();
        d = d < 10 ? '0' + d : d;
        return y + '-' + m + '-' + d;
      } //id代表字段名 val代表字段值


      switch (id) {
        case 'model':
          var _data4 = '';
          this.componeyModelList.map(function (item) {
            if (item.value == val) {
              _data4 = item.name;
            }
          });
          return _data4;

        case 'closeFlag':
          return val == '1' ? '停业' : '正常';

        case 'userType':
          return _assets_staticFilter__WEBPACK_IMPORTED_MODULE_13__["userType"][val];
          break;

        case 'createDate':
          return formatDate(val);
          break;

        case 'signingDate':
          return formatDate(val);
          break;
      }

      if (id == 'initialLevel') {
        return this.rateLevelTransformation(val);
      }

      if (id == 'currentLevel') {
        return this.rateLevelTransformation(val);
      }

      if (id == 'rateStatus') {
        return val == '1' ? '关' : '开';
      }
    },
    //费率等级转换
    rateLevelTransformation: function rateLevelTransformation(val) {
      if (val == undefined || val == '') {
        return '';
      }

      var result = '';
      this.rateLevenType.map(function (item) {
        if (item.value == val) {
          result = item.name;
        }
      });
      return result;
    },
    onSubmit: function onSubmit() {
      //查询
      this.tbOptionData.currentTableData = this.tableData;
      this.tbOptionData.currentPage = 1; //每次查询重置当前页

      this.dataInit();
    },
    handlPageChange: function handlPageChange(cur, size) {
      //页码改变
      var params = JSON.parse(JSON.stringify(this.searchForm));
      params.pageNum = cur;
      this.tbOptionData.currentPage = cur; //给当前页赋值

      params.pageSize = this.tbOptionData.pageSize;
      this.getList(params);
    },
    //列表数据更新
    dataInit: function dataInit() {
      var params = JSON.parse(JSON.stringify(this.searchForm));
      params.pageNum = this.tbOptionData.currentPage; //当前页面

      params.pageSize = this.tbOptionData.pageSize; //没页显示的条数

      this.getList(params);
    },
    //查询列表
    getList: function getList(params) {
      var _this14 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
        var result, _data5;

        return regeneratorRuntime.wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                _context7.next = 2;
                return Object(_api_mgaApi__WEBPACK_IMPORTED_MODULE_11__["channelCompanyListApi"])(params);

              case 2:
                result = _context7.sent;

                if (result.code == 200) {
                  _data5 = JSON.parse(JSON.stringify(result.data.records));
                  _this14.tbOptionData.currentTableData = _data5;
                  _this14.tbOptionData.total = result.data.total;
                }

              case 4:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee7);
      }))();
    },
    //清除数据
    clear: function clear() {}
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"b9734f90-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/channelcomponeny.vue?vue&type=template&id=18c45759&":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"b9734f90-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/mga-manage/channelcomponeny.vue?vue&type=template&id=18c45759& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { attrs: { id: "container" } },
    [
      _c("div", { staticClass: "queryHeading" }, [_vm._v("查询条件")]),
      _c(
        "div",
        [
          _c(
            "el-form",
            {
              staticClass: "demo-form-inline",
              attrs: {
                inline: true,
                model: _vm.searchForm,
                "label-width": "120px"
              }
            },
            [
              _c(
                "el-form-item",
                { attrs: { label: " 渠道公司名称:" } },
                [
                  _c("el-input", {
                    attrs: { placeholder: "请输入内容", clearable: "" },
                    model: {
                      value: _vm.searchForm.channelCompanyName,
                      callback: function($$v) {
                        _vm.$set(_vm.searchForm, "channelCompanyName", $$v)
                      },
                      expression: "searchForm.channelCompanyName"
                    }
                  })
                ],
                1
              ),
              _c(
                "el-form-item",
                { attrs: { label: "渠道公司编码:" } },
                [
                  _c("el-input", {
                    attrs: { placeholder: "请输入内容", clearable: "" },
                    model: {
                      value: _vm.searchForm.channelCompanyCode,
                      callback: function($$v) {
                        _vm.$set(_vm.searchForm, "channelCompanyCode", $$v)
                      },
                      expression: "searchForm.channelCompanyCode"
                    }
                  })
                ],
                1
              ),
              _c(
                "el-form-item",
                { attrs: { label: "渠道公司所在省:" } },
                [
                  _c(
                    "el-select",
                    {
                      attrs: { placeholder: "请选择所在地区", clearable: "" },
                      model: {
                        value: _vm.searchForm.areaProvinceCode,
                        callback: function($$v) {
                          _vm.$set(_vm.searchForm, "areaProvinceCode", $$v)
                        },
                        expression: "searchForm.areaProvinceCode"
                      }
                    },
                    _vm._l(_vm.dictList, function(item) {
                      return _c("el-option", {
                        key: item.areaCode,
                        attrs: { label: item.areaName, value: item.areaCode }
                      })
                    }),
                    1
                  )
                ],
                1
              ),
              _c(
                "el-form-item",
                { attrs: { label: "合作模式:" } },
                [
                  _c(
                    "el-select",
                    {
                      attrs: { placeholder: "请选择合作模式", clearable: "" },
                      model: {
                        value: _vm.searchForm.model,
                        callback: function($$v) {
                          _vm.$set(_vm.searchForm, "model", $$v)
                        },
                        expression: "searchForm.model"
                      }
                    },
                    _vm._l(_vm.componeyModelList, function(item) {
                      return _c("el-option", {
                        key: item.value,
                        attrs: { label: item.name, value: item.value }
                      })
                    }),
                    1
                  )
                ],
                1
              ),
              _c(
                "el-form-item",
                [
                  _c(
                    "el-button",
                    {
                      attrs: {
                        type: "primary",
                        icon: "el-icon-search",
                        size: "samll"
                      },
                      on: { click: _vm.onSubmit }
                    },
                    [_vm._v("查询")]
                  )
                ],
                1
              ),
              _c(
                "el-form-item",
                [
                  _c(
                    "el-button",
                    {
                      attrs: { type: "primary", size: "samll" },
                      on: { click: _vm.handleAdd }
                    },
                    [_vm._v("新增")]
                  )
                ],
                1
              )
            ],
            1
          )
        ],
        1
      ),
      _c("div", { staticClass: "queryHeading" }, [_vm._v("查询结果")]),
      _c("stable", {
        ref: "result",
        attrs: { config: _vm.tbConfig, optionData: _vm.tbOptionData }
      }),
      _c(
        "el-dialog",
        {
          attrs: {
            title: "配置产品",
            visible: _vm.productDialogVisible,
            width: "1200px"
          },
          on: {
            "update:visible": function($event) {
              _vm.productDialogVisible = $event
            }
          }
        },
        [
          _c("div", { staticClass: "header showTab" }, [
            _c("div", { staticClass: "selGroup" }, [
              _c(
                "div",
                { staticClass: "selItem" },
                [
                  _c("label", { attrs: { for: "" } }, [_vm._v("产品名称")]),
                  _c("el-input", {
                    model: {
                      value: _vm.searchRowData.productName,
                      callback: function($$v) {
                        _vm.$set(_vm.searchRowData, "productName", $$v)
                      },
                      expression: "searchRowData.productName"
                    }
                  })
                ],
                1
              ),
              _c(
                "div",
                { staticClass: "selItem" },
                [
                  _c("label", { attrs: { for: "" } }, [_vm._v("产品状态")]),
                  _c(
                    "el-select",
                    {
                      attrs: { clearable: "", placeholder: "请选择" },
                      model: {
                        value: _vm.searchRowData.productState,
                        callback: function($$v) {
                          _vm.$set(_vm.searchRowData, "productState", $$v)
                        },
                        expression: "searchRowData.productState"
                      }
                    },
                    _vm._l(_vm.productStateList, function(item, index) {
                      return _c("el-option", {
                        key: index,
                        attrs: { label: item.name, value: item.value }
                      })
                    }),
                    1
                  )
                ],
                1
              ),
              _c(
                "div",
                { staticClass: "selItem" },
                [
                  _c("label", [_vm._v("所属供应商")]),
                  _c("el-input", {
                    model: {
                      value: _vm.searchRowData.companyName,
                      callback: function($$v) {
                        _vm.$set(_vm.searchRowData, "companyName", $$v)
                      },
                      expression: "searchRowData.companyName"
                    }
                  })
                ],
                1
              ),
              _c(
                "div",
                { staticClass: "selItem selItem1" },
                [
                  _c("label", [_vm._v("保险公司")]),
                  _c("el-autocomplete", {
                    attrs: { "fetch-suggestions": _vm.querySearchAsyncCompany },
                    on: { select: _vm.handleSelect },
                    model: {
                      value: _vm.searchRowData.supplierName,
                      callback: function($$v) {
                        _vm.$set(_vm.searchRowData, "supplierName", $$v)
                      },
                      expression: "searchRowData.supplierName"
                    }
                  })
                ],
                1
              )
            ]),
            _c(
              "div",
              {
                staticClass: "product selItem",
                staticStyle: { "margin-top": "10px" }
              },
              [
                _c(
                  "label",
                  {
                    staticClass: "label",
                    staticStyle: { "margin-right": "29px" }
                  },
                  [_vm._v("产品类型")]
                ),
                _c(
                  "el-select",
                  {
                    attrs: { clearable: "", placeholder: "请选择" },
                    model: {
                      value: _vm.searchRowData.productType,
                      callback: function($$v) {
                        _vm.$set(_vm.searchRowData, "productType", $$v)
                      },
                      expression: "searchRowData.productType"
                    }
                  },
                  _vm._l(_vm.riskType, function(item, index) {
                    return _c("el-option", {
                      key: index,
                      attrs: { label: item.name, value: item.value }
                    })
                  }),
                  1
                )
              ],
              1
            ),
            _c(
              "div",
              { staticClass: "groupBtn" },
              [
                _c(
                  "el-button",
                  {
                    attrs: { type: "primary", size: "mini" },
                    on: { click: _vm.goSearchDetail }
                  },
                  [_vm._v("查询")]
                ),
                _c(
                  "el-button",
                  {
                    attrs: { type: "primary", size: "mini" },
                    on: {
                      click: function($event) {
                        return _vm.goChange("insert")
                      }
                    }
                  },
                  [_vm._v("上线")]
                ),
                _c(
                  "el-button",
                  {
                    attrs: { type: "primary", size: "mini" },
                    on: {
                      click: function($event) {
                        return _vm.goChange("delete")
                      }
                    }
                  },
                  [_vm._v("下线")]
                )
              ],
              1
            )
          ]),
          _c(
            "el-table",
            {
              ref: "multipleTable",
              staticClass: "selfTable",
              staticStyle: { width: "100%" },
              attrs: {
                data: _vm.tableDataDetail,
                "tooltip-effect": "dark",
                "max-height": "750px"
              },
              on: { "selection-change": _vm.handleSingleSelect }
            },
            [
              _c("el-table-column", {
                attrs: {
                  width: "55",
                  type: "selection",
                  align: "center",
                  "header-align": "center"
                }
              }),
              _c("el-table-column", {
                attrs: {
                  label: "序号",
                  prop: "",
                  width: "55",
                  align: "center",
                  "header-align": "center"
                },
                scopedSlots: _vm._u([
                  {
                    key: "default",
                    fn: function(scope) {
                      return [_vm._v(" " + _vm._s(scope.$index + 1) + " ")]
                    }
                  }
                ])
              }),
              _c("el-table-column", {
                attrs: {
                  label: "产品编码",
                  width: "180",
                  prop: "productCode",
                  align: "center",
                  "header-align": "center"
                }
              }),
              _c("el-table-column", {
                attrs: {
                  prop: "productName",
                  label: "产品名称",
                  width: "180",
                  align: "center",
                  "header-align": "center"
                }
              }),
              _c("el-table-column", {
                attrs: {
                  prop: "supplierName",
                  label: "保险公司",
                  width: "180",
                  align: "center",
                  "header-align": "center"
                }
              }),
              _c("el-table-column", {
                attrs: {
                  prop: "companyName",
                  label: "供应商",
                  width: "180",
                  align: "center",
                  "header-align": "center"
                }
              }),
              _c("el-table-column", {
                attrs: {
                  prop: "productTypeName",
                  label: "产品类型",
                  width: "120",
                  align: "center",
                  "header-align": "center"
                }
              }),
              _c("el-table-column", {
                attrs: {
                  prop: "productStatus",
                  label: "产品状态",
                  width: "120",
                  align: "center",
                  "header-align": "center"
                }
              }),
              _c("el-table-column", {
                attrs: {
                  prop: "saleStatus",
                  label: "可售卖状态",
                  width: "120",
                  align: "center",
                  "header-align": "center"
                }
              })
            ],
            1
          ),
          _vm.tableDataDetail.length > 0
            ? _c(
                "div",
                { staticClass: "pagination" },
                [
                  _c("el-pagination", {
                    attrs: {
                      background: "",
                      layout: "total,prev, pager, next",
                      "current-page": _vm.curPage,
                      total: _vm.detailTotal
                    },
                    on: { "current-change": _vm.handleCurrentChange }
                  })
                ],
                1
              )
            : _vm._e(),
          _c(
            "span",
            {
              staticClass: "dialog-footer",
              attrs: { slot: "footer" },
              slot: "footer"
            },
            [
              _c(
                "el-button",
                {
                  on: {
                    click: function($event) {
                      _vm.productDialogVisible = false
                    }
                  }
                },
                [_vm._v("关闭")]
              )
            ],
            1
          )
        ],
        1
      ),
      _c(
        "el-dialog",
        {
          attrs: {
            title: "调整等级标准",
            visible: _vm.adjustGradeStandardPopup,
            width: "400px"
          },
          on: {
            "update:visible": function($event) {
              _vm.adjustGradeStandardPopup = $event
            }
          }
        },
        [
          _c(
            "div",
            { staticClass: "header showTab" },
            [
              _c(
                "el-row",
                { staticStyle: { "margin-left": "58px" } },
                [
                  _c(
                    "el-col",
                    { attrs: { span: 20 } },
                    [
                      _c(
                        "span",
                        {
                          staticClass: "strang",
                          staticStyle: { "margin-left": "-30px" }
                        },
                        [_vm._v("A+:")]
                      ),
                      _c("el-input", {
                        attrs: {
                          onkeyup: "value=value.replace(/[^\\d.]/g,'')",
                          placeholder: "只能输入数字"
                        },
                        model: {
                          value: _vm.rateGradeForm.level5,
                          callback: function($$v) {
                            _vm.$set(_vm.rateGradeForm, "level5", $$v)
                          },
                          expression: "rateGradeForm.level5"
                        }
                      })
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                {
                  staticStyle: { "margin-left": "58px", "margin-top": "30px" }
                },
                [
                  _c(
                    "el-col",
                    { attrs: { span: 20 } },
                    [
                      _c(
                        "span",
                        {
                          staticClass: "strang",
                          staticStyle: { "margin-left": "-30px" }
                        },
                        [_vm._v("A :")]
                      ),
                      _c("el-input", {
                        attrs: {
                          onkeyup: "value=value.replace(/[^\\d.]/g,'')",
                          placeholder: "只能输入数字"
                        },
                        model: {
                          value: _vm.rateGradeForm.level4,
                          callback: function($$v) {
                            _vm.$set(_vm.rateGradeForm, "level4", $$v)
                          },
                          expression: "rateGradeForm.level4"
                        }
                      })
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-button",
                {
                  staticStyle: { "margin-left": "95px", "margin-top": "128px" },
                  on: {
                    click: function($event) {
                      _vm.adjustGradeStandardPopup = false
                    }
                  }
                },
                [_vm._v(" 取消 ")]
              ),
              _c(
                "el-button",
                {
                  attrs: { type: "primary" },
                  on: { click: _vm.adjustGradeStandardSub }
                },
                [_vm._v("提交")]
              )
            ],
            1
          )
        ]
      ),
      _c(
        "el-dialog",
        {
          attrs: {
            title: "调整等级标准",
            visible: _vm.adjustGradeStandardPopupB,
            width: "400px"
          },
          on: {
            "update:visible": function($event) {
              _vm.adjustGradeStandardPopupB = $event
            }
          }
        },
        [
          _c(
            "div",
            { staticClass: "header showTab" },
            [
              _c(
                "el-row",
                { staticStyle: { "margin-left": "58px" } },
                [
                  _c(
                    "el-col",
                    { attrs: { span: 20 } },
                    [
                      _c(
                        "span",
                        {
                          staticClass: "strang",
                          staticStyle: { "margin-left": "-30px" }
                        },
                        [_vm._v("B+:")]
                      ),
                      _c("el-input", {
                        attrs: {
                          onkeyup: "value=value.replace(/[^\\d.]/g,'')",
                          placeholder: "只能输入数字"
                        },
                        model: {
                          value: _vm.rateGradeForm.level3,
                          callback: function($$v) {
                            _vm.$set(_vm.rateGradeForm, "level3", $$v)
                          },
                          expression: "rateGradeForm.level3"
                        }
                      })
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                {
                  staticStyle: { "margin-left": "58px", "margin-top": "30px" }
                },
                [
                  _c(
                    "el-col",
                    { attrs: { span: 20 } },
                    [
                      _c(
                        "span",
                        {
                          staticClass: "strang",
                          staticStyle: { "margin-left": "-30px" }
                        },
                        [_vm._v("B :")]
                      ),
                      _c("el-input", {
                        attrs: {
                          onkeyup: "value=value.replace(/[^\\d.]/g,'')",
                          placeholder: "只能输入数字"
                        },
                        model: {
                          value: _vm.rateGradeForm.level2,
                          callback: function($$v) {
                            _vm.$set(_vm.rateGradeForm, "level2", $$v)
                          },
                          expression: "rateGradeForm.level2"
                        }
                      })
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                {
                  staticStyle: { "margin-left": "58px", "margin-top": "30px" }
                },
                [
                  _c(
                    "el-col",
                    { attrs: { span: 20 } },
                    [
                      _c(
                        "span",
                        {
                          staticClass: "strang",
                          staticStyle: { "margin-left": "-30px" }
                        },
                        [_vm._v("B-:")]
                      ),
                      _c("el-input", {
                        attrs: {
                          onkeyup: "value=value.replace(/[^\\d.]/g,'')",
                          placeholder: "只能输入数字"
                        },
                        model: {
                          value: _vm.rateGradeForm.level1,
                          callback: function($$v) {
                            _vm.$set(_vm.rateGradeForm, "level1", $$v)
                          },
                          expression: "rateGradeForm.level1"
                        }
                      })
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-button",
                {
                  staticStyle: { "margin-left": "95px", "margin-top": "128px" },
                  on: {
                    click: function($event) {
                      _vm.adjustGradeStandardPopupB = false
                    }
                  }
                },
                [_vm._v(" 取消 ")]
              ),
              _c(
                "el-button",
                {
                  attrs: { type: "primary" },
                  on: { click: _vm.adjustGradeStandardBSub }
                },
                [_vm._v("提交")]
              )
            ],
            1
          )
        ]
      ),
      _c(
        "el-dialog",
        {
          attrs: {
            title: _vm.sdialogConfig.title,
            visible: _vm.dialogVisible,
            width: "50%"
          },
          on: {
            "update:visible": function($event) {
              _vm.dialogVisible = $event
            }
          }
        },
        [
          _c(
            "el-form",
            {
              ref: "form",
              attrs: {
                "label-positio": "left",
                model: _vm.addForm,
                "label-width": "200px"
              }
            },
            [
              _c(
                "el-row",
                [
                  _c(
                    "el-col",
                    { attrs: { span: 20 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "渠道公司名称:", required: true } },
                        [
                          _c("el-input", {
                            attrs: { maxlength: 30, placeholder: "请输入内容" },
                            model: {
                              value: _vm.addForm.channelCompanyName,
                              callback: function($$v) {
                                _vm.$set(_vm.addForm, "channelCompanyName", $$v)
                              },
                              expression: "addForm.channelCompanyName"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 20 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "合作模式:", required: true } },
                        [
                          _c(
                            "el-select",
                            {
                              attrs: {
                                placeholder: "请选择合作模式",
                                clearable: ""
                              },
                              model: {
                                value: _vm.addForm.model,
                                callback: function($$v) {
                                  _vm.$set(_vm.addForm, "model", $$v)
                                },
                                expression: "addForm.model"
                              }
                            },
                            _vm._l(_vm.componeyModelList, function(item) {
                              return _c("el-option", {
                                key: item.value,
                                attrs: { label: item.name, value: item.value }
                              })
                            }),
                            1
                          )
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 20 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "初始等级:", required: true } },
                        [
                          _c(
                            "el-select",
                            {
                              attrs: {
                                placeholder: "请选择初始等级",
                                clearable: "",
                                disabled: _vm.isInitialLevel
                              },
                              model: {
                                value: _vm.addForm.initialLevel,
                                callback: function($$v) {
                                  _vm.$set(_vm.addForm, "initialLevel", $$v)
                                },
                                expression: "addForm.initialLevel"
                              }
                            },
                            _vm._l(_vm.rateLevenType, function(item) {
                              return _c("el-option", {
                                key: item.value,
                                attrs: { label: item.name, value: item.value }
                              })
                            }),
                            1
                          )
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 20 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "当前等级:", required: true } },
                        [
                          _c(
                            "el-select",
                            {
                              attrs: {
                                placeholder: "请选择当前等级",
                                clearable: ""
                              },
                              model: {
                                value: _vm.addForm.currentLevel,
                                callback: function($$v) {
                                  _vm.$set(_vm.addForm, "currentLevel", $$v)
                                },
                                expression: "addForm.currentLevel"
                              }
                            },
                            _vm._l(_vm.rateLevenType, function(item) {
                              return _c("el-option", {
                                key: item.value,
                                attrs: { label: item.name, value: item.value }
                              })
                            }),
                            1
                          )
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _vm.isEdit
                    ? _c(
                        "el-col",
                        { attrs: { span: 20 } },
                        [
                          _c(
                            "el-form-item",
                            { attrs: { label: "渠道公司编码:" } },
                            [
                              _c("el-input", {
                                attrs: {
                                  maxlength: 30,
                                  placeholder: "请输入内容",
                                  disabled: ""
                                },
                                model: {
                                  value: _vm.addForm.channelCompanyCode,
                                  callback: function($$v) {
                                    _vm.$set(
                                      _vm.addForm,
                                      "channelCompanyCode",
                                      $$v
                                    )
                                  },
                                  expression: "addForm.channelCompanyCode"
                                }
                              })
                            ],
                            1
                          )
                        ],
                        1
                      )
                    : _vm._e(),
                  _c(
                    "el-col",
                    { attrs: { span: 20 } },
                    [
                      _c(
                        "el-form-item",
                        {
                          attrs: { label: "渠道公司所在地区:", required: true }
                        },
                        [
                          _c(
                            "el-select",
                            {
                              attrs: {
                                placeholder: "请选择所在地区",
                                clearable: ""
                              },
                              model: {
                                value: _vm.addForm.areaProvinceCode,
                                callback: function($$v) {
                                  _vm.$set(_vm.addForm, "areaProvinceCode", $$v)
                                },
                                expression: "addForm.areaProvinceCode"
                              }
                            },
                            _vm._l(_vm.dictList, function(item) {
                              return _c("el-option", {
                                key: item.areaCode,
                                attrs: {
                                  label: item.areaName,
                                  value: item.areaCode
                                }
                              })
                            }),
                            1
                          )
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 20 } },
                    [
                      _c(
                        "el-form-item",
                        {
                          attrs: { label: "渠道公司创建时间:", required: true }
                        },
                        [
                          _c("el-date-picker", {
                            attrs: {
                              type: "date",
                              placeholder: "选择日期",
                              "value-format": "yyyy-MM-dd"
                            },
                            model: {
                              value: _vm.addForm.createDate,
                              callback: function($$v) {
                                _vm.$set(_vm.addForm, "createDate", $$v)
                              },
                              expression: "addForm.createDate"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 20 } },
                    [
                      _c(
                        "el-form-item",
                        {
                          attrs: { label: "渠道公司签约时间:", required: true }
                        },
                        [
                          _c("el-date-picker", {
                            attrs: {
                              type: "date",
                              placeholder: "选择日期",
                              "value-format": "yyyy-MM-dd"
                            },
                            model: {
                              value: _vm.addForm.signingDate,
                              callback: function($$v) {
                                _vm.$set(_vm.addForm, "signingDate", $$v)
                              },
                              expression: "addForm.signingDate"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 20 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "渠道公司电话号:" } },
                        [
                          _c("el-input", {
                            attrs: { maxlength: 30, placeholder: "请输入内容" },
                            model: {
                              value: _vm.addForm.channelCompanyPhone,
                              callback: function($$v) {
                                _vm.$set(
                                  _vm.addForm,
                                  "channelCompanyPhone",
                                  $$v
                                )
                              },
                              expression: "addForm.channelCompanyPhone"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 20 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "渠道公司负责人:" } },
                        [
                          _c("el-input", {
                            attrs: { maxlength: 30, placeholder: "请输入内容" },
                            model: {
                              value: _vm.addForm.managerName,
                              callback: function($$v) {
                                _vm.$set(_vm.addForm, "managerName", $$v)
                              },
                              expression: "addForm.managerName"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 20 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "负责人电话:" } },
                        [
                          _c("el-input", {
                            attrs: { maxlength: 30, placeholder: "请输入内容" },
                            model: {
                              value: _vm.addForm.managerPhone,
                              callback: function($$v) {
                                _vm.$set(_vm.addForm, "managerPhone", $$v)
                              },
                              expression: "addForm.managerPhone"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 20 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "渠道公司详细地址:" } },
                        [
                          _c("el-input", {
                            attrs: {
                              maxlength: 30,
                              placeholder: "请输入详细地址"
                            },
                            model: {
                              value: _vm.addForm.address,
                              callback: function($$v) {
                                _vm.$set(_vm.addForm, "address", $$v)
                              },
                              expression: "addForm.address"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 20 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "收款账号:" } },
                        [
                          _c("el-input", {
                            attrs: {
                              maxlength: 30,
                              placeholder: "请输收款账号"
                            },
                            model: {
                              value: _vm.addForm.accountNumber,
                              callback: function($$v) {
                                _vm.$set(_vm.addForm, "accountNumber", $$v)
                              },
                              expression: "addForm.accountNumber"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 20 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "收款银行:" } },
                        [
                          _c("el-input", {
                            attrs: {
                              maxlength: 30,
                              placeholder: "请输入收款银行"
                            },
                            model: {
                              value: _vm.addForm.receivingBank,
                              callback: function($$v) {
                                _vm.$set(_vm.addForm, "receivingBank", $$v)
                              },
                              expression: "addForm.receivingBank"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 20 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "收款银行全称:" } },
                        [
                          _c("el-input", {
                            attrs: {
                              maxlength: 30,
                              placeholder: "请输入收款银行全称"
                            },
                            model: {
                              value: _vm.addForm.receivingBankName,
                              callback: function($$v) {
                                _vm.$set(_vm.addForm, "receivingBankName", $$v)
                              },
                              expression: "addForm.receivingBankName"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 20 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "备注:" } },
                        [
                          _c("el-input", {
                            attrs: { maxlength: 30, placeholder: "请输入内容" },
                            model: {
                              value: _vm.addForm.remark,
                              callback: function($$v) {
                                _vm.$set(_vm.addForm, "remark", $$v)
                              },
                              expression: "addForm.remark"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 20 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "停业标志:", required: true } },
                        [
                          _c(
                            "el-radio-group",
                            {
                              model: {
                                value: _vm.addForm.closeFlag,
                                callback: function($$v) {
                                  _vm.$set(_vm.addForm, "closeFlag", $$v)
                                },
                                expression: "addForm.closeFlag"
                              }
                            },
                            [
                              _c("el-radio", { attrs: { label: "0" } }, [
                                _vm._v("正常")
                              ]),
                              _c("el-radio", { attrs: { label: "1" } }, [
                                _vm._v("停业")
                              ])
                            ],
                            1
                          )
                        ],
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              )
            ],
            1
          ),
          _c(
            "span",
            {
              staticClass: "dialog-footer",
              attrs: { slot: "footer" },
              slot: "footer"
            },
            [
              _c(
                "el-button",
                {
                  on: {
                    click: function($event) {
                      _vm.dialogVisible = false
                    }
                  }
                },
                [_vm._v("取消")]
              ),
              _c(
                "el-button",
                { attrs: { type: "primary" }, on: { click: _vm.saveAction } },
                [_vm._v("保存")]
              )
            ],
            1
          )
        ],
        1
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/core-js/modules/es.array.filter.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es.array.filter.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var $filter = __webpack_require__(/*! ../internals/array-iteration */ "./node_modules/core-js/internals/array-iteration.js").filter;
var arrayMethodHasSpeciesSupport = __webpack_require__(/*! ../internals/array-method-has-species-support */ "./node_modules/core-js/internals/array-method-has-species-support.js");

var HAS_SPECIES_SUPPORT = arrayMethodHasSpeciesSupport('filter');

// `Array.prototype.filter` method
// https://tc39.es/ecma262/#sec-array.prototype.filter
// with adding support of @@species
$({ target: 'Array', proto: true, forced: !HAS_SPECIES_SUPPORT }, {
  filter: function filter(callbackfn /* , thisArg */) {
    return $filter(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es.array.map.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/es.array.map.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var $map = __webpack_require__(/*! ../internals/array-iteration */ "./node_modules/core-js/internals/array-iteration.js").map;
var arrayMethodHasSpeciesSupport = __webpack_require__(/*! ../internals/array-method-has-species-support */ "./node_modules/core-js/internals/array-method-has-species-support.js");

var HAS_SPECIES_SUPPORT = arrayMethodHasSpeciesSupport('map');

// `Array.prototype.map` method
// https://tc39.es/ecma262/#sec-array.prototype.map
// with adding support of @@species
$({ target: 'Array', proto: true, forced: !HAS_SPECIES_SUPPORT }, {
  map: function map(callbackfn /* , thisArg */) {
    return $map(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/channelcomponeny.vue?vue&type=style&index=0&lang=less&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--10-oneOf-1-2!./node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/mga-manage/channelcomponeny.vue?vue&type=style&index=0&lang=less& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".allcover {\n  position: absolute;\n  top: 0;\n  right: 0;\n}\n.ctt {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n}\n.tb {\n  position: absolute;\n  top: 50%;\n  transform: translateY(-50%);\n}\n.lr {\n  position: absolute;\n  left: 50%;\n  transform: translateX(-50%);\n}\n.el-form-item__label {\n  white-space: nowrap;\n}\n.el-select {\n  width: 100%;\n}\n#container {\n  padding: 15px;\n}\n#container .queryHeading {\n  background-color: #f4f4f5;\n  color: #909399;\n  font-size: 14px;\n  padding: 10px 10px;\n  margin-bottom: 15px;\n}\n#container .pagination {\n  margin-top: 15px;\n  float: right;\n}\n#container .editinfo {\n  margin-bottom: 15px;\n}\n#container .dialog-content .list {\n  margin-bottom: 15px;\n}\n#container .dialog-title {\n  font-size: 20px;\n}\n#container .dialog-footer {\n  padding-top: 20px;\n  display: flex;\n  justify-content: flex-end;\n}\n#container /deep/ .el-transfer-panel {\n  height: 400px !important;\n}\n#container .el-transfer-panel__list.is-filterable {\n  height: 300px;\n}\n#container .el-date-editor.el-input {\n  width: 180px !important;\n  color: red;\n}\n#container .el-select {\n  width: 180px;\n}\n.showTab {\n  margin-bottom: 20px;\n  min-height: 80px;\n  position: relative;\n}\n.showTab .groupBtn {\n  height: 80px;\n  position: absolute;\n  top: 60px;\n  right: 80px;\n}\n.selGroup {\n  display: flex;\n}\n.selGroup .selItem {\n  margin-right: 10px;\n  display: flex;\n  align-items: center;\n  width: 320px;\n}\n.selGroup .selItem label {\n  width: 80px;\n  margin-right: 10px;\n}\n.selGroup .selItem > .el-input {\n  width: 180px;\n}\n.selGroup .selItem1 {\n  width: 320px;\n}\n.selGroup .selItem1 label {\n  width: 80px;\n}\n.selGroup .selItem1 .el-input {\n  width: 250px;\n}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/channelcomponeny.vue?vue&type=style&index=0&lang=less&":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--10-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--10-oneOf-1-2!./node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/mga-manage/channelcomponeny.vue?vue&type=style&index=0&lang=less& ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--10-oneOf-1-2!../../../node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../node_modules/vue-loader/lib??vue-loader-options!./channelcomponeny.vue?vue&type=style&index=0&lang=less& */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/channelcomponeny.vue?vue&type=style&index=0&lang=less&");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("61166a33", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/assets/staticFilter.js":
/*!************************************!*\
  !*** ./src/assets/staticFilter.js ***!
  \************************************/
/*! exports provided: classification, specialArea, recommend, bannerPlat, bannerPos, bannerStatus, picAddr, isUse, posterStatus, posterTypes, category, riskType, appStatus, verifyStatus, orderStatus, userType, status, userLocked, permissionType, goldType, picPostion, orderSource */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "classification", function() { return classification; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "specialArea", function() { return specialArea; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "recommend", function() { return recommend; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bannerPlat", function() { return bannerPlat; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bannerPos", function() { return bannerPos; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bannerStatus", function() { return bannerStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "picAddr", function() { return picAddr; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isUse", function() { return isUse; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "posterStatus", function() { return posterStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "posterTypes", function() { return posterTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "category", function() { return category; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "riskType", function() { return riskType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "appStatus", function() { return appStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "verifyStatus", function() { return verifyStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "orderStatus", function() { return orderStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "userType", function() { return userType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "status", function() { return status; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "userLocked", function() { return userLocked; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "permissionType", function() { return permissionType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "goldType", function() { return goldType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "picPostion", function() { return picPostion; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "orderSource", function() { return orderSource; });
//静态变量过滤器
//classification
var classification = {
  //图文分类
  '1': '图文',
  '2': '视频'
}; //specialArea

var specialArea = {
  //专区
  '0': '财富密码',
  '1': '保险知识',
  '2': '走进理赔'
}; //recommend

var recommend = {
  //推荐
  '0': '是',
  '1': '否'
}; //bannerPlat

var bannerPlat = {
  //所属平台
  '0': '小程序',
  '1': '公众号',
  '2': 'App'
}; //bannerPos

var bannerPos = {
  //位置
  '0': '首页banner图',
  '1': '轮播图'
}; //bannerStatus

var bannerStatus = {
  //状态
  '0': '已上架',
  '1': '未上架',
  '2': '已下架'
};
var picAddr = {
  '0': '公众号财报头条',
  '1': '公众号保险商城',
  '2': '小程序首页图片',
  '3': 'APP首页',
  '4': '产品库首页',
  '5': '弹窗图'
};
var isUse = {
  //状态
  '0': '未使用',
  '1': '已上架'
};
var posterStatus = {
  '0': '未使用',
  '1': '已上架',
  '2': '已下架'
};
var posterTypes = {
  '1': '问候',
  '2': '理念',
  '3': '励志',
  '4': '增员',
  '5': '节日',
  '6': '理财'
}; //category

var category = {
  //状态
  '1': '公司新闻',
  '2': '行业动态'
}; //riskType

var riskType = {
  //保险类型、产品类型
  A: '企业财产险',
  B: '家庭财产险',
  C: '工程险',
  D: '船舶险',
  E: '农业险',
  F: '货物运输险',
  G: '责任险',
  O: '健康险',
  J: '综合险',
  K: '特殊风险险',
  L: '信用险',
  M: '保证险',
  X: '意外险',
  Y: '寿险',
  P: '失能险',
  Q: '护理险',
  R: '税收优惠健康险',
  S: '旅行意外伤害险',
  T: '长期意外伤害险',
  W: '两全险',
  N: '年金险',
  H: '财产险',
  Z: '全部产品'
}; //appStatus

var appStatus = {
  //保单状态
  UNINSURED: '未承保',
  ACPTINSD_FAILURE: '承保失败',
  ACPTINSD_SUCCESS: '承保成功',
  SURRENDER_SUCCESS: '犹豫期退保成功',
  REVISIT_FAILURE: '回访失败',
  REVISIT_SUCCESS: '已回访',
  RECEIPT_SUCCESS: '回执成功',
  VERIFY_SUCCESS: '核保成功',
  REFUNDPOLICY_SUCCESS: '退保终止'
};
var verifyStatus = {
  //核保状态
  UNVERIFY: '未核保',
  VERIFY_RIGHTOFF: '待核保',
  VERIFY_SUCCESS: '核保成功',
  VERIFY_FAILURE: '核保失败'
}; //orderStatus

var orderStatus = {
  //订单状态
  UNPROCESSED: '未处理',
  PROCESSE: '处理中',
  PROCESSED: '已处理',
  CLOSED: '已关闭'
}; //userType

var userType = {
  //订单状态
  N: '普通',
  T: '推客',
  A: '代理人'
}; //state

var status = {
  //订单状态
  Y: '有效',
  N: '无效'
}; //userLocked

var userLocked = {
  //账号是否锁定
  '1': '是',
  '0': '否'
}; //permissionType

var permissionType = {
  //账号是否锁定
  '1': '菜单',
  '2': '页面按钮',
  '3': '表格按钮'
};
var goldType = {
  Y: '是',
  N: '否'
}; //图片位置

var picPostion = {
  '0': '公众号财报头条',
  '1': '公众号保险商城',
  '2': '小程序首页图片'
}; //订单来源

var orderSource = {
  U: '渠道',
  C: '公众号',
  X: '小程序',
  A: 'app',
  S: '公众号'
};

/***/ }),

/***/ "./src/views/mga-manage/channelcomponeny.vue":
/*!***************************************************!*\
  !*** ./src/views/mga-manage/channelcomponeny.vue ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _channelcomponeny_vue_vue_type_template_id_18c45759___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./channelcomponeny.vue?vue&type=template&id=18c45759& */ "./src/views/mga-manage/channelcomponeny.vue?vue&type=template&id=18c45759&");
/* harmony import */ var _channelcomponeny_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./channelcomponeny.vue?vue&type=script&lang=js& */ "./src/views/mga-manage/channelcomponeny.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _channelcomponeny_vue_vue_type_style_index_0_lang_less___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./channelcomponeny.vue?vue&type=style&index=0&lang=less& */ "./src/views/mga-manage/channelcomponeny.vue?vue&type=style&index=0&lang=less&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _channelcomponeny_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _channelcomponeny_vue_vue_type_template_id_18c45759___WEBPACK_IMPORTED_MODULE_0__["render"],
  _channelcomponeny_vue_vue_type_template_id_18c45759___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/mga-manage/channelcomponeny.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/mga-manage/channelcomponeny.vue?vue&type=script&lang=js&":
/*!****************************************************************************!*\
  !*** ./src/views/mga-manage/channelcomponeny.vue?vue&type=script&lang=js& ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_12_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_channelcomponeny_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--12-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../node_modules/vue-loader/lib??vue-loader-options!./channelcomponeny.vue?vue&type=script&lang=js& */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/channelcomponeny.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_12_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_channelcomponeny_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/mga-manage/channelcomponeny.vue?vue&type=style&index=0&lang=less&":
/*!*************************************************************************************!*\
  !*** ./src/views/mga-manage/channelcomponeny.vue?vue&type=style&index=0&lang=less& ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_channelcomponeny_vue_vue_type_style_index_0_lang_less___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--10-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--10-oneOf-1-2!../../../node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../node_modules/vue-loader/lib??vue-loader-options!./channelcomponeny.vue?vue&type=style&index=0&lang=less& */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/channelcomponeny.vue?vue&type=style&index=0&lang=less&");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_channelcomponeny_vue_vue_type_style_index_0_lang_less___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_channelcomponeny_vue_vue_type_style_index_0_lang_less___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_channelcomponeny_vue_vue_type_style_index_0_lang_less___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_channelcomponeny_vue_vue_type_style_index_0_lang_less___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/mga-manage/channelcomponeny.vue?vue&type=template&id=18c45759&":
/*!**********************************************************************************!*\
  !*** ./src/views/mga-manage/channelcomponeny.vue?vue&type=template&id=18c45759& ***!
  \**********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_channelcomponeny_vue_vue_type_template_id_18c45759___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"b9734f90-vue-loader-template"}!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../node_modules/vue-loader/lib??vue-loader-options!./channelcomponeny.vue?vue&type=template&id=18c45759& */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"b9734f90-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/channelcomponeny.vue?vue&type=template&id=18c45759&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_channelcomponeny_vue_vue_type_template_id_18c45759___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_channelcomponeny_vue_vue_type_template_id_18c45759___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=30.js.map