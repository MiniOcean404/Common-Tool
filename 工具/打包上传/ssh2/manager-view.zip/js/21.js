(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[21],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/SafeAllMange/SafeAllMange.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--12-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/mga-manage/SafeAllMange/SafeAllMange.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.string.split.js */ "./node_modules/core-js/modules/es.string.split.js");
/* harmony import */ var core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _common_MixinUtils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/common/MixinUtils */ "./src/common/MixinUtils.js");
/* harmony import */ var _api_SafeAllMange_SafeAllMangeApi__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/api/SafeAllMange/SafeAllMangeApi */ "./src/api/SafeAllMange/SafeAllMangeApi.js");
/* harmony import */ var _api_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/api/common */ "./src/api/common.js");
/* harmony import */ var _api_api__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/api/api */ "./src/api/api.js");
/* harmony import */ var _common_tableDate_SafeAllMange__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @/common/tableDate/SafeAllMange */ "./src/common/tableDate/SafeAllMange.js");
/* harmony import */ var common_dictionarieList_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! common/dictionarieList/common */ "./src/common/dictionarieList/common.js");




//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//todo 导入混入
 // todo api



 //导入请求
// todo 导入字典



/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'SafeAllMange',
  mixins: [_common_MixinUtils__WEBPACK_IMPORTED_MODULE_4__["tableMixin"]],
  data: function data() {
    return {
      importExcel: _api_api__WEBPACK_IMPORTED_MODULE_7__["importExcel"],
      headers: {
        mimeType: 'multipart/form-data'
      },
      // todo 传递的数据
      queryParams: {},
      //todo 字典
      fromState: common_dictionarieList_common__WEBPACK_IMPORTED_MODULE_9__["fromState"],
      //todo 表格展示数据
      tableData: {
        resultData: [],
        needData: _common_tableDate_SafeAllMange__WEBPACK_IMPORTED_MODULE_8__["table"]
      },
      // 退保
      cancellationPolicyDate: '',
      policyNoList: [],
      // todo 文件导入
      fileList: [],
      importData: {}
    };
  },
  created: function created() {
    this.requestDeploy();
  },
  methods: {
    // todo 导出excel文件
    downLoad: function downLoad() {
      Object(_api_common__WEBPACK_IMPORTED_MODULE_6__["download"])('/admin/preservation/downSurrenderTemplate', {}, 'get');
    },
    // todo 导入成功
    uploadSuccess: function uploadSuccess(response, file, fileList) {
      if (response.code == '200') {
        this.$message({
          type: 'success',
          message: '犹豫期退保导入成功'
        });
      } else {
        this.$message({
          type: 'error',
          message: response.msg
        });
      }
    },
    selectChange: function selectChange(val) {
      var proxy = new Proxy(val, {
        get: function get(target, p, receiver) {
          if (target.length > 0) {
            return target.map(function (item) {
              return item.policyNo;
            });
          }

          return target;
        }
      });
      this.policyNoList = proxy[0];
    },
    saveDate: function saveDate() {
      var _this = this;

      if (this.policyNoList.length === 0) {
        this.$message({
          type: 'error',
          message: '列表选择不能为空'
        });
        return;
      }

      var data = {
        policyNoList: this.policyNoList,
        surrenderDate: this.cancellationPolicyDate
      };
      Object(_api_SafeAllMange_SafeAllMangeApi__WEBPACK_IMPORTED_MODULE_5__["getCancellationPolicy"])(data).then(function (res, rej) {
        if (res.msg === 'OK' && res.code === 200) {
          _this.$message({
            type: 'success',
            message: '犹豫期犹豫期退保成功'
          });

          _this.requestDeploy();
        }
      });
    },
    // *----------------------------------处理页码，过滤函数
    // todo 当前表格请求配置
    requestDeploy: function requestDeploy(current) {
      var dateArr = [{
        data: ['makeDateStart', 'makeDateEnd'],
        dataOne: ['surrenderDateStart', 'surrenderDateEnd']
      }]; //api、查询表格、页、表格数据、当前页、时间数组，过滤函数

      this.getList(_api_SafeAllMange_SafeAllMangeApi__WEBPACK_IMPORTED_MODULE_5__["getPreservationList"], this.queryData, this.pageOption, this.tableData, current, dateArr, this.filter);
    },
    // todo 点击查询按钮
    queryButton: function queryButton(e, apiNum) {
      this.requestDeploy();
    },
    // todo 过滤函数
    filter: function filter(v) {
      if (v[0].toLowerCase().indexOf('date') > 0 && v[1] !== '') {
        return [v[0], v[1].split(' ')[0]];
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"b9734f90-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/SafeAllMange/SafeAllMange.vue?vue&type=template&id=24809ca5&scoped=true&":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"b9734f90-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/mga-manage/SafeAllMange/SafeAllMange.vue?vue&type=template&id=24809ca5&scoped=true& ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { attrs: { id: "SafeAllMange_container" } },
    [
      _c("Input", {
        attrs: { queryData: _vm.queryData },
        scopedSlots: _vm._u([
          {
            key: "up",
            fn: function(ref) {
              var queryData = ref.queryData
              return [
                _c("div", { staticClass: "query_title" }, [
                  _c("span", [_vm._v("查询条件")])
                ]),
                _c(
                  "el-form",
                  {
                    attrs: {
                      "label-width": "100px",
                      model: queryData,
                      "label-position": "right",
                      inline: true
                    }
                  },
                  [
                    _c(
                      "el-form-item",
                      { attrs: { label: " 投保人:" } },
                      [
                        _c("el-input", {
                          attrs: { placeholder: "请输入内容", clearable: "" },
                          model: {
                            value: queryData.holderName,
                            callback: function($$v) {
                              _vm.$set(queryData, "holderName", $$v)
                            },
                            expression: "queryData.holderName"
                          }
                        })
                      ],
                      1
                    ),
                    _c(
                      "el-form-item",
                      { attrs: { label: "保单号:" } },
                      [
                        _c("el-input", {
                          attrs: { placeholder: "请输入内容", clearable: "" },
                          model: {
                            value: queryData.policyNo,
                            callback: function($$v) {
                              _vm.$set(queryData, "policyNo", $$v)
                            },
                            expression: "queryData.policyNo"
                          }
                        })
                      ],
                      1
                    ),
                    _c(
                      "el-form-item",
                      { attrs: { label: "代理人:" } },
                      [
                        _c("el-input", {
                          attrs: { placeholder: "请输入内容", clearable: "" },
                          model: {
                            value: queryData.agentName,
                            callback: function($$v) {
                              _vm.$set(queryData, "agentName", $$v)
                            },
                            expression: "queryData.agentName"
                          }
                        })
                      ],
                      1
                    ),
                    _c(
                      "el-form-item",
                      { attrs: { label: "人员编码:" } },
                      [
                        _c("el-input", {
                          attrs: { placeholder: "请输入内容", clearable: "" },
                          model: {
                            value: queryData.agentCode,
                            callback: function($$v) {
                              _vm.$set(queryData, "agentCode", $$v)
                            },
                            expression: "queryData.agentCode"
                          }
                        })
                      ],
                      1
                    ),
                    _c(
                      "el-form-item",
                      { attrs: { label: "产品名称:" } },
                      [
                        _c("el-input", {
                          attrs: { placeholder: "请输入内容", clearable: "" },
                          model: {
                            value: queryData.productName,
                            callback: function($$v) {
                              _vm.$set(queryData, "productName", $$v)
                            },
                            expression: "queryData.productName"
                          }
                        })
                      ],
                      1
                    ),
                    _c(
                      "el-form-item",
                      { attrs: { label: "供应商名称:" } },
                      [
                        _c("el-input", {
                          attrs: { placeholder: "请输入内容", clearable: "" },
                          model: {
                            value: queryData.insCompany,
                            callback: function($$v) {
                              _vm.$set(queryData, "insCompany", $$v)
                            },
                            expression: "queryData.insCompany"
                          }
                        })
                      ],
                      1
                    ),
                    _c(
                      "el-form-item",
                      { attrs: { label: "保险公司:" } },
                      [
                        _c("el-input", {
                          attrs: { placeholder: "请输入内容", clearable: "" },
                          model: {
                            value: queryData.supplierName,
                            callback: function($$v) {
                              _vm.$set(queryData, "supplierName", $$v)
                            },
                            expression: "queryData.supplierName"
                          }
                        })
                      ],
                      1
                    ),
                    _c(
                      "el-form-item",
                      { attrs: { label: "渠道公司名称:" } },
                      [
                        _c("el-input", {
                          attrs: { placeholder: "请输入内容", clearable: "" },
                          model: {
                            value: queryData.channelName,
                            callback: function($$v) {
                              _vm.$set(queryData, "channelName", $$v)
                            },
                            expression: "queryData.channelName"
                          }
                        })
                      ],
                      1
                    ),
                    _c(
                      "el-form-item",
                      { attrs: { label: "保单状态" } },
                      [
                        _c(
                          "el-select",
                          {
                            attrs: {
                              clearable: "",
                              placeholder: "请选择内容",
                              filterable: ""
                            },
                            model: {
                              value: queryData.appStatus,
                              callback: function($$v) {
                                _vm.$set(queryData, "appStatus", $$v)
                              },
                              expression: "queryData.appStatus"
                            }
                          },
                          _vm._l(_vm.fromState, function(item) {
                            return _c("el-option", {
                              key: item.value,
                              attrs: { label: item.label, value: item.value }
                            })
                          }),
                          1
                        )
                      ],
                      1
                    ),
                    _c(
                      "el-form-item",
                      { attrs: { label: "出单日期" } },
                      [
                        _c("el-date-picker", {
                          attrs: {
                            format: "yyyy-MM-dd",
                            "value-format": "yyyy-MM-dd",
                            type: "daterange",
                            align: "right",
                            "unlink-panels": "",
                            "range-separator": "至",
                            "start-placeholder": "开始日期",
                            "end-placeholder": "结束日期",
                            "picker-options": _vm.pickerOptions
                          },
                          model: {
                            value: queryData.data,
                            callback: function($$v) {
                              _vm.$set(queryData, "data", $$v)
                            },
                            expression: "queryData.data"
                          }
                        })
                      ],
                      1
                    ),
                    _c(
                      "el-form-item",
                      { attrs: { label: "退保日期" } },
                      [
                        _c("el-date-picker", {
                          attrs: {
                            format: "yyyy-MM-dd",
                            "value-format": "yyyy-MM-dd",
                            type: "daterange",
                            align: "right",
                            "unlink-panels": "",
                            "range-separator": "至",
                            "start-placeholder": "开始日期",
                            "end-placeholder": "结束日期",
                            "picker-options": _vm.pickerOptions
                          },
                          model: {
                            value: queryData.dataOne,
                            callback: function($$v) {
                              _vm.$set(queryData, "dataOne", $$v)
                            },
                            expression: "queryData.dataOne"
                          }
                        })
                      ],
                      1
                    ),
                    _c(
                      "el-button",
                      {
                        attrs: { type: "primary" },
                        on: { click: _vm.queryButton }
                      },
                      [_vm._v("查询")]
                    )
                  ],
                  1
                )
              ]
            }
          }
        ])
      }),
      _c("div", { staticClass: "block-SafeAllMange" }, [
        _c("span", { staticClass: "demonstration" }, [
          _vm._v("客户犹豫期退保日期")
        ]),
        _c(
          "span",
          [
            _c("el-date-picker", {
              attrs: {
                type: "date",
                format: "yyyy-MM-dd",
                "value-format": "yyyy-MM-dd",
                placeholder: "选择日期",
                size: "mini"
              },
              model: {
                value: _vm.cancellationPolicyDate,
                callback: function($$v) {
                  _vm.cancellationPolicyDate = $$v
                },
                expression: "cancellationPolicyDate"
              }
            })
          ],
          1
        ),
        _c(
          "span",
          [
            _c(
              "el-button",
              {
                attrs: { type: "primary", size: "mini" },
                on: { click: _vm.saveDate }
              },
              [_vm._v("保存")]
            )
          ],
          1
        ),
        _c("span", [_vm._v("请先选择一条数据再进行保存")]),
        _c("span", [
          _c("div", { staticClass: "toolGroup" }, [
            _c(
              "div",
              { staticClass: "import" },
              [
                _c("label", { attrs: { for: "" } }, [_vm._v("导入：")]),
                _c(
                  "el-upload",
                  {
                    ref: "upload",
                    staticClass: "upload-demo",
                    attrs: {
                      action: _vm.importExcel,
                      "file-list": _vm.fileList,
                      headers: _vm.headers,
                      "on-success": _vm.uploadSuccess,
                      "with-credentials": true,
                      accept: ".xlsx,.xls",
                      multiple: "",
                      name: "uploadFile"
                    }
                  },
                  [
                    _c(
                      "el-button",
                      { attrs: { size: "mini", type: "primary" } },
                      [_vm._v("导入")]
                    )
                  ],
                  1
                )
              ],
              1
            ),
            _c(
              "div",
              { staticClass: "export" },
              [
                _c("label", { attrs: { for: "" } }, [_vm._v("模版下载：")]),
                _c(
                  "el-button",
                  {
                    attrs: { size: "mini", type: "primary" },
                    on: { click: _vm.downLoad }
                  },
                  [_vm._v("下载")]
                )
              ],
              1
            )
          ])
        ])
      ]),
      _c("div", { staticClass: "query_title" }, [_vm._v("查询结果")]),
      _c("Table", {
        attrs: { tableData: _vm.tableData, isCheckbox: true },
        on: { handleSelectionChange: _vm.selectChange }
      }),
      _c("Pagination", {
        attrs: { pageOption: _vm.pageOption },
        on: { currentPageChange: _vm.currentPageChange }
      })
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/core-js/internals/is-regexp.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/internals/is-regexp.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");
var classof = __webpack_require__(/*! ../internals/classof-raw */ "./node_modules/core-js/internals/classof-raw.js");
var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");

var MATCH = wellKnownSymbol('match');

// `IsRegExp` abstract operation
// https://tc39.es/ecma262/#sec-isregexp
module.exports = function (it) {
  var isRegExp;
  return isObject(it) && ((isRegExp = it[MATCH]) !== undefined ? !!isRegExp : classof(it) == 'RegExp');
};


/***/ }),

/***/ "./node_modules/core-js/modules/es.array.filter.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es.array.filter.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var $filter = __webpack_require__(/*! ../internals/array-iteration */ "./node_modules/core-js/internals/array-iteration.js").filter;
var arrayMethodHasSpeciesSupport = __webpack_require__(/*! ../internals/array-method-has-species-support */ "./node_modules/core-js/internals/array-method-has-species-support.js");

var HAS_SPECIES_SUPPORT = arrayMethodHasSpeciesSupport('filter');

// `Array.prototype.filter` method
// https://tc39.es/ecma262/#sec-array.prototype.filter
// with adding support of @@species
$({ target: 'Array', proto: true, forced: !HAS_SPECIES_SUPPORT }, {
  filter: function filter(callbackfn /* , thisArg */) {
    return $filter(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es.array.map.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/es.array.map.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var $map = __webpack_require__(/*! ../internals/array-iteration */ "./node_modules/core-js/internals/array-iteration.js").map;
var arrayMethodHasSpeciesSupport = __webpack_require__(/*! ../internals/array-method-has-species-support */ "./node_modules/core-js/internals/array-method-has-species-support.js");

var HAS_SPECIES_SUPPORT = arrayMethodHasSpeciesSupport('map');

// `Array.prototype.map` method
// https://tc39.es/ecma262/#sec-array.prototype.map
// with adding support of @@species
$({ target: 'Array', proto: true, forced: !HAS_SPECIES_SUPPORT }, {
  map: function map(callbackfn /* , thisArg */) {
    return $map(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es.string.split.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es.string.split.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var fixRegExpWellKnownSymbolLogic = __webpack_require__(/*! ../internals/fix-regexp-well-known-symbol-logic */ "./node_modules/core-js/internals/fix-regexp-well-known-symbol-logic.js");
var isRegExp = __webpack_require__(/*! ../internals/is-regexp */ "./node_modules/core-js/internals/is-regexp.js");
var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/core-js/internals/an-object.js");
var requireObjectCoercible = __webpack_require__(/*! ../internals/require-object-coercible */ "./node_modules/core-js/internals/require-object-coercible.js");
var speciesConstructor = __webpack_require__(/*! ../internals/species-constructor */ "./node_modules/core-js/internals/species-constructor.js");
var advanceStringIndex = __webpack_require__(/*! ../internals/advance-string-index */ "./node_modules/core-js/internals/advance-string-index.js");
var toLength = __webpack_require__(/*! ../internals/to-length */ "./node_modules/core-js/internals/to-length.js");
var callRegExpExec = __webpack_require__(/*! ../internals/regexp-exec-abstract */ "./node_modules/core-js/internals/regexp-exec-abstract.js");
var regexpExec = __webpack_require__(/*! ../internals/regexp-exec */ "./node_modules/core-js/internals/regexp-exec.js");
var stickyHelpers = __webpack_require__(/*! ../internals/regexp-sticky-helpers */ "./node_modules/core-js/internals/regexp-sticky-helpers.js");

var UNSUPPORTED_Y = stickyHelpers.UNSUPPORTED_Y;
var arrayPush = [].push;
var min = Math.min;
var MAX_UINT32 = 0xFFFFFFFF;

// @@split logic
fixRegExpWellKnownSymbolLogic('split', 2, function (SPLIT, nativeSplit, maybeCallNative) {
  var internalSplit;
  if (
    'abbc'.split(/(b)*/)[1] == 'c' ||
    // eslint-disable-next-line regexp/no-empty-group -- required for testing
    'test'.split(/(?:)/, -1).length != 4 ||
    'ab'.split(/(?:ab)*/).length != 2 ||
    '.'.split(/(.?)(.?)/).length != 4 ||
    // eslint-disable-next-line regexp/no-assertion-capturing-group, regexp/no-empty-group -- required for testing
    '.'.split(/()()/).length > 1 ||
    ''.split(/.?/).length
  ) {
    // based on es5-shim implementation, need to rework it
    internalSplit = function (separator, limit) {
      var string = String(requireObjectCoercible(this));
      var lim = limit === undefined ? MAX_UINT32 : limit >>> 0;
      if (lim === 0) return [];
      if (separator === undefined) return [string];
      // If `separator` is not a regex, use native split
      if (!isRegExp(separator)) {
        return nativeSplit.call(string, separator, lim);
      }
      var output = [];
      var flags = (separator.ignoreCase ? 'i' : '') +
                  (separator.multiline ? 'm' : '') +
                  (separator.unicode ? 'u' : '') +
                  (separator.sticky ? 'y' : '');
      var lastLastIndex = 0;
      // Make `global` and avoid `lastIndex` issues by working with a copy
      var separatorCopy = new RegExp(separator.source, flags + 'g');
      var match, lastIndex, lastLength;
      while (match = regexpExec.call(separatorCopy, string)) {
        lastIndex = separatorCopy.lastIndex;
        if (lastIndex > lastLastIndex) {
          output.push(string.slice(lastLastIndex, match.index));
          if (match.length > 1 && match.index < string.length) arrayPush.apply(output, match.slice(1));
          lastLength = match[0].length;
          lastLastIndex = lastIndex;
          if (output.length >= lim) break;
        }
        if (separatorCopy.lastIndex === match.index) separatorCopy.lastIndex++; // Avoid an infinite loop
      }
      if (lastLastIndex === string.length) {
        if (lastLength || !separatorCopy.test('')) output.push('');
      } else output.push(string.slice(lastLastIndex));
      return output.length > lim ? output.slice(0, lim) : output;
    };
  // Chakra, V8
  } else if ('0'.split(undefined, 0).length) {
    internalSplit = function (separator, limit) {
      return separator === undefined && limit === 0 ? [] : nativeSplit.call(this, separator, limit);
    };
  } else internalSplit = nativeSplit;

  return [
    // `String.prototype.split` method
    // https://tc39.es/ecma262/#sec-string.prototype.split
    function split(separator, limit) {
      var O = requireObjectCoercible(this);
      var splitter = separator == undefined ? undefined : separator[SPLIT];
      return splitter !== undefined
        ? splitter.call(separator, O, limit)
        : internalSplit.call(String(O), separator, limit);
    },
    // `RegExp.prototype[@@split]` method
    // https://tc39.es/ecma262/#sec-regexp.prototype-@@split
    //
    // NOTE: This cannot be properly polyfilled in engines that don't support
    // the 'y' flag.
    function (regexp, limit) {
      var res = maybeCallNative(internalSplit, regexp, this, limit, internalSplit !== nativeSplit);
      if (res.done) return res.value;

      var rx = anObject(regexp);
      var S = String(this);
      var C = speciesConstructor(rx, RegExp);

      var unicodeMatching = rx.unicode;
      var flags = (rx.ignoreCase ? 'i' : '') +
                  (rx.multiline ? 'm' : '') +
                  (rx.unicode ? 'u' : '') +
                  (UNSUPPORTED_Y ? 'g' : 'y');

      // ^(? + rx + ) is needed, in combination with some S slicing, to
      // simulate the 'y' flag.
      var splitter = new C(UNSUPPORTED_Y ? '^(?:' + rx.source + ')' : rx, flags);
      var lim = limit === undefined ? MAX_UINT32 : limit >>> 0;
      if (lim === 0) return [];
      if (S.length === 0) return callRegExpExec(splitter, S) === null ? [S] : [];
      var p = 0;
      var q = 0;
      var A = [];
      while (q < S.length) {
        splitter.lastIndex = UNSUPPORTED_Y ? 0 : q;
        var z = callRegExpExec(splitter, UNSUPPORTED_Y ? S.slice(q) : S);
        var e;
        if (
          z === null ||
          (e = min(toLength(splitter.lastIndex + (UNSUPPORTED_Y ? q : 0)), S.length)) === p
        ) {
          q = advanceStringIndex(S, q, unicodeMatching);
        } else {
          A.push(S.slice(p, q));
          if (A.length === lim) return A;
          for (var i = 1; i <= z.length - 1; i++) {
            A.push(z[i]);
            if (A.length === lim) return A;
          }
          q = p = e;
        }
      }
      A.push(S.slice(p));
      return A;
    }
  ];
}, UNSUPPORTED_Y);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/SafeAllMange/SafeAllMange.vue?vue&type=style&index=0&id=24809ca5&lang=scss&scoped=true&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--8-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--8-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--8-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/mga-manage/SafeAllMange/SafeAllMange.vue?vue&type=style&index=0&id=24809ca5&lang=scss&scoped=true& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "#SafeAllMange_container[data-v-24809ca5] {\n  padding: 15px;\n}\n#SafeAllMange_container .query_title[data-v-24809ca5] {\n  background-color: #f4f4f5;\n  color: #909399;\n  font-size: 14px;\n  padding: 10px 10px;\n  margin-bottom: 15px;\n}\n#SafeAllMange_container .info_show span[data-v-24809ca5] {\n  display: inline-block;\n  padding: 10px;\n}\n#SafeAllMange_container .block-SafeAllMange[data-v-24809ca5] {\n  padding: 1em 0 1em 0;\n  border-top: 1px solid #ececec;\n  margin-top: 1em;\n}\n#SafeAllMange_container .block-SafeAllMange span[data-v-24809ca5] {\n  margin-right: 10px;\n}\n#SafeAllMange_container .block-SafeAllMange span[data-v-24809ca5]:nth-last-child(2) {\n  color: red;\n}\n#SafeAllMange_container .block-SafeAllMange span[data-v-24809ca5]:nth-last-child(2)::before {\n  content: \"*\";\n  vertical-align: middle;\n  margin-right: 0.3em;\n}\n.toolGroup[data-v-24809ca5] {\n  padding: 10px 10px 0 10px;\n  border-top: none;\n}\n.toolGroup .timeInput[data-v-24809ca5] {\n  margin-top: 10px;\n}\n.toolGroup .timeInput label[data-v-24809ca5] {\n  display: inline-block;\n  width: 180px;\n}\n.toolGroup .import[data-v-24809ca5] {\n  margin-top: 20px;\n  display: flex;\n}\n.toolGroup .import label[data-v-24809ca5] {\n  display: inline-block;\n  width: 80px;\n}\n.toolGroup .import .upload-demo[data-v-24809ca5] {\n  display: inline-block;\n}\n.toolGroup .import .el-upload-list[data-v-24809ca5] {\n  display: none;\n}\n.toolGroup .export[data-v-24809ca5] {\n  margin-top: 10px;\n  display: flex;\n}\n.toolGroup .export label[data-v-24809ca5] {\n  display: inline-block;\n  width: 80px;\n}\n.toolGroup .export > button[data-v-24809ca5] {\n  margin-left: 0 !important;\n}\n.toolGroup .tips[data-v-24809ca5] {\n  margin-left: 10px;\n  display: inline-block;\n  font-size: 12px;\n  color: red;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/SafeAllMange/SafeAllMange.vue?vue&type=style&index=0&id=24809ca5&lang=scss&scoped=true&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--8-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--8-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--8-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--8-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/mga-manage/SafeAllMange/SafeAllMange.vue?vue&type=style&index=0&id=24809ca5&lang=scss&scoped=true& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js??ref--8-oneOf-1-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--8-oneOf-1-2!../../../../node_modules/sass-loader/dist/cjs.js??ref--8-oneOf-1-3!../../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./SafeAllMange.vue?vue&type=style&index=0&id=24809ca5&lang=scss&scoped=true& */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/SafeAllMange/SafeAllMange.vue?vue&type=style&index=0&id=24809ca5&lang=scss&scoped=true&");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("4c912924", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/api/SafeAllMange/SafeAllMangeApi.js":
/*!*************************************************!*\
  !*** ./src/api/SafeAllMange/SafeAllMangeApi.js ***!
  \*************************************************/
/*! exports provided: getPreservationList, getCancellationPolicy */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getPreservationList", function() { return getPreservationList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCancellationPolicy", function() { return getCancellationPolicy; });
/* harmony import */ var _config_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/config/service */ "./src/config/service.js");
/* harmony import */ var _config_env__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/config/env */ "./src/config/env.js");
 //axios


function getPreservationList(data) {
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_0__["Service"])({
    url: _config_env__WEBPACK_IMPORTED_MODULE_1__["baseUrl"] + "/admin/preservation/list",
    method: "post",
    data: data
  });
}
function getCancellationPolicy(data) {
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_0__["Service"])({
    url: _config_env__WEBPACK_IMPORTED_MODULE_1__["baseUrl"] + "/admin/preservation/cancellationPolicy",
    method: "post",
    data: data
  });
}

/***/ }),

/***/ "./src/common/MixinUtils.js":
/*!**********************************!*\
  !*** ./src/common/MixinUtils.js ***!
  \**********************************/
/*! exports provided: tableMixin */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tableMixin", function() { return tableMixin; });
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! regenerator-runtime/runtime.js */ "./node_modules/regenerator-runtime/runtime.js");
/* harmony import */ var regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.entries.js */ "./node_modules/core-js/modules/es.object.entries.js");
/* harmony import */ var core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var components_common_Table__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/common/Table */ "./src/components/common/Table.vue");
/* harmony import */ var components_common_Pagination__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/common/Pagination */ "./src/components/common/Pagination.vue");
/* harmony import */ var components_common_Input__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/common/Input */ "./src/components/common/Input.vue");









var defaultDate = [{
  data: ['createDateBegin', 'createDateEnd']
}];
var tableMixin = {
  components: {
    Table: components_common_Table__WEBPACK_IMPORTED_MODULE_6__["default"],
    Pagination: components_common_Pagination__WEBPACK_IMPORTED_MODULE_7__["default"],
    Input: components_common_Input__WEBPACK_IMPORTED_MODULE_8__["default"]
  },
  data: function data() {
    return {
      // todo 查询的所有数据
      queryAllData: {},
      // todo 表格搜索数据
      queryData: {},
      cloneData: {},
      // todo 页码改变
      pageOption: {
        currentPage: 1,
        total: 0,
        pageSize: 10
      },
      // todo 时间选择
      pickerOptions: {
        shortcuts: [{
          text: '昨天',
          onClick: function onClick(picker) {
            var end = new Date();
            var start = new Date();
            start.setDate(start.getDate() - 1);
            end.setDate(end.getDate() - 1);
            picker.$emit('pick', [start, end]);
          }
        }, {
          text: '本周',
          onClick: function onClick(picker) {
            var end = new Date();
            var start = new Date();
            var currentDay = new Date().getDay() === 0 ? 7 : new Date().getDay();
            start.setDate(start.getDate() - currentDay + 1);
            end.setDate(end.getDate());
            picker.$emit('pick', [start, end]);
          }
        }, {
          text: '本月',
          onClick: function onClick(picker) {
            var end = new Date();
            var start = new Date();
            start.setDate(1);
            end.setMonth(end.getMonth() + 1);
            end.setDate(0);
            picker.$emit('pick', [start, end]);
          }
        }, {
          text: '上个月',
          onClick: function onClick(picker) {
            var end = new Date();
            var start = new Date();
            start.setMonth(start.getMonth() - 1);
            start.setDate(1);
            end.setDate(0);
            picker.$emit('pick', [start, end]);
          }
        }, {
          text: '最近三个月',
          onClick: function onClick(picker) {
            var end = new Date();
            var start = new Date();
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
            picker.$emit('pick', [start, end]);
          }
        }, {
          text: '本年',
          onClick: function onClick(picker) {
            var end = new Date();
            var start = new Date();
            start.setDate(1);
            start.setMonth(0);
            picker.$emit('pick', [start, end]);
          }
        }]
      }
    };
  },
  methods: {
    //todo 通用列表数据初始化
    getSelectList: function getSelectList(api, list, value, label, params) {
      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
        var _yield$api, data;

        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return api(params);

              case 2:
                _yield$api = _context.sent;
                data = _yield$api.data;

                if (list.length === 0) {
                  data.forEach(function (i) {
                    var obj = {};
                    obj.value = i[value];
                    obj.label = i[label];
                    list.push(obj);
                  });
                }

              case 5:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    // todo 通用查询
    getList: function getList(api, query, page, tableData, currentPage) {
      var _arguments = arguments,
          _this = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
        var dateArr, cb, data, result;
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                dateArr = _arguments.length > 5 && _arguments[5] !== undefined ? _arguments[5] : defaultDate;
                cb = _arguments.length > 6 ? _arguments[6] : undefined;
                data = JSON.parse(JSON.stringify(query)); // 处理页数

                data.pageNum = currentPage !== undefined ? page.currentPage = currentPage : page.currentPage = 1;
                data.pageSize = page.pageSize; // 处理时间

                dateArr.forEach(function (date) {
                  for (var _i = 0, _Object$entries = Object.entries(date); _i < _Object$entries.length; _i++) {
                    var _Object$entries$_i = Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__["default"])(_Object$entries[_i], 2),
                        key = _Object$entries$_i[0],
                        value = _Object$entries$_i[1];

                    if (data[key] !== null && data[key] !== undefined) {
                      data[value[0]] = data[key][0];
                      data[value[1]] = data[key][1];
                      delete data[key];
                    }
                  }
                }); // 请求结果

                _context2.next = 8;
                return api(data);

              case 8:
                result = _context2.sent;

                if (result !== null && result.code === 200 && result.data !== '') {
                  tableData.resultData = cb ? everyData(result.data.records, cb) : result.data.records;
                  page.total = result.data.total;
                  _this.queryAllData = result;
                } else if (result.data === '') {
                  tableData.resultData = [];
                  page.total = 0;
                }

                _this.cloneData = data;

              case 11:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    // todo 通用校验
    check: function check(message, key, value) {
      if (value === undefined && (key === '' || key === null || key === undefined)) {
        this.$message({
          type: 'error',
          message: message
        });
        throw new TypeError('填写的内容为空');
      } else if (value && key === value) {
        this.$message({
          type: 'error',
          message: message
        });
        throw new TypeError('填写的内容错误');
      }
    },
    // todo 点击查询按钮
    queryButton: function queryButton(e, apiNum) {
      this.requestDeploy();
    },
    // todo 页码改变
    currentPageChange: function currentPageChange(current) {
      this.requestDeploy(current);
    }
  }
}; // todo 过滤函数

function everyData(data, cb) {
  return data.map(function (item) {
    var arr = Object.entries(item);

    for (var _i2 = 0, _arr = arr; _i2 < _arr.length; _i2++) {
      var i = _arr[_i2];

      if (cb(i)) {
        item[cb(i)[0]] = cb(i)[1];
      }
    }

    return item;
  });
}

/***/ }),

/***/ "./src/common/dictionarieList/common.js":
/*!**********************************************!*\
  !*** ./src/common/dictionarieList/common.js ***!
  \**********************************************/
/*! exports provided: companyList, insuranceCompanyList, teamList, riskType, supplier, fromState */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "companyList", function() { return companyList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "insuranceCompanyList", function() { return insuranceCompanyList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "teamList", function() { return teamList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "riskType", function() { return riskType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "supplier", function() { return supplier; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fromState", function() { return fromState; });
var companyList = []; //渠道名称

var insuranceCompanyList = []; //公司名称

var teamList = []; //团队名称

var riskType = []; //险种类别

var supplier = []; //供应商名称
//保单状态

var fromState = [{
  value: 'UNINSURED',
  label: '未承保'
}, {
  value: 'ACPTINSD_FAILURE',
  label: '承保失败'
}, {
  value: 'ACPTINSD_SUCCESS',
  label: '承保成功'
}, {
  value: 'SURRENDER_FAILURE',
  label: '退保失败'
}, {
  value: 'SURRENDER_SUCCESS',
  label: '犹豫期退保成功'
}, {
  value: 'REVISIT_SUCCESS',
  label: '已回访'
}, {
  value: 'RECEIPT_SUCCESS',
  label: '回执成功'
}, {
  value: 'REFUNDPOLICY_SUCCESS',
  label: '退保终止'
}];

/***/ }),

/***/ "./src/common/tableDate/SafeAllMange.js":
/*!**********************************************!*\
  !*** ./src/common/tableDate/SafeAllMange.js ***!
  \**********************************************/
/*! exports provided: table */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "table", function() { return table; });
var table = [// 表格展示属性:列名、长度、颜色、是否需要点击事件、是否需要操作列、操作列名称
['orderId', '订单号', '', '', false, false], ['productName', '产品名称', '', '', false, false], ['companyName', '供应商名称', '', '', false, false], ['insuranceCompany', '保险公司名称', '', '', false, false], ['channelName', '渠道公司名称', '', '', false, false], ['policyNo', '保单号', '', '', false, false], ['appStatus', '保单状态', '', '', false, false], ['holderName', '投保人', '', '', false, false], ['agentName', '代理人', '', '', false, false], ['agentCode', '代理人编码', '', '', false, false], ['makeDate', '出单日期', '', '', false, false], ['insuredDate', '承保日期', '', '', false, false], ['surrenderDate', '退保日期', '', '', false, false]];

/***/ }),

/***/ "./src/views/mga-manage/SafeAllMange/SafeAllMange.vue":
/*!************************************************************!*\
  !*** ./src/views/mga-manage/SafeAllMange/SafeAllMange.vue ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SafeAllMange_vue_vue_type_template_id_24809ca5_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SafeAllMange.vue?vue&type=template&id=24809ca5&scoped=true& */ "./src/views/mga-manage/SafeAllMange/SafeAllMange.vue?vue&type=template&id=24809ca5&scoped=true&");
/* harmony import */ var _SafeAllMange_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SafeAllMange.vue?vue&type=script&lang=js& */ "./src/views/mga-manage/SafeAllMange/SafeAllMange.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _SafeAllMange_vue_vue_type_style_index_0_id_24809ca5_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SafeAllMange.vue?vue&type=style&index=0&id=24809ca5&lang=scss&scoped=true& */ "./src/views/mga-manage/SafeAllMange/SafeAllMange.vue?vue&type=style&index=0&id=24809ca5&lang=scss&scoped=true&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _SafeAllMange_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SafeAllMange_vue_vue_type_template_id_24809ca5_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SafeAllMange_vue_vue_type_template_id_24809ca5_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "24809ca5",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/mga-manage/SafeAllMange/SafeAllMange.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/mga-manage/SafeAllMange/SafeAllMange.vue?vue&type=script&lang=js&":
/*!*************************************************************************************!*\
  !*** ./src/views/mga-manage/SafeAllMange/SafeAllMange.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_12_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SafeAllMange_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--12-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./SafeAllMange.vue?vue&type=script&lang=js& */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/SafeAllMange/SafeAllMange.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_12_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SafeAllMange_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/mga-manage/SafeAllMange/SafeAllMange.vue?vue&type=style&index=0&id=24809ca5&lang=scss&scoped=true&":
/*!**********************************************************************************************************************!*\
  !*** ./src/views/mga-manage/SafeAllMange/SafeAllMange.vue?vue&type=style&index=0&id=24809ca5&lang=scss&scoped=true& ***!
  \**********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_8_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_8_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SafeAllMange_vue_vue_type_style_index_0_id_24809ca5_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-style-loader??ref--8-oneOf-1-0!../../../../node_modules/css-loader/dist/cjs.js??ref--8-oneOf-1-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--8-oneOf-1-2!../../../../node_modules/sass-loader/dist/cjs.js??ref--8-oneOf-1-3!../../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./SafeAllMange.vue?vue&type=style&index=0&id=24809ca5&lang=scss&scoped=true& */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/SafeAllMange/SafeAllMange.vue?vue&type=style&index=0&id=24809ca5&lang=scss&scoped=true&");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_8_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_8_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SafeAllMange_vue_vue_type_style_index_0_id_24809ca5_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_8_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_8_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SafeAllMange_vue_vue_type_style_index_0_id_24809ca5_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_8_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_8_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SafeAllMange_vue_vue_type_style_index_0_id_24809ca5_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_8_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_8_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SafeAllMange_vue_vue_type_style_index_0_id_24809ca5_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/mga-manage/SafeAllMange/SafeAllMange.vue?vue&type=template&id=24809ca5&scoped=true&":
/*!*******************************************************************************************************!*\
  !*** ./src/views/mga-manage/SafeAllMange/SafeAllMange.vue?vue&type=template&id=24809ca5&scoped=true& ***!
  \*******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SafeAllMange_vue_vue_type_template_id_24809ca5_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"b9734f90-vue-loader-template"}!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./SafeAllMange.vue?vue&type=template&id=24809ca5&scoped=true& */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"b9734f90-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/SafeAllMange/SafeAllMange.vue?vue&type=template&id=24809ca5&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SafeAllMange_vue_vue_type_template_id_24809ca5_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SafeAllMange_vue_vue_type_template_id_24809ca5_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=21.js.map