(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[4],{

/***/ "./node_modules/core-js/internals/string-trim-forced.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/internals/string-trim-forced.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
var whitespaces = __webpack_require__(/*! ../internals/whitespaces */ "./node_modules/core-js/internals/whitespaces.js");

var non = '\u200B\u0085\u180E';

// check that a method works with the correct list
// of whitespaces and has a correct name
module.exports = function (METHOD_NAME) {
  return fails(function () {
    return !!whitespaces[METHOD_NAME]() || non[METHOD_NAME]() != non || whitespaces[METHOD_NAME].name !== METHOD_NAME;
  });
};


/***/ }),

/***/ "./node_modules/core-js/internals/string-trim.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/internals/string-trim.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var requireObjectCoercible = __webpack_require__(/*! ../internals/require-object-coercible */ "./node_modules/core-js/internals/require-object-coercible.js");
var whitespaces = __webpack_require__(/*! ../internals/whitespaces */ "./node_modules/core-js/internals/whitespaces.js");

var whitespace = '[' + whitespaces + ']';
var ltrim = RegExp('^' + whitespace + whitespace + '*');
var rtrim = RegExp(whitespace + whitespace + '*$');

// `String.prototype.{ trim, trimStart, trimEnd, trimLeft, trimRight }` methods implementation
var createMethod = function (TYPE) {
  return function ($this) {
    var string = String(requireObjectCoercible($this));
    if (TYPE & 1) string = string.replace(ltrim, '');
    if (TYPE & 2) string = string.replace(rtrim, '');
    return string;
  };
};

module.exports = {
  // `String.prototype.{ trimLeft, trimStart }` methods
  // https://tc39.es/ecma262/#sec-string.prototype.trimstart
  start: createMethod(1),
  // `String.prototype.{ trimRight, trimEnd }` methods
  // https://tc39.es/ecma262/#sec-string.prototype.trimend
  end: createMethod(2),
  // `String.prototype.trim` method
  // https://tc39.es/ecma262/#sec-string.prototype.trim
  trim: createMethod(3)
};


/***/ }),

/***/ "./node_modules/core-js/internals/whitespaces.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/internals/whitespaces.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// a string of all valid unicode whitespaces
module.exports = '\u0009\u000A\u000B\u000C\u000D\u0020\u00A0\u1680\u2000\u2001\u2002' +
  '\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200A\u202F\u205F\u3000\u2028\u2029\uFEFF';


/***/ }),

/***/ "./node_modules/core-js/modules/es.string.trim.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es.string.trim.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var $trim = __webpack_require__(/*! ../internals/string-trim */ "./node_modules/core-js/internals/string-trim.js").trim;
var forcedStringTrimMethod = __webpack_require__(/*! ../internals/string-trim-forced */ "./node_modules/core-js/internals/string-trim-forced.js");

// `String.prototype.trim` method
// https://tc39.es/ecma262/#sec-string.prototype.trim
$({ target: 'String', proto: true, forced: forcedStringTrimMethod('trim') }, {
  trim: function trim() {
    return $trim(this);
  }
});


/***/ }),

/***/ "./src/api/mgaApi.js":
/*!***************************!*\
  !*** ./src/api/mgaApi.js ***!
  \***************************/
/*! exports provided: wageSettleApi, queryCountListApi, createCountOddApi, queryChannelCompanyApi, queryTeamApi, productSumTwoApi, productSumApi, queryConstructionListApi, queryBatchListApi, deleteBatchListApi, queryBatchDetailApi, updataBatchApi, sumBatchApi, exportBatchApi, exportThirdpartyApi, queryDetailChannelApi, queryGatheringApi, changeGatheringApi, DownGatheringTeamApi, queryAllBusinessApi, exportTableApi, institutionIncomeSumApi, institutionIncomeSumDetailApi, exportTableApi2, receiptListApi, signedReceiptDateApi, revisitListApi, signedRevisitDateApi, revisitDownload, receiptDownload, activityAddApi, activityUpdateApi, activityDetailApi, activityListApi, queryActivityUserListApi, activityDeleteApi, activeupdateStatusApi, queryProductListApi, channelCompanyListApi, channelCompanySaveApi, channelCompanyModifyApi, channelCompanyDetailApi, channelCompanyDeleteApi, channelGroupListApi, channelGroupSaveApi, channelGroupModifyApi, channelGroupDetailApi, channelGroupDeleteApi, companyListApi, bgDictApi, channelAgentListApi, channelAgentSaveApi, channelAgentDetailApi, channelAgentAuditApi, resignAuditResult, selectPeopleApi, getBank, groupSelectListApi, fValueBySKApi, getSettleList, settleUpdatestatus, downloadsettle, downloadApi, downRiskRateTemplateApi, importRiskRateApi, getRateAuditListApi, getRateByRiskCodeApi, getRateByBatchNoApi, updateByBatchNoApi, freelookListApi, signedFreelookDateApi, getPolicyInfoListApi, generateBatchApi, getBatchCheckResultsApi, getBatchDetailsApi, getBatchInfoListApi, deleteBatchApi, acceptApi, untreatedApi, setReceivableApi, setReceiptsApi, reconciliationCancelApi, downInscTemplateAPi, getPolicyInfoListExportApi, batchListApi, batchRemoveApi, batchDetailApi, batchExportApi, batchAccountListApi, batchOrderListApi, submitReviewApi, submitReviewApiTwo, auditReviewApi, getChannelProductInfoApi, channelCompanyProductOperApi, publishByListApi, publisherInfo, bgFminscomListApi, bgFminscomSaveApi, bgFminscomUpladeApi, bgFminscomDetailApi, bgFminscomDeleteApi, getChannelPremData, updatePremGrade, updateRateSwitch, getRateLevelAuditListApi, updateCommByBatchNoApi, getCommRateByProductCodeApi, getCommRateByBatchNoApi */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "wageSettleApi", function() { return wageSettleApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "queryCountListApi", function() { return queryCountListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createCountOddApi", function() { return createCountOddApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "queryChannelCompanyApi", function() { return queryChannelCompanyApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "queryTeamApi", function() { return queryTeamApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "productSumTwoApi", function() { return productSumTwoApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "productSumApi", function() { return productSumApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "queryConstructionListApi", function() { return queryConstructionListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "queryBatchListApi", function() { return queryBatchListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "deleteBatchListApi", function() { return deleteBatchListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "queryBatchDetailApi", function() { return queryBatchDetailApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updataBatchApi", function() { return updataBatchApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sumBatchApi", function() { return sumBatchApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "exportBatchApi", function() { return exportBatchApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "exportThirdpartyApi", function() { return exportThirdpartyApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "queryDetailChannelApi", function() { return queryDetailChannelApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "queryGatheringApi", function() { return queryGatheringApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "changeGatheringApi", function() { return changeGatheringApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DownGatheringTeamApi", function() { return DownGatheringTeamApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "queryAllBusinessApi", function() { return queryAllBusinessApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "exportTableApi", function() { return exportTableApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "institutionIncomeSumApi", function() { return institutionIncomeSumApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "institutionIncomeSumDetailApi", function() { return institutionIncomeSumDetailApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "exportTableApi2", function() { return exportTableApi2; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "receiptListApi", function() { return receiptListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "signedReceiptDateApi", function() { return signedReceiptDateApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "revisitListApi", function() { return revisitListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "signedRevisitDateApi", function() { return signedRevisitDateApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "revisitDownload", function() { return revisitDownload; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "receiptDownload", function() { return receiptDownload; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "activityAddApi", function() { return activityAddApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "activityUpdateApi", function() { return activityUpdateApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "activityDetailApi", function() { return activityDetailApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "activityListApi", function() { return activityListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "queryActivityUserListApi", function() { return queryActivityUserListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "activityDeleteApi", function() { return activityDeleteApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "activeupdateStatusApi", function() { return activeupdateStatusApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "queryProductListApi", function() { return queryProductListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "channelCompanyListApi", function() { return channelCompanyListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "channelCompanySaveApi", function() { return channelCompanySaveApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "channelCompanyModifyApi", function() { return channelCompanyModifyApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "channelCompanyDetailApi", function() { return channelCompanyDetailApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "channelCompanyDeleteApi", function() { return channelCompanyDeleteApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "channelGroupListApi", function() { return channelGroupListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "channelGroupSaveApi", function() { return channelGroupSaveApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "channelGroupModifyApi", function() { return channelGroupModifyApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "channelGroupDetailApi", function() { return channelGroupDetailApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "channelGroupDeleteApi", function() { return channelGroupDeleteApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "companyListApi", function() { return companyListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bgDictApi", function() { return bgDictApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "channelAgentListApi", function() { return channelAgentListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "channelAgentSaveApi", function() { return channelAgentSaveApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "channelAgentDetailApi", function() { return channelAgentDetailApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "channelAgentAuditApi", function() { return channelAgentAuditApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resignAuditResult", function() { return resignAuditResult; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectPeopleApi", function() { return selectPeopleApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getBank", function() { return getBank; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "groupSelectListApi", function() { return groupSelectListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fValueBySKApi", function() { return fValueBySKApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSettleList", function() { return getSettleList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "settleUpdatestatus", function() { return settleUpdatestatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "downloadsettle", function() { return downloadsettle; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "downloadApi", function() { return downloadApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "downRiskRateTemplateApi", function() { return downRiskRateTemplateApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "importRiskRateApi", function() { return importRiskRateApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getRateAuditListApi", function() { return getRateAuditListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getRateByRiskCodeApi", function() { return getRateByRiskCodeApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getRateByBatchNoApi", function() { return getRateByBatchNoApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateByBatchNoApi", function() { return updateByBatchNoApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "freelookListApi", function() { return freelookListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "signedFreelookDateApi", function() { return signedFreelookDateApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getPolicyInfoListApi", function() { return getPolicyInfoListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "generateBatchApi", function() { return generateBatchApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getBatchCheckResultsApi", function() { return getBatchCheckResultsApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getBatchDetailsApi", function() { return getBatchDetailsApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getBatchInfoListApi", function() { return getBatchInfoListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "deleteBatchApi", function() { return deleteBatchApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "acceptApi", function() { return acceptApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "untreatedApi", function() { return untreatedApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setReceivableApi", function() { return setReceivableApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setReceiptsApi", function() { return setReceiptsApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "reconciliationCancelApi", function() { return reconciliationCancelApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "downInscTemplateAPi", function() { return downInscTemplateAPi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getPolicyInfoListExportApi", function() { return getPolicyInfoListExportApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "batchListApi", function() { return batchListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "batchRemoveApi", function() { return batchRemoveApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "batchDetailApi", function() { return batchDetailApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "batchExportApi", function() { return batchExportApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "batchAccountListApi", function() { return batchAccountListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "batchOrderListApi", function() { return batchOrderListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "submitReviewApi", function() { return submitReviewApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "submitReviewApiTwo", function() { return submitReviewApiTwo; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "auditReviewApi", function() { return auditReviewApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getChannelProductInfoApi", function() { return getChannelProductInfoApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "channelCompanyProductOperApi", function() { return channelCompanyProductOperApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "publishByListApi", function() { return publishByListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "publisherInfo", function() { return publisherInfo; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bgFminscomListApi", function() { return bgFminscomListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bgFminscomSaveApi", function() { return bgFminscomSaveApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bgFminscomUpladeApi", function() { return bgFminscomUpladeApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bgFminscomDetailApi", function() { return bgFminscomDetailApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bgFminscomDeleteApi", function() { return bgFminscomDeleteApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getChannelPremData", function() { return getChannelPremData; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updatePremGrade", function() { return updatePremGrade; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateRateSwitch", function() { return updateRateSwitch; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getRateLevelAuditListApi", function() { return getRateLevelAuditListApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateCommByBatchNoApi", function() { return updateCommByBatchNoApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCommRateByProductCodeApi", function() { return getCommRateByProductCodeApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCommRateByBatchNoApi", function() { return getCommRateByBatchNoApi; });
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.string.trim.js */ "./node_modules/core-js/modules/es.string.trim.js");
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _config_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/config/service */ "./src/config/service.js");
/* harmony import */ var _config_env__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/config/env */ "./src/config/env.js");




 //axios


var loginBase = _config_env__WEBPACK_IMPORTED_MODULE_5__["baseUrl"]; //"http://10.20.110.94:8088" //http://10.20.110.94:8088 李必攀
//***********************MGA管理**************************
// -----------------------------------------------------结算管理-----------------------------------------------------------
//todo 1 代理人收入列表

function wageSettleApi(params) {
  var url = "".concat(loginBase, "/admin/wageSettle/list");
  var method = 'get';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} // todo 3 查询结算批次列表接口 ！

function queryCountListApi(params) {
  var url = "".concat(loginBase, "/admin/wageSettle/batchList");
  var method = 'get';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} // todo 1 代理人收入 生成结算单接口

function createCountOddApi(params) {
  var url = "".concat(loginBase, "/admin/wageSettle/generateBatch");
  var method = 'POST';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} // todo 1 查询渠道公司下拉框列表接口

function queryChannelCompanyApi(params) {
  var url = "".concat(loginBase, "/admin/channelCompany/companyList");
  var method = 'get';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} // todo 2 查询团队下拉框接口

function queryTeamApi(params) {
  var url = "".concat(loginBase, "/admin/channelGroup/groupSelect");
  var method = 'get';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} // todo 生成结算单接口（代理人、大B基础）

function productSumTwoApi(data) {
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: "".concat(loginBase, "/admin/wageSettle/generateBatch"),
    method: 'POST',
    data: data
  });
}
/**
 * @杨浩接口
 */
//todo 生成结算表

function productSumApi(params) {
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: "".concat(loginBase, "/admin/wageBatch/settlement"),
    method: 'get',
    params: params
  });
} // todo 2  查询活动结构列表查询

function queryConstructionListApi(data) {
  var url = "".concat(loginBase, "/admin/wageBatch/list");
  var method = 'post';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    data: data
  });
} // -----------------------------------------------------结算批次列表-----------------------------------------------------------

/**
 * @杨浩接口
 */
// todo 查询批次列表

function queryBatchListApi(data) {
  var url = "".concat(loginBase, "/admin/batch/list");
  var method = 'POST';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    data: data
  });
} // todo 删除批次

function deleteBatchListApi(params) {
  var url = "".concat(loginBase, "/admin/batch/remove");
  var method = 'get';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //todo  1.6	批次表详情接口

function queryBatchDetailApi(params) {
  var url = "".concat(loginBase, "/admin/batch/detail");
  var method = 'get';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //todo  1.7	手动修改数据接口

function updataBatchApi(params) {
  var url = "".concat(loginBase, "/admin/batch/update");
  var method = 'get';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //todo  1.8	批次详情结算接口

function sumBatchApi(params) {
  var url = "".concat(loginBase, "/admin/batch/amount");
  var method = 'get';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //todo 1.9	批次详情导出接口

function exportBatchApi(params) {
  var jsontoQuery = function jsontoQuery(params) {
    //定义一个空数组
    var ary = [];
    var str; //对象的遍历操作

    for (var i in params) {
      // todo 对象是否有这个属性
      if (params.hasOwnProperty(i)) {
        //将对象名push到数组里
        ary.push(i); //对象的值

        ary.push("=".concat(params[i], "&"));
      }
    } //将数组转变成字符串  //todo 将字符串最后一个&符剪切走 返回新数组


    str = ary.join('').trim();
    str = str.slice(0, str.length - 1);
    return str;
  };

  var queryString = jsontoQuery(params);
  window.location.href = "".concat(loginBase, "/admin/batch/export") + '?' + queryString;
} //第三方导出

function exportThirdpartyApi(params) {
  var jsontoQuery = function jsontoQuery(params) {
    //定义一个空数组
    var ary = [];
    var str; //对象的遍历操作

    for (var i in params) {
      // todo 对象是否有这个属性
      if (params.hasOwnProperty(i)) {
        //将对象名push到数组里
        ary.push(i); //对象的值

        ary.push("=".concat(params[i], "&"));
      }
    } //将数组转变成字符串  //todo 将字符串最后一个&符剪切走 返回新数组


    str = ary.join('').trim();
    str = str.slice(0, str.length - 1);
    return str;
  };

  var queryString = jsontoQuery(params);
  window.location.href = "".concat(loginBase, "/admin/batch/exportThirdparty") + '?' + queryString;
} // todo 1.10	渠道订单明细查询接口

function queryDetailChannelApi(params) {
  var url = "".concat(loginBase, "/admin/batchOrder/list");
  var method = 'get';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} // -----------------------------------------------------体现申请-----------------------------------------------------------
//todo 	2.1	提现申请管理-查询接口

function queryGatheringApi(params) {
  var url = "".concat(loginBase, "/admin/userWithdraw/list");
  var method = 'get';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //todo 2.2	修改结算状态接口

function changeGatheringApi(data) {
  var url = "".concat(loginBase, "/admin/userWithdraw/modify");
  var method = 'POST';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    data: data
  });
} // todo 2.3	下载接口

function DownGatheringTeamApi(params) {
  var jsontoQuery = function jsontoQuery(params) {
    //定义一个空数组
    var ary = [];
    var str; //对象的遍历操作

    for (var i in params) {
      // todo 对象是否有这个属性
      if (params.hasOwnProperty(i)) {
        //将对象名push到数组里
        ary.push(i); //对象的值

        ary.push("=".concat(params[i], "&"));
      }
    } //将数组转变成字符串  //todo 将字符串最后一个&符剪切走 返回新数组


    str = ary.join('').trim();
    str = str.slice(0, str.length - 1);
    return str;
  };

  var queryString = jsontoQuery(params);
  window.location.href = "".concat(loginBase, "/admin/userWithdraw/Excel") + '?' + queryString;
} // -----------------------------------------------------机构业务统计-----------------------------------------------------------
//todo 查询所有业务接口

function queryAllBusinessApi(params) {
  var url = "".concat(loginBase, "/admin/ibs/condtionQuery");
  var method = 'get';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //todo 导出表格

function exportTableApi(params) {
  var jsontoQuery = function jsontoQuery(params) {
    //定义一个空数组
    var ary = [];
    var str; //对象的遍历操作

    for (var i in params) {
      // todo 对象是否有这个属性
      if (params.hasOwnProperty(i)) {
        //将对象名push到数组里
        ary.push(i); //对象的值

        ary.push("=".concat(params[i], "&"));
      }
    } //将数组转变成字符串  //todo 将字符串最后一个&符剪切走 返回新数组


    str = ary.join('').trim();
    str = str.slice(0, str.length - 1);
    return str;
  };

  var queryString = jsontoQuery(params);
  console.log("".concat(loginBase, "/admin/ibs/Excel") + '?' + queryString);
  window.location.href = "".concat(loginBase, "/admin/ibs/Excel") + '?' + queryString;
} // -----------------------------------------------------机构收入统计-----------------------------------------------------------
// todo 查询所有数据

function institutionIncomeSumApi(params) {
  var url = "".concat(loginBase, "/admin/orderWageBatch/list");
  var method = 'get';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
}
function institutionIncomeSumDetailApi(params) {
  var url = "".concat(loginBase, "/admin/orderWageBatch/details");
  var method = 'get';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
}
function exportTableApi2(params) {
  var jsontoQuery = function jsontoQuery(params) {
    //定义一个空数组
    var ary = [];
    var str; //对象的遍历操作

    for (var i in params) {
      // todo 对象是否有这个属性
      if (params.hasOwnProperty(i)) {
        //将对象名push到数组里
        ary.push(i); //对象的值

        ary.push("=".concat(params[i], "&"));
      }
    } //将数组转变成字符串  //todo 将字符串最后一个&符剪切走 返回新数组


    str = ary.join('').trim();
    str = str.slice(0, str.length - 1);
    return str;
  };

  var queryString = jsontoQuery(params);
  window.location.href = "".concat(loginBase, "/admin/orderWageBatch/Excel") + '?' + queryString;
} // ----------------------------------------------------------------------------------------------------------------
//回执管理

var loginURL = ' http://10.20.150.87:8089';
function receiptListApi(data) {
  var url = "".concat(loginBase, "/admin/receipt/list");
  var method = 'POST';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //回执日期填写

function signedReceiptDateApi(data) {
  var url = "".concat(loginBase, "/admin/receipt/signedReceiptDate");
  var method = 'POST';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //保单回访列表

function revisitListApi(data) {
  var url = "".concat(loginBase, "/admin/revisit/list");
  var method = 'POST';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //保单回访日期维护

function signedRevisitDateApi(data) {
  var url = "".concat(loginBase, "/admin/revisit/signedRevisitDate");
  var method = 'POST';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //回访模版下载

function revisitDownload(params) {
  function jsontoQuery(params) {
    //定义一个空数组
    var ary = [];
    var str; //对象的遍历操作

    for (var i in params) {
      //将对象名push到数组里
      ary.push(i); //对象的值

      ary.push("=".concat(params[i], "& "));
    } //将数组转变成字符串


    str = ary.join(''); //将字符串最后一个&符剪切走

    str = str.slice(0, str.length - 1);
    return str;
  }

  var queryString = jsontoQuery(params);
  var url = "".concat(loginBase, "/admin/revisit/download");
  window.location.href = url;
} //回执导出数据

function receiptDownload(params) {
  function jsontoQuery(params) {
    //定义一个空数组
    var ary = [];
    var str; //对象的遍历操作

    for (var i in params) {
      //将对象名push到数组里
      ary.push(i); //对象的值

      ary.push("=".concat(params[i], "& "));
    } //将数组转变成字符串


    str = ary.join(''); //将字符串最后一个&符剪切走

    str = str.slice(0, str.length - 1);
    return str;
  }

  var queryString = jsontoQuery(params);
  var url = "".concat(loginBase, "/admin/receipt/download");
  window.location.href = url;
} //活动管理-添加

function activityAddApi(data) {
  var url = "".concat(loginBase, "/admin/activity/add");
  var method = 'POST';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //活动管理-修改

function activityUpdateApi(data) {
  var url = "".concat(loginBase, "/admin/activity/update");
  var method = 'POST';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //活动管理-获取详情

function activityDetailApi(params) {
  var url = "".concat(loginBase, "/admin/activity/queryActivityInfo");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //活动管理-活动列表

function activityListApi(params) {
  var url = "".concat(loginBase, "/admin/activity/list");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //活动管理-根据类型查询活动对象

function queryActivityUserListApi(params) {
  var url = "".concat(loginBase, "/admin/activity/queryActivityUserList");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //活动管理-删除活动

function activityDeleteApi(params) {
  var url = "".concat(loginBase, "/admin/activity/delete");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //活动管理-活动上架下架

function activeupdateStatusApi(params) {
  var url = "".concat(loginBase, "/admin/activity/updateStatus");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //活动管理-查询活动产品列表

function queryProductListApi(params) {
  var url = "".concat(loginBase, "/admin/activity/queryProductList");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //渠道-公司列表

function channelCompanyListApi(params) {
  var url = "".concat(loginBase, "/admin/channelCompany/list");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //渠道-公司新增

function channelCompanySaveApi(data) {
  var url = "".concat(loginBase, "/admin/channelCompany/save");
  var method = 'POST';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //渠道-公司修改

function channelCompanyModifyApi(data) {
  var url = "".concat(loginBase, "/admin/channelCompany/modify");
  var method = 'POST';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //渠道-公司详情

function channelCompanyDetailApi(params) {
  var url = "".concat(loginBase, "/admin/channelCompany/detail");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //渠道-公司删除

function channelCompanyDeleteApi(params) {
  var url = "".concat(loginBase, "/admin/channelCompany/delete");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //渠道-团队列表

function channelGroupListApi(params) {
  var url = "".concat(loginBase, "/admin/channelGroup/list");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //渠道-团队新增

function channelGroupSaveApi(data) {
  var url = "".concat(loginBase, "/admin/channelGroup/save");
  var method = 'POST';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //渠道-团队修改

function channelGroupModifyApi(data) {
  var url = "".concat(loginBase, "/admin/channelGroup/modify");
  var method = 'POST';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //渠道-团队详情

function channelGroupDetailApi(params) {
  var url = "".concat(loginBase, "/admin/channelGroup/detail");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //渠道-团队删除

function channelGroupDeleteApi(params) {
  var url = "".concat(loginBase, "/admin/channelGroup/delete");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //todo 获取公司列表

function companyListApi(params) {
  var url = "".concat(loginBase, "/admin/channelCompany/companyList");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //获取地区列表

function bgDictApi(params) {
  var url = "".concat(loginBase, "/admin/bgDict/list");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //渠道-人员列表

function channelAgentListApi(params) {
  var url = "".concat(loginBase, "/admin/agent/list");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //渠道-人员保存

function channelAgentSaveApi(data) {
  var url = "".concat(loginBase, "/admin/agent/save");
  var method = 'POST';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //渠道-人员详情

function channelAgentDetailApi(params) {
  var url = "".concat(loginBase, "/admin/agent/detail");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //渠道-人员审核/拒绝

function channelAgentAuditApi(data) {
  var url = "".concat(loginBase, "/admin/agent/audit");
  var method = 'POST';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    data: data
  });
}
function resignAuditResult(params) {
  var url = "/admin/agent/resignAuditResult";
  var method = 'get';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
}
function selectPeopleApi(params) {
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: _config_env__WEBPACK_IMPORTED_MODULE_5__["baseUrl"] + '/admin/order/agent/selectAim',
    method: 'GET',
    params: params
  });
}
function getBank(params) {
  var url = "".concat(loginBase, "/account/dev/fValueList?dicttypeName=mgabanktype");
  var method = 'get';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //渠道-人员 下拉框选择渠道团队列表接口

function groupSelectListApi(params) {
  var url = "".concat(loginBase, "/admin/channelGroup/groupSelectList");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
}
function fValueBySKApi(params) {
  var url = "".concat(loginBase, "/account/dev/fValueList");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //查询结算列表

function getSettleList(params) {
  var url = "".concat(loginBase, "/admin/settlement/list");
  var method = 'get';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //查询结算列表

function settleUpdatestatus(data) {
  var url = "".concat(loginBase, "/admin/settlement/updatestatus");
  var method = 'POST';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //下载待结算列表

function downloadsettle(data) {
  var url = "".concat(loginBase, "/admin/settlement/download");
  var method = 'POST';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //渠道-人员 人员管理-下载模板

function downloadApi(params) {
  function jsontoQuery(params) {
    //定义一个空数组
    var ary = [];
    var str; //对象的遍历操作

    for (var i in params) {
      //将对象名push到数组里
      ary.push(i); //对象的值

      ary.push("=".concat(params[i], "& "));
    } //将数组转变成字符串


    str = ary.join(''); //将字符串最后一个&符剪切走

    str = str.slice(0, str.length - 1);
    return str;
  }

  var queryString = jsontoQuery(params);
  var url = "".concat(loginBase, "/admin/agent/download").concat(queryString);
  window.location.href = url;
} //手续费率
//导出手续费率模版

function downRiskRateTemplateApi(params) {
  function jsontoQuery(params) {
    //定义一个空数组
    var ary = [];
    var str; //对象的遍历操作

    for (var i in params) {
      //将对象名push到数组里
      ary.push(i); //对象的值

      ary.push("=".concat(params[i], "& "));
    } //将数组转变成字符串


    str = ary.join(''); //将字符串最后一个&符剪切走

    str = str.slice(0, str.length - 1);
    return str;
  }

  var queryString = jsontoQuery(params);
  var url = "".concat(loginBase, "/admin/product/downRiskRateTemplate");
  window.location.href = url;
} //导入产品费率

function importRiskRateApi(data) {
  var url = "".concat(loginBase, "/admin/product/importRiskRate");
  var method = 'POST';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //查询产品审核列表

function getRateAuditListApi(params) {
  var url = "".concat(loginBase, "/admin/product/getRateAuditList");
  var method = 'get';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //根据产品编码查出查询费率

function getRateByRiskCodeApi(params) {
  var url = "".concat(loginBase, "/admin/product/getRateByRiskCode");
  var method = 'get';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //根据产品编码查出查询费率

function getRateByBatchNoApi(params) {
  var url = "".concat(loginBase, "/admin/product/getRateByBatchNo");
  var method = 'get';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //产品费率删除

function updateByBatchNoApi(data) {
  var url = "".concat(loginBase, "/admin/product/updateByBatchNo");
  var method = 'POST';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    data: data
  });
} // 犹豫期管理 -列表查询

function freelookListApi(data) {
  var url = "".concat(loginBase, "/admin/freelook/list");
  var method = 'POST';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //犹豫期管理 - 犹豫期状态管理

function signedFreelookDateApi(data) {
  var url = "".concat(loginBase, "/admin/freelook/signedFreelookDate");
  var method = 'POST';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    data: data
  });
} // -----------------------------对账管理-----------------------------------------------------------
//对账管理 - 列表查询

function getPolicyInfoListApi(params) {
  var url = "".concat(loginBase, "/admin/reconciliation/getPolicyInfoList");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //对账管理 - 生成批次

function generateBatchApi(data) {
  var url = "".concat(loginBase, "/admin/reconciliation/generateBatch");
  var method = 'POST';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //对账批次 - 获取对账结果

function getBatchCheckResultsApi(params) {
  var url = "".concat(loginBase, "/admin/reconciliation/getBatchCheckResults");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //对账批次 - 对账详情

function getBatchDetailsApi(params) {
  var url = "".concat(loginBase, "/admin/reconciliation/getBatchDetails");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //对账批次 - 获取批次列表

function getBatchInfoListApi(params) {
  var url = "".concat(loginBase, "/admin/reconciliation/getBatchInfoList");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //对账批次 - 删除批次

function deleteBatchApi(params) {
  var url = "".concat(loginBase, "/admin/reconciliation/deleteBatch");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //对账详情 -接受

function acceptApi(params) {
  var url = "".concat(loginBase, "/admin/reconciliation/accept");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //对账详情 -本次不处理

function untreatedApi(data) {
  var url = "".concat(loginBase, "/admin/reconciliation/untreated");
  var method = 'POST';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //对账详情 -设为应收

function setReceivableApi(data) {
  var url = "".concat(loginBase, "/admin/reconciliation/setReceivable");
  var method = 'POST';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //对账详情 -设为实收

function setReceiptsApi(params) {
  var url = "".concat(loginBase, "/admin/reconciliation/setReceipts");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //对账结果 -取消核对

function reconciliationCancelApi(params) {
  var url = "".concat(loginBase, "/admin/reconciliation/cancel");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //对账管理 - 下载保单对账模版

function downInscTemplateAPi(params) {
  function jsontoQuery(params) {
    //定义一个空数组
    var ary = [];
    var str; //对象的遍历操作

    for (var i in params) {
      //将对象名push到数组里
      ary.push(i); //对象的值

      ary.push("=".concat(params[i], "& "));
    } //将数组转变成字符串


    str = ary.join(''); //将字符串最后一个&符剪切走

    str = str.slice(0, str.length - 1);
    return str;
  }

  var queryString = jsontoQuery(params);
  var url = "".concat(loginBase, "/admin/reconciliation/downInscTemplate");
  window.location.href = url;
} // 对账管理 - 导出

function getPolicyInfoListExportApi(params) {
  function jsontoQuery(params) {
    var arr = [];
    var str = "";

    for (var i in params) {
      arr.push(i);
      arr.push("=".concat(params[i], "&"));
    }

    str = arr.join('');
    str = str.slice(0, str.length - 1);
    str = "?" + str;
    return str;
  }

  var queryString = jsontoQuery(params);
  var url = "".concat(loginBase, "/admin/reconciliation/getPolicyInfoListExport").concat(queryString);
  console.log(url, "url");
  window.location.href = url;
}
/*****************************结算批次列表*****************************/
//结算批次 -列表查询

function batchListApi(params) {
  var url = "".concat(loginBase, "/admin/batch/list");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //结算批次 -删除批次

function batchRemoveApi(params) {
  var url = "".concat(loginBase, "/admin/batch/remove");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //结算批次 -批次详情

function batchDetailApi(params) {
  var url = "".concat(loginBase, "/admin/wageSettle/wageBatchDetail");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //结算批次 -批次详情-导出接口

function batchExportApi(params) {
  function jsontoQuery(params) {
    //定义一个空数组
    var ary = [];
    var str; //对象的遍历操作

    for (var i in params) {
      //将对象名push到数组里
      ary.push(i); //对象的值

      ary.push("=".concat(params[i], "& "));
    } //将数组转变成字符串


    str = ary.join(''); //将字符串最后一个&符剪切走

    str = str.slice(0, str.length - 1);
    return str;
  }

  var queryString = jsontoQuery(params);
  var url = "".concat(loginBase, "/admin/batch/export");
  window.location.href = url;
} //结算批次 -批次详情-结算列表接口

function batchAccountListApi(params) {
  var url = "".concat(loginBase, "/admin/batch/amount");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //结算批次 -批次详情-渠道订单明细

function batchOrderListApi(params) {
  var url = "".concat(loginBase, "/admin/batchOrder/list");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //结算批次 -批次详情-提交复核

function submitReviewApi(data) {
  var url = "".concat(loginBase, "/admin/wageSettle/submitReview");
  var method = 'POST';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    data: data
  });
}
function submitReviewApiTwo(params) {
  var url = "".concat(loginBase, "/admin/batch/submitReview");
  var method = 'get';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //结算批次 -批次详情-确认付款

function auditReviewApi(data) {
  var url = "".concat(loginBase, "/admin/wageSettle/auditReview");
  var method = 'POST';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //获取渠道产品信息列表：

function getChannelProductInfoApi(params) {
  var url = "".concat(loginBase, "/admin/channelCompany/getChannelProductInfo");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //渠道产品上线下线

function channelCompanyProductOperApi(data) {
  var url = "".concat(loginBase, "/admin/channelCompany/operation");
  var method = 'POST';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //接收人类型

function publishByListApi(params) {
  var url = "".concat(loginBase, "/admin/activity/publishByList");
  var method = 'GET';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} // todo 发布人下

function publisherInfo(params) {
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: "".concat(_config_env__WEBPACK_IMPORTED_MODULE_5__["baseUrl"], "/admin/activity/publishByList"),
    method: 'get',
    params: params
  });
} //供应商管理-列表查询

function bgFminscomListApi(params) {
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: "".concat(_config_env__WEBPACK_IMPORTED_MODULE_5__["baseUrl"], "/admin/bgFminscom/list"),
    method: 'get',
    params: params
  });
} //供应商管理-新增

function bgFminscomSaveApi(data) {
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: "".concat(_config_env__WEBPACK_IMPORTED_MODULE_5__["baseUrl"], "/admin/bgFminscom/save"),
    method: 'POST',
    data: data
  });
} //供应商管理-修改

function bgFminscomUpladeApi(data) {
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: "".concat(_config_env__WEBPACK_IMPORTED_MODULE_5__["baseUrl"], "/admin/bgFminscom/update"),
    method: 'post',
    data: data
  });
} //供应商管理-详情

function bgFminscomDetailApi(params) {
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: "".concat(_config_env__WEBPACK_IMPORTED_MODULE_5__["baseUrl"], "/admin/bgFminscom/detail"),
    method: 'get',
    params: params
  });
} //供应商管理-删除

function bgFminscomDeleteApi(params) {
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: "".concat(_config_env__WEBPACK_IMPORTED_MODULE_5__["baseUrl"], "/admin/bgFminscom/delete"),
    method: 'get',
    params: params
  });
} //获取渠道公司的考核保费

function getChannelPremData(params) {
  var url = "".concat(loginBase, "/admin/channelCompany/selectLevel");
  var method = "get";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //更新渠道公司考核保费

function updatePremGrade(data) {
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: "".concat(_config_env__WEBPACK_IMPORTED_MODULE_5__["baseUrl"], "/admin/channelCompany/saveLevel"),
    method: 'post',
    data: data
  });
} //修改费率等级开关

function updateRateSwitch(params) {
  var url = "".concat(loginBase, "/admin/channelCompany/updateRateStatus");
  var method = "post";
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //查询产品审核列表 佣金

function getRateLevelAuditListApi(params) {
  var url = "".concat(loginBase, "/admin/commission/getRateLevelAuditList");
  var method = 'get';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //佣金费率删除

function updateCommByBatchNoApi(data) {
  var url = "".concat(loginBase, "/admin/commission/updateLevelByBatchNo");
  var method = 'POST';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    data: data
  });
} //根据产品编码查出查询佣金费率

function getCommRateByProductCodeApi(params) {
  var url = "".concat(loginBase, "/admin/commission/getRateByRiskCode");
  var method = 'get';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
} //根据批次号 查出查询佣金费率

function getCommRateByBatchNoApi(params) {
  var url = "".concat(loginBase, "/admin/commission/getRateByBatchNo");
  var method = 'get';
  return Object(_config_service__WEBPACK_IMPORTED_MODULE_4__["Service"])({
    url: url,
    method: method,
    params: params
  });
}

/***/ })

}]);
//# sourceMappingURL=4.js.map