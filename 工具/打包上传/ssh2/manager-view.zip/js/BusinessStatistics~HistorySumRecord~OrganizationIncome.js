(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["BusinessStatistics~HistorySumRecord~OrganizationIncome"],{

/***/ "./node_modules/core-js/internals/inherit-if-required.js":
/*!***************************************************************!*\
  !*** ./node_modules/core-js/internals/inherit-if-required.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");
var setPrototypeOf = __webpack_require__(/*! ../internals/object-set-prototype-of */ "./node_modules/core-js/internals/object-set-prototype-of.js");

// makes subclassing work correct for wrapped built-ins
module.exports = function ($this, dummy, Wrapper) {
  var NewTarget, NewTargetPrototype;
  if (
    // it can work only with native `setPrototypeOf`
    setPrototypeOf &&
    // we haven't completely correct pre-ES6 way for getting `new.target`, so use this
    typeof (NewTarget = dummy.constructor) == 'function' &&
    NewTarget !== Wrapper &&
    isObject(NewTargetPrototype = NewTarget.prototype) &&
    NewTargetPrototype !== Wrapper.prototype
  ) setPrototypeOf($this, NewTargetPrototype);
  return $this;
};


/***/ }),

/***/ "./node_modules/core-js/internals/is-regexp.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/internals/is-regexp.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");
var classof = __webpack_require__(/*! ../internals/classof-raw */ "./node_modules/core-js/internals/classof-raw.js");
var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");

var MATCH = wellKnownSymbol('match');

// `IsRegExp` abstract operation
// https://tc39.es/ecma262/#sec-isregexp
module.exports = function (it) {
  var isRegExp;
  return isObject(it) && ((isRegExp = it[MATCH]) !== undefined ? !!isRegExp : classof(it) == 'RegExp');
};


/***/ }),

/***/ "./node_modules/core-js/modules/es.array.map.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/es.array.map.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var $map = __webpack_require__(/*! ../internals/array-iteration */ "./node_modules/core-js/internals/array-iteration.js").map;
var arrayMethodHasSpeciesSupport = __webpack_require__(/*! ../internals/array-method-has-species-support */ "./node_modules/core-js/internals/array-method-has-species-support.js");

var HAS_SPECIES_SUPPORT = arrayMethodHasSpeciesSupport('map');

// `Array.prototype.map` method
// https://tc39.es/ecma262/#sec-array.prototype.map
// with adding support of @@species
$({ target: 'Array', proto: true, forced: !HAS_SPECIES_SUPPORT }, {
  map: function map(callbackfn /* , thisArg */) {
    return $map(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es.regexp.constructor.js":
/*!***************************************************************!*\
  !*** ./node_modules/core-js/modules/es.regexp.constructor.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/core-js/internals/descriptors.js");
var global = __webpack_require__(/*! ../internals/global */ "./node_modules/core-js/internals/global.js");
var isForced = __webpack_require__(/*! ../internals/is-forced */ "./node_modules/core-js/internals/is-forced.js");
var inheritIfRequired = __webpack_require__(/*! ../internals/inherit-if-required */ "./node_modules/core-js/internals/inherit-if-required.js");
var defineProperty = __webpack_require__(/*! ../internals/object-define-property */ "./node_modules/core-js/internals/object-define-property.js").f;
var getOwnPropertyNames = __webpack_require__(/*! ../internals/object-get-own-property-names */ "./node_modules/core-js/internals/object-get-own-property-names.js").f;
var isRegExp = __webpack_require__(/*! ../internals/is-regexp */ "./node_modules/core-js/internals/is-regexp.js");
var getFlags = __webpack_require__(/*! ../internals/regexp-flags */ "./node_modules/core-js/internals/regexp-flags.js");
var stickyHelpers = __webpack_require__(/*! ../internals/regexp-sticky-helpers */ "./node_modules/core-js/internals/regexp-sticky-helpers.js");
var redefine = __webpack_require__(/*! ../internals/redefine */ "./node_modules/core-js/internals/redefine.js");
var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
var enforceInternalState = __webpack_require__(/*! ../internals/internal-state */ "./node_modules/core-js/internals/internal-state.js").enforce;
var setSpecies = __webpack_require__(/*! ../internals/set-species */ "./node_modules/core-js/internals/set-species.js");
var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");

var MATCH = wellKnownSymbol('match');
var NativeRegExp = global.RegExp;
var RegExpPrototype = NativeRegExp.prototype;
var re1 = /a/g;
var re2 = /a/g;

// "new" should create a new object, old webkit bug
var CORRECT_NEW = new NativeRegExp(re1) !== re1;

var UNSUPPORTED_Y = stickyHelpers.UNSUPPORTED_Y;

var FORCED = DESCRIPTORS && isForced('RegExp', (!CORRECT_NEW || UNSUPPORTED_Y || fails(function () {
  re2[MATCH] = false;
  // RegExp constructor can alter flags and IsRegExp works correct with @@match
  return NativeRegExp(re1) != re1 || NativeRegExp(re2) == re2 || NativeRegExp(re1, 'i') != '/a/i';
})));

// `RegExp` constructor
// https://tc39.es/ecma262/#sec-regexp-constructor
if (FORCED) {
  var RegExpWrapper = function RegExp(pattern, flags) {
    var thisIsRegExp = this instanceof RegExpWrapper;
    var patternIsRegExp = isRegExp(pattern);
    var flagsAreUndefined = flags === undefined;
    var sticky;

    if (!thisIsRegExp && patternIsRegExp && pattern.constructor === RegExpWrapper && flagsAreUndefined) {
      return pattern;
    }

    if (CORRECT_NEW) {
      if (patternIsRegExp && !flagsAreUndefined) pattern = pattern.source;
    } else if (pattern instanceof RegExpWrapper) {
      if (flagsAreUndefined) flags = getFlags.call(pattern);
      pattern = pattern.source;
    }

    if (UNSUPPORTED_Y) {
      sticky = !!flags && flags.indexOf('y') > -1;
      if (sticky) flags = flags.replace(/y/g, '');
    }

    var result = inheritIfRequired(
      CORRECT_NEW ? new NativeRegExp(pattern, flags) : NativeRegExp(pattern, flags),
      thisIsRegExp ? this : RegExpPrototype,
      RegExpWrapper
    );

    if (UNSUPPORTED_Y && sticky) {
      var state = enforceInternalState(result);
      state.sticky = true;
    }

    return result;
  };
  var proxy = function (key) {
    key in RegExpWrapper || defineProperty(RegExpWrapper, key, {
      configurable: true,
      get: function () { return NativeRegExp[key]; },
      set: function (it) { NativeRegExp[key] = it; }
    });
  };
  var keys = getOwnPropertyNames(NativeRegExp);
  var index = 0;
  while (keys.length > index) proxy(keys[index++]);
  RegExpPrototype.constructor = RegExpWrapper;
  RegExpWrapper.prototype = RegExpPrototype;
  redefine(global, 'RegExp', RegExpWrapper);
}

// https://tc39.es/ecma262/#sec-get-regexp-@@species
setSpecies('RegExp');


/***/ }),

/***/ "./node_modules/core-js/modules/es.regexp.to-string.js":
/*!*************************************************************!*\
  !*** ./node_modules/core-js/modules/es.regexp.to-string.js ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var redefine = __webpack_require__(/*! ../internals/redefine */ "./node_modules/core-js/internals/redefine.js");
var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/core-js/internals/an-object.js");
var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
var flags = __webpack_require__(/*! ../internals/regexp-flags */ "./node_modules/core-js/internals/regexp-flags.js");

var TO_STRING = 'toString';
var RegExpPrototype = RegExp.prototype;
var nativeToString = RegExpPrototype[TO_STRING];

var NOT_GENERIC = fails(function () { return nativeToString.call({ source: 'a', flags: 'b' }) != '/a/b'; });
// FF44- RegExp#toString has a wrong name
var INCORRECT_NAME = nativeToString.name != TO_STRING;

// `RegExp.prototype.toString` method
// https://tc39.es/ecma262/#sec-regexp.prototype.tostring
if (NOT_GENERIC || INCORRECT_NAME) {
  redefine(RegExp.prototype, TO_STRING, function toString() {
    var R = anObject(this);
    var p = String(R.source);
    var rf = R.flags;
    var f = String(rf === undefined && R instanceof RegExp && !('flags' in RegExpPrototype) ? flags.call(R) : rf);
    return '/' + p + '/' + f;
  }, { unsafe: true });
}


/***/ }),

/***/ "./src/common/MixinUtils.js":
/*!**********************************!*\
  !*** ./src/common/MixinUtils.js ***!
  \**********************************/
/*! exports provided: tableMixin */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tableMixin", function() { return tableMixin; });
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! regenerator-runtime/runtime.js */ "./node_modules/regenerator-runtime/runtime.js");
/* harmony import */ var regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.entries.js */ "./node_modules/core-js/modules/es.object.entries.js");
/* harmony import */ var core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var components_common_Table__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! components/common/Table */ "./src/components/common/Table.vue");
/* harmony import */ var components_common_Pagination__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! components/common/Pagination */ "./src/components/common/Pagination.vue");
/* harmony import */ var components_common_Input__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/common/Input */ "./src/components/common/Input.vue");









var defaultDate = [{
  data: ['createDateBegin', 'createDateEnd']
}];
var tableMixin = {
  components: {
    Table: components_common_Table__WEBPACK_IMPORTED_MODULE_6__["default"],
    Pagination: components_common_Pagination__WEBPACK_IMPORTED_MODULE_7__["default"],
    Input: components_common_Input__WEBPACK_IMPORTED_MODULE_8__["default"]
  },
  data: function data() {
    return {
      // todo 查询的所有数据
      queryAllData: {},
      // todo 表格搜索数据
      queryData: {},
      cloneData: {},
      // todo 页码改变
      pageOption: {
        currentPage: 1,
        total: 0,
        pageSize: 10
      },
      // todo 时间选择
      pickerOptions: {
        shortcuts: [{
          text: '昨天',
          onClick: function onClick(picker) {
            var end = new Date();
            var start = new Date();
            start.setDate(start.getDate() - 1);
            end.setDate(end.getDate() - 1);
            picker.$emit('pick', [start, end]);
          }
        }, {
          text: '本周',
          onClick: function onClick(picker) {
            var end = new Date();
            var start = new Date();
            var currentDay = new Date().getDay() === 0 ? 7 : new Date().getDay();
            start.setDate(start.getDate() - currentDay + 1);
            end.setDate(end.getDate());
            picker.$emit('pick', [start, end]);
          }
        }, {
          text: '本月',
          onClick: function onClick(picker) {
            var end = new Date();
            var start = new Date();
            start.setDate(1);
            end.setMonth(end.getMonth() + 1);
            end.setDate(0);
            picker.$emit('pick', [start, end]);
          }
        }, {
          text: '上个月',
          onClick: function onClick(picker) {
            var end = new Date();
            var start = new Date();
            start.setMonth(start.getMonth() - 1);
            start.setDate(1);
            end.setDate(0);
            picker.$emit('pick', [start, end]);
          }
        }, {
          text: '最近三个月',
          onClick: function onClick(picker) {
            var end = new Date();
            var start = new Date();
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
            picker.$emit('pick', [start, end]);
          }
        }, {
          text: '本年',
          onClick: function onClick(picker) {
            var end = new Date();
            var start = new Date();
            start.setDate(1);
            start.setMonth(0);
            picker.$emit('pick', [start, end]);
          }
        }]
      }
    };
  },
  methods: {
    //todo 通用列表数据初始化
    getSelectList: function getSelectList(api, list, value, label, params) {
      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
        var _yield$api, data;

        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return api(params);

              case 2:
                _yield$api = _context.sent;
                data = _yield$api.data;

                if (list.length === 0) {
                  data.forEach(function (i) {
                    var obj = {};
                    obj.value = i[value];
                    obj.label = i[label];
                    list.push(obj);
                  });
                }

              case 5:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    // todo 通用查询
    getList: function getList(api, query, page, tableData, currentPage) {
      var _arguments = arguments,
          _this = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
        var dateArr, cb, data, result;
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                dateArr = _arguments.length > 5 && _arguments[5] !== undefined ? _arguments[5] : defaultDate;
                cb = _arguments.length > 6 ? _arguments[6] : undefined;
                data = JSON.parse(JSON.stringify(query)); // 处理页数

                data.pageNum = currentPage !== undefined ? page.currentPage = currentPage : page.currentPage = 1;
                data.pageSize = page.pageSize; // 处理时间

                dateArr.forEach(function (date) {
                  for (var _i = 0, _Object$entries = Object.entries(date); _i < _Object$entries.length; _i++) {
                    var _Object$entries$_i = Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__["default"])(_Object$entries[_i], 2),
                        key = _Object$entries$_i[0],
                        value = _Object$entries$_i[1];

                    if (data[key] !== null && data[key] !== undefined) {
                      data[value[0]] = data[key][0];
                      data[value[1]] = data[key][1];
                      delete data[key];
                    }
                  }
                }); // 请求结果

                _context2.next = 8;
                return api(data);

              case 8:
                result = _context2.sent;

                if (result !== null && result.code === 200 && result.data !== '') {
                  tableData.resultData = cb ? everyData(result.data.records, cb) : result.data.records;
                  page.total = result.data.total;
                  _this.queryAllData = result;
                } else if (result.data === '') {
                  tableData.resultData = [];
                  page.total = 0;
                }

                _this.cloneData = data;

              case 11:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    // todo 通用校验
    check: function check(message, key, value) {
      if (value === undefined && (key === '' || key === null || key === undefined)) {
        this.$message({
          type: 'error',
          message: message
        });
        throw new TypeError('填写的内容为空');
      } else if (value && key === value) {
        this.$message({
          type: 'error',
          message: message
        });
        throw new TypeError('填写的内容错误');
      }
    },
    // todo 点击查询按钮
    queryButton: function queryButton(e, apiNum) {
      this.requestDeploy();
    },
    // todo 页码改变
    currentPageChange: function currentPageChange(current) {
      this.requestDeploy(current);
    }
  }
}; // todo 过滤函数

function everyData(data, cb) {
  return data.map(function (item) {
    var arr = Object.entries(item);

    for (var _i2 = 0, _arr = arr; _i2 < _arr.length; _i2++) {
      var i = _arr[_i2];

      if (cb(i)) {
        item[cb(i)[0]] = cb(i)[1];
      }
    }

    return item;
  });
}

/***/ }),

/***/ "./src/common/dictionarieList/OrganizationIncomeNum.js":
/*!*************************************************************!*\
  !*** ./src/common/dictionarieList/OrganizationIncomeNum.js ***!
  \*************************************************************/
/*! exports provided: Model */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Model", function() { return Model; });
var Model = [{
  value: "0",
  label: "大B模式"
}, {
  value: "1",
  label: "小B模式"
}];

/***/ }),

/***/ "./src/common/dictionarieList/common.js":
/*!**********************************************!*\
  !*** ./src/common/dictionarieList/common.js ***!
  \**********************************************/
/*! exports provided: companyList, insuranceCompanyList, teamList, riskType, supplier, fromState */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "companyList", function() { return companyList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "insuranceCompanyList", function() { return insuranceCompanyList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "teamList", function() { return teamList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "riskType", function() { return riskType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "supplier", function() { return supplier; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fromState", function() { return fromState; });
var companyList = []; //渠道名称

var insuranceCompanyList = []; //公司名称

var teamList = []; //团队名称

var riskType = []; //险种类别

var supplier = []; //供应商名称
//保单状态

var fromState = [{
  value: 'UNINSURED',
  label: '未承保'
}, {
  value: 'ACPTINSD_FAILURE',
  label: '承保失败'
}, {
  value: 'ACPTINSD_SUCCESS',
  label: '承保成功'
}, {
  value: 'SURRENDER_FAILURE',
  label: '退保失败'
}, {
  value: 'SURRENDER_SUCCESS',
  label: '犹豫期退保成功'
}, {
  value: 'REVISIT_SUCCESS',
  label: '已回访'
}, {
  value: 'RECEIPT_SUCCESS',
  label: '回执成功'
}, {
  value: 'REFUNDPOLICY_SUCCESS',
  label: '退保终止'
}];

/***/ }),

/***/ "./src/common/utils.js":
/*!*****************************!*\
  !*** ./src/common/utils.js ***!
  \*****************************/
/*! exports provided: filterHandle, copyUrl, Storage, formatDate */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "filterHandle", function() { return filterHandle; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "copyUrl", function() { return copyUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Storage", function() { return Storage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "formatDate", function() { return formatDate; });
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.object.entries.js */ "./node_modules/core-js/modules/es.object.entries.js");
/* harmony import */ var core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_regexp_constructor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.regexp.constructor.js */ "./node_modules/core-js/modules/es.regexp.constructor.js");
/* harmony import */ var core_js_modules_es_regexp_constructor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_constructor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_7__);








function filterHandle(tableData, dictionaryData) {
  for (var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
    args[_key - 2] = arguments[_key];
  }

  args.forEach(function (item) {
    dictionaryData.forEach(function (i) {
      if (tableData[item[0]] === i.value) {
        tableData[item[0]] = i.label;
      }
    });
  });
} // 复制URL

function copyUrl(url) {
  // 创建一个 Input标签
  var cInput = document.createElement("input");
  cInput.value = url;
  document.body.appendChild(cInput);
  cInput.select(); // 选取文本域内容;
  // 执行浏览器复制命令
  // 复制命令会将当前选中的内容复制到剪切板中（这里就是创建的input标签）
  // Input要在正常的编辑状态下原生复制方法才会生效

  document.execCommand("Copy"); /// 复制成功后再将构造的标签 移除

  cInput.remove();
} // 设置SessionStrong

var Storage = {
  set: function set(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  },
  get: function get(key) {
    return JSON.parse(localStorage.getItem(key));
  },
  remove: function remove(key) {
    localStorage.removeItem(key);
  }
};
function formatDate(date, format) {
  var RegAndValue = null;

  if (date instanceof Date) {
    RegAndValue = {
      'y+': date.getFullYear(),
      'M+': date.getMonth() + 1,
      'd+': date.getDate(),
      'h+': date.getHours(),
      'm+': date.getMinutes(),
      's+': date.getSeconds()
    };
  } else {
    RegAndValue = {
      'h+': date / 3600,
      'm+': date % 3600 / 60,
      's+': date % 60
    };
  }

  for (var _i = 0, _Object$entries = Object.entries(RegAndValue); _i < _Object$entries.length; _i++) {
    var _Object$entries$_i = Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__["default"])(_Object$entries[_i], 2),
        key = _Object$entries$_i[0],
        value = _Object$entries$_i[1];

    var reg = new RegExp("(".concat(key, ")"), 'gms');

    if (reg.test(format)) {
      var str = date instanceof Date ? value.toString() : Math.round(value).toString();
      var match = RegExp.$1;
      var replace = replaceV(RegExp.$1.length, str);
      format = format.replace(match, replace);
    }
  } // 在不足两位的前面加0


  function replaceV(currentLength, str) {
    if (str.length === 4) {
      var start = 4 - RegExp.$1.length;
      return str.substr(start);
    } else if (0 < str.length < 4) {
      return ('00' + str).substr(str.length);
    }
  }

  return format;
}

/***/ })

}]);
//# sourceMappingURL=BusinessStatistics~HistorySumRecord~OrganizationIncome.js.map