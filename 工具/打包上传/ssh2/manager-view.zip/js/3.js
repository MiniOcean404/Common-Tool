(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[3],{

/***/ "./src/common/dictionary.js":
/*!**********************************!*\
  !*** ./src/common/dictionary.js ***!
  \**********************************/
/*! exports provided: default, noticeType, receiverType, Onliestatus, upOnlieStatus, isMainRisk, publishBy */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "noticeType", function() { return noticeType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "receiverType", function() { return receiverType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Onliestatus", function() { return Onliestatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "upOnlieStatus", function() { return upOnlieStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isMainRisk", function() { return isMainRisk; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "publishBy", function() { return publishBy; });
//数据字典
var dictonary = {
  // ------------------------------------------------结算管理-----------------------------------------------------
  //人员类型
  peopleType: [{
    value: '',
    name: '全部'
  }, {
    value: '1',
    name: '签约'
  }, {
    value: '2',
    name: '认证'
  }],
  // 渠道名称
  channelCompanyName: [],
  // 团队名称、
  teamName: [],
  //保单状态
  appStatusName: [{
    value: 'ACPTINSD_SUCCESS',
    name: '承保成功'
  }, {
    value: 'RECEIPT_SUCCESS',
    name: '回执成功'
  }, {
    value: 'SURRENDER_SUCCESS',
    name: '犹豫期退保成功'
  }],
  // 结算状态
  wageSettleStatusList: [{
    value: '0',
    name: '未结算'
  }, {
    value: '1',
    name: '待结算'
  }, {
    value: '2',
    name: '已结算'
  }],
  wageSettleStatusList1: [{
    value: '1',
    name: '待结算'
  }, {
    value: '2',
    name: '已结算'
  }],
  // 收款状态
  insCompanySettleStatusList: [{
    value: '0',
    name: '未收'
  }, {
    value: '1',
    name: '应收'
  }, {
    value: '2',
    name: '实收'
  }],
  // 产品类型
  eSourceList: [{
    value: '01',
    name: '自营'
  }, {
    value: '02',
    name: '三方'
  }],
  // 拆单状态
  isSplitList: [{
    value: '0',
    name: '未拆单'
  }, {
    value: '1',
    name: '已拆单'
  }],
  visitStatus: [{
    value: '0',
    name: '回访失败'
  }, {
    value: '1',
    name: '回访成功'
  }],
  // 合作模式
  modeNameList: [{
    value: '1',
    name: '小B模式'
  }, {
    value: '2',
    name: '普通小A代理人'
  }],
  modeNameList2: [{
    value: '0',
    name: '大B模式'
  }, {
    value: '1',
    name: '小B模式'
  }],
  sunType: [{
    value: '1',
    name: '代理人收入'
  }, {
    value: '2',
    name: '大B基础收入'
  }],
  // ------------------------------------------------机构收入统计-----------------------------------------------------
  //结算状态
  settleStatusList: [{
    value: '0',
    name: '未结算'
  }, {
    value: '1',
    name: '待结算'
  }, {
    value: '2',
    name: '已结算'
  }],
  // 产品类型
  productType: [{
    value: '01',
    name: '自营',
    extName: '自营'
  }, {
    value: '02',
    name: '三方',
    extName: '三方'
  }],
  // 人员类型
  joinApplyType: [{
    value: '1',
    name: '签约'
  }, {
    value: '2',
    name: '认证'
  }],
  // ------------------------------------------------机构业务统计-----------------------------------------------------
  // -----------------------------------------------------------------------------------------------------
  //订单类型
  esourceList: [{
    value: '01',
    name: '内部'
  }, {
    value: '02',
    name: '外部'
  }],
  //代理人类型区分
  receiverTypeList: [{
    value: 'AGE',
    label: '普通小A代理人',
    id: '1'
  }, {
    value: 'CMA',
    label: '小B渠道负责人',
    id: '2'
  }, {
    value: 'CME',
    label: '小B渠道成员',
    id: '3'
  }],
  //代理人类型区分活动
  receiverTypeListAction: [{
    value: 'AGE',
    label: '普通小A代理人',
    id: '1'
  }, {
    value: 'CMA',
    label: '小B渠道公司',
    id: '2'
  }, {
    value: 'CME',
    label: '小B渠道成员',
    id: '3'
  }, {
    value: 'LCMA',
    label: '大B渠道公司',
    id: '4'
  }, {
    isDisable: true,
    value: 'LCME',
    label: '大B渠道成员',
    id: '5'
  }],
  receiverTypeListAction2: [{
    value: 'AGE',
    label: '普通小A代理人',
    id: '1'
  }, {
    value: 'CMA',
    label: '小B渠道公司',
    id: '2'
  }, {
    value: 'CME',
    label: '小B渠道成员',
    id: '3'
  }, {
    value: 'LCMA',
    label: '大B渠道公司',
    id: '4'
  }, {
    value: 'LCME',
    label: '大B渠道成员',
    id: '5'
  }],
  // 财寿险标志
  ProductTypeOptions: [{
    value: '1',
    label: '财险'
  }, {
    value: '2',
    label: '寿险'
  }],
  // 财寿险标志
  stateOptions: [{
    value: '0',
    label: '未上架'
  }, {
    value: '1',
    label: '已上架'
  }],
  //长短险
  riskPeriodOptions: [{
    value: 'L',
    label: '长期险'
  }, {
    value: 'M',
    label: '短期险'
  }],
  //团个险
  groupRiskOptions: [{
    value: 'G',
    label: '团险'
  }, {
    value: 'I',
    label: '个险'
  }],
  //险种类别
  riskType: [{
    value: 'O',
    name: '健康险'
  }, {
    value: 'Y',
    name: '寿险'
  }, {
    value: 'N',
    name: '年金险'
  }, {
    value: 'X',
    name: '意外险'
  }, {
    value: 'A',
    name: '企业财产险'
  }, {
    value: 'B',
    name: '家庭财产险'
  }, {
    value: 'C',
    name: '工程险'
  }, {
    value: 'D',
    name: '船舶险'
  }, {
    value: 'E',
    name: '农业险'
  }, {
    value: 'F',
    name: '货物运输险'
  }, {
    value: 'G',
    name: '责任险'
  }, {
    value: 'J',
    name: '综合险'
  }, {
    value: 'K',
    name: '特殊风险险'
  }, {
    value: 'L',
    name: '信用险'
  }, {
    value: 'M',
    name: '保证险'
  }, {
    value: 'P',
    name: '失能险'
  }, {
    value: 'Q',
    name: '护理险'
  }, {
    value: 'R',
    name: '税收优惠健康险'
  }, {
    value: 'S',
    name: '旅行意外伤害险'
  }, {
    value: 'T',
    name: '长期意外伤害险'
  }, {
    value: 'W',
    name: '两全险'
  }, {
    value: 'H',
    name: '财产险'
  }, {
    value: 'Z',
    name: '全部产品'
  }],
  //保障年期
  getValueDataYear: [{
    value: '1Y',
    label: '1年'
  }, {
    value: '5Y',
    label: '5年'
  }, {
    value: '10Y',
    label: '10年'
  }, {
    value: '15Y',
    label: '15年'
  }, {
    value: '20Y',
    label: '20年'
  }, {
    value: '25Y',
    label: '25年'
  }, {
    value: '30Y',
    label: '30年'
  }],
  //保障年龄
  getValueDataAge: [{
    value: '105A',
    label: '105岁'
  }, {
    value: '88A',
    label: '88岁'
  }, {
    value: '80A',
    label: '80岁'
  }, {
    value: '77A',
    label: '77岁'
  }, {
    value: '70A',
    label: '70岁'
  }, {
    value: '66A',
    label: '66岁'
  }, {
    value: '60A',
    label: '60岁'
  }],
  //对账状态
  reconciliationStatusList: [{
    value: '0',
    label: '未对账'
  }, {
    value: '1',
    label: '已对帐'
  }],
  //收款状态
  receiptsStatusList: [{
    value: '0',
    label: '未收'
  }, {
    value: '1',
    label: '应收'
  }, {
    value: '2',
    label: '实收'
  }],
  // 犹豫期状态
  hesitationStatusList: [{
    value: '0',
    label: '未过犹豫期'
  }, {
    value: '1',
    label: '已过犹豫期'
  }],
  // 回访状态
  revisitStatusList: [{
    value: '0',
    label: '回访失败'
  }, {
    value: '1',
    label: '回访成功'
  }],
  payStatusList: [{
    value: '0',
    name: '未付款'
  }, {
    value: '1',
    name: '待处理'
  }, {
    value: '2',
    name: '付款成功'
  }, {
    value: '3',
    name: '打款异常'
  }],
  //对账结果
  checkResultList: [{
    value: '0',
    name: '双方一致'
  }, {
    value: '1',
    name: '双方不一致'
  }, {
    value: '2',
    name: '仅保司有'
  }, {
    value: '3',
    name: '仅我司有'
  }],
  // 订单状态
  model: [{
    value: 'UNPROCESSED',
    name: '未处理'
  }, {
    value: 'PROCESSE',
    name: '处理中'
  }, {
    value: 'PROCESSED',
    name: '已处理'
  }, {
    value: 'CLOSED',
    name: '已关闭'
  }],
  // 保单状态
  appStatusList: [{
    value: 'UNINSURED',
    name: '未承保'
  }, {
    value: 'ACPTINSD_FAILURE',
    name: '承保失败'
  }, {
    value: 'ACPTINSD_SUCCESS',
    name: '承保成功'
  }, {
    value: 'SURRENDER_FAILURE',
    name: '退保失败'
  }, {
    value: 'SURRENDER_SUCCESS',
    name: '犹豫期退保成功'
  }, {
    value: 'REVISIT_SUCCESS',
    name: '已回访'
  }, {
    value: 'RECEIPT_SUCCESS',
    name: '回执成功'
  }, {
    value: 'RREFUNDPOLICY_SUCCESS',
    name: '退保终止'
  }],
  //结算类型
  wageTypeList: [{
    value: '1',
    name: '代理人收入'
  }, {
    value: '2',
    name: '大B基础收入'
  }, {
    value: '3',
    name: '机构活动收入'
  }],
  componeyModel: [{
    value: '0',
    name: '大B模式'
  }, {
    value: '1',
    name: '小B模式'
  }],
  //销售对象
  salesScopeType: [{
    value: '1',
    name: '大B渠道'
  }, {
    value: '2',
    name: '小B渠道'
  }, {
    value: '3',
    name: '小A代理人'
  }, {
    value: '4',
    name: '独代'
  }],
  //线上线下标志
  isOnlineType: [{
    value: '0',
    name: '线上'
  }, {
    value: '1',
    name: '线下'
  }],
  //渠道公司费率等级
  rateLeven: [{
    value: '0',
    name: 'B-'
  }, {
    value: '1',
    name: 'B'
  }, {
    value: '2',
    name: 'B+'
  }, {
    value: '3',
    name: 'A'
  }, {
    value: '4',
    name: 'A+'
  }],
  //费率开关
  rateSwitch: [{
    value: '0',
    name: '开'
  }, {
    value: '1',
    name: '关'
  }],
  //渠道考核结果审核状态
  rateGradeAuditStatus: [{
    value: '0',
    name: '未审核'
  }, {
    value: '1',
    name: '已审核'
  }]
};
/* harmony default export */ __webpack_exports__["default"] = (dictonary);
var noticeType = [{
  value: '1',
  name: '通用'
}, {
  value: '2',
  name: '产品停售'
}, {
  value: '3',
  name: '产品上线'
}, {
  value: '4',
  name: '投保规则'
}, {
  value: '5',
  name: '系统维护'
}];
var receiverType = [{
  value: 'AGE',
  name: '普通小A代理人'
}, {
  value: 'CMA',
  name: '小B渠道公司'
}, {
  value: 'CME',
  name: '小B渠道成员'
}, {
  value: 'LCMA',
  name: '大B渠道公司'
}, {
  value: 'LCME',
  name: '大B渠道成员'
}, {
  value: 'ALL',
  name: '所有人'
}];
var Onliestatus = [{
  value: '0',
  name: '下线'
}, {
  value: '1',
  name: '上线'
}, {
  value: '2',
  name: '未发布'
}];
var upOnlieStatus = [{
  value: '0',
  name: '已下线'
}, {
  value: '1',
  name: '已上线'
}, {
  value: '2',
  name: '未发布'
}];
var isMainRisk = [{
  value: '1',
  label: '主险'
}, {
  value: '2',
  label: '附险'
}];
var publishBy = [];

/***/ })

}]);
//# sourceMappingURL=3.js.map