(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[51],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/Statistics.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--12-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/mga-manage/Statistics.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! regenerator-runtime/runtime.js */ "./node_modules/regenerator-runtime/runtime.js");
/* harmony import */ var regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(regenerator_runtime_runtime_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _api_mgaApi_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/api/mgaApi.js */ "./src/api/mgaApi.js");
/* harmony import */ var _common_dictionary_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/common/dictionary.js */ "./src/common/dictionary.js");
/* harmony import */ var api_api__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! api/api */ "./src/api/api.js");





//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'settleManger',
  data: function data() {
    return {
      // todo 查看详情
      detailConfig: {
        //详情查看弹窗组件配置项
        dialogVisible: false,
        width: '1100px',
        buttonPosition: 'flex-end',
        ismodal: true,
        modalClose: false,
        Button: [{
          name: '关闭',
          type: 'default',
          methods: 'handleDialogClose'
        }]
      },
      orderBase: {},
      //订单
      orderNewCovenant: {},
      //保单
      orderPolicyHolder: {},
      //投保人
      selIndex: 'first',
      //tab 默认选项
      allSelectId: [],
      form: {},
      //新增存储数据
      tableData: [],
      //todo 字典
      modelList: _common_dictionary_js__WEBPACK_IMPORTED_MODULE_6__["default"].modeNameList2,
      channelCompanyNameList: _common_dictionary_js__WEBPACK_IMPORTED_MODULE_6__["default"].channelCompanyName,
      teamNameList: [],
      // todo 表格数据
      searchForm: {
        channel_group_name: ''
      },
      //搜索表单
      tbConfig: {
        height: '530px',
        // table高度
        select: false,
        // 是否可以多选择
        isSingleSelect: false,
        //是否可以单选
        isCommands: false,
        //是否需要操作列
        commandsWidth: '200',
        //操作列宽度
        isOrder: true,
        showPagenation: true,
        //是否需要显示分页器
        layout: 'total, prev, pager, next, jumper',
        //分页器控件
        requestCurData: true,
        // 每次分页数据是否请求后台 true:每次都请求后台
        columns: [// 后台字段属性、表头名、长度、颜色、是否过长隐藏、是否需要字典转换、点击事件的处理函数
        ['order_id', '订单编码', '130', '#409eff', true, false, 'orderDetail'], ['channel_company_name', '渠道名称', '', '', true, false], ['channel_company_code', '渠道编码', '', '', true, false], ['model', '合作模式', '', '', true, true], ['channel_group_name', '团队名称', '', '', true, false], ['channel_group_code', '团队编码', '', '', true, false], ['member_name', '代理人', '', false, false], ['type', '人员类型', '', '', true, true], ['phone', '手机号', '', '', true, false], ['ins_company_name', '保险公司', '', '', true, false], ['product_name', '产品名称', '130', '', true, false], ['policy_no', '保单号', '150', '', true, false], ['name', '投保人', '', '', true, false], ['premium', '保费', '', '', true, false], ['prem_wage', '收入', '', '', false, false], ['create_date', '出单日期', '', '', true, false], ['appStatusName', '保单状态', '', '', false, false], ['revisitStatusName', '回访状态', '', '', false, false], ['revisitDate', '回访时间', '', '', false, false], ['freelookEnddate', '犹豫期止期', '', '', false, false]] // table行按钮：color 文字 处理点击的事件函数名  elementUicon

      },
      tbOptionData: {
        selectDatas: 'handleSelect',
        //页面单选函数
        currentTableData: [],
        //当前表格数据
        TransValtoDesc: 'dataFilter',
        //数据字典过滤函数
        pageSize: 10,
        // 每页行数
        currentPage: 1,
        // 当前页
        total: 0,
        //总数据量
        pagenationChange: 'handlPageChange' //处理分页器长度改变或页码改变的函数

      },
      backupsData: []
    };
  },
  mounted: function mounted() {
    this.dataInit();
    this.queryChannelCompanyApi();
    this.queryTeamApi();
  },
  methods: {
    //todo 查看详情
    orderDetail: function orderDetail(row) {
      var params = {
        orderId: row.order_id
      };
      this.detailConfig.dialogVisible = true;
      this.searchOrderDetail(params);
    },
    handleDetailClick: function handleDetailClick(row) {
      //点击了详情
      console.log('查看详情', row);
      var params = {
        orderId: row.orderId
      };
      this.detailConfig.dialogVisible = true;
      this.searchOrderDetail(params);
    },
    handleDialogClose: function handleDialogClose() {
      this.detailConfig.dialogVisible = false;
    },
    searchOrderDetail: function searchOrderDetail(params) {
      var _this = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
        var result;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                if (!_this.api) {
                  _context.next = 6;
                  break;
                }

                _context.next = 3;
                return _this.api(params);

              case 3:
                result = _context.sent;
                _context.next = 9;
                break;

              case 6:
                _context.next = 8;
                return Object(api_api__WEBPACK_IMPORTED_MODULE_7__["searchOrderDetail"])(params);

              case 8:
                result = _context.sent;

              case 9:
                if (result.code === 200) {
                  _this.orderRisks = result.data.orderRisks;
                  _this.orderNewCovenant = result.data.orderNewCovenant;
                  _this.orderBase = result.data.orderBase;
                  _this.orderPolicyHolder = result.data.orderPolicyHolder;
                  _this.orderInsureds = result.data.orderInsureds;
                  _this.orderBeneficiarys = result.data.orderBeneficiarys;
                  _this.isLegar = result.data.orderBase.isLegar;
                }

              case 10:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },

    /*
     * @请求
     */
    //todo 数据初始化及更新
    dataInit: function dataInit() {
      var params = JSON.parse(JSON.stringify(this.searchForm));
      params.pageNum = this.tbOptionData.currentPage;
      params.pageSize = this.tbOptionData.pageSize;
      this.getList(params);
    },
    //todo 页码改变
    handlPageChange: function handlPageChange(cur, size) {
      var params = JSON.parse(JSON.stringify(this.searchForm));
      params.pageNum = cur;
      this.tbOptionData.currentPage = cur;
      params.pageSize = this.tbOptionData.pageSize;
      this.getList(params);
    },
    //todo 选择后查询
    handleSelect: function handleSelect(data) {
      var _this2 = this;

      this.allSelectId = [];
      this.allSelect = [];
      var selectData = this.allSelect = JSON.parse(JSON.stringify(data));
      selectData.forEach(function (value, index) {
        _this2.allSelectId.push(value.id);
      });
    },
    //todo 点击查询
    onSubmit: function onSubmit() {
      this.tbOptionData.currentTableData = this.tableData;
      this.tbOptionData.currentPage = 1;
      this.dataInit();
    },
    //todo 查询列表
    getList: function getList(params) {
      var _this3 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
        var result, data;
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return Object(_api_mgaApi_js__WEBPACK_IMPORTED_MODULE_5__["queryAllBusinessApi"])(params);

              case 2:
                result = _context2.sent;

                if (result.code === 200) {
                  data = JSON.parse(JSON.stringify(result.data.records));
                  _this3.tbOptionData.currentTableData = data;
                  _this3.tbOptionData.total = result.data.total;
                }

              case 4:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    //切换渠道公司
    channelCompanyNameChange: function channelCompanyNameChange(value) {
      var _this4 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
        var companyValue;
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _this4.searchForm.channel_group_name = '';

                if (value) {
                  companyValue = [];

                  _this4.backupsData.forEach(function (item) {
                    console.log(item.channelCompanyName, value);

                    if (item.channelCompanyName === value) {
                      companyValue.push(item);
                    }
                  });

                  if (companyValue.length > 0) {
                    _this4.teamNameList = companyValue;
                  } else {
                    _this4.teamNameList = [];
                  }
                } else {
                  _this4.queryTeamApi();
                }

              case 2:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3);
      }))();
    },
    // todo  查询渠道公司下拉框列表接口
    queryChannelCompanyApi: function queryChannelCompanyApi() {
      var _this5 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
        var res;
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return Object(_api_mgaApi_js__WEBPACK_IMPORTED_MODULE_5__["queryChannelCompanyApi"])();

              case 2:
                res = _context4.sent;

                if (res.code === 200) {
                  res.data.map(function (item) {
                    item.value = item.channelCompanyCode;
                    item.name = item.channelCompanyName;
                  });
                  _this5.channelCompanyNameList = res.data;
                }

              case 4:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4);
      }))();
    },
    // todo 查询团队下拉框接口
    queryTeamApi: function queryTeamApi(req) {
      var _this6 = this;

      return Object(D_SoftwareDev_Code_Work_GT_spread_backstage_leave_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
        var res;
        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.next = 2;
                return Object(_api_mgaApi_js__WEBPACK_IMPORTED_MODULE_5__["queryTeamApi"])(req);

              case 2:
                res = _context5.sent;

                if (res.code === 200) {
                  res.data.map(function (item) {
                    item.value = item.channelGroupCode;
                    item.name = item.channelGroupName;
                  });
                  _this6.teamNameList = res.data;
                  _this6.backupsData = res.data;
                }

              case 4:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5);
      }))();
    },
    //todo tab 切换
    selTab: function selTab(tab, event) {
      this.searchForm.params = null;

      switch (this.selIndex) {
        case 'first':
          this.searchForm = {
            channel_group_name: ''
          };
          this.searchForm.params = null;
          break;

        case 'second':
          this.searchForm = {};
          this.searchForm.app_status = 'ACPTINSD_SUCCESS';
          this.searchForm.freelook_status = 0;
          break;

        case 'three':
          this.searchForm = {};
          this.searchForm.app_status = 'REVISIT_SUCCESS';
          this.searchForm.freelook_status = 0;
          break;

        case 'four':
          this.searchForm = {};
          this.searchForm.freelook_status = 1;
          break;

        case 'five':
          this.searchForm = {};
          this.searchForm.app_status = 'SURRENDER_SUCCESS';
          break;
      }

      this.getList(this.searchForm);
    },
    exportTableHandle: function exportTableHandle() {
      Object(_api_mgaApi_js__WEBPACK_IMPORTED_MODULE_5__["exportTableApi"])(this.searchForm);
    },
    //数据过滤
    dataFilter: function dataFilter(id, val) {
      if (id === 'model') {
        return val === '0' ? '大B模式' : val === '1' ? '小B模式' : '普通代理人';
      }

      if (id === 'type') {
        return val === '1' ? '签约' : val === '' ? '' : '认证';
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"b9734f90-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/Statistics.vue?vue&type=template&id=c338de86&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"b9734f90-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/mga-manage/Statistics.vue?vue&type=template&id=c338de86& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "selfCon", attrs: { id: "container" } },
    [
      _c("div", { staticClass: "queryHeading" }, [_vm._v("查询条件")]),
      _c(
        "div",
        [
          _c(
            "el-form",
            {
              staticClass: "demo-form-inline",
              attrs: {
                inline: true,
                model: _vm.searchForm,
                "label-width": "120px"
              }
            },
            [
              _c(
                "el-row",
                [
                  _c(
                    "el-col",
                    { attrs: { span: 6 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: " 投保人:" } },
                        [
                          _c("el-input", {
                            attrs: { placeholder: "请输入内容" },
                            model: {
                              value: _vm.searchForm.name,
                              callback: function($$v) {
                                _vm.$set(_vm.searchForm, "name", $$v)
                              },
                              expression: "searchForm.name"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 6 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "代理人:" } },
                        [
                          _c("el-input", {
                            attrs: { placeholder: "请输入内容" },
                            model: {
                              value: _vm.searchForm.member_name,
                              callback: function($$v) {
                                _vm.$set(_vm.searchForm, "member_name", $$v)
                              },
                              expression: "searchForm.member_name"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 6 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "手机号:" } },
                        [
                          _c("el-input", {
                            attrs: { placeholder: "请输入内容" },
                            model: {
                              value: _vm.searchForm.phone,
                              callback: function($$v) {
                                _vm.$set(_vm.searchForm, "phone", $$v)
                              },
                              expression: "searchForm.phone"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 6 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: " 订单编号:" } },
                        [
                          _c("el-input", {
                            attrs: { placeholder: "请输入内容" },
                            model: {
                              value: _vm.searchForm.order_id,
                              callback: function($$v) {
                                _vm.$set(_vm.searchForm, "order_id", $$v)
                              },
                              expression: "searchForm.order_id"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                [
                  _c(
                    "el-col",
                    { attrs: { span: 6 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: " 出单日期:" } },
                        [
                          _c("el-date-picker", {
                            attrs: {
                              placeholder: "开始时间",
                              type: "date",
                              "value-format": "yyyy-MM-dd"
                            },
                            model: {
                              value: _vm.searchForm.beginTime,
                              callback: function($$v) {
                                _vm.$set(_vm.searchForm, "beginTime", $$v)
                              },
                              expression: "searchForm.beginTime"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 6 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "至:" } },
                        [
                          _c("el-date-picker", {
                            attrs: {
                              placeholder: "结束时间",
                              type: "date",
                              "value-format": "yyyy-MM-dd"
                            },
                            model: {
                              value: _vm.searchForm.endTime,
                              callback: function($$v) {
                                _vm.$set(_vm.searchForm, "endTime", $$v)
                              },
                              expression: "searchForm.endTime"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 6 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: " 产品名称:" } },
                        [
                          _c("el-input", {
                            attrs: { placeholder: "请输入内容" },
                            model: {
                              value: _vm.searchForm.product_name,
                              callback: function($$v) {
                                _vm.$set(_vm.searchForm, "product_name", $$v)
                              },
                              expression: "searchForm.product_name"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 6 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: " 保单号:" } },
                        [
                          _c("el-input", {
                            attrs: { placeholder: "请输入内容" },
                            model: {
                              value: _vm.searchForm.policy_no,
                              callback: function($$v) {
                                _vm.$set(_vm.searchForm, "policy_no", $$v)
                              },
                              expression: "searchForm.policy_no"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              ),
              _c(
                "el-row",
                [
                  _c(
                    "el-col",
                    { attrs: { span: 6 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: " 保险公司:" } },
                        [
                          _c("el-input", {
                            attrs: { placeholder: "请输入内容" },
                            model: {
                              value: _vm.searchForm.ins_company_name,
                              callback: function($$v) {
                                _vm.$set(
                                  _vm.searchForm,
                                  "ins_company_name",
                                  $$v
                                )
                              },
                              expression: "searchForm.ins_company_name"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 6 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "渠道名称:" } },
                        [
                          _c(
                            "el-select",
                            {
                              attrs: { clearable: "", placeholder: "请选择" },
                              on: {
                                change: function($event) {
                                  return _vm.channelCompanyNameChange($event)
                                }
                              },
                              model: {
                                value: _vm.searchForm.channel_company_name,
                                callback: function($$v) {
                                  _vm.$set(
                                    _vm.searchForm,
                                    "channel_company_name",
                                    $$v
                                  )
                                },
                                expression: "searchForm.channel_company_name"
                              }
                            },
                            _vm._l(_vm.channelCompanyNameList, function(
                              item,
                              index
                            ) {
                              return _c("el-option", {
                                key: index,
                                attrs: { label: item.name, value: item.name }
                              })
                            }),
                            1
                          )
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 6 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "团队名称:" } },
                        [
                          _c(
                            "el-select",
                            {
                              attrs: { clearable: "", placeholder: "请选择" },
                              model: {
                                value: _vm.searchForm.channel_group_name,
                                callback: function($$v) {
                                  _vm.$set(
                                    _vm.searchForm,
                                    "channel_group_name",
                                    $$v
                                  )
                                },
                                expression: "searchForm.channel_group_name"
                              }
                            },
                            _vm._l(_vm.teamNameList, function(item, index) {
                              return _c("el-option", {
                                key: index,
                                attrs: { label: item.name, value: item.name }
                              })
                            }),
                            1
                          )
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    { attrs: { span: 6 } },
                    [
                      _c(
                        "el-form-item",
                        { attrs: { label: "合作模式:" } },
                        [
                          _c(
                            "el-select",
                            {
                              attrs: { clearable: "", placeholder: "请选择" },
                              model: {
                                value: _vm.searchForm.model,
                                callback: function($$v) {
                                  _vm.$set(_vm.searchForm, "model", $$v)
                                },
                                expression: "searchForm.model"
                              }
                            },
                            _vm._l(_vm.modelList, function(item, index) {
                              return _c("el-option", {
                                key: index,
                                attrs: { label: item.name, value: item.value }
                              })
                            }),
                            1
                          )
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _c(
                    "el-col",
                    {
                      staticStyle: { margin: "0 0 30px 3%" },
                      attrs: { span: 12 }
                    },
                    [
                      _c(
                        "el-button",
                        {
                          attrs: { type: "primary", size: "mini" },
                          on: { click: _vm.onSubmit }
                        },
                        [_vm._v("查询")]
                      )
                    ],
                    1
                  )
                ],
                1
              )
            ],
            1
          )
        ],
        1
      ),
      _c(
        "div",
        { staticClass: "showTab" },
        [
          _c(
            "el-tabs",
            {
              attrs: { type: "card" },
              on: { "tab-click": _vm.selTab },
              model: {
                value: _vm.selIndex,
                callback: function($$v) {
                  _vm.selIndex = $$v
                },
                expression: "selIndex"
              }
            },
            [
              _c("el-tab-pane", { attrs: { label: "全部", name: "first" } }),
              _c("el-tab-pane", {
                attrs: { label: "已承保未回访", name: "second" }
              }),
              _c("el-tab-pane", { attrs: { label: "已回访", name: "three" } }),
              _c("el-tab-pane", {
                attrs: { label: "已过犹豫期", name: "four" }
              }),
              _c("el-tab-pane", {
                attrs: { label: "犹豫期退保成功", name: "five" }
              })
            ],
            1
          ),
          _c(
            "div",
            { staticClass: "buttonGroup" },
            [
              _c(
                "el-button",
                {
                  attrs: { size: "mini", type: "primary" },
                  on: { click: _vm.exportTableHandle }
                },
                [_vm._v("导出表格")]
              )
            ],
            1
          )
        ],
        1
      ),
      _c("div", { staticClass: "queryHeading" }, [_vm._v("查询结果")]),
      _c("stable", {
        ref: "result",
        attrs: { config: _vm.tbConfig, optionData: _vm.tbOptionData }
      }),
      _c("sdialog", { attrs: { config: _vm.detailConfig } }, [
        _c(
          "div",
          { staticClass: "detaiConfig-wrap" },
          [
            _c(
              "el-card",
              { staticClass: "box-card" },
              [
                _c(
                  "div",
                  {
                    staticClass: "clearfix",
                    attrs: { slot: "header" },
                    slot: "header"
                  },
                  [_c("span", [_vm._v("订单详情")])]
                ),
                _c(
                  "el-main",
                  [
                    _c(
                      "el-row",
                      [
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("订单号:")
                          ]),
                          _vm._v(" " + _vm._s(_vm.orderBase.order_id) + " ")
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("订单状态:")
                          ]),
                          _vm._v(
                            " " + _vm._s(_vm.orderBase.order_status_name) + " "
                          )
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("代理人:")
                          ]),
                          _vm._v(" " + _vm._s(_vm.orderBase.member_name) + " ")
                        ])
                      ],
                      1
                    ),
                    _c(
                      "el-row",
                      [
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("保险公司:")
                          ]),
                          _vm._v(" " + _vm._s(_vm.orderBase.supplierName) + " ")
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("计划名称:")
                          ]),
                          _vm._v(" " + _vm._s(_vm.orderBase.programName) + " ")
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("险种名称:")
                          ]),
                          _vm._v(" " + _vm._s(_vm.orderBase.product_name) + " ")
                        ]),
                        _c("el-col", { attrs: { span: 8 } })
                      ],
                      1
                    ),
                    _c(
                      "el-row",
                      [
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("订单生成时间:")
                          ]),
                          _vm._v(" " + _vm._s(_vm.orderBase.create_date) + " ")
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("支付状态:")
                          ]),
                          _vm._v(
                            " " + _vm._s(_vm.orderBase.pay_status_name) + " "
                          )
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("份数:")
                          ]),
                          _vm._v(" " + _vm._s(_vm.orderBase.buy_copies) + " ")
                        ])
                      ],
                      1
                    ),
                    _c(
                      "el-row",
                      [
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("支付金额:")
                          ]),
                          _vm.orderBase.total_order_payment
                            ? _c("span", [
                                _vm._v(
                                  _vm._s(_vm.orderBase.total_order_payment) +
                                    " 元"
                                )
                              ])
                            : _vm._e()
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("保单金额:")
                          ]),
                          _vm.orderBase.total_order
                            ? _c("span", [
                                _vm._v(
                                  _vm._s(_vm.orderBase.total_order) + " 元"
                                )
                              ])
                            : _vm._e()
                        ])
                      ],
                      1
                    ),
                    _c(
                      "el-row",
                      [
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("开户行:")
                          ]),
                          _vm._v(" " + _vm._s(_vm.orderBase.openBank) + " ")
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("账户名:")
                          ]),
                          _vm._v(
                            " " + _vm._s(_vm.orderBase.bankSubmitName) + " "
                          )
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("银行账号:")
                          ]),
                          _vm._v(" " + _vm._s(_vm.orderBase.bankCode) + " ")
                        ])
                      ],
                      1
                    ),
                    _c("el-row")
                  ],
                  1
                )
              ],
              1
            ),
            _c(
              "el-card",
              { staticClass: "box-card" },
              [
                _c(
                  "div",
                  {
                    staticClass: "clearfix",
                    attrs: { slot: "header" },
                    slot: "header"
                  },
                  [_c("span", [_vm._v("保单信息")])]
                ),
                _c(
                  "el-main",
                  [
                    _c(
                      "el-row",
                      [
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("保单号:")
                          ]),
                          _vm._v(
                            " " + _vm._s(_vm.orderNewCovenant.policyNo) + " "
                          )
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("保单状态:")
                          ]),
                          _vm._v(
                            " " + _vm._s(_vm.orderNewCovenant.appStatus) + " "
                          )
                        ])
                      ],
                      1
                    ),
                    _vm._l(_vm.orderRisks, function(item, index) {
                      return [
                        _c("div", { key: index }, [
                          _c(
                            "div",
                            { staticClass: "baodan-item" },
                            [
                              _c(
                                "el-row",
                                [
                                  _c("el-col", { attrs: { span: 8 } }, [
                                    _c("span", { staticClass: "col-title" }, [
                                      _vm._v("险种名称:")
                                    ]),
                                    _vm._v(
                                      " " +
                                        _vm._s(
                                          _vm.orderRisks[index].productName
                                        ) +
                                        " "
                                    )
                                  ]),
                                  _c("el-col", { attrs: { span: 8 } }, [
                                    _c("span", { staticClass: "col-title" }, [
                                      _vm._v("是否主险:")
                                    ]),
                                    _vm._v(
                                      " " +
                                        _vm._s(
                                          _vm._f("ismainx")(
                                            _vm.orderRisks[index].mainRiskFlag
                                          )
                                        ) +
                                        " "
                                    )
                                  ]),
                                  _c("el-col", { attrs: { span: 8 } }, [
                                    _c("span", { staticClass: "col-title" }, [
                                      _vm._v("保额:")
                                    ]),
                                    _vm.orderRisks[index].amnt
                                      ? _c("span", [
                                          _vm._v(
                                            _vm._s(_vm.orderRisks[index].amnt) +
                                              " 元"
                                          )
                                        ])
                                      : _vm._e()
                                  ])
                                ],
                                1
                              ),
                              _c(
                                "el-row",
                                [
                                  _c("el-col", { attrs: { span: 8 } }, [
                                    _c("span", { staticClass: "col-title" }, [
                                      _vm._v("缴费方式:")
                                    ]),
                                    _vm._v(
                                      " " +
                                        _vm._s(_vm.orderRisks[index].appType) +
                                        " "
                                    )
                                  ]),
                                  _c("el-col", { attrs: { span: 8 } }, [
                                    _c("span", { staticClass: "col-title" }, [
                                      _vm._v("缴费期间:")
                                    ]),
                                    _vm._v(
                                      " " +
                                        _vm._s(_vm.orderRisks[index].feeYear) +
                                        " "
                                    )
                                  ]),
                                  _c("el-col", { attrs: { span: 8 } }, [
                                    _c("span", { staticClass: "col-title" }, [
                                      _vm._v("保障时间:")
                                    ]),
                                    _vm._v(
                                      " " +
                                        _vm._s(_vm.orderRisks[index].period) +
                                        " "
                                    )
                                  ])
                                ],
                                1
                              ),
                              _c(
                                "el-row",
                                [
                                  _c("el-col", { attrs: { span: 8 } }, [
                                    _c("span", { staticClass: "col-title" }, [
                                      _vm._v("保费:")
                                    ]),
                                    _vm.orderRisks[index].premium
                                      ? _c("span", [
                                          _vm._v(
                                            _vm._s(
                                              _vm.orderRisks[index].premium
                                            ) + "元"
                                          )
                                        ])
                                      : _vm._e()
                                  ])
                                ],
                                1
                              )
                            ],
                            1
                          )
                        ])
                      ]
                    })
                  ],
                  2
                )
              ],
              1
            ),
            _c(
              "el-card",
              { staticClass: "box-card" },
              [
                _c(
                  "div",
                  {
                    staticClass: "clearfix",
                    attrs: { slot: "header" },
                    slot: "header"
                  },
                  [_c("span", [_vm._v("投保人信息")])]
                ),
                _c(
                  "el-main",
                  [
                    _c(
                      "el-row",
                      [
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("投保人:")
                          ]),
                          _vm._v(" " + _vm._s(_vm.orderPolicyHolder.name) + " ")
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("手机号码:")
                          ]),
                          _vm._v(
                            " " +
                              _vm._s(_vm.orderPolicyHolder.phoneNumber) +
                              " "
                          )
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("证件类型:")
                          ]),
                          _vm._v(
                            " " +
                              _vm._s(
                                _vm.orderPolicyHolder.certificateTypeName
                              ) +
                              " "
                          )
                        ])
                      ],
                      1
                    ),
                    _c(
                      "el-row",
                      [
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("证件号:")
                          ]),
                          _vm._v(
                            " " +
                              _vm._s(_vm.orderPolicyHolder.certificateNumber) +
                              " "
                          )
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("证件有效期:")
                          ]),
                          _vm.orderPolicyHolder.certificateValidityEnd != "" &&
                          _vm.orderPolicyHolder.certificateValidityEnd !=
                            null &&
                          _vm.orderPolicyHolder.certificateValidityEnd !=
                            "undefined"
                            ? _c("span", [
                                _vm._v(
                                  " " +
                                    _vm._s(
                                      _vm.orderPolicyHolder
                                        .certificateValidityStart
                                    ) +
                                    " 至 " +
                                    _vm._s(
                                      _vm.orderPolicyHolder
                                        .certificateValidityEnd
                                    ) +
                                    " "
                                )
                              ])
                            : _vm._e()
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("出生日期:")
                          ]),
                          _vm._v(
                            " " + _vm._s(_vm.orderPolicyHolder.birthday) + " "
                          )
                        ])
                      ],
                      1
                    ),
                    _c(
                      "el-row",
                      [
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("性别:")
                          ]),
                          _vm._v(
                            " " + _vm._s(_vm.orderPolicyHolder.sexName) + " "
                          )
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("通讯地址:")
                          ]),
                          _vm._v(
                            " " +
                              _vm._s(_vm.orderPolicyHolder.homeaddress) +
                              " "
                          )
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("详细地址:")
                          ]),
                          _vm._v(
                            " " + _vm._s(_vm.orderPolicyHolder.address) + " "
                          )
                        ])
                      ],
                      1
                    ),
                    _c(
                      "el-row",
                      [
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("电子邮箱:")
                          ]),
                          _vm._v(" " + _vm._s(_vm.orderPolicyHolder.mail) + " ")
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _c("span", { staticClass: "col-title" }, [
                            _vm._v("国籍:")
                          ]),
                          _vm._v(
                            " " +
                              _vm._s(_vm.orderPolicyHolder.nationalityname) +
                              " "
                          )
                        ]),
                        _c("el-col", { attrs: { span: 8 } }, [
                          _vm.orderPolicyHolder.occupationName
                            ? _c("span", { staticClass: "col-title" }, [
                                _vm._v("从事职业名称:")
                              ])
                            : _vm._e(),
                          _vm._v(
                            " " +
                              _vm._s(_vm.orderPolicyHolder.occupationName) +
                              " "
                          )
                        ])
                      ],
                      1
                    ),
                    _c("el-row")
                  ],
                  1
                )
              ],
              1
            ),
            _c(
              "el-card",
              { staticClass: "box-card" },
              [
                _c(
                  "div",
                  {
                    staticClass: "clearfix",
                    attrs: { slot: "header" },
                    slot: "header"
                  },
                  [_c("span", [_vm._v("被保人信息")])]
                ),
                _c(
                  "el-main",
                  [
                    _vm._l(_vm.orderInsureds, function(item, index) {
                      return [
                        _c(
                          "div",
                          { key: index },
                          [
                            _c(
                              "el-row",
                              [
                                _c("el-col", { attrs: { span: 8 } }, [
                                  _c("span", { staticClass: "col-title" }, [
                                    _vm._v("被保人:")
                                  ]),
                                  _vm._v(" " + _vm._s(item.name) + " ")
                                ]),
                                _c("el-col", { attrs: { span: 8 } }, [
                                  _c("span", { staticClass: "col-title" }, [
                                    _vm._v("与投保人的关系:")
                                  ]),
                                  _vm._v(
                                    " " + _vm._s(item.holderRelationName) + " "
                                  )
                                ]),
                                _c("el-col", { attrs: { span: 8 } }, [
                                  _c("span", { staticClass: "col-title" }, [
                                    _vm._v("证件类型:")
                                  ]),
                                  _vm._v(
                                    " " + _vm._s(item.certificateTypeName) + " "
                                  )
                                ])
                              ],
                              1
                            ),
                            _c(
                              "el-row",
                              [
                                _c("el-col", { attrs: { span: 8 } }, [
                                  _c("span", { staticClass: "col-title" }, [
                                    _vm._v("证件号:")
                                  ]),
                                  _vm._v(
                                    " " + _vm._s(item.certificateNumber) + " "
                                  )
                                ]),
                                _c("el-col", { attrs: { span: 8 } }, [
                                  _c("span", { staticClass: "col-title" }, [
                                    _vm._v("证件有效期:")
                                  ]),
                                  item.certificateValidityEnd
                                    ? _c("span", [
                                        _vm._v(
                                          " " +
                                            _vm._s(
                                              item.certificateValidityStart
                                            ) +
                                            " 至 " +
                                            _vm._s(
                                              item.certificateValidityEnd
                                            ) +
                                            " "
                                        )
                                      ])
                                    : _vm._e()
                                ]),
                                _c("el-col", { attrs: { span: 8 } }, [
                                  _c("span", { staticClass: "col-title" }, [
                                    _vm._v("出生日期:")
                                  ]),
                                  _vm._v(" " + _vm._s(item.birthday) + " ")
                                ])
                              ],
                              1
                            ),
                            _c(
                              "el-row",
                              [
                                _c("el-col", { attrs: { span: 8 } }, [
                                  _c("span", { staticClass: "col-title" }, [
                                    _vm._v("性别:")
                                  ]),
                                  _vm._v(" " + _vm._s(item.sexName) + " ")
                                ]),
                                _c("el-col", { attrs: { span: 8 } }, [
                                  _c("span", { staticClass: "col-title" }, [
                                    _vm._v("通讯地址:")
                                  ]),
                                  _vm._v(" " + _vm._s(item.homeaddress) + " ")
                                ]),
                                _c("el-col", { attrs: { span: 8 } }, [
                                  _c("span", { staticClass: "col-title" }, [
                                    _vm._v("详细地址:")
                                  ]),
                                  _vm._v(" " + _vm._s(item.address) + " ")
                                ])
                              ],
                              1
                            ),
                            _c(
                              "el-row",
                              [
                                _c("el-col", { attrs: { span: 8 } }, [
                                  _c("span", { staticClass: "col-title" }, [
                                    _vm._v("电子邮箱:")
                                  ]),
                                  _vm._v(" " + _vm._s(item.mail) + " ")
                                ]),
                                _c("el-col", { attrs: { span: 8 } }, [
                                  _c("span", { staticClass: "col-title" }, [
                                    _vm._v("手机号码:")
                                  ]),
                                  _vm._v(" " + _vm._s(item.phoneNumber) + " ")
                                ]),
                                _c("el-col", { attrs: { span: 8 } }, [
                                  _c("span", { staticClass: "col-title" }, [
                                    _vm._v("国籍:")
                                  ]),
                                  _vm._v(
                                    " " + _vm._s(item.nationalityname) + " "
                                  )
                                ])
                              ],
                              1
                            ),
                            _c(
                              "el-row",
                              [
                                _c("el-col", { attrs: { span: 8 } }, [
                                  item.occupationName
                                    ? _c("span", { staticClass: "col-title" }, [
                                        _vm._v("从事职业名称:")
                                      ])
                                    : _vm._e(),
                                  _vm._v(
                                    " " + _vm._s(item.occupationName) + " "
                                  )
                                ])
                              ],
                              1
                            )
                          ],
                          1
                        )
                      ]
                    })
                  ],
                  2
                )
              ],
              1
            ),
            _c("el-card", { staticClass: "box-card" }, [
              _vm.isLegar === "N"
                ? _c(
                    "div",
                    [
                      _c(
                        "div",
                        {
                          staticClass: "clearfix",
                          attrs: { slot: "header" },
                          slot: "header"
                        },
                        [_c("span", [_vm._v("受益人信息")])]
                      ),
                      _vm.orderBeneficiarys.length > 0
                        ? _c(
                            "el-main",
                            [
                              _vm._l(_vm.orderBeneficiarys, function(
                                item,
                                index
                              ) {
                                return [
                                  _c(
                                    "div",
                                    { key: index, staticClass: "baodan-item" },
                                    [
                                      _c(
                                        "el-col",
                                        {
                                          staticStyle: {
                                            "margin-bottom": "1.5%"
                                          },
                                          attrs: { span: 24 }
                                        },
                                        [
                                          _c(
                                            "span",
                                            { staticClass: "col-title" },
                                            [_vm._v("受益人顺序:")]
                                          ),
                                          _c("span", [
                                            _vm._v(_vm._s(item.bnfOrder))
                                          ])
                                        ]
                                      ),
                                      _c(
                                        "el-row",
                                        [
                                          _c("el-col", { attrs: { span: 8 } }, [
                                            _c(
                                              "span",
                                              { staticClass: "col-title" },
                                              [_vm._v("受益人:")]
                                            ),
                                            _vm._v(
                                              " " + _vm._s(item.name) + " "
                                            )
                                          ]),
                                          _c("el-col", { attrs: { span: 8 } }, [
                                            _c(
                                              "span",
                                              { staticClass: "col-title" },
                                              [_vm._v("与被保人的关系:")]
                                            ),
                                            _vm._v(
                                              " " +
                                                _vm._s(
                                                  item.insuredrelationname
                                                ) +
                                                " "
                                            )
                                          ]),
                                          _c("el-col", { attrs: { span: 8 } }, [
                                            _c(
                                              "span",
                                              { staticClass: "col-title" },
                                              [_vm._v("证件类型:")]
                                            ),
                                            _vm._v(
                                              " " +
                                                _vm._s(
                                                  item.certificateTypeName
                                                ) +
                                                " "
                                            )
                                          ])
                                        ],
                                        1
                                      ),
                                      _c(
                                        "el-row",
                                        [
                                          _c("el-col", { attrs: { span: 8 } }, [
                                            _c(
                                              "span",
                                              { staticClass: "col-title" },
                                              [_vm._v("证件号:")]
                                            ),
                                            _vm._v(
                                              " " +
                                                _vm._s(item.certificateNumber) +
                                                " "
                                            )
                                          ]),
                                          _c("el-col", { attrs: { span: 8 } }, [
                                            _c(
                                              "span",
                                              { staticClass: "col-title" },
                                              [_vm._v("证件有效期:")]
                                            ),
                                            _vm._v(
                                              " " +
                                                _vm._s(
                                                  item.certificateValidityStart
                                                ) +
                                                " 至 " +
                                                _vm._s(
                                                  item.certificatevalidityend
                                                ) +
                                                " "
                                            )
                                          ]),
                                          _c("el-col", { attrs: { span: 8 } }, [
                                            _c(
                                              "span",
                                              { staticClass: "col-title" },
                                              [_vm._v("出生日期:")]
                                            ),
                                            _vm._v(
                                              " " + _vm._s(item.birthday) + " "
                                            )
                                          ])
                                        ],
                                        1
                                      ),
                                      _c(
                                        "el-row",
                                        [
                                          _c("el-col", { attrs: { span: 8 } }, [
                                            _c(
                                              "span",
                                              { staticClass: "col-title" },
                                              [_vm._v("性别:")]
                                            ),
                                            _vm._v(
                                              " " + _vm._s(item.sexname) + " "
                                            )
                                          ]),
                                          _c("el-col", { attrs: { span: 8 } }, [
                                            _c(
                                              "span",
                                              { staticClass: "col-title" },
                                              [_vm._v("受益份额:")]
                                            ),
                                            _vm._v(
                                              " " + _vm._s(item.beneper) + " "
                                            )
                                          ])
                                        ],
                                        1
                                      )
                                    ],
                                    1
                                  )
                                ]
                              })
                            ],
                            2
                          )
                        : _vm._e()
                    ],
                    1
                  )
                : _vm._e(),
              _vm.isLegar === "Y" ? _c("div", [_vm._v("法定受益人")]) : _vm._e()
            ])
          ],
          1
        )
      ])
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/core-js/modules/es.array.map.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/es.array.map.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var $map = __webpack_require__(/*! ../internals/array-iteration */ "./node_modules/core-js/internals/array-iteration.js").map;
var arrayMethodHasSpeciesSupport = __webpack_require__(/*! ../internals/array-method-has-species-support */ "./node_modules/core-js/internals/array-method-has-species-support.js");

var HAS_SPECIES_SUPPORT = arrayMethodHasSpeciesSupport('map');

// `Array.prototype.map` method
// https://tc39.es/ecma262/#sec-array.prototype.map
// with adding support of @@species
$({ target: 'Array', proto: true, forced: !HAS_SPECIES_SUPPORT }, {
  map: function map(callbackfn /* , thisArg */) {
    return $map(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/Statistics.vue?vue&type=style&index=0&lang=less&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--10-oneOf-1-2!./node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/mga-manage/Statistics.vue?vue&type=style&index=0&lang=less& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".allcover {\n  position: absolute;\n  top: 0;\n  right: 0;\n}\n.ctt {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n}\n.tb {\n  position: absolute;\n  top: 50%;\n  transform: translateY(-50%);\n}\n.lr {\n  position: absolute;\n  left: 50%;\n  transform: translateX(-50%);\n}\n.el-form-item__label {\n  white-space: nowrap;\n}\n.el-select {\n  width: 100%;\n}\n.showTab {\n  position: relative;\n  margin-bottom: 10px;\n}\n.showTab .buttonGroup {\n  position: absolute;\n  right: 0;\n  top: 10px;\n}\n#container {\n  padding: 15px;\n}\n#container .queryHeading {\n  background-color: #f4f4f5;\n  color: #909399;\n  font-size: 14px;\n  padding: 10px 10px;\n  margin-bottom: 15px;\n}\n#container .pagination {\n  margin-top: 15px;\n  float: right;\n}\n#container .editinfo {\n  margin-bottom: 15px;\n}\n#container .dialog-content .list {\n  margin-bottom: 15px;\n}\n#container .dialog-title {\n  font-size: 20px;\n}\n#container .dialog-footer {\n  padding-top: 20px;\n  display: flex;\n  justify-content: flex-end;\n}\n#container .el-transfer-panel__list.is-filterable {\n  height: 300px;\n}\n#container .el-date-editor.el-input {\n  width: 180px !important;\n}\n#container .el-select {\n  width: 180px;\n}\n#container .self .el-input--prefix .el-input__inner {\n  width: 230px;\n}\n#container .self .el-date-editor.el-input {\n  width: 220px !important;\n}\n#container .detaiConfig-wrap .el-header {\n  height: 40px !important;\n  font-size: 20px;\n  line-height: 40px;\n  border-bottom: 1px solid #cdcdcd;\n}\n#container .box-card {\n  margin-bottom: 15px;\n}\n#container .el-row {\n  margin: 5px 0;\n}\n#container .col-title {\n  color: #999;\n  padding-right: 7px;\n}\n#container .baodan-item {\n  border: 1px dashed #cdcdcd;\n  border-radius: 10px;\n  width: 99%;\n  margin: 10px auto;\n  padding: 10px;\n}\n#container .el-main {\n  padding: 10px 20px 20px 20px;\n}\n#container .el-main .el-row {\n  margin-bottom: 15px;\n}\n.selfCon .el-form-item__content .el-select {\n  position: relative;\n  font-size: 14px;\n  display: inline-block;\n  width: 100% !important;\n}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/Statistics.vue?vue&type=style&index=0&lang=less&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--10-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--10-oneOf-1-2!./node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/mga-manage/Statistics.vue?vue&type=style&index=0&lang=less& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--10-oneOf-1-2!../../../node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../node_modules/vue-loader/lib??vue-loader-options!./Statistics.vue?vue&type=style&index=0&lang=less& */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/Statistics.vue?vue&type=style&index=0&lang=less&");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("d799138a", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/views/mga-manage/Statistics.vue":
/*!*********************************************!*\
  !*** ./src/views/mga-manage/Statistics.vue ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Statistics_vue_vue_type_template_id_c338de86___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Statistics.vue?vue&type=template&id=c338de86& */ "./src/views/mga-manage/Statistics.vue?vue&type=template&id=c338de86&");
/* harmony import */ var _Statistics_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Statistics.vue?vue&type=script&lang=js& */ "./src/views/mga-manage/Statistics.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _Statistics_vue_vue_type_style_index_0_lang_less___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Statistics.vue?vue&type=style&index=0&lang=less& */ "./src/views/mga-manage/Statistics.vue?vue&type=style&index=0&lang=less&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Statistics_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Statistics_vue_vue_type_template_id_c338de86___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Statistics_vue_vue_type_template_id_c338de86___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/mga-manage/Statistics.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/mga-manage/Statistics.vue?vue&type=script&lang=js&":
/*!**********************************************************************!*\
  !*** ./src/views/mga-manage/Statistics.vue?vue&type=script&lang=js& ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_12_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Statistics_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--12-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../node_modules/vue-loader/lib??vue-loader-options!./Statistics.vue?vue&type=script&lang=js& */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/Statistics.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_12_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Statistics_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/mga-manage/Statistics.vue?vue&type=style&index=0&lang=less&":
/*!*******************************************************************************!*\
  !*** ./src/views/mga-manage/Statistics.vue?vue&type=style&index=0&lang=less& ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Statistics_vue_vue_type_style_index_0_lang_less___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--10-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--10-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--10-oneOf-1-2!../../../node_modules/less-loader/dist/cjs.js??ref--10-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../node_modules/vue-loader/lib??vue-loader-options!./Statistics.vue?vue&type=style&index=0&lang=less& */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/Statistics.vue?vue&type=style&index=0&lang=less&");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Statistics_vue_vue_type_style_index_0_lang_less___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Statistics_vue_vue_type_style_index_0_lang_less___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Statistics_vue_vue_type_style_index_0_lang_less___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_10_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_10_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_10_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_10_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Statistics_vue_vue_type_style_index_0_lang_less___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/mga-manage/Statistics.vue?vue&type=template&id=c338de86&":
/*!****************************************************************************!*\
  !*** ./src/views/mga-manage/Statistics.vue?vue&type=template&id=c338de86& ***!
  \****************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Statistics_vue_vue_type_template_id_c338de86___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"b9734f90-vue-loader-template"}!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/cache-loader/dist/cjs.js??ref--0-0!../../../node_modules/vue-loader/lib??vue-loader-options!./Statistics.vue?vue&type=template&id=c338de86& */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"b9734f90-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/mga-manage/Statistics.vue?vue&type=template&id=c338de86&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Statistics_vue_vue_type_template_id_c338de86___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_b9734f90_vue_loader_template_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Statistics_vue_vue_type_template_id_c338de86___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=51.js.map